/**
 * @file lightsout.c
 * @author Zach Taylor (zstaylor)
 */
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <stdbool.h>

#include "common.h"

#ifndef UNSAFE
sem_t* boardSem;
#endif

bool move (GameState* board, int row, int col) {

    //ensure that the row and column given are valid
    if(row < 0 || row >= 5 || col < 0 || col >= 5) {
        return false;
    }

#ifndef UNSAFE
    sem_wait(boardSem);
#endif

    //set the lastboard to the current contents, enable an undo
    memcpy(board->previousBoard, board->currentBoard, sizeof(board->currentBoard));
    board->undoPossible = 1;

    //retrieve idx from row/col info
    int idx = row * BOARDSIZE + col;

    //process north cell, if possible
    if(idx - 5 >= 0) {

        if(board->currentBoard[idx-5] == '.') {
            board->currentBoard[idx-5] = '*';
        }
        else {
            board->currentBoard[idx-5] = '.';
        }
    }

    //south cell, if possible
    if(idx + 5 < 25) {

        if(board->currentBoard[idx+5] == '.') {
            board->currentBoard[idx+5] = '*';
        }
        else {
            board->currentBoard[idx+5] = '.';
        }
    }

    //west cell, if possible
    if(idx - 1 >= 0 && col - 1 >= 0) {

        if(board->currentBoard[idx-1] == '.') {
            board->currentBoard[idx-1] = '*';
        }
        else {
            board->currentBoard[idx-1] = '.';
        }
    }

    //east cell
    if(idx + 1 < 25 && col + 1 <= 4) {

        if(board->currentBoard[idx+1] == '.') {
            board->currentBoard[idx+1] = '*';
        }
        else {
            board->currentBoard[idx+1] = '.';
        }
    }

    //cell itself
    if(idx >= 0 && idx < 25) {

        if(board->currentBoard[idx] == '.') {
            board->currentBoard[idx] = '*';
        }
        else {
            board->currentBoard[idx] = '.';
        }
    }

#ifndef UNSAFE
    sem_post(boardSem);
#endif

    return true;
}

bool undo (GameState* board) {

#ifndef UNSAFE
    sem_wait(boardSem);
#endif

    //check if undo is possible
    if(board->undoPossible == 0) {
        return false;
    }

    //roll back current board with last board contents
    memcpy(board->currentBoard, board->previousBoard, sizeof(board->previousBoard));
    board->undoPossible = 0;

#ifndef UNSAFE
    sem_post(boardSem);
#endif

    return true;
}

void report (GameState* board) {

#ifndef UNSAFE
    sem_wait(boardSem);
#endif

    //loop with a second counter to determine when to indent
    for(int i = 0, counter = 0; i < (BOARDSIZE * BOARDSIZE); i++, counter++) {

        if (counter == BOARDSIZE) {
            printf("\n");
            counter = 0;
        }

        printf("%c", board->currentBoard[i]);
    }

    printf("\n");
#ifndef UNSAFE
    sem_post(boardSem);
#endif
}

/**
 * Program entry point
 * @param argc Argument Count
 * @param argv Arguments
 * @return Exit status
 */
int main(int argc, char* argv[]) {

    //check for invalid cli arguments
    if(argc < 2 || argc > 5) {
        printf( "error\n" );
        exit( 1 );
    }

    //get and attach shared memory segment
    key_t shmkey = ftok(SHMKeySeed, 1);
    int segment = shmget(shmkey, sizeof(struct gameState), 0666 | IPC_CREAT);
    if(segment < 0) {
        fprintf(stderr, "Failed to get to shared memory\n");
        exit(1);
    }

    GameState* board = (GameState*)shmat(segment, 0, 0);
    if(board == (GameState*)-1) {
        printf("Could not attach shared memory segment\n");
        exit(1);
    }

    //open named semaphore
#ifndef UNSAFE
    boardSem = sem_open(SEM_NAME, 0 );

    if(boardSem == SEM_FAILED) {
        fprintf(stderr, "Failed to get semaphore\n");
        exit(1);
    }
#endif

    //move cmd
    if(strcmp(argv[1], "move") == 0) {
        int row = atoi(argv[2]);
        int col = atoi(argv[3]);

        bool result = move(board, row, col);

        if(result) {
            printf("success\n");
        }
        else {
            printf("error\n");
            exit(1);
        }
    }
    else if (strcmp(argv[1], "test") == 0) {
        int rep = atoi(argv[2]);
        int row = atoi(argv[3]);
        int col = atoi(argv[4]);

        if(row >= 0 && row < 5 && col >= 0 && col < 5) {
            for(int i = 0; i < rep; i++) {
                move(board, row, col);
            }
        }
    }
    else if (strcmp(argv[1], "undo") == 0) {

        bool result = undo(board);

        if(result) {
            printf("success\n");
        }
        else {
            printf("error\n");
            exit(1);
        }

    }
    else if (strcmp(argv[1], "report") == 0) {

        report(board);
    }
    else {
        //print usage if bad commands
        printf("error\n");
        exit(1);
    }

    //detach shared memory
    shmdt(&segment);
#ifndef UNSAFE
    sem_close(boardSem);
#endif
    return 0;
}
