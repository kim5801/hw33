/**
 * Calculates the maximum sum of an arbitrary range of values in an array. Using
 * multiple worker threads, and properly synchronized. Input can arrive late/
 * after threads have started and will work through the input as quickly as
 * possible.
 * @file maxsum-sem.c
 * @author Zach Taylor (zstaylor)
 * @author CSC246 Teaching Staff
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//semaphores for synchronization
sem_t maxsumAccess;
sem_t getWorkAccess;
sem_t workAvailable;
bool allread = false;

//work idx and seed for thread id
int workIdx = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    //post to work available to show a new value is available to be worked on
    sem_post(&workAvailable);
  }

  //show that all of the values have been read
  allread = true;
  //notify if finished reading
  sem_post(&workAvailable);
}

/**
 * Getwork delegates the next index currently available to the caller
 * Synchronized
 * @return Next idx to perform work on
 * @author Zach Taylor (zstaylor)
 */
int getWork() {
    //wait for getwork
    sem_wait(&getWorkAccess);

    //wait for work to be available
    sem_wait(&workAvailable);

    //return sentinel if work finished
    if (allread == true && workIdx >= vCount) {
        sem_post(&workAvailable);
        sem_post(&getWorkAccess);
        return -1;
    }

    //get next return idx;
    int retIdx = workIdx;
    workIdx += 1;

    //allow next worker into getwork
    sem_post(&getWorkAccess);
    return retIdx;
}


/** Start routine for each worker.
 * @author Zach Taylor (zstaylor)
 */
void *workerRoutine( void *arg ) {

    //get id and localmax set up
    int localMax = INT_MIN;

    while(true) {

        //retrieve work
        int nextIdx = getWork();

        //deal with out of work case
        if(nextIdx == -1) {

            //update global max on exit
            sem_wait(&maxsumAccess);

            if(localMax > max_sum) {
                max_sum = localMax;
            }

            sem_post(&maxsumAccess);
            sem_post(&workAvailable);

            //report if necessary
            if(report) {
                printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), localMax);
            }

            return NULL;
        }

        //do work
        int localsum = 0;
        for(int i = nextIdx; i >= 0; i--) {

            localsum += vList[i];

            if(localsum > localMax) {
                localMax = localsum;
            }
        }
    }

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //initialize semaphores
  sem_init(&maxsumAccess, 0, 1);
  sem_init(&getWorkAccess, 0, 1);
  sem_init(&workAvailable, 0, 0);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(worker + i, 0, workerRoutine, 0);

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
