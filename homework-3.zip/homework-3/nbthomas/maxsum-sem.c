/** 
  @file maxsum-sem.c
  @author Noah Thomas (nbthomas)
  maxsum-sem computes the largest continguous sum froma set of provided values using threads in parallel. Additionally, it dynamically allocates
  work to the threads based on a availablilty as input is collected to better handle large/slow i/o collection.
  Each thread is also available to report the max they found if the desired by the user.
  */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

int workers; //numer of workers

bool finished = false; //determines if readList has been completed and used as signal for getting work

sem_t idxFinders; //semaphore for work delegation
sem_t maxUpdater; //semaphore to update global max

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;
int currentIndex = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {

  sem_wait(&idxFinders); //only one thread is able to get a work assignment at a time
  int current = currentIndex; //copies currentIndex counter into a local thread variable it can reference without worry of modification
  int localThrdMax = vList[current]; //largest value found by a thread through all of the indexes its assigned
  currentIndex++; //incremented index for next thread to use
  sem_post(&idxFinders); //release lock to allow another thread

  while(!finished || current < vCount) { //continues if readList is still being populated or the index assigned is less than vCount
    if(current >= vCount) { //if readList hasn't finished but current >= vCount, uses some waiting
      continue;
    }

    int localMax = vList[current]; //largest sum found for the current index the thread is iterating through

      
    int currentSum = vList[current]; //current sum tracked

    for(int i = current - 1; i >= 0; i--) {//tracks sum from current index to the beginning of the values provided, avoids issue of missing some values based on how far readList has gotten
      currentSum += vList[i]; //increments sum
      if(currentSum > localMax) { //check if new sum is larger than the local max
        localMax = currentSum;

        if(localMax > localThrdMax) { //if the local max was updated then see if its now larger than the local thread max
          localThrdMax = localMax;
        }
      }
    }

    sem_wait(&idxFinders); //one thread is looking for new work
    current = currentIndex; //copies up to date current index
    currentIndex++; //updates counter for next thread
    sem_post(&idxFinders); //releases thread
  }

  if(report) {
    printf("I'm thread %lu. The maximum sum I found is %d.\n",pthread_self(), localThrdMax); //reprot sumps
  }

  sem_wait(&maxUpdater); //only one thread should update max_sum at a time
  if(localThrdMax > max_sum) { //if local thread max is larger than the max_sum
    max_sum = localThrdMax; //updates max_sum
  }
  sem_post(&maxUpdater); //release lock

  return NULL;
}

int main( int argc, char *argv[] ) {

  workers = atoi(argv[1]);
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //initializing semaphores
  sem_init(&idxFinders, 0, 1);
  sem_init(&maxUpdater, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, NULL);

  // Then, start getting work for them to do.
  readList();

  finished = true; //confirms that readList() has completed and used to indicate when work should stop being assigned

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) 
    pthread_join(worker[i], NULL);
  

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
