/** 
  @file reset.c
  @author Noah Thomas (nbthomas)
  Reset creates the shared memory GameState and initializes with the contents of a provided file. This GameState
  is then referenced by lightsout.c to perform various game functions and maintain its environment.
  */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

sem_t *mySemaphore; //semaphore to assist lightsout commands

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/** 
  Performs initial error checking with file provided, generates the shared memory, and populate GameState
  with file contents.
  @param argc number of arguments
  @param argv collection of arguments
  */
int main( int argc, char *argv[] ) {
  if(argc != 2) { //checks that only two arguments are given on command line
    usage();
  }

  int inp = open(argv[1], O_RDONLY); //opens board file
  if(inp < 1) { //informs if unable to open board file
    fprintf(stderr, "Invalid input file: %s", argv[1]);
    fail("");    
  }

  key_t idKey = ftok("/afs/unity.ncsu.edu/users/n/nbthomas", 1); //creates key for shared memory

  int shmid = shmget(idKey, sizeof(GameState), 0666 | IPC_CREAT); //requests shared memory

  if(shmid < 0) { //checks for issues in getting memory
    perror("problem getting shared memory: ");
  }

  sem_unlink(SEMAPHORE_NAME); //unlinks for a new semaphore creation

  mySemaphore = sem_open(SEMAPHORE_NAME, O_CREAT, 0666, 1); //creates semaphore for the first time
  if(mySemaphore == SEM_FAILED) { //error check
    printf("we have a problem\n");
  }

  GameState *state = (GameState *)shmat(shmid, 0, 0); //attaches shared memory

  if(state == (GameState *)-1) { //checks for errors in attaching memory
    perror("problem adding shared memory: ");
  }

  state->cantUndo = true; //should not be able to undo board when it has just been created

  for(int c = 0; c < GRID_SIZE; c++) {
    read(inp, state->board_state[c], sizeof(char) * LINE_SIZE); //filling the current board with the file contents
    for(int b = 0; b < GRID_SIZE; b++) { //checks if the file given has any invalid characters
      if(state->board_state[c][b] != '\n' && state->board_state[c][b] != '*' && state->board_state[c][b] != '.') { //checks for valid elements
        fprintf(stderr, "Invalid input file: %s", argv[1]);
        fail(""); 
      }
    }
  }

  sem_close(mySemaphore); //closing semaphore for use in lightsout

  shmdt(state); //detatches from shared memory

  return SUCCESSFUL_EXIT;
}
