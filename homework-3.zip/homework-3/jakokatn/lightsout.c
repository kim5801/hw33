#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <ctype.h> 
#include <semaphore.h>

// Named semaphore for mutual exclusion
sem_t *sem;

// Acquire sem
static void acquireSem() {
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
}

// Release sem
static void releaseSem() {
  #ifndef UNSAFE
    sem_post( sem );
  #endif
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int r, int c ) {
  acquireSem();

  // check validity
  if ( r > 4 || c > 4 || r < 0 || c < 0 ) {
    releaseSem();
    fail( "error" );
  }

  // flip lights
  state->state[ r ][ c ] = !state->state[ r ][ c ];
  if ( r - 1 >= 0 ) {
    state->state[ r - 1 ][ c ] = !state->state[ r - 1 ][ c ];
  }
  if ( r + 1 <= 4 ) {
    state->state[ r + 1 ][ c ] = !state->state[ r + 1 ][ c ];
  }
  if ( c - 1 >= 0 ) {
    state->state[ r ][ c - 1 ] = !state->state[ r ][ c - 1 ];
  }
  if ( c + 1 <= 4 ) {
    state->state[ r ][ c + 1 ] = !state->state[ r ][ c + 1 ];
  }

  // store position for undo command
  state->prevX = r;
  state->prevY = c; 

  releaseSem();
  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ) {
  acquireSem();

  // undo command (only if history exists)
  int r = state->prevX;
  int c = state->prevY;

  if ( r == -1 || c == -1 ) {
    releaseSem();
    fail( "error" );
  }
  
  // flip lights
  state->state[ r ][ c ] = !state->state[ r ][ c ];
  if ( r - 1 >= 0 ) {
    state->state[ r - 1 ][ c ] = !state->state[ r - 1 ][ c ];
  }
  if ( r + 1 <= 4 ) {
    state->state[ r + 1 ][ c ] = !state->state[ r + 1 ][ c ];
  }
  if ( c - 1 >= 0 ) {
    state->state[ r ][ c - 1 ] = !state->state[ r ][ c - 1 ];
  }
  if ( c + 1 <= 4 ) {
    state->state[ r ][ c + 1 ] = !state->state[ r ][ c + 1 ];
  }

  // clear position history
  state->prevX = -1;
  state->prevY = -1;

  releaseSem();
  return true;
}

// Print the current state of the board.
void report( GameState *state ) {
  acquireSem();
  char statusString[ 31 ];
    
  // get status string
  int i = 0;
  for ( int j = 0; j < 5; j++ ) {
    for ( int k = 0; k < 5; k++ ) {
      if ( state->state[ j ][ k ] == true ) {
        statusString[ i ] = '*';
      } else {
        statusString[ i ] = '.';
      }
      i++;
    }
    statusString[ i ] = '\n';
    i++;
  }

  statusString[ i ] = '\0';

  printf( "%s\n", statusString ); 
  releaseSem();
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

int main( int argc, char *argv[] ) {

  // check cl arg count
  if ( argc >= 6 || argc <= 1 ) {
    fail( "error" );
  }

  // Get shared memory slot
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/j/jakokatn", 0 ), sizeof( GameState ), 0 );

  // Add shared memory and cast to GameState pointer
  GameState *gameState = (GameState *)shmat(shmid, 0, 0);

  // Get named semaphore
  sem = sem_open ( "/jakokatn-lightsout-lock", 0 );

  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    // check number validity
    if ( strlen( argv[ 2 ] ) > 1 || strlen( argv[ 3 ] ) > 1 || !isdigit( argv[ 2 ][ 0 ] ) || !isdigit( argv[ 3 ][ 0 ] ) ) {
      fail( "error" );
    }

    // parse row and column numbers
    int r = atoi( argv[ 2 ] );
    int c = atoi( argv[ 3 ] );

    // call move function
    bool ret = move( gameState, r, c );

    if ( ret == true ) {
      printf( "success\n" );
    }
  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    // call undo function
    bool ret = undo( gameState );

    if ( ret == true ) {
      printf( "success\n" );
    }
  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // call report function
    report( gameState );  
  } else if ( strcmp( argv[ 1 ], "test" ) == 0 ) {
    // parse row and column numbers
    int n = 0;
    int r = 0;
    int c = 0;
    int ret1 = sscanf( argv[2], "%d", &n );
    int ret2 = sscanf( argv[3], "%d", &r );
    int ret3 = sscanf( argv[4], "%d", &c );
    
    if ( ret1 != 1 || ret2 != 1 || ret3 != 1 ) {
      fail( "error" );
    }

    // call test function
    test( gameState, n, r, c );
  } else {
    fail( "error" );
  }

  return 0;
}
