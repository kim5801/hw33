// Height and width of the playing area.
#define GRID_SIZE 5

// Struct to store game state
struct GameStateStruct {
  bool state[ GRID_SIZE ][ GRID_SIZE ];
  int prevX;
  int prevY;
};

// Typedef for GameState
typedef struct GameStateStruct GameState;