#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // Check command line args
  if ( argc != 2 ) {
    usage();
  }

  // Open file
  FILE * fp = fopen( argv[ 1 ], "r" );
  if ( fp == NULL ) {
    printf( "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  // Get shared memory slot
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/j/jakokatn", 0 ), sizeof( GameState ), 0666 | IPC_CREAT );

  // Add shared memory and cast to GameState pointer
  GameState *gameState = (GameState *)shmat(shmid, 0, 0);
  gameState->prevX = -1;
  gameState->prevY = -1;

  // Create named semaphore
  sem_t *sem = sem_open( "/jakokatn-lightsout-lock", O_CREAT, 0600, 1 );

  // Read file contents into memory (acquire sem just in case)
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  
  int i = 0;
  int j = 0;
  char c;
  while ( (c = fgetc( fp )) != EOF ) {
    if ( c == '\n' ) {
      j = 0;
      i++;
    } else if ( c == '.' ) {
      gameState->state[ i ][ j ] = false;
      j++;
    } else if ( c == '*' ) {
      gameState->state[ i ][ j ] = true;
      j++;
    } else {
      printf( "Invalid input file: %s\n", argv[ 1 ] );
      exit( 1 );
    }
  }

  // release sem
  #ifndef UNSAFE
    sem_post( sem );
  #endif

  return 0;
}
