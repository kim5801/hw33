#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>

#include "common.h"

// Print out an error message and exit.
static void fail(char const* message) {
	fprintf(stderr, "%s\n", message);
	exit(1);
}

// Print out a usage message and exit.
static void usage() {
	fprintf(stderr, "usage: reset <board-file>\n");
	exit(1);
}

int main(int argc, char* argv[]) {
	// Validate arguments
	if (argc != 2) usage();
	int boardfp = open(argv[1], O_RDONLY);
	if (boardfp == -1) {
		fprintf(stderr, "Invalid input file: %s\n", argv[1]);
		return 1;
	}

	// Open the named semaphore
	sem_t* sem_rst = sem_open(SEM_NAME, O_CREAT, 0666, 1);
	if (sem_rst == SEM_FAILED) fail_errno("Couldn't open semaphore!");

	// Populate GameState shmem while locking the semaphore
	sem_wait(sem_rst);
	GameState gs = getGameState();
	char c = 0;
	for (int i = 0; i < GRID_SIZE; i++)
		for (int j = 0; j < ROW_SIZE; j++) {
			switch (read(boardfp, &c, 1) * c) {
			case 0: // Unexpected EOF
				fprintf(stderr, "Unexpected EOF! (forgot trailing newline?)");
			case '*':
			case '.':
			case '\n':
				// Break if expected char
				if (c && (c == '\n') == (j == ROW_SIZE - 1)) break;
			default: // Unexpected char
				fprintf(stderr, "Invalid input file: ");
				close(boardfp);
				shmdt(gs);
				fail(argv[1]);
			}
			gs->spaces[i * ROW_SIZE + j] = c;
		}
	gs->spaces[GRID_SIZE * ROW_SIZE] = 0;
	gs->undo = -1;
	sem_post(sem_rst);

	// Quit program
	sem_close(sem_rst);
	close(boardfp);
	shmdt(gs);
	return 0;
}
