#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>

#include "common.h"

// If COND evaluates true on argc and the ARGVth argument matches CMD, return the return value of ACT
// The calling parentheses of ACT are written outside of the macro
#define cmdeval(COND, ARGV, CMD, ACT) if (argc COND && strcmp(argv[ARGV], CMD) == 0) return ACT

// Macro for toggling a space on a board
#define tglbrd(IDX) gs->spaces[IDX] = gs->spaces[IDX] == '.' ? '*' : '.'

// Error conditions
enum { ERR_SUCCESS, ERR_COMMAND, ERR_FORMAT };

// Named semaphore
sem_t* sem_lout;

// Validate move arguments
int doMove(GameState gs, char* rstr, char* cstr) {
	int idx, r, c;

	// Setup
	if (rstr != NULL && cstr != NULL) { // Normal mode
		// Validate arguments
		if (sscanf(rstr, "%d", &r) != 1 || sscanf(cstr, "%d", &c) != 1 ||
			r < 0 || GRID_SIZE <= r || c < 0 || GRID_SIZE <= c)
			return ERR_FORMAT;
		// Get move parameters
#ifndef UNSAFE
		sem_wait(sem_lout);
#endif // !UNSAFE

		gs->undo = idx = r * ROW_SIZE + c;
	} else { // Undo mode
		// Get move parameters
#ifndef UNSAFE
		sem_wait(sem_lout);
#endif // !UNSAFE

		idx = gs->undo;
		r = idx / ROW_SIZE;
		c = idx % ROW_SIZE;
		gs->undo = -1;
	}

	// Perform move
	tglbrd(idx);
	if (c > 0) tglbrd(idx - 1);
	if (r > 0) tglbrd(idx - ROW_SIZE);
	if (c < GRID_SIZE - 1) tglbrd(idx + 1);
	if (r < GRID_SIZE - 1) tglbrd(idx + ROW_SIZE);

	// Return
#ifndef UNSAFE
	sem_post(sem_lout);
#endif // !UNSAFE

	return ERR_SUCCESS;
}

// Report board state
int doReport(GameState gs) {
#ifndef UNSAFE
	sem_wait(sem_lout);
#endif // !UNSAFE

	printf(gs->spaces);

#ifndef UNSAFE
	sem_post(sem_lout);
#endif // !UNSAFE

	return ERR_SUCCESS;
}

int doTest(GameState gs, char* nstr, char* rstr, char* cstr) {
	int n;

	// Validate argument
	if (sscanf(nstr, "%d", &n) != 1 || n < 0)
		return ERR_FORMAT;

	// Perform move testing
	for (int ret_val = 0; n; n--) {
		ret_val = doMove(gs, rstr, cstr);
		if (ret_val) return ret_val;
	}

	return ERR_SUCCESS;
}

int parseCommands(GameState gs, int argc, char* argv[]) {
	// Try to match each command
	// cmdeval(argc condition, which argv, compare to string, which function to call)
	cmdeval(== 4, 1, "move", doMove)(gs, argv[2], argv[3]);
	cmdeval(== 2, 1, "report", doReport)(gs);
	cmdeval(== 5, 1, "test", doTest)(gs, argv[2], argv[3], argv[4]);
	cmdeval(== 2, 1, "undo", doMove)(gs, NULL, NULL); // Sentinel values for undo

	// No command matched
	return ERR_COMMAND;
}

int main(int argc, char* argv[]) {
	// Open named semaphore
	sem_lout = sem_open(SEM_NAME, 0);
	if (sem_lout == SEM_FAILED) fail_errno("Couldn't open semaphore!");

	// Get the gamestate
#ifndef UNSAFE
	sem_wait(sem_lout);
#endif // !UNSAFE

	GameState gs = getGameState();

#ifndef UNSAFE
	sem_post(sem_lout);
#endif // !UNSAFE

	// Parse commands
	int ret_val = parseCommands(gs, argc, argv);

	// Close resources
	sem_close(sem_lout);
	shmdt(gs);

	// Process return value
	switch (ret_val) {
	case ERR_COMMAND:
		fprintf(stderr, "usage: lightsout [report|undo]\n       lightsout move [r] [c]\n       lightsout test [n] [r] [c]");
		return ERR_COMMAND;
	case ERR_FORMAT:
		fprintf(stderr, "error");
		return ERR_FORMAT;
	default:
		return ERR_SUCCESS;
	}

	return 0;
}
