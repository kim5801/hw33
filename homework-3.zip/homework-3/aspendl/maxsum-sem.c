#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const* message) {
	fprintf(stderr, "%s\n", message);
	exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage() {
	printf("usage: maxsum-sem <workers>\n");
	printf("       maxsum-sem <workers> report\n");
	exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Increments each time a thread gets it's next job
int end_idx = 0;

// Synchronization semaphores
sem_t read_jobdetail, record_maxsum, release_job;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
	// Keep reading as many values as we can.
	int v;
	while (scanf("%d", &v) == 1) {
		// Make sure we have enough room, then store the latest input.
		if (vCount > MAX_VALUES)
			fail("Too many input values");

		// Store the latest value.
		vList[vCount++] = v;
		// Let the next thread start
		sem_post(&release_job);
	}
	sem_post(&release_job);
}

/** Start routine for each worker. */
void* workerRoutine(void* arg) {
	// Get this thread's ID
	pthread_t self = pthread_self();
	int max;
	bool ran = false;

	// Keep running until exit condition
	while (true) {
		// Get the next job index
		sem_wait(&release_job);
		sem_wait(&read_jobdetail);
		int job_idx = end_idx++;
		sem_post(&read_jobdetail);

		// Exit condition
		if (job_idx >= vCount) break;

		// Find the greatest sum that ends at job_idx
		max = vList[job_idx];
		for (int sum = max, i = job_idx - 1; i >= 0; i--) {
			sum += vList[i];
			if (max < sum) max = sum;
		}

		// Record findings
		sem_wait(&record_maxsum);
		if (max_sum < max)
			max_sum = max;
		sem_post(&record_maxsum);

		// Flag indicating at least one iteration occurred
		ran = true;
	}

	// Release remaining threads
	sem_post(&release_job);

	// Report findings
	if (report) {
		// The work is assigned on a first-come-first-serve basis (i.e. up to the scheduler),
		//   thus there's a chance that a thread may never get to process the input,
		//   especially if the input set is small
		if (ran) printf("I'm thread %d. The maximum sum I found is %d.\n", (int)self, max);
		else printf("I'm thread %d. I didn't get to go at all :(\n", (int)self);
	}

	return NULL;
}

int main(int argc, char* argv[]) {
	int workers = 4;

	// Parse command-line arguments.
	if (argc < 2 || argc > 3)
		usage();

	if (sscanf(argv[1], "%d", &workers) != 1 ||
		workers < 1)
		usage();

	// If there's a second argument, it better be "report"
	if (argc == 3) {
		if (strcmp(argv[2], "report") != 0)
			usage();
		report = true;
	}

	// Jobs can get their job index
	sem_init(&read_jobdetail, false, 1);
	// Jobs can report their finding
	sem_init(&record_maxsum, false, 1);
	// Jobs cannot start by default
	sem_init(&release_job, false, 0);

	// Make each of the workers.
	pthread_t worker[workers];
	for (int i = 0; i < workers; i++)
		pthread_create(worker + i, NULL, workerRoutine, NULL);

	// Then, start getting work for them to do.
	readList();

	// Wait until all the workers finish.
	for (int i = 0; i < workers; i++)
		pthread_join(worker[i], NULL);

	// Report the max product and release the semaphores.
	printf("Maximum Sum: %d\n", max_sum);

	return EXIT_SUCCESS;
}
