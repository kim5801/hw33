#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Semaphore for test function
sem_t s;

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int r, int c ) {
  #ifndef UNSAFE
    sem_wait(&s);
  #endif
   if (state->board[(r * GRID_SIZE) + c] == '*') {
      state->board[(r * GRID_SIZE) + c] = '.';
    } else if (state->board[(r * GRID_SIZE) + c] == '.') {
      state->board[(r * GRID_SIZE) + c] = '*';
    }
    state->recentMove[0] = r;
    state->recentMove[1] = c;
    #ifndef UNSAFE
      sem_post(&s);
    #endif
    return true;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ) {
  if (state->recentMove[0] == -1 || state->recentMove[1] == -1) {
      return false;
    }
    int r = state->recentMove[0];
    int c = state->recentMove[1];
    state->board[(r * GRID_SIZE) + c] = '.';
    state->recentMove[0] = -1;
    state->recentMove[1] = -1;
    return true;
}

// Print the current state of the board.
void report( GameState *state ) {
  for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
        printf("%c", state->board[(i * GRID_SIZE) + j]);
      }
      printf("/n");
    }
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}


int main( int argc, char *argv[] ) {
  char *cmd = argv[1];
  if (strcmp(cmd, "move") != 0 && strcmp(cmd, "undo") != 0 && strcmp(cmd, "report") != 0 && strcmp(cmd, "test") != 0) {
    fail("Invalid command");
  }
  
  key_t key = ftok("/afs/unity.ncsu.edu/users/j/jnbenton", 28);
  int shmid = shmget(key, 0, 0);
  GameState *gameBuffer = (GameState *)shmat(shmid, 0, 0);
  sem_init(&s, 0, 1);

  if (strcmp(cmd, "move") == 0) {
    if (argc != 4) {
      printf("error\n");
      fail("Invalid move command");
    }
    if (atoi(argv[2]) < 0 || atoi(argv[2]) > 4 || atoi(argv[3]) < 0 || atoi(argv[3]) > 4) {
      printf("error\n");
      fail("Invalid move command - not in bounds");
    }
    int r = atoi(argv[2]);
    int c = atoi(argv[3]);
    if (!move(gameBuffer, r, c)) {
      printf("error\n");
      fail("invalid move");
    }
   
  }

  if (strcmp(cmd, "undo") == 0) {
    if (argc != 2) {
      printf("error\n");
      fail("Invalid undo command");
    }
    if (!undo(gameBuffer)) {
      printf("error\n");
      fail("invalid undo");
    }
    
  }

  if (strcmp(cmd, "report") == 0) {
    if (argc != 2) {
      printf("error\n");
      fail("Invalid report command");
    }
    report(gameBuffer);
    
  }

  if (strcmp(cmd, "test") == 0) {
    int n = atoi(argv[2]);
    int r = atoi(argv[3]);
    int c = atoi(argv[4]);
    if (!test(gameBuffer, n, r, c)) {
      printf("error\n");
      fail("invalid test");
    }
  }
  printf("success");

  return 0;
}
