/**
    @file maxsum-sem.c
    @author Caleb Rollins (ccrollin)
    This is the same max sum program that we created in homework
    assignments 1 and 2 except in this case we start work on the segment
    summations for each thread before all the list is completely filled in
    the buffer such that we do not have to wait for large files.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// True if we're supposed to report what we find.
bool report = false;

// True if the list is done being filled in from readList()
bool listCompleted = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// Current position in the list we are processing
int parsePos = 0;

// The number of workers/threads being used
int workers = 4;

// An anonymous POSIX semaphore to provide for mutual exclusion between the multiple thread calls to getWork()
// function because they are manipulating the same global variables
sem_t w;

// An anonymous POSIX semaphore to provide for proper turn taking between the readList() and getWork() functions
// This semaphore mainly ensures that getWork() blocks if the list data structure is empty. Each time we read an
// item into the list we release on 'z' to allow getWork() to run for each character read in.
sem_t z;

// An anonymous POSIX semaphore to provide for mutual exclusion between threads when comparing their thread sum
// with the overall global maximum sum which without this semaphore could cause race conditions when comparing
sem_t y;

// Print out an error message and exit.
static void fail( char const *message )
{
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage()
{
    printf( "usage: maxsum-sem <workers>\n" );
    printf( "       maxsum-sem <workers> report\n" );
    exit( 1 );
}

// Read the list of values.
void readList()
{
    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Make sure we have enough room, then store the latest input.
        if ( vCount > MAX_VALUES )
            fail( "Too many input values" );

        // Store the latest value.
        vList[vCount++] = v;
        // Let workers know that work is available
        sem_post( &z );
    }
    // Let workers run again to get sentinel values
    listCompleted = true;
    sem_post( &z );
}

// This is a function that will delegate the index of a sequence to assign
// to a thread that is ready for more work. If the list is empty or all work
// has been assigned to other threads this will block accordingly.
static int getWork()
{
    int returnVal;
    sem_wait( &z );
    sem_wait( &w );
    if ( listCompleted && vCount == parsePos ) {
        returnVal = -1;
    }
    else {
        returnVal = parsePos++;
    }
    sem_post( &w );
    return returnVal;
}

// This function will iterate through the vList with the goal of calculating the maximum sum in this segment
static int runSummationSegment( int sIdx )
{
    int segmentMax = 0;
    int runningSum = 0;
    for ( int j = sIdx; j >= 0; j-- ) {
        runningSum += *( vList + j );
        if ( runningSum > segmentMax ) {
            segmentMax = runningSum;
        }
    }
    return segmentMax;
}

// This function is the start routine for each worker
void *workerRoutine( void *arg )
{
    // Store the highest sequence sum the thread inspects
    int mySum = 0;

    // Workers are dispatched
    while ( true ) {
        // get the index that this worker should examine for a segment
        int workIdx = getWork();
        // if we get sentinel values let workers that are waiting finish and then break out of this loop
        if ( workIdx < 0 ) {
            sem_post( &z );
            break;
        }
        // run a summation for a segment ending at the workIdx passed
        int segmentMaxSum = runSummationSegment( workIdx );
        // compare if the segment sum is greater than the thread sum then set the new thread sum
        if ( segmentMaxSum > mySum ) {
            mySum = segmentMaxSum;
        }
    }

    // If the user wants to report the local child max then we can do that here
    if ( report ) {
        printf( "I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), mySum );
    }

    // compare the thread max sum with the global max sum and set the global max if a new max is found
    // also here we provide mutual exclusion code to make sure that other threads are not manipulating the
    // global max sum
    sem_wait( &y );
    if ( mySum > max_sum ) {
        max_sum = mySum;
    }
    sem_post( &y );
    return NULL;
}

// Create the workers and wait for all of them to return their local max sum to then find/report the global max
int main( int argc, char *argv[] )
{
    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();

    if ( sscanf( argv[1], "%d", &workers ) != 1 || workers < 1 )
        usage();

    // If there's a second argument, it better be "report"
    if ( argc == 3 ) {
        if ( strcmp( argv[2], "report" ) != 0 )
            usage();
        report = true;
    }

    // here we create all of our semaphores that we will be using to provide synchronization
    // we also initialize then to their various starting values
    // all are anonymous semaphores with w and y having 1 free pass
    int wInit = sem_init( &w, 0, 1 );
    int yInit = sem_init( &y, 0, 1 );
    int zInit = sem_init( &z, 0, 0 );
    if ( wInit == -1 || yInit == -1 || zInit == -1 ) {
        fail( "There was a problem initializing a semaphore." );
    }

    // Make each of the workers.
    pthread_t worker[workers];
    for ( int i = 0; i < workers; i++ ) {
        int threadCreateResult = pthread_create( &( worker[i] ), NULL, workerRoutine, NULL );
        if ( threadCreateResult == -1 ) {
            fail( "There was a problem creating a thread." );
        }
    }

    // Then, start getting work for them to do.
    readList();

    // Wait for all workers to finish before doing anything
    // Record the overall/global max when inspecting all workers
    for ( int i = 0; i < workers; i++ ) {
        int threadJoinResult = pthread_join( worker[i], NULL );
        if ( threadJoinResult == -1 ) {
            fail( "There was a problem joining with a thread." );
        }
    }

    // Report the max sum and destroy the semaphores.
    printf( "Maximum Sum: %d\n", max_sum );

    int wDest = sem_destroy( &w );
    int yDest = sem_destroy( &y );
    int zDest = sem_destroy( &z );
    if ( wDest == -1 || yDest == -1 || zDest == -1 ) {
        fail( "There was a problem destroying a semaphore." );
    }

    return EXIT_SUCCESS;
}
