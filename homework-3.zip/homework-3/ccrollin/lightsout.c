/**
    @file lightsout.c
    @author Caleb Rollins (ccrollin)
    This is the lightsout.c program for the Lights Out board game that will respond
    to user commands and issue them appropriately by changing the fields within the
    shared reference to the GameState struct.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// A pointer to a semaphore to prevent race condition of editing GameState struct
sem_t *semLock;

// Print out an error message and exit.
static void fail( char const *message )
{
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// This is a helper method that makes a new move on the game board using the row and column passed
// The move function is also called when the user wants to undo the last move
// We return true on a successful move operation, otherwise we return false on an unsuccessful move operation
static bool move( GameState *state, int r, int c )
{
    #ifndef UNSAFE
        sem_wait( semLock );
    #endif
    // Ensure that the row and column sent by client are valid for the grid size
    if ( r >= 0 && r < GRID_SIZE && c >= 0 && c < GRID_SIZE ) {
        // If so just negate the current status of the cell at row and column
        state->boardStatus[r][c] = !( state->boardStatus[r][c] );
    }
    else {
        // Otherwise let the client know that they did not provide proper row and column
        #ifndef UNSAFE
            sem_post( semLock );
        #endif
        return false;
    }

    // Set the top cell above the cell at row and column while accounting for edge case
    if ( r != 0 ) {
        state->boardStatus[r - 1][c] = !( state->boardStatus[r - 1][c] );
    }
    // Set the bottom cell below the cell at row and column while accounting for edge case
    if ( r != GRID_SIZE - 1 ) {
        state->boardStatus[r + 1][c] = !( state->boardStatus[r + 1][c] );
    }
    // Set the cell to the left of the cell at row and column while accounting for edge case
    if ( c != 0 ) {
        state->boardStatus[r][c - 1] = !( state->boardStatus[r][c - 1] );
    }
    // Set the cell to the right of the cell at row and column while accounting for edge case
    if ( c != GRID_SIZE - 1 ) {
        state->boardStatus[r][c + 1] = !( state->boardStatus[r][c + 1] );
    }

    // Store the most recent cell that makeMove worked on so that it can be potentially undone
    state->mostRecentMoveR = r;
    state->mostRecentMoveC = c;
    state->undoCompleted = false;

    #ifndef UNSAFE
        sem_post( semLock );
    #endif
    return true;
}

// This is a helper method the delegates to move to undo the last move on the game board
// A player can only undo the most recent play, so we also ensure that they cannot undo multiple times
// We return true on a successful move operation, otherwise we return false on an unsuccessful move operation
static bool undo( GameState *state )
{
    #ifndef UNSAFE
        sem_wait( semLock );
    #endif
    if ( state->undoCompleted ) {
        #ifndef UNSAFE
            sem_post( semLock );
        #endif
        return false;
    }
    else {
        #ifndef UNSAFE
            sem_post( semLock );
        #endif
        move( state, state->mostRecentMoveR, state->mostRecentMoveC );
        // Set the value of undoCompleted in the state struct now that we have done an undo call
        #ifndef UNSAFE
            sem_wait( semLock );
        #endif
        state->undoCompleted = true;
        #ifndef UNSAFE
            sem_post( semLock );
        #endif
        return true;
    }
}

// This is a helper method that goes through our the game grid/board stored in the state struct
// and prints out a character representation of the board that includes newline characters
static void report( GameState *state )
{
    #ifndef UNSAFE
        sem_wait( semLock );
    #endif
    int i = 0;
    for ( int r = 0; r < GRID_SIZE; r++ ) {
        for ( int c = 0; c < GRID_SIZE; c++ ) {
            if ( state->boardStatus[r][c] ) {
                putchar( '*' );
            }
            else {
                putchar( '.' );
            }
            i++;
        }
        putchar( '\n' );
        i++;
    }
    #ifndef UNSAFE
        sem_post( semLock );
    #endif
}

// This is a helper method that calls the move() function for N number of times
// N is one of the parameters that the caller specifies to this function. The reason
// this function exists is to test a race condition of editing the same GameState struct
// between multiple executions of lightout.c
static bool test( GameState *state, int n, int r, int c )
{
    // Make sure the row / column is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );
    return true;
}

// This is the home of all code in this program
// Here we read command line arguments that dictate how we play and then appropriately respond
int main( int argc, char *argv[] )
{
    // We need to have at least one command line argument to tell it what to do
    if ( argc < 2 ) {
        printf( "error\n" );
        exit( 1 );
    }

    // Here we open the already created POSIX named semaphore for aquire() and release() calls
    semLock = sem_open( SEM_LIGHTSOUT, O_RDONLY );
    if ( semLock == SEM_FAILED ) {
        fail( "Issue opening the POSIX named semaphore" );
    }

    // Here we are accessing the already created shared memory, stating the size of a GameState struct for this
    // shared memory sector. Note: the  ftok() call ensures that the id of the shared memory is unique to myself
    // by using my home directory path in AFS
    int shmID = shmget( ftok( "/afs/unity.ncsu.edu/users/c/ccrollin", 0 ), sizeof( GameState ), 0 );
    // Handle the case where we have an issue accessing shared memory
    if ( shmID == -1 ) {
        fail( "Can't access shared memory" );
    }

    // Now we can attach to the shared memory segment and get a reference (pointer) back
    // that we can now use as we see fit later on in the program
    char *sharedBuff = ( char * ) shmat( shmID, NULL, 0 );
    // Handle the case where we have an issue mapping the shared memory segment into address space
    if ( sharedBuff == ( char * ) -1 ) {
        fail( "Can't map shared memory segment into address space" );
    }

    // At first, we have access to only this shared buffer as a sequence of bytes
    // Since we know that only a GameState struct will be passed and the memory is the
    // correct size of a GameState struct, we can cast sharedBuff to a GameState ptr
    GameState *state = ( GameState * ) ( sharedBuff );

    // If the first command line argument is move then handle a move operation
    if ( strcmp( argv[1], "move" ) == 0 ) {
        // Ensure that there is a row and column command line argument specified
        if ( argc != 4 ) {
            printf( "error\n" );
            exit( 1 );
        }

        // Convert the ASCII version of the row and column to integer versions
        int row = atoi( argv[2] );
        int col = atoi( argv[3] );

        bool returnMoveStatus = move( state, row, col );
        if ( returnMoveStatus == true ) {
            // if we got a response, and it was a success print the word "success" to the console
            printf( "success\n" );
        }
        else {
            // if we got a response, and it was a failure print the word "error" and exit
            printf( "error\n" );
            exit( 1 );
        }
    }
    else if ( strcmp( argv[1], "undo" ) == 0 ) {
        // If the first command line argument is to undo the previous move
        // Check that the only command line argument is the undo
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }

        bool undoMoveStatus = undo( state );
        if ( undoMoveStatus == true ) {
            // if we got a response, and it was a success print the word "success" to the console
            printf( "success\n" );
        }
        else {
            // if we got a response, and it was a failure print the word "error" and exit
            printf( "error\n" );
            exit( 1 );
        }
    }
    else if ( strcmp( argv[1], "report" ) == 0 ) {
        // If the first command line argument is to report the current state of the board
        // Check that the only command line argument is the report
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }
        report( state );
    }
    else if ( strcmp( argv[1], "test" ) == 0 ) {
        // If the first command line argument is to test for a race condition when accessing the shared struct
        if ( argc != 5 ) {
            printf( "error\n" );
            exit( 1 );
        }

        // Convert the ASCII version of the number of times to iterate, row, and column to integer versions
        int n = atoi( argv[2] );
        int row = atoi( argv[3] );
        int col = atoi( argv[4] );

        bool testStatus = test( state, n, row, col );
        if ( testStatus == true ) {
            // if we got a response, and it was a success print the word "success" to the console
            printf( "success\n" );
        }
        else {
            // if we got a response, and it was a failure print the word "error" and exit
            printf( "error\n" );
            exit( 1 );
        }
    }
    else {
        // if we got a command that was not one of the valid commands then let the user know, and then quit
        printf( "error\n" );
        exit( 1 );
    }

    // Release our reference to the shared memory segment
    shmdt( sharedBuff );

    // If we made it here without calling fail() or exiting unsuccessfully, then we exit successfully
    return EXIT_SUCCESS;
}
