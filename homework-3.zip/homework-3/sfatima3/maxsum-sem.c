/**
 * @file maxsum-sem.c
 * @author Sameeha Fatima
 * Multiple worker threads to find the contiguous non-empty subsequence within the sequence
 * of integers that has the largest sum. However, instead of dividing up the work
 * statically (where each worker is always assigned the same subtasks of the problem), 
 * we’ll divide up the work dynamically (so different workers may get different subtasks 
 * from execution to execution).
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//keeps track of index in vList
int indexForChild = 0;

//sets where the child should start in vList
int startingIndexForChild = 0;

//locks access to max_sum to modify max_sum
sem_t lock;

//boolean that says whether a variable is finished reading or not
bool finishReading = false;

// Reads in input file values
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );
    // Store the latest value.
    vList[vCount++] = v;
  }
  
  finishReading = true;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int startingIndexForChild = 0;
  int threadMaxValue = 0;
  while (true) {

    //Break out of the while loop if the child doesn't have anything else left to do
    if (finishReading && indexForChild >= vCount) {
      break;
    }

    //Sum that holds the sum of vList values
    int threadValue = 0;

    //Sets where the child should start
    startingIndexForChild = indexForChild++;

      //go from the child's starting index to index 0
      for(int i = startingIndexForChild; i >= 0; i--) {
        threadValue += vList[i];

        if (threadValue > threadMaxValue) {
          threadMaxValue = threadValue;
        }
      }
    }

    if (report) {
      printf("I’m process %d. The maximum sum I found is %d.\n", (int) pthread_self(), threadMaxValue);
    }

    //Check if there's a new max_sum value
    if (threadMaxValue > max_sum) {
      sem_wait(&lock);
      max_sum = threadMaxValue;
      sem_post(&lock);
    }

    return NULL;
}

/**
 * Multiple worker threads to find the contiguous non-empty subsequence within the sequence
 * of integers that has the largest sum. However, instead of dividing up the work
 * statically (where each worker is always assigned the same subtasks of the problem), 
 * we’ll divide up the work dynamically (so different workers may get different subtasks 
 * from execution to execution).
 * @param argc number of arguments
 * @param argv list of arguments
 * @return success number
 */
int main( int argc, char *argv[] ) {
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
        workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //Semaphore used to lock
  sem_init(&lock, 0 , MAX_VALUES); 

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if(pthread_create(&worker[i], NULL, workerRoutine, &i) != 0) {
      fail("Failure to create thread\n");
    }
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join( worker[i], NULL );
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  //Destorys semaphore
  sem_destroy( &lock );

  return EXIT_SUCCESS;
}