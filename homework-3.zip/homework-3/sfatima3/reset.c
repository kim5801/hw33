/**
 * @file reset.c
 * @author Sameeha Fatima
 * Read the initial game board state just like the server did in the previous 
 * assignment and create a shared memory segment containing any needed information 
 * about the game
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * Read the initial game board state just like the server did in the previous 
 * assignment and create a shared memory segment containing any needed information 
 * about the game
 * @param argc number of chars in argv
 * @param argv char array
 * @return success
 */
int main( int argc, char *argv[] ) {
  //checks is command line has the right amount of arguments
  if(argc != 2) {
    usage();
  }

  //unlinks old versions if they still exist
  sem_unlink( "/sfatima3-lightsout-lock" );
  
  //created lock semaphore
  sem_t *lock = sem_open( "/sfatima3-lightsout-lock", O_CREAT, 0600, 1 );

  //fails if lock cannot be created
  if( lock == SEM_FAILED ) {
    fail( "Can't make semaphore" );
  }
  
  //get key
  key_t key = ftok( "/afs/unity.ncsu.edu/users/k/kmgalla5", 1 );
  
  //get shared memory identifier associated w/key
  int smi = shmget( key, sizeof(GameState), 0666 | IPC_CREAT );
  
  //if shmget returns -1, call fail
  if( smi == -1 ) {
    fail( "Unable to get shared memory identifier for given key" );
  }
  
  //connects shared memory segment with shared memory identifier
  GameState *gm = (GameState*) malloc (sizeof(GameState));
  
  //Casts to gamestate pointer
  gm = (GameState *) shmat( smi, 0, 0 );

  //if gm returns -1, call fail
  if( gm == (GameState *)-1 ) {
    fail( "Unable to connect shared memory segment with shared memory identifier" );
  }

  //open file
  FILE *fp = fopen( argv[1], "r" );

  //fail if file does not open
  if(!fp) {
    printf( "Invalid input file: %s\n", argv[1]);
    exit( 1 );
  }

  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  //char that will read in each character from the input file
  char c;

  //reads file into struct's array
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      
      c = (char)fgetc(fp);
      
      if( c != '*' && c != '.' && c == ' ' && c != EOF ) {
        printf( "Invalid input file: %s\n", argv[1]);
        exit( 1 );
      }

      if( c == EOF ) {
        break;
      }
      else if (c == '\n') {
        c = fgetc(fp);
      }

      gm -> gameState[i][j] = c;
    }
  }

  gm -> previous[0] = -1;
  gm -> previous[1] = -1;

  #ifndef UNSAFE
    sem_post( lock );
  #endif

  //detach shared memory
  shmdt( gm );
  return 0;
}