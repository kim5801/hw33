/**
 * @file lightsout.c
 * @author Sameeha Fatima
 * Interpret a user command given in the command- line arguments and make 
 * requested changes to the game board stored in shared memory
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/*semaphore lock for memory*/
sem_t *lock;

// Print out an error message and exit.
static void fail( char const *message ) 
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//switches light on board
void witch( GameState *gm, int row, int col );
// test interface
bool test( GameState *state, int n, int row, int col );
// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int r, int c );
// Undo the most recent move, returning true if successful.
bool undo( GameState *state );
// Print the current state of the board.
void report( GameState *state );

// Switches the light associated with the row and col 
// to be the opposite state of what it was
void witch( GameState *gm, int row, int col ) 
{
  //check if row is valid
  if(row < 0 || row > GRID_SIZE - 1) {
    //nothing
  } 
  //check if column is valid
  else if (col < 0 || col > GRID_SIZE - 1) {
    //nothing
  }
  //change from * to .
  else if(gm -> gameState[row][col] == '*') {
    gm -> gameState[row][col] = '.';
  } 
  //change from . to *
  else if(gm -> gameState[row][col] == '.') {
    gm -> gameState[row][col] = '*';
  }
}

// test interface
bool test( GameState *state, int n, int row, int col ) 
{
  //check if row is valid
  if(row < 0 || row > GRID_SIZE - 1) {
    //nothing
  } 
  //check if column is valid
  else if (col < 0 || col > GRID_SIZE - 1) {
    //nothing
  }

  // makes a move n times
  for ( int i = 0; i < n; i++ ) {
    move( state, row, col );
  }
  return true;
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int r, int c ) {
  #ifndef UNSAFE
    sem_wait( lock );
  #endif
  
  //if invalid grid spot
  if( r < 0 || r > GRID_SIZE - 1 || c < 0 || c > GRID_SIZE - 1 ) {
    #ifndef UNSAFE
      sem_post( lock );
    #endif
    return false;
  }

  //switch the correct row and columns in the array
  witch(state, r, c);
  witch(state, r, c + 1);
  witch(state, r, c - 1);
  witch(state, r + 1, c);
  witch(state, r - 1, c);

  state -> previous[0] = r;
  state -> previous[1] = c;

  #ifndef UNSAFE
    sem_post( lock );
  #endif

  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ) {
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  //if undo has already been done and is being attempted to be done again
  if( state -> previous[0] < 0 ) {
    #ifndef UNSAFE
      sem_post( lock );
    #endif
    return false;
  }

  //switch the correct row and columns in the array back to the original state
  witch(state, state -> previous[0], state -> previous[1]);
  witch(state, state -> previous[0], state -> previous[1] + 1);
  witch(state, state -> previous[0], state -> previous[1] - 1);
  witch(state, state -> previous[0] + 1, state -> previous[1]);
  witch(state, state -> previous[0] - 1, state -> previous[1]);

  //makes sure two undos don't happen at once
  state -> previous[0] = -1;
  state -> previous[1] = -1;

  #ifndef UNSAFE
    sem_post( lock );
  #endif

  return true;
}

// Print the current state of the board.
void report( GameState *state ) {
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  //print out board
  for(int i = 0; i < GRID_SIZE; i++ ) {
    for(int j = 0; j < GRID_SIZE; j++) {
      putchar( state->gameState[i][j] );
    }
    putchar( '\n' );
  }

  #ifndef UNSAFE
    sem_post( lock );
  #endif
}

/**
 * interpret a user command given in the command- line arguments and make 
 * requested changes to the game board stored in shared memory
 * @param argc number of chars in argv
 * @param argv char array
 * @return success
 */
int main( int argc, char *argv[] ) 
{
  lock = sem_open( "/sfatima3-lightsout-lock", 0 );

  if( lock == SEM_FAILED ) {
    fail( "Can't open semaphore" );
  }

  //makes key
  key_t key = ftok( "/afs/unity.ncsu.edu/users/s/sfatima3", 1 );
  
  //get shared memory identifier associated w/key
  int smi = shmget( key, sizeof(GameState), 0 );
  
  //if shmget returns -1, call fail
  if( smi == -1 ) {
    fail( "Unable to get shared memory identifier for given key" );
  }
  
  //connects shared memory segment with shared memory identifier
  GameState *gm = (GameState *)shmat( smi, 0, 0 );

  //if gm returns -1, call fail
  if( gm == (GameState *) - 1 ) {
    fail( "Unable to connect shared memory segment with shared memory identifier" );
  }
  
  //calls move method
  if( argc == 4 && strcmp( argv[1], "move" )  == 0 ) {
    int row = atoi( argv[2] );
    int col = atoi( argv[3] );

    if( move( gm, row, col ) == true ) {
      printf( "success\n" );
    } 
    else {
      fail( "error" );
    }
  } 
  //calls undo method
  else if( argc == 2 && strcmp( argv[1], "undo" ) == 0 ) {
    if( undo( gm ) == true ) {
      printf( "success\n" );
    } 
    else {
      fail( "error" );
    }
  } 
  //calls report method
  else if( argc == 2 && strcmp( argv[1], "report" ) == 0 ) {
    report( gm );
  } 
  //calls test command
  else if( argc == 5 && strcmp( argv[1], "test" ) == 0 ) {
    int n = atoi( argv[2] );
    int row = atoi( argv[3] );
    int col = atoi( argv[4] );

    if( test( gm, n, row, col == true ) ) {
      printf( "success\n" );
    } 
    else {
      fail( "error" );
    }
  } 
  else { //else is an error
    fail( "error" );
  }
  
  //detach shared memory
  shmdt( gm );
  return 0;
}