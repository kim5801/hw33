#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
    printf("usage: maxsum-sem <workers>\n");
    printf("       maxsum-sem <workers> report\n");
    exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

/** Stores the arguments passed into the threads */
typedef struct
{
    int workers;
    bool report;
    int tempMax;
} myThread;

// semaphores for race conditions
sem_t semTotal;

sem_t semTime;

sem_t semPos;

// tells if program is still reading in input
bool isWorking;

// for if program is running
bool isRunning = true;

// position of thread going through list
int pos = 0;

// Read through and get position index of worker while values
// are being read in
int getWork()
{
    while (true)
    {
        //if done working
        if (!isWorking && pos >= vCount - 1)
        {
            return -1;
        }
        //if at end of list but still working
        else if (pos >= vCount - 1)
        {
            continue;
        }
        //update position and return with semaphores
        else
        {
            sem_wait(&semPos);
            pos = vCount - 1;
            sem_post(&semPos);
            return pos;
        }
    }
}

// Read the list of values.
void readList()
{
    // Keep reading as many values as we can.
    int v;
    isWorking = true;
    while (scanf("%d", &v) == 1)
    {
        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");

        // Store the latest value.
        vList[vCount++] = v;
        sem_post(&semTime);
    }
    sem_post(&semTime);
    isWorking = false;
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
    myThread *threadJawn = arg;
    int workers = threadJawn->workers;
    int tempMaxActual = 0;
    while (isRunning)
    {
        int work = getWork();
        if (work == -1)
        {
            sem_post(&semTime);
            break;
        }

        // run through same logic as previous program but from ending index
        int tempMax = 0;
        for (int j = pos; j >= 0; j -= workers)
        {
            int tempSum = 0;
            for (int k = j; k >= 0; k--)
            {
                tempSum += vList[k];
                if (tempSum > tempMax)
                {
                    tempMax = tempSum;
                }
            }
        }
        // set temporary max and release semTime
        tempMaxActual = tempMax;
        sem_post(&semTime);
    }

    // print statement for children and what they found
    pid_t childID = pthread_self();
    if (threadJawn->report)
    {
        printf("I’m process %d. The maximum sum I found is %d.\n", childID, tempMaxActual);
    }

    // setting and comparing actual max
    if (threadJawn->tempMax < tempMaxActual)
    {
        threadJawn->tempMax = tempMaxActual;
    }

    // comparing actual max again
    if (threadJawn->tempMax > max_sum)
    {
        sem_wait(&semTotal);
        max_sum = threadJawn->tempMax;
        sem_post(&semTotal);
    }

    free(threadJawn);
    return NULL;
}

int main(int argc, char *argv[])
{
    int workers = 4;

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 ||
        workers < 1)
        usage();

    // If there's a second argument, it better be "report"
    if (argc == 3)
    {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    // Make each of the workers.
    pthread_t worker[workers];

    // initialize semaphores
    sem_init(&semTotal, 0, 1);
    sem_init(&semPos, 0, 1);
    sem_init(&semTime, 0, 1);
    // initialize workers and perform routines
    for (int i = 0; i < workers; i++)
    {
        myThread *threadJawn = malloc(sizeof(*threadJawn));
        threadJawn->workers = workers;
        threadJawn->tempMax = 0;
        threadJawn->report = report;
        pthread_create(&worker[i], NULL, workerRoutine, threadJawn);
    }

    readList();

    // Wait until all the workers finish.
    for (int i = 0; i < workers; i++)
    {
        pthread_join(worker[i], NULL);
    }

    // Report the max product and release the semaphores.
    printf("Maximum Sum: %d\n", max_sum);

    return EXIT_SUCCESS;
}
