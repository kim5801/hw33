#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <semaphore.h>

// // Print out an error message and exit.
// static void fail(char const *message) {
//     fprintf(stderr, "%s\n", message);
//     exit(1);
// }



// semaphores for race conditions
//sem_t semLights = sem_open("/lmgetzen-lightsout-lock", O_CREAT, 0, 1);


sem_t *semLights;



/**
 * switch functionality for move command argument
 * 
 * @param g game to used
 * @param r row to be moved
 * @param c column to be moved
 */
static void switchFunc(GameState *g, int r, int c) {
    if (g->board[r][c] == '.') {
        g->board[r][c] = '*';
    }
    else if (g->board[r][c] == '*') {
        g->board[r][c] = '.';
    }
    else if (g->board[r][c] == '\n') {
        //do nothing
    }
}


// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *game, int r, int c ) {
    
    #ifndef UNSAFE
        sem_wait(semLights);
    #endif
    
    //saving oldboard state for undo function later on
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j <= GRID_SIZE; j++) {
            game->oldBoard[i][j] = game->board[i][j];
        }
    }
        



    

    //setting undo boolean to true so that functionality can be used next
    game->undo = true;

        
    //check origin first
    if (game->rowM == 0 && game->colM == 0) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM + 1, game->colM);
        switchFunc(game, game->rowM, game->colM + 1);
    }
        
    //bottom left corner
    else if (game->rowM == 4 && game->colM == 0) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM - 1, game->colM);
        switchFunc(game, game->rowM, game->colM + 1);
    }
    //bottom right corner
    else if (game->rowM == 4 && game->colM == 4) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM - 1, game->colM);
        switchFunc(game, game->rowM, game->colM - 1);
    }
    //top right corner
    else if (game->rowM == 0 && game->colM == 4) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM + 1, game->colM);
        switchFunc(game, game->rowM, game->colM - 1);
    }
    //left column
    else if ((game->rowM >= 1 && game->rowM <= 3) && game->colM == 0) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM + 1, game->colM);
        switchFunc(game, game->rowM - 1, game->colM);
        switchFunc(game, game->rowM, game->colM + 1);
    }
    //upper row
    else if (game->rowM == 0 && (game->colM >= 1 && game->colM <= 3)) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM + 1, game->colM);
        switchFunc(game, game->rowM, game->colM - 1);
        switchFunc(game, game->rowM, game->colM + 1);
    }
    //right column
    else if ((game->rowM >= 1 && game->rowM <= 3) && game->colM == 4) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM + 1, game->colM);
        switchFunc(game, game->rowM - 1, game->colM);
        switchFunc(game, game->rowM, game->colM - 1);
    }
    //bottom row
    else if (game->rowM == 4 && (game->colM >= 1 && game->colM <= 3)) {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM - 1, game->colM);
        switchFunc(game, game->rowM, game->colM - 1);
        switchFunc(game, game->rowM, game->colM + 1);
    }
    //anything without special conditions
    else {
        switchFunc(game, game->rowM, game->colM);
        switchFunc(game, game->rowM - 1, game->colM);
        switchFunc(game, game->rowM + 1, game->colM);
        switchFunc(game, game->rowM, game->colM - 1);
        switchFunc(game, game->rowM, game->colM + 1);
    }

    //printf("success\n");

    #ifndef UNSAFE
        sem_post(semLights);
    #endif

    return true;

        

}


// Undo the most recent move, returning true if successful.
bool undo( GameState *game ) {

    #ifndef UNSAFE
        sem_wait(semLights);
    #endif

    //if game is able to use undo functionality
    if (game->undo) {
        //copy over old saved board into the actual game board
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j <= GRID_SIZE; j++) {
                game->board[i][j] = game->oldBoard[i][j];
            }
        }
        game->undo = false;
        printf("success\n");
    }

    //otherwise print error if undo has already been done or is not allowed
    else {
        printf("error\n");
    }
    
    #ifndef UNSAFE
        sem_post(semLights);
    #endif

    return true;

    
}


// Print the current state of the board.
void report( GameState *game ) {

    #ifndef UNSAFE
        sem_wait(semLights);
    #endif

    //print out the board
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j <= GRID_SIZE; j++) {
            printf("%c", game->board[i][j]);
        }
    }
    printf("\n");

    #ifndef UNSAFE
        sem_post(semLights);
    #endif

}


// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
        return false;
    }
        
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ ) {
        move( state, r, c );
    }

    return true;
}



int main(int argc, char *argv[]) {
    
    //create key to get access to shared memory
    key_t key = ftok(PATH, 28);             
    //get shared memory identifier with key
    int memID = shmget(key, 0, 0);


    //get game structure from memory saved from reset
    GameState *game = (GameState *) shmat(memID, 0, 0);

    
    // Open semaphore
    semLights = sem_open("/lmgetzen-lightsout-lock", 0);

        
    //if command argument is report
    if (strcmp(argv[1], "report") == 0) {
        report(game);
    }

    //check for invalid numbers
    else if (argc == 4 && ((atoi(argv[2]) > 4 || atoi(argv[2]) < 0) || (atoi(argv[3]) > 4 || atoi(argv[3]) < 0))) {
        printf("error\n");
    }



    //if command argument is move
    else if (argc == 4 && (strcmp(argv[1], "move") == 0)) {

        //converting each string from command line to integer
        game->rowM = atoi(argv[2]);
        game->colM = atoi(argv[3]);


        if(move(game, game->rowM, game->colM)) {
            printf("success\n");
        }

        
    }

    //if undo functionality has been selected
    else if (strcmp(argv[1], "undo") == 0) {
        undo(game);
    }

    else if (strcmp(argv[1], "test") == 0) {
        //converting each string from command line to integer
        int n = atoi(argv[2]);
        game->rowM = atoi(argv[3]);
        game->colM = atoi(argv[4]);

        
        test(game, n, game->rowM, game->colM);
    }

    else {
        printf("error\n");
    }




    
    

    return 0;

}
