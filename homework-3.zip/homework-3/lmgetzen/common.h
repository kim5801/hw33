#include <stdbool.h>


// Height and width of the playing area.
#define GRID_SIZE 5

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Path to home directory in AFS
#define PATH "/afs/unity.ncsu.edu/users/l/lmgetzen"


typedef struct {
    char board[GRID_SIZE][GRID_SIZE + 1];
    char oldBoard[GRID_SIZE][GRID_SIZE + 1];
    bool undo;
    int rowM;
    int colM;
    //char oldBoard[GRID_SIZE][GRID_SIZE];
} GameState;
