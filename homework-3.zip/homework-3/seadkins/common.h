// Height and width of the playing area.
#define GRID_SIZE 5
#define ON '*'
#define OFF '.'
#define COMMAND_LIMIT = 1024

// Struct that represents the state of the board
struct GameState {
  char board[GRID_SIZE][GRID_SIZE];
  bool moved;
  bool undone;
  int rowMoved;
  int colMoved;
};