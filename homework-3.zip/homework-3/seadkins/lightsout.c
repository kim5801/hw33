#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <ctype.h>
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make a move at the given row, column location, returning true if successful.
bool move( struct GameState *state, int r, int c ){
  // Open the semaphore already made by reset.c
  sem_t *stateSem = sem_open( "/seadkins-lightsout-lock", 1 );
  if ( stateSem == SEM_FAILED ) {
    fail( "Can't open tag semaphore" );
  }
  // Use semaphore to wait here until other processes are done modifying the gameState.
  #ifndef UNSAFE
    sem_wait( stateSem );
  #endif

  // save the original state of the board
  state->rowMoved = r;
  state->colMoved = c;

  // switches the selected light
  if (state->board[r][c] == '*') {
    state->board[r][c] = '.';
  }
  else {
    state->board[r][c] = '*';
  }
  // switches the light below the selected light
  if (r < GRID_SIZE - 1) {
    if (state->board[r + 1][c] == '*') {
      state->board[r + 1][c] = '.';
    }
    else {
      state->board[r + 1][c] = '*';
    }
  }
  // switches the light above the selected light
  if (r > 0) {
    if (state->board[r - 1][c] == '*') {
      state->board[r - 1][c] = '.';
    }
    else {
      state->board[r - 1][c] = '*';
    }
  }
  // switches the light to the right of the selected light
  if (c < GRID_SIZE - 1) {
    if (state->board[r][c + 1] == '*') {
      state->board[r][c + 1] = '.';
    }
    else {
      state->board[r][c + 1] = '*';
    }
  }
  // switches the light to the left of the selected light
  if (c > 0) {
    if (state->board[r][c - 1] == '*') {
      state->board[r][c - 1] = '.';
    }
    else {
      state->board[r][c - 1] = '*';
    }
  }

  state->moved = true;
  
  state->undone = false;
  

  // Release semaphore here to let other processes know that this process is done modifying the gameState.
  #ifndef UNSAFE
    sem_post( stateSem );
  #endif

  // Close the semaphore.
  sem_close( stateSem );

  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( struct GameState *state ) {
  // save the original state of the board
  int row1 = state->rowMoved;
  int col1 = state->colMoved;
  if (move(state, row1, col1)) {
    return true;
  }
  return false;
}

// Print the current state of the board.
void report( struct GameState *state ){
  printf("\n");
  int count = 0;
  for (int row = 0; row < GRID_SIZE; row ++)
  {
    for(int col = 0; col < GRID_SIZE; col++)
    {
      printf("%c", state->board[row][col]);
      count++;
    }
    printf("\n");
  }
}

// Test interface, for quickly making a given move over and over.
bool test( struct GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }
  return true;
}

int main( int argc, char *argv[] ) {

  bool userReport = false;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 5 ) {
    fail("error");
  }

  // If the second argument is "move" it should have 2 more commands for row and collumn. 
  if ( argc == 4 ) {
    if ( strcmp( argv[ 1 ], "move" ) != 0 ) {
      fail("error");
    }
  }

  // if the second argument is "test", there should be three more commands, for row, collumn, and number of moves.
  if ( argc == 5 ) {
    if ( strcmp( argv[ 1 ], "test" ) != 0 ) {
      fail("error");
    }
  }

  // Determine what command was given by the user
  char *command = argv[1];
  int row1 = 0;
  int col1 = 0;

  // the number of times to repeat the move if the user is running a "test"
  int n = 0;

  // if the user command was "move", then assign the following integers as the row and col of the tile to move
  if (strcmp( command, "move" ) == 0 && argc == 4) {
    char possRow[2];
    char possCol[2];
    strcpy(possRow, argv[2]);
    strcpy(possCol, argv[3]);
    if (!isdigit(possRow[0]) || !isdigit(possCol[0])) {
      fail("error");
    }
    row1 = atoi(argv[2]);
    col1 = atoi(argv[3]);
    if (row1 < 0 || row1 > 4 || col1 < 0 || col1 > 4) {
      fail("error");
    }
  }
  else if (strcmp( command, "move" ) == 0 && argc != 4) {
    fail("error");
  }

  // If the command was "test", assign the row, col, and n values (n is the number of times to repeat the move).
  if (strcmp( command, "test" ) == 0 && argc == 5) {
    char possRow[2];
    char possCol[2];
    char possN[2];
    strcpy(possN, argv[2]);
    strcpy(possRow, argv[3]);
    strcpy(possCol, argv[4]);
    if (!isdigit(possRow[0]) || !isdigit(possCol[0]) || !isdigit(possN[0])) {
      fail("error");
    }
    n = atoi(argv[2]);
    row1 = atoi(argv[3]);
    col1 = atoi(argv[4]);
    if (row1 < 0 || row1 > 4 || col1 < 0 || col1 > 4 || n < 1) {
      fail("error");
    }
  }
  else if (strcmp( command, "test" ) == 0 && argc != 5) {
    fail("error");
  }

  // if the user requested a report, set report to true
  if (strcmp( argv[ 1 ], "report" ) == 0) {
    userReport = true;
  }

  // Make a shared memory segment as big as the GameState struct, named key
  key_t key = ftok("/afs/unity.ncsu.edu/users/s/seadkins", 0);
  int shmid = shmget( key, 0, 0 );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Initialize the GameState and map the shared memory into my address space
  struct GameState *gs = (struct GameState *)shmat( shmid, 0, 0 );
  if ( gs == (struct GameState *) - 1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  // If the user requests a test, then quickly repeate the move requested n times.
  if (strcmp(command, "test") == 0) {
    test(gs, n, row1, col1);
  }

  // If the user requests a move, move the requested board tile
  if (strcmp(command, "move") == 0) {

    if (move(gs, row1, col1)) {
      printf("success\n");
    }
  }

  // if the user requests to undo the last move, then preform the previous move again to reset it
  if (strcmp(command, "undo") == 0 && !gs->undone && gs->moved) {
    
    if (undo(gs)) {
      printf("success\n");
    }
  }
  else if (strcmp(command, "undo") == 0 && (gs->undone || !gs->moved)) {
    fail("error");
  }

  // If the user has requested a report, print out the report
  if (userReport) {
    report(gs);
  }

  return 0;
}
