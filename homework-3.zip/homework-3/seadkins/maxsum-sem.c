#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

int workers;

int index = 0;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

sem_t workLock;
sem_t sumLock;

bool done = false;

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
  }
  done = true;
}

/** Method to determine if there is still work to be done, and assign workers their values.*/
int getWork() {
  // Use semaphore to wait here until readList() reads in a new value.
  while (!done || index < vCount) {
    while (index >= vCount) {
      ;
    }
    sem_wait(&workLock);
    return index++;
  }
  return -1;
}

/** Start routine for each worker. */
void *workerRoutine( void *args ) {
  
  int end = getWork();

  int threadMax = INT_MIN;

  while (end != -1) {

    sem_post(&workLock);
    int childMax = 0;
    
    for ( int i = end; i >= 0; i-- ) {
      
      childMax += vList[i];
      if (childMax < vList[i]) {
        childMax = vList[i];
      }
 
      if (threadMax < childMax) {
        threadMax = childMax;
      }
      
    }
    
    end = getWork();
  }

  if (report) {
    printf("I'm process %d. The maximum sum I found is %d.\n", (int)pthread_self(), threadMax);
  }

  // Use semaphore to lock the other threads out of this portion
  sem_wait(&sumLock);

  if (threadMax > max_sum) {
    max_sum = threadMax;
  }

  sem_post(&sumLock);

  return NULL;
}

int main( int argc, char *argv[] ) {
  workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Initialize the sempahore(s) that will be keeping track of if there is more work to be done.
  sem_init(&sumLock, 0, 1);

  sem_init(&workLock, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, 0);

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) 
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}

     
      // for ( int j = i; j >= 0; j-- ) {
      //   childMax += vList[j];

      //   if (threadMax < childMax) {
      //     threadMax = childMax;
      //   }

      // }
