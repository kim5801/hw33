// Height and width of the playing area.
#define GRID_SIZE 5

// 2 characters define a move - a row and a column
#define MOVE_LENGTH 2

// Struct representing the game board, its most recent move, and whether undo can be played
struct GameState {
    char board[GRID_SIZE][GRID_SIZE];
    int lastMoveRow;
    int lastMoveCol;
    bool undoAvailable;
};
