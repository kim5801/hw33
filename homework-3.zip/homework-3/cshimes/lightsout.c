/**
 * @file lightsout.c
 * @author Cameron Himes
 * @brief Contains functionality to parse user input then report on the state of the game board as well
 * as playing moves and undoing moves where possible.
 * 
 * Updated for HW3 pt3 to include mutual exclusion.
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// A pointer to semaphore used to perform operations on the game board
sem_t * gameSem;

// Print out an error message and exit.
static void fail( char const *message, struct GameState * gameState ) {
  fprintf( stderr, "%s\n", message );
  shmdt(gameState);
  exit(1);
}

// Print out an error message and exit.
static void error( struct GameState * gameState ) {
  printf("error\n");
  shmdt(gameState);
  exit(1);
}

// Print out a success message and exit.
static void success( struct GameState * gameState ) {
  printf("success\n");
  shmdt(gameState);
  exit(0);
}

// Play a move on the board
// Adopted from the playMove method of HW1 Pt4 'server.c' file
bool move(struct GameState *state, int r, int c) {
  // Acquire the semaphore before editing the game state
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif
  
  // Play the move by editing values in the game board
  state->board[r][c] = state->board[r][c] == '.'? '*': '.';

  if (r != 0) {
    state->board[r - 1][c] = state->board[r - 1][c] == '.'? '*': '.';
  }

  if (r != GRID_SIZE - 1) {
    state->board[r + 1][c] = state->board[r + 1][c] == '.'? '*': '.';
  }

  if (c != 0) {
    state->board[r][c - 1] = state->board[r][c - 1] == '.'? '*': '.';
  }

  if (c != GRID_SIZE - 1) {
    state->board[r][c + 1] = state->board[r][c + 1] == '.'? '*': '.';
  }

  // Update the Game struct's lastMove and undoAvailable fields
  state->lastMoveRow = r;
  state->lastMoveCol = c;
  state->undoAvailable = true;

  // Release the semaphore and return true
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif
  return true;
}

/**
 * @brief Performs an undo operation by replaying the most recent move
 * 
 * @param state the current gamestate
 * @return true if successful
 * @return false if unsuccessful
 */
bool undo(struct GameState *state) {
  // Acquire the semaphore before editing the game state
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif

  // Undo the most recent move by playing it again
  if (state->undoAvailable == false) {
    // Release the semaphore and return false
    #ifndef UNSAFE
      sem_post(gameSem);
    #endif
    return false;
  }

  // Play the move by editing values in the game board
  int r = state->lastMoveRow;
  int c = state->lastMoveCol;
  state->board[r][c] = state->board[r][c] == '.'? '*': '.';

  if (r != 0) {
    state->board[r - 1][c] = state->board[r - 1][c] == '.'? '*': '.';
  }

  if (r != GRID_SIZE - 1) {
    state->board[r + 1][c] = state->board[r + 1][c] == '.'? '*': '.';
  }

  if (c != 0) {
    state->board[r][c - 1] = state->board[r][c - 1] == '.'? '*': '.';
  }

  if (c != GRID_SIZE - 1) {
    state->board[r][c + 1] = state->board[r][c + 1] == '.'? '*': '.';
  }

  // Update the undoAvailable field so two undos cannot be performed in a row
  state->undoAvailable = false;

  // Release the semaphore and return true
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif
  return true;
}

/**
 * @brief Prints out the contents of the game state passed as a parameter then exits
 * 
 * @param state a GameState struct
 */
void report(struct GameState *state) {
  // Acquire the semaphore before printing the game state
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif

  // Print out the contents of the board
  for (int i = 0; i < GRID_SIZE; i++) {
    printf("%c", state->board[i][0]);
    printf("%c", state->board[i][1]);
    printf("%c", state->board[i][2]);
    printf("%c", state->board[i][3]);
    printf("%c\n", state->board[i][4]);
  }
  // Print an additional line for a better looking output
  printf("\n");

  // Release the semaphore and exit
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif
  exit(0);
}

// Test interface, for quickly making a given move over and over.
bool test( struct GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

int main( int argc, char *argv[] ) {
  // Attach to memory, make a pointer for the gameState object
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/c/cshimes", 1), sizeof(struct GameState), 0666);
  struct GameState *gameState = (struct GameState *) shmat(shmid, 0, 0);
  if (gameState == (struct GameState *) -1) {
    fail("Couldn't attach to the shared memory space.", gameState);
  }

  // Get the named semaphore used for mutual exclusion
  gameSem = sem_open("/cshimes-lightsout-lock", 0);

  if (gameSem == SEM_FAILED) {
    fail("Couldn't open the named semaphore.", gameState);
  }

  // Handle user input
  // Code adopted from input validation in HW2 Pt.4 - client.c
   if (argc == 2) {
    // Undo command
    if (strcmp("undo", argv[1]) == 0) {
      if (undo(gameState)) {
        success(gameState);
      } else {
        error(gameState);
      }
    } 
    // Report command
    else if (strcmp("report", argv[1]) == 0) 
    {
      report(gameState);
    } else {
        error(gameState);
    }
    // Move command
   } else if (argc == 4) {
        if (strcmp("move", argv[1]) != 0) {
          error(gameState);
        }
        int row;
        int col;
        // Attempt to parse the input into rows and columns, which have to be between 0 and 4 (inclusive)
        if (sscanf(argv[2], "%d", &row) != 1 || row < 0 || row > GRID_SIZE - 1) {
          error(gameState);
        }

        if (sscanf(argv[3], "%d", &col) != 1 || col < 0 || col > GRID_SIZE - 1) {
          error(gameState);
        }

        // Play the move
        if (move(gameState, row, col)) {
          success(gameState);
        } else {
          error(gameState);
        }
    // Test command
   } else if (argc == 5) {
        if (strcmp("test", argv[1]) != 0) {
          error(gameState);
        }

        // Try to parse the input into 3 integers - n, rows, and columns
        int n;
        int row;
        int col;
        if (sscanf(argv[2], "%d", &n) != 1) {
          error(gameState);
        }

        if (sscanf(argv[3], "%d", &row) != 1 || row < 0 || row > GRID_SIZE - 1) {
          error(gameState);
        }

        if (sscanf(argv[4], "%d", &col) != 1 || col < 0 || col > GRID_SIZE - 1) {
          error(gameState);
        }

        // Run the test command with the given arguments
        test(gameState, n, row, col);
   } else {
      error(gameState);
   }
}
