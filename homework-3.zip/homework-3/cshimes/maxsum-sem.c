/**
 * @file maxsum-sem.c
 * @author Cameron Himes
 * @brief Computes the maximum sum of integer input using a user-specified number of threads
 * that are dynamically allocated work to complete.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// The maximum sum the worker threads look for
int maxSum;

// Semaphore to allow or block workers wanting to call getWork
sem_t workAvailable;

// Semaphore to allow or block workers from writing their local max sum to the global variable
sem_t maxSumWriteable;

// Semaphore to allow or block workers from checking whether work is available for them
sem_t checkForWork;

// Indicates whether all input has been read in
bool inputReadingComplete = false;

// Indicates whether all possible work has been assigned
bool allWorkAssigned = false;

// The newest index that hasn't been checked
int nextIdx = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    // Wake up one thread waiting for work, because a new ending index is available
    sem_post(&workAvailable);
  }
  // Update the boolean to indicate that all input has been read in
  inputReadingComplete = true;
}

/**
 * @brief Returns the index a worker should search up to if work is available,
 * blocks the worker if no work is available yet, and -1 if the main thread
 * is done reading in input, and it's time for the calling thread to exit.
 * 
 * @return an int
 */
int getWork() {
  // Return -1 if input has been read in and all work has been assigned and or completed
  // Use the checkForWork semaphore to ensure only one thread can check if work is available
  // at a time. This ensures no deadlock occurs.
  sem_wait(&checkForWork);
  if (allWorkAssigned) {
    sem_post(&checkForWork);
    return -1;
  }

  // Get work if it's available, wait if not
  sem_wait(&workAvailable);

  // Check if this is the last bit of work
  int workAvailableVal;
  sem_getvalue(&workAvailable, &workAvailableVal);
  if (workAvailableVal == 0 && inputReadingComplete) {
    allWorkAssigned = true;
  }

  // Wake up one thread waiting to check if work is available
  sem_post(&checkForWork);
  return nextIdx++;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  unsigned long int threadId = pthread_self();
  int endIndex;
  int localMaxSum = INT_MIN;
  while (true) {
    // Exit if getWork returned -1
    endIndex = getWork();
    if (endIndex == -1) {
      break;
    }

    // Otherwise, find the local max sum in the assigned portion of the input array.
    // Specifically, search all ranges ending at endIndex by going backwards
    int localSum = 0;
    for (int i = endIndex; i >= 0; i--) {
      localSum += vList[i];
        if (localSum > localMaxSum)
          localMaxSum = localSum;
    }
  }

  // If the report option was specified, print out your local max sum 
  if (report && localMaxSum != INT_MIN) {
    printf("I'm thread %lu. The maximum sum I found is %d.\n", threadId, localMaxSum);
  }

  // Block other threads from writing to the global max sum, and check if your local max sum
  // has a greater value. If so, update the global max sum
  sem_wait(&maxSumWriteable);
  if (localMaxSum > max_sum) {
    max_sum = localMaxSum;
  }
  sem_post(&maxSumWriteable);
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Initialize the semaphores for the workers
  sem_init(&workAvailable, 0, 0);
  sem_init(&maxSumWriteable, 0, 1);
  sem_init(&checkForWork, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, NULL);

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  sem_destroy(&workAvailable);
  sem_destroy(&maxSumWriteable);
  sem_destroy(&checkForWork);
  
  return EXIT_SUCCESS;
}
