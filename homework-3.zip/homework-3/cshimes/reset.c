/**
 * @file reset.c
 * @author Cameron Himes
 * @brief Contains functionality to set the state of the 5x5 game board to the contents
 * of a provided input file.
 * 
 * Updated for HW3 pt3 to include mutual exclusion.
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Read the game board in from the given file and store the information in the game struct
// Code based on code from HW1 Pt. 4, 'server.c'
void readGameBoard(char * fileName, struct GameState *gameState) {
  FILE *boardFptr = fopen(fileName, "r");

  if (boardFptr == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", fileName);
    exit(1);
  }

  // Read in the file contents
  char c;
  int charsRead = 0;
  int linesRead = 0;
  while ((c = fgetc(boardFptr)) != EOF && linesRead < GRID_SIZE) {
    if (c == '*' || c == '.') {
      gameState->board[linesRead][charsRead - (linesRead * GRID_SIZE)] = c;
      charsRead++;
    } else if (c == '\n') {
      if (charsRead % GRID_SIZE != 0) {
        // There should be 5 characters read per line
        fprintf(stderr, "Invalid input file: %s\n", fileName);
        exit(1);
      }
      linesRead++;
    } else if (c != 1) {
        fprintf(stderr, "Invalid input file: %s\n", fileName);
        exit(1);
    }
  }

  // Check that the correct amount of characters and lines were read
  if (charsRead != GRID_SIZE * GRID_SIZE || linesRead != GRID_SIZE) {
    fprintf(stderr, "Invalid input file: %s\n", fileName);
    exit(1);
  }

  // If there are any more characters, the file format is invalid
  if (c != EOF) {
    fprintf(stderr, "Invalid input file: %s\n", fileName);
    exit(1);
  }
}

// Set up the initial game board
int main( int argc, char *argv[] ) {
  // Check that only one command-line argument was given
  if (argc != 2) {
    usage();
  }

  // Created a shared memory segment 
  // Code based (to a degree) on the code in the lecture three example file 'shmReader.c'.
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/c/cshimes", 1), sizeof(struct GameState), 0666 | IPC_CREAT);
  if (shmid == -1) {
    fail("Couldn't create shared memory.");
  }

  // Attach to the shared memory
  struct GameState *gameState = (struct GameState *) shmat(shmid, 0, 0);
  if (gameState == (struct GameState *) -1) {
    fail("Couldn't attach to the shared memory space.");
  }

  // Unlink the named semaphore if it exists
  sem_unlink("/cshimes-lightsout-lock");

  // Create a named semaphore
  sem_t * sem = sem_open("/cshimes-lightsout-lock", O_CREAT, 0600, 1);
  if (sem == SEM_FAILED) {
    fail("Can't make the named semaphore.");
  }

  // Try to read in the board state from the given file
  readGameBoard(argv[1], gameState);
  
  // The player cannot undo moves until one has been performed
  gameState->undoAvailable = false;
  
  // Release our reference to the memory and the semaphore we created
  shmdt(gameState);
  sem_close(sem);

  return 0;
}
