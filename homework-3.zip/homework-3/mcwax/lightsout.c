#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Semaphore for shared memory
sem_t *lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Parse string as int
int stringToInt( char string[] ) {
  // Iterate through string to take each digit and add it to value
  int value = 0, currDigit = 0, i = 0;
  while ( string[i] != '\0' ) {
    // Not a numerical digit (0-9)
    if ( string[i] < ASCII_LOW || string[i] > ASCII_UP ) {
        return -1;
    }

    currDigit = string[i] - ASCII_LOW;
    value = currDigit + ( value * 10 );

    i++;
  }

  return value;
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( struct GameState *currGame, int r, int c ) {

  // Lock for editing
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  // Invalid integer move input
  if ( ( r == -1 || c == -1 ) || ( r < 0 || r >= GRID_SIZE ) || ( c < 0 || c >= GRID_SIZE ) ) {

    // Unlock
    #ifndef UNSAFE
      sem_post( lock );
    #endif

    return false;
  }
  else {
    // Save state of current grid in case of undo
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        currGame->copy[ i ][ j ] = currGame->board[ i ][ j ];
      }
    }

    // Carry out initial move
    if ( currGame->board[ r ][ c ] == '.' ) {
      currGame->board[ r ][ c ] = '*';
    }
    else {
      currGame->board[ r ][ c ] = '.';
    }

    // Now cascading moves
    // Up
    if ( ( ( r - 1 ) >= 0 ) && ( ( r - 1 ) < GRID_SIZE ) ) {
      if ( currGame->board[ r - 1 ][ c ] == '.' ) {
        currGame->board[ r - 1 ][ c ] = '*';
      }
      else {
        currGame->board[ r - 1 ][ c ] = '.';
      }
    }
    // Down
    if ( ( ( r + 1 ) >= 0 ) && ( ( r + 1 ) < GRID_SIZE ) ) {
      if ( currGame->board[ r + 1 ][ c ] == '.' ) {
        currGame->board[ r + 1 ][ c ] = '*';
      }
      else {
        currGame->board[ r + 1 ][ c ] = '.';
      }
    }
    // Right
    if ( ( ( c + 1 ) >= 0 ) && ( ( c + 1 ) < GRID_SIZE ) ) {
      if ( currGame->board[ r ][ c + 1 ] == '.' ) {
        currGame->board[ r ][ c + 1 ] = '*';
      }
      else {
        currGame->board[ r ][ c + 1 ] = '.';
      }
    }
    // Left
    if ( ( ( c - 1 ) >= 0 ) && ( ( c - 1 ) < GRID_SIZE ) ) {
      if ( currGame->board[ r ][ c - 1 ] == '.' ) {
        currGame->board[ r ][ c - 1 ] = '*';
      }
      else {
        currGame->board[ r ][ c - 1 ] = '.';
      }
    }
  }

  // Move carried out successfully
  #ifndef UNSAFE
    sem_post( lock );
  #endif

  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( struct GameState *currGame ) {

  // Lock
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  // Check similarity to previous grid. If the same, can't undo
  int validUndo = 0;
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      if ( currGame->copy[ i ][ j ] != currGame->board[ i ][ j ] ) {
        // There is a difference, good to go
        validUndo = 1;
      }
    }
  }
  // Copy over old grid, or exit with error
  if ( validUndo ) {
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        currGame->board[ i ][ j ] = currGame->copy[ i ][ j ];
      }
    }

    // Return success message
    #ifndef UNSAFE
      sem_post( lock );
    #endif
    return true;
  }
  // Error
  else {
    #ifndef UNSAFE
      sem_post( lock );
    #endif

    return false;
  }

}

// Print the current state of the board.
void report( struct GameState *currGame ) {

  // Lock
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  // Print out shared memory struct
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", currGame->board[ i ][ j ] );
    }
    printf("\n");
  }

  // Unlock
  #ifndef UNSAFE
    sem_post( lock );
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( struct GameState *currGame, int n, int r, int c ) {

// Make sure the row / colunn is valid.
if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
  return false;

// Make the same move a bunch of times.
for ( int i = 0; i < n; i++ )
  move( currGame, r, c );

return true;
}

int main( int argc, char *argv[] ) {

  // Create access to shared memory
  int shmid = shmget( ftok( PATHNAME, 1 ), sizeof( struct GameState * ), 0 );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Assign semaphore
  lock = sem_open( SEMAPHORE, 0 );

  // Shared memory access
  struct GameState *currGame = ( struct GameState * ) shmat( shmid, 0, 0 );

  // Test interface indicated
  if ( strcmp( argv[ 1 ], "test" ) == 0 ) {

    // Parse number of iterations
    int n = stringToInt( argv[ 2 ] );

    // Parse row num from string
    int r = stringToInt( argv[ 3 ] );

    // Parse col num from string
    int c = stringToInt( argv[ 4 ] );

    if ( test( currGame, n, r, c ) == false )
      fail( ERROR );

  }
  // Player wants to do a move
  else if ( strcmp( argv[ 1 ], "move" ) == 0 ) {

    // Parse row num from string
    int r = stringToInt( argv[ 2 ] );

    // Parse col num from string
    int c = stringToInt( argv[ 3 ] );

    // Pass movements to function
    if ( move( currGame, r, c ) == false )
      fail( ERROR );

  }
  else if ( strcmp( argv[ 1 ], "undo") == 0 ) {
    
    if ( undo( currGame ) == false )
      fail( ERROR );

  }
  // Printf out current board report
  else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    report( currGame );
  }
  // Command not recognized
  else {
    printf( "%s\n", ERROR );
  }


  // All commands read, good to exit
  return 0;
}
