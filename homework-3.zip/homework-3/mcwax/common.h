// Height and width of the playing area.
#define GRID_SIZE 5

// Upper boundary ASCII value
#define ASCII_UP 57

// Lower boundary ASCII value
#define ASCII_LOW 48

// Maximum length for any message
#define MESSAGE_LIMIT 1024

// Error message for invalid file
#define INVALID_FILE "Invalid input file: "

// Success message for client
#define SUCCESS "success"

// Error message for client
#define ERROR "error"

// Path name to use for shared memory
#define PATHNAME "/afs/unity.ncsu.edu/users/m/mcwax"

#define SEMAPHORE "/mcwax-lightsout-lock"

// Struct for state of current game
struct GameState {
    char board[ GRID_SIZE ][ GRID_SIZE ];
    char copy[ GRID_SIZE ][ GRID_SIZE ];
};
