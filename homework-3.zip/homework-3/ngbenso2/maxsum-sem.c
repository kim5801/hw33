#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <pthread.h>

/** Default number of workers */
#define DEFAULT_WORKERS 4
/** Minimum number of arguments */
#define MIN_ARGS 2

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Semaphore for determining thread work
sem_t threadWork;

// Lock for changing the maxsum
sem_t valueLock;

// Increment value for worker indexes
int increment;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

/**
 * Determines next index for worker to begin calculations
 * @param index index the worker started at
 * @param first flag for whether this is the worker's first time calling getWork()
 * @return new index to start calculations
 */
int getWork( int index, bool first )
{
  int semVal;
  sem_getvalue( &threadWork, &semVal );
  if ( semVal == 0 && vCount > 1 ) {
    return -1;
  }
  sem_wait( &threadWork );
  int newIndex = index;
  if ( first ) {
    return newIndex;
  }
  newIndex = index + increment;
  return newIndex;
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post( &threadWork );
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) 
{
  // Index to start work at
  sem_wait( &valueLock );
  int startIndex = getWork( *( ( int * ) arg ), true );
  sem_post( &valueLock );
  int maxSum = vList[ startIndex ];
  while ( startIndex < vCount ) {
    int sum = 0;
    for ( int j = startIndex; j >= 0; j-- ) {
      sum += vList[ j ];
      maxSum = sum > maxSum ? sum : maxSum;
    }
    sem_wait( &valueLock );
    startIndex = getWork( startIndex, false );
    // Need to make sure vCount is finished adding up
    if ( startIndex >= vCount ) {
      sem_post( &threadWork );
    }
    sem_post( &valueLock );
    if ( startIndex == -1 ) {
      break;
    }
  }
  // Changes max sum
  sem_wait( &valueLock );
  max_sum = maxSum > max_sum ? maxSum : max_sum;
  sem_post( &valueLock );

  // Prints out thread report for max sum
  if ( report ) {
    printf( "I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), maxSum );
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = DEFAULT_WORKERS;
  
  // Parse command-line arguments.
  if ( argc < MIN_ARGS || argc > MIN_ARGS + 1 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == MIN_ARGS + 1 ) {
    if ( strcmp( argv[ MIN_ARGS ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Initialize worker lock to 0
  sem_init( &threadWork, 0, 0 );
  // Initialize max sum lock to 1
  sem_init( &valueLock, 0, 1 );
  // Increments for multiple workers
  increment = workers;
  // Make each of the workers.
  int numArray[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    numArray[ i ] = i;
  }
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    pthread_create( &worker[ i ], NULL, workerRoutine, ( void * ) &numArray[ i ] );
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join( worker[ i ], NULL );
  }
  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  sem_close( &valueLock );
  sem_close( &threadWork );
  return EXIT_SUCCESS;
}
