/**
  * @author Natasha Benson
  * @file reset.c
  * Creates and attaches the shared memory segment for the GameState struct
  * and uploads the information from the text file into the struct
  */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/** Max args for move command */
#define MAX_ARGS 2
/** Index of first newline char */
#define N_INDEX_1 5
/** Index of second newline char */
#define N_INDEX_2 11
/** Index of third newline char */
#define N_INDEX_3 17
/** Index of fourth newline char */
#define N_INDEX_4 23
/** Index of fifth newline char */
#define N_INDEX_5 29
/** Buffer size to hold input file chars */
#define MAX_CHARS 31

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

/**
  * Reeads in the board from the text file and creates shared memory
  * for the board to be updated by user commands
  * 
  * Function based off code in server.c which was completed on 9/15/22
  * @param argc number of arguments run with program
  * @param argv command line arguments
  * @return exit status
  */
int main( int argc, char *argv[] ) {

  // Destroys previous instance of sem
  sem_unlink( "/ngbenso2-lightsout-lock" );

  // Checks that program is run with only 2 arguments
  if ( argc != MAX_ARGS ) {
    usage();
  }

  // Valid file check
  int rfp = open( argv[ 1 ], O_RDONLY );
  if ( rfp == -1 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  // Create shared memory segemnt as instance of GameState
  key_t key = ftok( "/afs/unity.ncsu.edu/users/n/ngbenso2", 'a' );
  int shmID = shmget( key, sizeof( GameState ), 0666 | IPC_CREAT );
  if ( shmID == -1 ) {
    fail( "Can't create shared memory" );
  }
  GameState *sboard = ( GameState * )shmat( shmID, 0 , 0 );
  //sboard = &board;
  if ( sboard == ( GameState * )-1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  // Reads in characters from file
  char boardChars[ MAX_CHARS ];
  int length = read( rfp, boardChars, sizeof( boardChars ) );
  if ( length == 0 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  sem_t *sharedSem = sem_open( "/ngbenso2-lightsout-lock", O_CREAT, 0600, 1 );
  if ( sharedSem == SEM_FAILED ) {
    fail( "Can't open shared semaphore" );
  }

  /* Fills the board diagram within the board struct and checks for invalid
    characters from the file */
  int startIndex = 0;
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      char currentChar = boardChars[ startIndex++ ];
      // Ensures input file only contains valid characters
      if ( currentChar != '.' && currentChar != '*' && currentChar != '\n' ) {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        exit( 1 );
      }
      if ( startIndex == N_INDEX_1 || startIndex == N_INDEX_2 || startIndex == N_INDEX_3 ||
        startIndex == N_INDEX_4 || startIndex == N_INDEX_5 ) {
        startIndex++;
      }
      sboard->boardDiagram[ i ][ j ] = currentChar;
    }
  }

  sboard->moveMade = false;
  close( rfp );
  sem_close( sharedSem );
  return 0;
}
