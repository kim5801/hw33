/**
  * @author Natasha Benson
  * @file lightsout.c
  * Opens shared memory segment for the GameState struct and uses the 
  * uploaded information to perform commands that change the GameState
  */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/** Max number of arguments for move command */
#define MAX_ARGS_MOVE 4
/** Max number of arguments for report and undo */
#define MAX_ARGS_OTHER 2
/** Max number for the row and columns */
#define MAX_RC_NUM 4
/** ASCII to decimal value conversion for numbers */
#define CHAR_TO_DEC 48
/** Bounds for turning multi digit number from char to decimal*/
#define DECIMAL_NINE 9
/** Multiplies by 10 for oonversion */
#define MULT_TEN 10

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Semaphore to enable mutual exclusion when editing board */
sem_t *sharedSem;

/**
  * Switches the lights on the board
  * 
  * Function based off code in client.c which was completed on 9/15/22
  * @param row row number of selected cell
  * @param col column number of selected cell
  * @param board board containing the diagram of the lights
  */
void switchLights( int row, int col, GameState *board )
{
  // Middle square switch
  board->boardDiagram[ row ][ col ] = board->boardDiagram[ row ][ col ] == '*' ? '.' : '*';
  // Left square switch
  if ( col - 1 > -1 ) {
    board->boardDiagram[ row ][ col - 1 ] = board->boardDiagram[ row ][ col - 1 ] == '*' ? '.' : '*';
  }
  // Right square switch
  if ( col + 1 < GRID_SIZE ) {
    board->boardDiagram[ row ][ col + 1 ] = board->boardDiagram[ row ][ col + 1 ] == '*' ? '.' : '*';
  }
  // Top square switch
  if ( row - 1 > - 1 ) {
    board->boardDiagram[ row - 1 ][ col ] = board->boardDiagram[ row - 1 ][ col ] == '*' ? '.' : '*';
  }
  // Bottom square switch
  if ( row + 1 < GRID_SIZE ) {
    board->boardDiagram[ row + 1 ][ col ] = board->boardDiagram[ row + 1 ][ col ] == '*' ? '.' : '*';
  }
}

/**
 * Performs move command on game board
 * @param state game board
 * @param r row number
 * @param c column number
 * @return true if lights switched successfully
 */
bool move( GameState *state, int r, int c )
{
  if ( r < 0 || r > MAX_RC_NUM || c < 0 || c > MAX_RC_NUM ) {
    return false;
  }
  #ifndef UNSAFE
    sem_wait( sharedSem );
  #endif
  switchLights( r, c, state );
  state->lastMove[ 0 ] = r;
  state->lastMove[ 1 ] = c;
  state->moveMade = true;
  #ifndef UNSAFE
    sem_post( sharedSem );
  #endif
  return true;
}

/**
 * Performs the undo command
 * @param state game board
 * @return true if undo command is successfully completed
 */
bool undo( GameState *state )
{
  if ( !state->moveMade ) {
    return false;
  }
  #ifndef UNSAFE
    sem_wait( sharedSem );
  #endif
  // Move is undone and board status for moveMade changed to false
  switchLights( state->lastMove[ 0 ], state->lastMove[ 1 ], state );
  state->moveMade = false;
  #ifndef UNSAFE
    sem_post( sharedSem );
  #endif
  return true;
}

/**
 * Prints out game board
 * @param state game board
*/
void report( GameState *state )
{
  #ifndef UNSAFE
    sem_wait( sharedSem );
  #endif
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", state->boardDiagram[ i ][ j ] );
    }
    printf( "\n" );
  }
  #ifndef UNSAFE
    sem_post( sharedSem );
  #endif
}

/**
 * Test interface to run the move command
 * @param state game board
 * @param n number of times move will be run
 * @param r row number
 * @param c column number
 * @return true if tests run successfully
 */
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }
  return true;
}

/**
  * Opens and attaches the shared memory segment to perform commands
  * and update the game state at the user's request
  * 
  * Function based off code in client.c and server.c which was completed 
  * on 9/15/22
  * @param row row number of selected cell
  * @param col column number of selected cell
  * @param board board containing the diagram of the lights
  * @return exit status
  */
int main( int argc, char *argv[] ) {

  // Open sempaphore 
  sharedSem = sem_open( "/ngbenso2-lightsout-lock", 1 );
  if ( sharedSem == SEM_FAILED ) {
    fail( "Can't open shared semaphore" );
  }

  key_t key = ftok( "/afs/unity.ncsu.edu/users/n/ngbenso2", 'a' );
  int shmID = shmget( key, 0, 0 );
  if ( shmID == -1 ) {
    fail( "Can't create shared memory" );
  }
  GameState *sboard = ( GameState * )shmat( shmID, 0 , 0 );
  if ( sboard == ( GameState * )-1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  // Handles commands from user input by calling helper methods
  if ( argc == MAX_ARGS_MOVE && strcmp( argv[ 1 ], "move" ) == 0 && strlen( argv[ MAX_ARGS_OTHER ] ) == 1 
    && strlen( argv[ MAX_ARGS_OTHER + 1 ] ) == 1 ) {
    // Convert char values to decimal values
    int rowVal = argv[ MAX_ARGS_OTHER ][ 0 ] - CHAR_TO_DEC;
    int colVal = argv[ MAX_ARGS_OTHER + 1 ][ 0 ] - CHAR_TO_DEC;
    if ( move( sboard, rowVal, colVal ) ) {
      printf( "success\n" );
    } else {
      fail( "error" );
    }
  } else if ( argc == MAX_ARGS_OTHER && strcmp( argv[ 1 ], "undo" ) == 0 ) {
    if ( undo( sboard ) ) {
      printf("success\n");
    } else {
      fail( "error" );
    } 
  } else if ( argc == MAX_ARGS_OTHER && strcmp( argv[ 1 ], "report" ) == 0 ) {
    report( sboard );
  } else if ( argc == MAX_ARGS_MOVE + 1 && strcmp( argv[ 1 ], "test" ) == 0
    && strlen( argv[ MAX_ARGS_OTHER + 1 ] ) == 1 && strlen( argv[ MAX_ARGS_MOVE ] ) == 1 ) {
    int length = strlen( argv[ MAX_ARGS_OTHER ] );
    int testNum = 0;
    int val = 1;
    // Converts string to number
    for ( int i = length - 1; i >= 0; i-- ) {
      testNum += ( argv[ MAX_ARGS_OTHER ][ i ] - CHAR_TO_DEC ) * val;
      val *= MULT_TEN;
    }
    int rowVal = argv[ MAX_ARGS_OTHER + 1 ][ 0 ] - CHAR_TO_DEC;
    int colVal = argv[ MAX_ARGS_MOVE ][ 0 ] - CHAR_TO_DEC;
    test( sboard, testNum, rowVal, colVal );
  } else {
    fail( "error" );
  }

  sem_close( sharedSem );
  return 0;
}
