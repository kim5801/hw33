// Height and width of the playing area.
#define GRID_SIZE 5

//my AFS pathname for key construction
#define KEY_PATH "/afs/unity.ncsu.edu/users/s/semoriso"

/** Unity ID semaphore name */
#define SEM_NAME "/semoriso-lightsout-lock"

#include <semaphore.h>

/** The struct used to define a GameState, in which a shared memory segment is stored */
typedef struct {
    bool undone;
    int rowUsed;
    int colUsed;
    char board[GRID_SIZE][GRID_SIZE];
} GameState;