#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Whether or not there's any more input left
bool doneReading = false;

bool doneCalculating = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

//Semaphore to avoid messing up max sum value
sem_t maxSem;

//Semaphore for calling getWork()
sem_t valSem;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//Current spot to read from in input
int workVal = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
  }
  doneReading = true; //signal that the input file has been fully processed
}

int getWork() {
    sem_wait(&valSem);
    if (doneReading && vCount == workVal) {
        return -10; //show the input has been read in and all lines have been processed
    }
    else if (workVal == vCount) {
        return -1; //show the program needs to wait for another line of input
    }
    else {
        workVal++; //increment workVal to show new index to process
    }
    return workVal;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  if (doneCalculating) {
    if (report) {
        int num = pthread_self();
        printf("I'm thread %d. The maximum sum I found is %d\n", num, INT_MIN);
    }
    return NULL;
  }
  int maxSum = INT_MIN; //temp value for max sum
  int val = -1; //place to hold value of getWork
  while (!doneCalculating) { //keep iterating while the list is not complete
    val = getWork();
    sem_post(&valSem);
    while (val == -1) { //wait if no new input to process
        val = getWork(); 
        sem_post(&valSem);
    }
    if (val == -10) {
     doneCalculating = true;
     sem_wait(&valSem);
     val = vCount;
     sem_post(&valSem);
    }
    int tempV = 0;
    for (int j = val; j >= 0; j--) {
        tempV += vList[j];
        if (tempV > maxSum) { //test current maxSum value against newly calc'd
            maxSum = tempV;
        }
    } 
  }
   
   if (report) { //print report if user specified
    int num = pthread_self();
    printf("I'm thread %d. The maximum sum I found is %d\n", num, maxSum);
   }
   if (maxSum > max_sum) { //update thread's max sum if it's bigger than the 'real' max sum
    sem_wait(&maxSem); //ensure max sum global isn't being changed at same time as another thread
    max_sum = maxSum;
    sem_post(&maxSem);
   }

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  
  //Setting up semaphores
  sem_init(&maxSem, 0, 1);
  sem_init(&valSem, 0, 1);
  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) { //start workers
    if ( pthread_create( &worker[i], NULL, workerRoutine, NULL) != 0 ) {
        fail( "Can't create a child thread\n" );
    }
  }
  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }
    
  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
