#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 Struct to hold shared memory info, holds whether or not undo was the last move, the row
 and column of the last move, a flag for shared memory reading/writing, and the game board
 */
struct GameState {
    bool undone;
    int rowUsed;
    int colUsed;
    char board[GRID_SIZE][GRID_SIZE];
};

int main( int argc, char *argv[] ) {
    if (argc != 2) {
        usage();
    }

    // First, destroy any old copies the tag semaphore, just in case
    // a previous execution of this program crashed and left the
    // semaphore in an unknown state.
    sem_unlink(SEM_NAME);

    // Make a shared memory segment size of gamestate struct
    int shmid = shmget( ftok(KEY_PATH, 5), sizeof(struct GameState), 0666 | IPC_CREAT );
    if ( shmid == -1 ) {
        fail( "Can't create shared memory" );
    }
    //create char buffer
    GameState *game = (GameState *)shmat( shmid, 0, 0 );
    if ( game == (GameState *)-1 ) {
        fail( "Can't map shared memory segment into address space" );
    }

    //set row and col to dummy vals since no moves have been made
    game->rowUsed = -1;
    game->colUsed = -1;
    game->undone = false;

    // Make a named semaphore to be shared, intialized to 1, for processes
    sem_t *tagSem = sem_open( SEM_NAME, O_CREAT, 0600, 1);
    if ( tagSem == SEM_FAILED ) {
        fail("Can't make tag semaphore");
    }
    //setting up game board
    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
    }
    for (int i = 0; i < GRID_SIZE; i++) { //read in input file to store in game board
        for (int j = 0; j < GRID_SIZE; j++) {
            read(fd, &(game->board[i][j]), 1);
            if (game->board[i][j] == '\n') {
                read(fd, &(game->board[i][j]), 1);
            }
            if (game->board[i][j] != '*' && game->board[i][j] != '.') {
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
                exit(1);
            }
        }
    }
    close(fd); //close file after use
    
    //release reference to shared mem segment
    shmdt(game);
    
    return 0;
}
