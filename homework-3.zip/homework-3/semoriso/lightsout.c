#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Semaphore to avoid any race conditions */
sem_t *tagSem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 Makes a move at given row and column, prints whether success or failure.
 Also used to undo a previous move if needed
 @param game the shared memory of the game we are accessing
 @param row the row of the move to be made
 @param col the column of the move to be made
 */
static void move(GameState *game, int row, int col) {
    #ifndef UNSAFE
        //wait until semaphore is ready
        sem_wait(tagSem);
    #endif
    if (game->board[row][col] == '*') { //checking at position
        game->board[row][col] = '.';
    }
    else {
        game->board[row][col] = '*';
    }
    if (col != 4) {
        if (game->board[row][col + 1] == '*') { //checking to the right, not going over bounds
            game->board[row][col + 1] = '.';
        }
        else {
            game->board[row][col + 1] = '*';
        }
    }
    if (col != 0) {
        if (game->board[row][col - 1] == '*') { //checking to the left, not going over bounds
            game->board[row][col - 1] = '.';
        }
        else {
            game->board[row][col - 1] = '*';
        }
    }
    if (row != 4) {
        if (game->board[row + 1][col] == '*') { //checking bottom
        game->board[row + 1][col] = '.';
    }
        else {
            game->board[row + 1][col] = '*';
        }
    }
    if (row != 0) {
        if (game->board[row - 1][col] == '*') { //checking top
            game->board[row - 1][col] = '.';
        }
        else {
            game->board[row - 1][col] = '*';
        }
    }
    #ifndef UNSAFE
        //indicate the process can continue
        sem_post(tagSem);
    #endif
}

/** 
 Test interface to make a move over and over
 @param state the given gamestate
 @param n the number of times to iterate through
 @param r the row to move through
 @param c the column to move through
 @return true if successful, false if not 
*/
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
        return false;
    }
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ ) {
        move(state, r, c);
    }
    return true;
}

/**
 Prints 5x5 square of characters showing current state of board
 @param game the shared memory of the game currently in progress
 */
static void report(GameState *game) {
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            printf("%c", game->board[i][j]);
        }
        printf("\n");
    }
}

int main( int argc, char *argv[] ) {
    //check command line args # validity
    if (argc < 2 || (argc > 2 && (strcmp(argv[1], "move") != 0 
        && strcmp(argv[1], "test") != 0))) {
        fail("usage: reset <board-file>");
    }
    //ensure client calls for one of 3 valid commands
    if (strcmp(argv[1], "move") != 0 && strcmp(argv[1], "report") != 0 && 
        strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "test") != 0) {
        fail("error");    
    }
    //error check other command line vals before sending to server
    if (strcmp("move", argv[1]) == 0) { //if move was entered
        if (argc != 4) { //checking command line #s
            printf("error\n");
            return -1;
        }
        if (*argv[2] < '0' || *argv[2] > '4' || *argv[3] < '0' || *argv[3] > '4') { //in bounds check
            printf("error\n");
            return -1;
        } 
    }
    else if (strcmp(argv[1], "test") == 0 && argc != 5) {
        printf("error\n");
        return -1;
    }
    else if (argc != 2 && strcmp(argv[1], "test") != 0) { //make sure undo and report stand alone
        printf("error\n");
        return -1;
    }
    int shmid = shmget( ftok(KEY_PATH, 5), sizeof(GameState), 0666 );
    if ( shmid == -1 ) {
        fail( "Can't create shared memory" );
    }
    //read in game state from shared memory
    GameState *game = (GameState *)shmat( shmid, 0, 0 );
    if ( game == (GameState *)-1 ) {
        fail( "Can't map shared memory segment into address space" );
    }
    //try to open semaphore already created in reset
    tagSem = sem_open(SEM_NAME, 1);
    if (tagSem == SEM_FAILED) {
        fail( "Can't open tag semaphore" );
    }
    
    if (strcmp(argv[1], "undo") == 0) { //undo command
        if (game->undone || game->rowUsed == -1 || game->colUsed == -1) { //cannot undo twice
            printf("error\n");
        }
        else {
            move(game, game->rowUsed, game->colUsed);
            game->undone = true;
            printf("success\n");
        }
    }
    else if (strcmp(argv[1], "move") == 0) {
       int row = -1;
       int col = -1;
       sscanf(argv[2], "%d", &row);
       sscanf(argv[3], "%d", &col);
       if (row == -1 || col == -1) { //check to see if values were changed
            printf("error\n");
       }
       else {
            move(game, row, col);
            game->undone = false; //undo = not last move
            //set last used row/col to args
            game->rowUsed = row;
            game->colUsed = col;
            printf("success\n");
       }
    }
    else if (strcmp(argv[1], "report") == 0) {
        report(game);
    }
    else if (strcmp(argv[1], "test") == 0) {
       int n = -1;
       int row = -1;
       int col = -1;
       sscanf(argv[2], "%d", &n);
       sscanf(argv[3], "%d", &row);
       sscanf(argv[4], "%d", &col);
       if (n == -1 || row == -1 || col == -1) { //check to see if values were changed
            printf("error\n");
       }
       else {
        bool val = test(game, n, row, col);
        if (!val) {
            printf("failed test\n");
        }   
       }
    }
    else { //invalid command
        printf("error\n");
    }
    //close the semaphore
    sem_close(tagSem);
    // Release our reference to the shared memory segment.
    shmdt( game );

  return 0;
}
