#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/**
 * File makes the shared memory segment, loads the initial
 * board state, and then exits
 */

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

int main( int argc, char *argv[] ) {
    // create game struct to be sent to memory
    GameState state;

    sem_unlink("/kepolcho-lightsout-lock");
    // create semaphore that can be shared across processes
    sem_t *lock = sem_open("/kepolcho-lightsout-lock", O_CREAT, 0600, 1);

    // check that it was successful
    if (lock == SEM_FAILED) {
        fail("Failed to create lock");
    }
    // error checking for files

    // check for valid # of arguments
    if (argc != 2) {
        usage();
    }

    // check if file is valid
    
    FILE *inputFile = fopen(argv[1], "r");
    if (inputFile == NULL) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(EXIT_FAILURE);
    }

    // read in from file, populate board
    char curr = fgetc(inputFile);
    int row = 0;
    int col = 0;

    // make the board from file, checking if valid while
    // reading in from file
    while (curr != EOF) {
        if (curr == '*' || curr == '.') {
            state.board[row][col] = curr;
            // increment column to the right
            col++;
        }
        else if (curr == '\n' && col == 5) { // check if at end of column
            row++;
            col = 0;
        }
        else { // file is invalid
            fprintf(stderr, "Invalid input file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
        }

        // check if the values exceed valid amounts
        if (col > GRID_SIZE || (row > MAX_LEN && curr != EOF && curr != '\n')) {
            fprintf(stderr, "Invalid input file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
        }

        // advance
        curr = fgetc(inputFile);
    }

    // check if it's valid, check last char
    if (state.board[MAX_LEN][MAX_LEN] != '*' && state.board[MAX_LEN][MAX_LEN] != '.') {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(EXIT_FAILURE);
    }

    // establish basic value for the state
    state.undoValid = false;

    // create the shared memory segment the size of a 
    // GameState struct
    
    // create the key for shared memory
    // key ID is lightsout, no spaces    

    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/k/kepolcho", 5), sizeof(state), 0666 | IPC_CREAT);

    // check if it was created
    if (shmid == -1) {
        fail("Failed to make shared memory");
    }

    GameState *gbuffer = (GameState *)shmat(shmid, 0, 0);
    if (gbuffer == (GameState *)-1) {
        fail("Can't map shared memory segment into address space");
    }
    // set gbuffer to hold state
    *gbuffer = state;

    return 0;
}
