#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include "common.h"

/**
 * Program interprets user commands from the command line
 * and makes changes as needed. Uses the shared memory made
 * by reset to store the current board and last move.
 */

sem_t *lock;

// Print out an error message and exit.
static void fail(char *errMessage) {
    fprintf(stdout, "%s\n", errMessage);
    exit(EXIT_FAILURE);
}

// change the value, used to adjust board
static void swapChars(char *current) {
  if (*current == '.') {
    *current = '*';
  }
  else {
    *current = '.';
  }
}

static int numeric(char *num) {
    return atoi(num);
}

/**
 * update the board, the impacted pieces are centered at 
 * r,c. 
 *
 * Note: pieces directly touching the noted piece are
 * flipped as well.
 */
bool move(int r, int c, GameState *state) {
    #ifndef UNSAFE
        sem_wait(lock);
    #endif
    // wait for it to be released
    

    // check that r and c are valid values
    if (r < 0 || r > MAX_LEN || c < 0 || c > MAX_LEN) {
        fail("Invalid row or column");
    }

    // store last move into state
    state->lastMove[0] = r;
    state->lastMove[1] = c;

    // update spot selected
    swapChars(&state->board[r][c]);

    // check edge locations before changing
    if (r != 0) { // change row above
        swapChars(&state->board[r - 1][c]);
    }
    if (r != MAX_LEN) { // change row below
        swapChars(&state->board[r + 1][c]);
    }
    if (c != 0) { // change left column
        swapChars(&state->board[r][c - 1]);
    }
    if (c != MAX_LEN) { // change right column
        swapChars(&state->board[r][c + 1]);
    }
    
    state->undoValid = true;

    // done with lock, release it
    #ifndef UNSAFE
        sem_post(lock);
    #endif 
    
    return true;
}

/**
 * undo the last move done - last move should have been saved
 * in the shared memory.
 */
bool undo(GameState *state) {
    #ifndef UNSAFE
        sem_wait(lock);
    #endif

    if (state->undoValid) {
        // undo the last move
        move(state->lastMove[0], state->lastMove[1], state);
        state->undoValid = false;  
        printf("success");
    }
    else {
        fail("Undo failed.");
    }    
    
    // done with lock, release it
    #ifndef UNSAFE
        sem_post(lock);
    #endif 

    return true;
}

/**
 * Print out the current board from shared memory
 */
void report(GameState *state) {
    #ifndef UNSAFE
        sem_wait(lock);
    #endif

    for (int r = 0; r < GRID_SIZE; r++) {
        // print out each spot in the board
        for (int c = 0; c < GRID_SIZE; c++) {
            printf("%c", state->board[r][c]);
        }
        // print new line to account for next
        // line in board
        printf("\n");
    }

    // done with lock, release it
    #ifndef UNSAFE
        sem_post(lock);
    #endif    
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    // if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    //     return false;
    // }
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ ) {
        move(r, c, state);
    }
    return true;
}


int main( int argc, char *argv[] ) {
    // open the lock so everything can access it!
    lock = sem_open("/kepolcho-lightsout-lock", 0);

    // starting board should have already been created
    // and is stored in shared memory with lightsout
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/k/kepolcho", 5), 0, 0);
    if (shmid == -1) {
        fail("Can't create shared memory");
    }

    // get board from shared memory
    GameState *sbuffer = (GameState *)shmat(shmid, 0, 0);
    if (sbuffer == (GameState *)-1) {
        fail("Can't map shared memory segment into address space");
    }

    // read user input on what command to run
    if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            fail("Invalid number of arguments");
        }

        // convert arguments into integers, error checking
        // handled in numeric
        int row = numeric(argv[2]);
        int col = numeric(argv[3]);
        move(row, col, sbuffer);        
        printf("success\n");
    }
    else if(strcmp(argv[1], "undo") == 0) {
        undo(sbuffer);
    }
    else if(strcmp(argv[1], "report") == 0) {
        report(sbuffer);
    }
    else if (strcmp(argv[1], "test") == 0) {
        if (argc != 5) {
            fail("Invalid number of args");
        }

        // pass arguments to test function
        int n = numeric(argv[2]);
        int row = numeric(argv[3]);
        int col = numeric(argv[4]);

        test(sbuffer, n, row, col);
    }
    else {
        fail("Invalid command");
    }

    
  return 0;
}
