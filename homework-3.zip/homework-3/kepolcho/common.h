// Height and width of the playing area.
#define GRID_SIZE 5
// max value for an row/column
#define MAX_LEN 4
// max length of a command
#define MESSAGE_LIMIT 1024

/**
 * Struct used to track board and other information
 * across itertions of lightsout, storing it into
 * the shared memory created by the reset file.
 */
typedef struct GameState_Struct {
    // track the current board
    char board[5][5];
    // last move done
    int lastMove[2];
    // flag to know if undo can be used or not
    bool undoValid;    
} GameState;
