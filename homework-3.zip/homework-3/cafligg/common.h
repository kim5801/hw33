// Height and width of the playing area.
#define GRID_SIZE 5

//the key to access the shared memory
#define SM_KEY ftok("/afs/unity.ncsu.edu/users/c/cafligg", 0)

#define SEM_NAME "/cafligg-lightsout-lock" 

typedef struct GameState {
  char board[GRID_SIZE*GRID_SIZE];
  char cord[2];
  bool undo;
} GameState;