#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <semaphore.h>
#include "common.h"

sem_t *mySemaphore;

// Print out the error message and exit.
static void fail() {
  printf("error\n");
  exit(1);
}

//the success ending
static void succeed() {
  printf("success\n");
}


//flip a bit
// we flipped the order of rows and columns because the data is stored backwards
void flip(char *board, int c, int r) {
  board[r+GRID_SIZE*c] = !board[r+GRID_SIZE*c];
  if(r-1 >= 0) { //bounds check
    board[r-1+GRID_SIZE*c] = !board[r-1+GRID_SIZE*c]; //assignment
  }
  if(r+1 < GRID_SIZE) { 
    board[r+1+GRID_SIZE*c] = !board[r+1+GRID_SIZE*c];
  }
  if(c-1 >= 0) {
    board[r+GRID_SIZE*(c-1)] = !board[r+GRID_SIZE*(c-1)];
  }
  if(c+1 < GRID_SIZE) {
    board[r+GRID_SIZE*(c+1)] = !board[r+GRID_SIZE*(c+1)]; 
  }
}


//new move function to move a var in named state
bool move(GameState *state, int r, int c) {

  if(r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE) { //no out of bounds errors please
    return false;
  }

  #ifndef UNSAFE
    sem_wait( mySemaphore );
  #endif
  flip(state->board, r, c); //move
  state->undo = true;
  state->cord[0] = r; //store our move
  state->cord[1] = c;   
  #ifndef UNSAFE
    sem_post( mySemaphore );
  #endif   
  return true;
  
  
}

bool undo(GameState *state) {
  #ifndef UNSAFE
    sem_wait( mySemaphore );
  #endif
  if(state->undo) { //if our last char is set then we are able to undo
    flip(state->board, state->cord[0], state->cord[1]); //an undo is just a flip
    state->undo = false; // we used up the undo
    #ifndef UNSAFE
      sem_post( mySemaphore );
    #endif
    return true;
  } else {
    #ifndef UNSAFE
      sem_post( mySemaphore );
    #endif
    return false;
  }
}

//reports the game state
void report(GameState *state) {
  #ifndef UNSAFE
    sem_wait( mySemaphore );
  #endif
  for(int i = 0; i < GRID_SIZE*GRID_SIZE; i++) {
      if(i != 0 && i % 5 == 0) {
        putchar('\n'); //our board is not stored in 2D array in memory so create appearance on printing
      }
      if(state->board[i] == 1) { //on
        putchar('*');
      } else { //off
        putchar('.');
      }
    }
  putchar('\n');
  
  #ifndef UNSAFE
    sem_post( mySemaphore );
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
// Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  
  return true;
}

//make sure a given number is a digit
void validateDigits(char *arg) {
  for(char *val = arg; *val != 0; val++) {
    if(!isdigit(*val)) {
      fail();
    }
  }
}



//main runtime
int main( int argc, char *argv[] ) {
  //setup access to shared memory
  int shmid = shmget(SM_KEY, sizeof(GameState), 0);
  //the access point
  GameState *state = (GameState *)shmat(shmid, 0, 0);

  mySemaphore = sem_open(SEM_NAME, O_EXCL); //maybe need flags TODO

  //criteria for undo command
  if(argc == 2 && strcmp(argv[1], "undo") == 0) {
    undo(state) ? succeed() : fail();
  //criteria for reporting
  } else if(argc == 2 && strcmp(argv[1], "report") == 0) {
    report(state);
    //criteria for a move command
  } else if(argc == 4 && strcmp(argv[1], "move") == 0) {
    //Valid that the arguments are actually numbers prior to conversion
    validateDigits(argv[2]);
    validateDigits(argv[3]);
    //end integer validation

    move(state, atoi(argv[2]), atoi(argv[3]))? succeed() : fail();

  } else if(argc == 5 && strcmp(argv[1], "test") == 0) {
    validateDigits(argv[2]);
    validateDigits(argv[3]);
    validateDigits(argv[4]);

    test(state, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
  } else {
    fail();
  }


  return 0;
}
