#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

//current index that has been assigned to a thread
int volatile currentIndex = 0;

//semaphore to prevent race condition in indexing
sem_t index_lock;

//determines if we are finished processing input
bool volatile done = false;


// True if we're supposed to report what we find.
bool report = false;

//number of workers
int workers = 4;


// Maximum sum we've found.
int max_sum = INT_MIN;

//controls accessing the max_sum
sem_t max_access;

//semaphore if there is more work to do
sem_t more_to_do;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//gets work for our threads
int getWork() {
  if(!done) { //if we are done we don't need to wait for new variables in the queue
    sem_wait(&more_to_do);
  }
  sem_wait(&index_lock); //make sure we are not increasing the index lock simulatiously
  if(currentIndex >= vCount) { //if we run out of indexes end the thread
    sem_post(&index_lock);
    return -2;
  }

  currentIndex++;
  sem_post(&index_lock);
  return currentIndex-1;
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&more_to_do);
  }

  done = true;
  for(int i = 0; i <= workers; i++) { //now that we are done notify any sleeping workers
    sem_post(&more_to_do);
  }

}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // ...
  int bestsum = INT_MIN;
  int work;
  while( (work = getWork()) != -2 ) { //get work from the work function
    int sum = 0;
    for(int i = work; i >= 0; i--) {       // logic to calculate sum
      sum += vList[i];
      if(sum > bestsum) {
        bestsum = sum;
      }
    }
  }

  if(report) { //report our process id and the max sum
    printf("I'm process %ld. The maximum sum I found is %d\n", pthread_self(), bestsum);
  }

  //compare to max
  sem_wait(&max_access); //access max when it is not race conditionable
  if(bestsum > max_sum) {
    max_sum = bestsum;
  }
  sem_post(&max_access);
  

  return NULL;
}

int main( int argc, char *argv[] ) {

  sem_init(&index_lock, 0, 1); //init our semaphores
  sem_init(&max_access, 0, 1);
  sem_init(&more_to_do, 0, 0);

  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();


  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    // ...
    pthread_create(&worker[i], NULL, workerRoutine, NULL);
  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    // ...
    //printf("Closing thread %d\n", i);
    pthread_join(worker[i], NULL);
  }
  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  

  sem_destroy(&index_lock); //destroy our semaphores
  sem_destroy(&max_access);
  sem_destroy(&more_to_do);
  return EXIT_SUCCESS;
}
