// Height and width of the playing area.
#define GRID_SIZE 5
//Name of the global semaphore
#define SEM_NAME "/bperdig-lightsout-lock"
