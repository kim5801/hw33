#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message) {
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage() {
    printf("usage: maxsum-sem <workers>\n");
    printf("       maxsum-sem <workers> report\n");
    exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

//Semaphore to block the max_sum variable from being changed by multiple threads at once.
sem_t sum_lock;

//The current index that is being processed by a thread.
int currIdx = 0;

//A semaphore that does not let an index be increased multiple times
sem_t idx_lock;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
    // Keep reading as many values as we can.
    int v;
    while (scanf( "%d", &v) == 1 ) {
        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");

    // Store the latest value.
    vList[vCount++] = v;
    }
}

/**
 * Function that keeps the threads busy while there is no work to be done.
 * If there is no work to be done, returns -1. Otherwise, it increases the current index,
 * and gives the thread the previous index that was stored in the global variable,
 * because it can now be worked on.
 */
int getWork() {

    if (currIdx >= vCount) {
        return -1;
    }
    sem_wait(&idx_lock);
    if (currIdx >= vCount) {
        sem_post(&idx_lock);
        return -1;
    }
    currIdx++;
    sem_post(&idx_lock);
    return currIdx - 1;


}
/** Start routine for each worker. */
void *workerRoutine(void *arg) {

    int startIdx = *((int *) arg);
    int max = INT_MIN;
    int final = max;
    restartLoop:
    //The thread waits while all of the values necessary to calculate the sums it has been given have been read.
    while (startIdx = getWork(), startIdx < 0) {
        if (currIdx > startIdx) {
            startIdx = currIdx;
        }
    }
    if (vList[startIdx] != INT_MAX) {
        max = vList[startIdx];
        int sum = 0;

        for (int i = 0; startIdx - i >= 0; i++) {
            sum += vList[startIdx - i];
            if (sum > max)
                max = sum;
        }
        sum = 0;

        sem_wait(&sum_lock);
        if (max > max_sum)
            max_sum = max;

        sem_post(&sum_lock);
        if (max > final)
            final = max;

        goto restartLoop;
    }
    currIdx--;
    if(report)
        printf("I'm thread %lu. The maximum sum I found is %d\n", pthread_self(), final);

    return NULL;
}

int main(int argc, char *argv[]) {
    int workers = 4;

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1)
        usage();

    // If there's a second argument, it better be "report"
    if (argc == 3) {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    sem_init(&sum_lock, 0, 1);
    sem_init(&idx_lock, 0, 1);

    // Make each of the workers.
    pthread_t worker[workers];
    for (int i = 0; i < workers; i++) {
        // int idx = workers - i;
        if (pthread_create(worker + i, NULL, workerRoutine, &i) != 0)
            fail("Cannot create a child thread.");
    }

    // Then, start getting work for them to do.
    readList();
    //Inserts dummy value at the end of a list to indicate the end of input.
    vList[vCount++] = INT_MAX;

    // Wait until all the workers finish.
    for (int i = 0; i < workers; i++)
        pthread_join(worker[i], NULL);

    // Report the max product and release the semaphores.
    printf("Maximum Sum: %d\n", max_sum);
    sem_destroy(&sum_lock);
    sem_destroy(&idx_lock);

    return EXIT_SUCCESS;
}
