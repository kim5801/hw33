#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

sem_t *mySemaphore;

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

//Struct with the board information.
typedef struct GameStateStruct {
    char grid[GRID_SIZE][GRID_SIZE];
    int lastX;
    int lastY;
}GameState;

/**  Function to make a move on the board, toggling the lights on or off based on their
  *  previous state.
  */
static void toggleLights(GameState* b, int x, int y) {

    //Toggles the desired location on the grid.
    (b->grid[x][y] == '.') ? (b->grid[x][y] = '*') : (b->grid[x][y] = '.');

    //All subsequent checks toggle the positions adjacent to the desired location if it exists.
    if (x + 1 < GRID_SIZE) {
        (b->grid[x + 1][y] == '.') ? (b->grid[x + 1][y] = '*') : (b->grid[x + 1][y] = '.');
    }
    if (x - 1 >= 0) {
        (b->grid[x - 1][y] == '.') ? (b->grid[x - 1][y] = '*') : (b->grid[x - 1][y] = '.');
    }

    if (y + 1 < GRID_SIZE) {
        (b->grid[x][y + 1] == '.') ? (b->grid[x][y + 1] = '*') : (b->grid[x][y + 1] = '.');
    }

    if (y - 1 >= 0) {
        (b->grid[x][y - 1] == '.') ? (b->grid[x][y - 1] = '*') : (b->grid[x][y - 1] = '.');
    }
}

/**
 * Function to make a move on the board, takes the board itself and the x and y
 * (represented by r (row) and c (column)) as parameters to make the move.
 * Returns true if the move was successful, and false otherwise.
 */
bool move(GameState *state, int r, int c) {
    //Must be numbers between 0 and 4
    if (r < 0 || r > GRID_SIZE - 1 || c < 0 || c > GRID_SIZE - 1)
        return false;

    //Acquires the semaphore if the UNSAFE macro has not been used
    #ifndef UNSAFE
        sem_wait(mySemaphore);
    #endif

    //Makes the move with the values received.
    toggleLights(state, r, c);

    //Last move is updated to reflect this move.
    state->lastX = r;
    state->lastY = c;

    //Releases the semaphore
    sem_post(mySemaphore);

    return true;
}

/**
 * Function that prints the current board.
 */
void report(GameState *state) {

    //Acquires the semaphore if the UNSAFE macro has not been used
    #ifndef UNSAFE
        sem_wait(mySemaphore);
    #endif

    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++)
            printf("%c", state->grid[i][j]);

        printf("\n");
    }
    printf("\n");

    //Releases the semaphore
    sem_post(mySemaphore);
}

/**
 * Function that undoes the previous move made by the player.
 * Can only undo a move that has been done, and cannot undo multiple moves in a row.
 * Returns true if the move was properly undone, and false otherwise.
 */
bool undo(GameState *state) {
    //A value of -1 means that either this is the first move or the previous move was an undo.
    if (state->lastX == -1 || state->lastY == -1)
        return false;

    else {
        //Acquires the semaphore if the UNSAFE macro has not been used
        #ifndef UNSAFE
            sem_wait(mySemaphore);
        #endif

        toggleLights(state, state->lastX, state->lastY);
        state->lastX = -1;
        state->lastY = -1;

        //Releases the semaphore
        sem_post(mySemaphore);

        return true;
    }
}

// Test interface, for quickly making a given move over and over.
bool test(GameState *state, int n, int r, int c) {
    // Make sure the row / colunn is valid.
    if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
        return false;

    // Make the same move a bunch of times.
    for (int i = 0; i < n; i++)
        move(state, r, c);

    return true;
}

int main(int argc, char *argv[]) {

    //Lightsout only takes 2 arguments
    if (argc < 2)
        fail("error");

    //Gets the location of the existing shared memory space created by the reset program.
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/b/bperdig", 2), sizeof(GameState), 0);

    //Opens the semaphore created by reset.c
    mySemaphore = sem_open(SEM_NAME, 1);

    //Creates a buffer to read and write to/from the shared memory
    GameState *b = (GameState *)shmat(shmid, 0, 0);

    if (strcmp(argv[1], "move") == 0) {
        //move must be accompanied by 2 numbers representing the position to receive the move
        if(argc == 4) {
            //Must be single digit numbers
            if (strlen(argv[2]) == 1 && strlen(argv[3]) == 1) {
                int x, y;
                x = argv[2][0] - '0';
                y = argv[3][0] - '0';

                if (move(b, x, y))
                    printf("success\n");
                else
                    fail("error");
            }
            else
                fail("error");
        }
        else
            fail("error");
    }

    else if (strcmp(argv[1], "report") == 0) {
        //report does not accept any extra arguments
        if (argc == 2)
            report(b);

        else
            fail("error");
    }

    else if (strcmp(argv[1], "undo") == 0) {
        //undo does not accept any extra arguments
        if (argc == 2) {
            if(undo(b))
                printf("success\n");

            else
                fail("error");
        }

        else
            fail("error");
    }

    else if (strcmp(argv[1], "test") == 0) {
        if(argc == 5) {
            //Must be single digit numbers
            if (strlen(argv[3]) == 1 && strlen(argv[4]) == 1) {
                int x, y, n;
                x = argv[3][0] - '0';
                y = argv[4][0] - '0';

                n = atoi(argv[2]);
                if (n > 0) {
                    if(!test(b, n, x, y))
                        fail("error");
                }

                else
                    fail("error");
            }

            else
                fail("error");
        }
        else
            fail("error");
    }

    //Detaches the program from the shared memory but leaves it there.
    shmdt(b);

    return 0;
}
