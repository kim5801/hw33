#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Semaphore used to prevent race condition on GameState
sem_t *state_lock;

// Boolean determining if the semaphore should be used
bool use_sem;

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Fail with the generic message "error"
static void error()
{
  fail("error");
}

// Toggle a bulb and the surrounding lights. Used by move and undo
static void toggle(GameState *s, int row, int column)
{
  s->board[row][column] = !s->board[row][column];
  if (row != 0) {
    s->board[row - 1][column] = !s->board[row - 1][column];
  }
  if (column != 0) {
    s->board[row][column - 1] = !s->board[row][column - 1];
  }
  if (row != (s->size - 1)) {
    s->board[row + 1][column] = !s->board[row + 1][column];
  }
  if (column != (s->size - 1)) {
    s->board[row][column + 1] = !s->board[row][column + 1];
  }
}

// Make a move on the board, store information in the struct to allow the move
// to be undone
static bool move(GameState *s, int row, int column)
{
  if (use_sem)
    sem_wait(state_lock);

  bool rtn;

  if (column >= 0 && column < GRID_SIZE && row >= 0 && row < GRID_SIZE) {
    s->last_row = row;
    s->last_column = column;
    s->undo = true;
    toggle(s, row, column);
    rtn = true;
  }
  rtn = false;

  if (use_sem)
    sem_post(state_lock);

  return rtn;
}

// Undo the last move, return error if the move cannot be undone
static bool undo(GameState *s)
{
  if (use_sem)
    sem_wait(state_lock);

  bool rtn;

  if (s->undo) {
    s->undo = false;
    toggle(s, s->last_row, s->last_column);
    rtn = true;
  }
  rtn = false;

  if (use_sem)
    sem_post(state_lock);

  return rtn;
}

// Method to print the board in the GameState struct to a string
static char *boardString(GameState *s)
{
  if (use_sem)
    sem_post(state_lock);

  char *str = calloc(GRID_SIZE * GRID_SIZE * 2, sizeof(char));
  int count = 0;
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      if (s->board[i][j]) {
        str[count++] = '*';
      } else {
        str[count++] = '.';
      }
    }
    str[count++] = '\n';
  }

  if (use_sem)
    sem_post(state_lock);

  return str;
}

// Test interface, for quickly making a given move over and over.
static bool test(GameState *state, int n, int r, int c)
{
  // Make sure the row / colunn is valid.
  if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
    return false;
  // Make the same move a bunch of times.
  for (int i = 0; i < n; i++)
    move(state, r, c);
  return true;
}

int main(int argc, char *argv[])
{
  use_sem = false;
// Set a variable telling the program to use the semaphore if compiled without
// defining UNSAFE
#ifndef UNSAFE
  use_sem = true;
#endif

  if (argc < 2) {
    error();
  }

  // Open shared memory and state in shared memory
  int key = ftok(MEM_NAME, 0);
  int shmid = shmget(key, sizeof(GameState), 0);
  if (shmid == -1)
    fail("Can't create shared memory");

  GameState *s = (GameState *)shmat(shmid, 0, 0);
  if (s == (GameState *)-1)
    fail("Can't map shared memory segment into address space");

  // Open semaphore
  if (use_sem)
    state_lock = sem_open(SEM_NAME, 0x00);

  // If statement for each command
  if (strcmp(argv[1], "move") == 0) {
    if (argc != 4) {
      error();
    }
    // Get the row and column and convert to int
    int row = argv[2][0] - '0';
    int col = argv[3][0] - '0';

    // Ensure the x and y values are with-in bounds and no extra input is given
    if (col < 0 || col > GRID_SIZE - 1 || row < 0 || row > GRID_SIZE - 1 ||
        argv[2][1] || argv[3][1]) {
      error();
    }

    if (move(s, row, col)) {
      printf("success\n");
    } else {
      error();
    }

  } else if (strcmp(argv[1], "undo") == 0) {
    // Ensure no more arguments are given
    if (argc != 2) {
      error();
    }

    if (undo(s)) {
      printf("success\n");
    } else {
      error();
    }

  } else if (strcmp(argv[1], "report") == 0) {
    // Ensure no more arguments are given
    if (argc != 2) {
      error();
    }
    printf("%s", boardString(s));

  } else if (strcmp(argv[1], "test") == 0) {
    if (argc != 5) {
      error();
    }

    // Use strtol to get the number of test to run
    int test_num = (int)strtol(argv[2], NULL, 10);
    // Get the row and column and convert to int
    int row = argv[3][0] - '0';
    int col = argv[4][0] - '0';

    // Ensure the x and y values are with-in bounds and no extra input is given
    if (col < 0 || col > GRID_SIZE - 1 || row < 0 || row > GRID_SIZE - 1 ||
        argv[3][1] || argv[4][1]) {
      error();
    }

    if (test(s, test_num, row, col)) {
      printf("success\n");
    } else {
      error();
    }

  } else {
    // Exit the program with an error if one of the above commands is not given
    error();
  }

  shmdt(s);

  // Close semaphore
  if (use_sem)
    sem_close(state_lock);

  return 0;
}
