#include <stdbool.h>
// Height and width of the playing area.
#define GRID_SIZE 5

#define SEM_NAME "/jdlawren-lightsout-lock"
#define MEM_NAME "/afs/unity.ncsu.edu/users/j/jdlawren"

typedef struct {
  bool board[GRID_SIZE][GRID_SIZE];
  bool undo;
  int size;
  int last_row;
  int last_column;
} GameState;
