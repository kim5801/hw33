#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum-sem <workers>\n");
  printf("       maxsum-sem <workers> report\n");
  exit(1);
}

// Semaphore used to restrict access to the global max sum variable to prevent
// race conditions
sem_t maxSumAccess;
// Semaphore used to restrict provisioning work to thread if there is no input
// to work on
sem_t input;
// Semaphore used to restrict access to the work provisioning method to prevent
// race conditions
sem_t lock;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// Index that the program is working on
int workingIndex = 0;

// Variable to determine if the program is done reading input
bool doneReading = false;
// Variable to determine if the program is done processing max sums
bool doneWorking = false;

// Read the list of values.
void readList()
{
  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1) {
    // Make sure we have enough room, then store the latest input.
    if (vCount > MAX_VALUES)
      fail("Too many input values");

    // Store the latest value.
    vList[vCount++] = v;
    sem_post(&input);
  }
  doneReading = true;
  sem_post(&input);
}

// Provision work to each of the threads
int getWork()
{
  sem_wait(&input);

  if (!doneWorking) {
    // Return the next thread that needs work, locked to prevent race condition
    sem_wait(&lock);
    int rtn = ++workingIndex;
    // Determine if the program is done working
    if (doneReading && workingIndex + 1 >= vCount) {
      doneWorking = true;
      sem_post(&input);
    }
    sem_post(&lock);
    return rtn;
  } else {
    // Return -1 if no work, free any waiting threads
    sem_post(&input);
    return -1;
  }
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
  // Max sum found by worker
  int wMax = 0;

  // Loop to compute max sums while work is available
  while (!doneWorking) {
    // Get work from provisioning function, break if no work is available
    int val = getWork();
    if (val == -1) {
      break;
    }

    // Compute all sums ending in the given value
    int sum = 0;
    for (int i = val; i >= 0; i--) {
      sum += vList[i];
      if (sum > wMax) {
        wMax = sum;
      }
    }
  }

  // Set the global max sum if wMax is larger than the global max
  sem_wait(&maxSumAccess);
  if (wMax > max_sum) {
    max_sum = wMax;
  }
  sem_post(&maxSumAccess);

  // Report pid and maximum sum if report option is given
  if (report) {
    printf("I'm thread %ld. The maximum sum I found is %d. \n", syscall(SYS_gettid),
           wMax);
  }

  return NULL;
}

int main(int argc, char *argv[])
{
  int workers = 4;

  // Initialize semaphores
  sem_init(&maxSumAccess, 0, 1);
  sem_init(&input, 0, 0);
  sem_init(&lock, 0, 1);

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1)
    usage();

  // If there's a second argument, it better be "report"
  if (argc == 3) {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[workers];
  for (int i = 0; i < workers; i++)
    pthread_create(&worker[i], NULL, workerRoutine, NULL);

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for (int i = 0; i < workers; i++)
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf("Maximum Sum: %d\n", max_sum);

  return EXIT_SUCCESS;
}
