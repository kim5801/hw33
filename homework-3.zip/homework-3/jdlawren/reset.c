#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Semaphore used by the program
sem_t *sem;

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Print out a usage message and exit.
static void usage()
{
  fprintf(stderr, "usage: reset <board-file>\n");
  exit(1);
}

// Create the board in the lights struct when given a file
static void readFile(GameState *s, char *file)
{
  FILE *fp = fopen(file, "r");
  if (fp == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", file);
    exit(1);
  }

  char test;
  for (int i = 0; i < s->size; i++) {
    for (int j = 0; j < s->size; j++) {
      test = fgetc(fp);
      if (test == '.') {
        s->board[i][j] = false;
      } else if (test == '*') {
        s->board[i][j] = true;
      } else {
        fclose(fp);
        fprintf(stderr, "Invalid input file: %s\n", file);
        exit(1);
      }
    }
    test = fgetc(fp);
    if (test != '\n') {
      fclose(fp);
      fprintf(stderr, "Invalid input file: %s\n", file);
      exit(1);
    }
  }
}

int main(int argc, char *argv[])
{

  if (argc != 2) {
    usage();
  }

  // Create section of shared memory
  int key = ftok(MEM_NAME, 0);
  int shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
  if (shmid == -1)
    fail("Can't create shared memory");

  GameState *s = (GameState *)shmat(shmid, 0, 0);
  if (s == (GameState *)-1)
    fail("Can't map shared memory segment into address space");

  // Unlink existing semaphore and create new one
  sem_unlink(SEM_NAME);
  sem = sem_open(SEM_NAME, O_CREAT, 0666, 1);

  // Read File
  s->size = GRID_SIZE;
  readFile(s, argv[1]);

  // Close shared memory and semaphore
  shmdt(s);
  sem_close(sem);
  return 0;
}
