/*
   Uses shared memory with lightsout.c, creates and attaches shared memory and populates the board from a given file in the command arguments, and creates a semaphore to limit access to the shared memory.
   @file reset.c
   @author Madeline Snyder (mdsnyde3)
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out an error message and exit.
static void failFile ( char const *message ) {
  fprintf( stderr, "Invalid input file: %s\n", message );
  exit( 1 );
}

// Declare the semaphore
sem_t *lock;

// Main method, checks the command line arguments, makes the shared memory, and populates the board
int main( int argc, char *argv[] ) {
  // Destroy old copies of the named semaphore
  sem_unlink( SEM_NAME );
  
  // Create the named semaphore
  lock = sem_open( SEM_NAME, O_CREAT, 0600, 1 );
  if( lock == SEM_FAILED ) {
    fail( "Cannot create named semaphore" );
  }
  
  // If we don't have exactly two command line arguments, this is invalid
  if( argc != 2 ) {
    fail( "usage: reset <game-state-file>" );
  }
  // Open the file
  FILE *fp = fopen( argv[ 1 ], "r" );
  char ch;
  // Check for an invalid file
  if( !fp ) {
    failFile( argv[ 1 ] );
  }
  // Use ftok to create the same key as we do in lightsout
  key_t key = ftok(HOME_PATH, ID);
  // Get the shared memory id
  int shmid = shmget( key, sizeof( GameState ), 0666 | IPC_CREAT );
  // Check if we can make it
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }
  // Attach the shared memory and cast it to a pointer to GameState
  GameState *gameBoard = (GameState *)shmat( shmid, 0, 0 );
  
  // Create counters to populate the board
  int rCounter = 0;
  int cCounter = 0;
  // Read in file line by line
  while( ( (ch = fgetc( fp ) ) != EOF && rCounter < GRID_SIZE ) ) {
    // If we get a character other than . or * and are not expecting /n, error
    if ( cCounter < GRID_SIZE && ( ( ch != '.' ) && ( ch != '*' ) ) ) {
      failFile( argv[ 1 ] );
    }
    // If we get a newline, move to the next row and reset column counter
    if ( cCounter == GRID_SIZE && ( ch == '\n' ) ) {
      rCounter++;
      cCounter = 0;
    }
    // If we don't get a newline where we want one, error
    else if( cCounter == GRID_SIZE && ( ch != '\n' ) ) {
      failFile( argv[ 1 ] );
    }
    // Set the board space to the char and move forward in the row
    else {
      gameBoard->board[ rCounter ][ cCounter ] = ch;
      cCounter++;
    }
  }
  // If we still have characters to read, invalid
  if( rCounter == GRID_SIZE && (ch = fgetc( fp ) ) != EOF ) {
    failFile( argv[ 1 ] );
  }
  // Set the undoBit to 1 initially so we can't call undo right away
  gameBoard->undoBit = 1;
  // Close the file
  fclose( fp );
  // Exit successfully!
  return 0;
}
