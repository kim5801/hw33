/*
   Uses shared memory with reset.c to run the lightsout game, taking in command line
   arguments to either report, undo, or move, while updating the state of the board in
   the shared memory. This program also uses a semaphore to eliminate race conditions.
   @file lightsout.c
   @author Madeline Snyder (mdsnyde3)
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <ctype.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Declare the semaphore
sem_t *lock;

// Move function
bool move( GameState *state, int r, int c ) {

  // Start mutual exclusion code
  #ifndef UNSAFE
    sem_wait( lock );
  #endif
  // Make sure they are within the bounds of our board
    if( ( r < 0 || r > 4 ) || ( c < 0 || c > 4 ) ) {  
      // End mutual exclusion code before we return
      #ifndef UNSAFE
        sem_post( lock );
      #endif
      return false;
    }
  // Populate state of undo board
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      state->undoBoard[ i ][ j ] = state->board[ i ][ j ];
    }
  }
  // Make it safe to undo
  state->undoBit = 0;     
  // Change surrounding spaces on the board
  for( int k = -1; k < 2; k++ ) {
    // Make sure we are in bounds for the array, then flip the . to * and vice versa
    if( (r + k ) >= 0 && (r + k) < GRID_SIZE ) {
      if ( state->board[ r + k ][ c ] == '.' ) {
        state->board[ r + k ][ c ] = '*';
      }
      else {
        state->board[ r + k ][ c ] = '.';
      }
    }
    // Make sure we are in bounds and we haven't already changed the space, then flip the characters
    if( ( ( c + k ) >= 0 && ( c + k) < GRID_SIZE ) && k != 0 ) {
      if ( state->board[ r ][ c + k ] == '.' ) {
        state->board[ r ][ c + k ] = '*';
      }
      else {
        state->board[ r ][ c + k ] = '.';
      }
    }
  }
  
  // End mutual exclusion code before returning
  #ifndef UNSAFE
    sem_post( lock );
  #endif
  return true;
}

// Undo function
bool undo( GameState *state ) {
  // Start optional mutual exclusion code
  #ifndef UNSAFE
    sem_wait( lock );
  #endif
  // If we have previously called undo, this is an error
  if( state->undoBit ) {
    // End mutual exclusion code before returning
    #ifndef UNSAFE
      sem_post( lock );
    #endif
    return false;
  }
  else {
    // Put values from undoBoard into the regular board
    for( int i = 0; i < GRID_SIZE; i++ ) {
      for( int j = 0; j < GRID_SIZE; j++ ) {
        state->board[ i ][ j ] = state->undoBoard[ i ][ j ];
      }
    }
    // Indicate we have just called undo
    state->undoBit = 1;
    
    // End the mutual exclusion code before returning
    #ifndef UNSAFE
      sem_post( lock );
    #endif
    return true;
  }
  
}

// Report function
void report( GameState *state ) {
  // Start mutual exclusion code
  #ifndef UNSAFE
    sem_wait( lock );
  #endif
  // Print out the state of the board character by character with newlines when appropriate
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", state->board[ i ][ j ] );
    }
    printf( "\n" );
  }
  
  //End mutual exclusion code before we exit the void function
  #ifndef UNSAFE
    sem_post( lock );
  #endif
}

// Test function
bool test( GameState *state, int n, int r, int c ) {
  // Make sure row/col is valid
  if( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
  
  // Make the same move a bunch of times
  for( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }
  return true;
}

// Main method, uses command line arguments to decide what command to run, updating the board as needed
int main( int argc, char *argv[] ) {
  // Open the semaphore made by reset
  lock = sem_open( SEM_NAME, 0 );  
  if( lock == SEM_FAILED ) {
    fail( "Cannot create named semaphore" );
  }
  
  // Use ftok to create a key for the shared memory
  key_t key = ftok(HOME_PATH, ID);
  // Get id to use for shared memory, using key from above
  int shmid = shmget( key, sizeof( GameState ), 0 );
  // If we get 1, we couldn't create the shared memory
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }
  // Cast the pointer from shmat into a shared GameState struct
  GameState *gameBoard = (GameState *)shmat( shmid, 0, 0 );
  
  // If we have less than 2 command line arguments (including ./lightsout), we have an error
  if ( argc < 2 ) {
    printf( "error\n" );
    exit( 1 );
  }
  
  // See if we have the report command
  if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // If we do not have exactly 2 args, we have an error
    if ( argc != 2 ) {
      printf( "error\n" );
      exit( 1 );
    } 
    // Call report command
    report( gameBoard );
  
  }
  // Case for the undo command
  else if( strcmp( argv[ 1 ], "undo" ) == 0) {
    // Call undo function and print outcome
    bool status = undo( gameBoard );
    if( status ) {
      printf( "success\n" );
    }
    else {
      printf( "error\n" );
      exit( 1 );
    }
  }
  // Case for move command
  else if( strcmp( argv[ 1 ], "move" ) == 0) {
    // If we don't have exactly 4 arguments, this is invalid
    if( argc != 4 ) {
      printf( "error\n" );
      exit( 1 );
    }
    // If the args are not valid digits, print an error
    if ( ( (strlen( argv[ 2 ] ) != 1) && !isdigit( argv[ 2 ][ 0 ] ) ) || ( (strlen( argv[ 3 ] ) != 1) && !isdigit( argv[ 3 ][ 0 ] ) ) ) {
      printf( "error\n" );
      exit( 1 );
    }
    // Get int values for row and column
    int row = atoi( argv[ 2 ] );
    int col = atoi( argv[ 3 ] );
    // Call move function and print outcome
    bool status = move( gameBoard, row, col ); 
    if( status ) {
      printf( "success\n" );
    }
    else {
      printf( "error\n" );
      exit( 1 );
    }
  }
  // Case for test command
  else if( strcmp( argv[ 1 ], "test" ) == 0 ) {
    // If we don't have exactly 5 arguments, this is invalid
    if( argc != 5 ) {
      printf( "error\n" );
      exit( 1 );
    }
    // If the args are not valid digits, print an error
    if ( ( (strlen( argv[ 3 ] ) != 1) && !isdigit( argv[ 3 ][ 0 ] ) ) || ( (strlen( argv[ 4 ] ) != 1) && !isdigit( argv[ 4 ][ 0 ] ) ) ) {
      printf( "error\n" );
      exit( 1 );
    }
    
    // If the number of times we test is not valid this is an error
    if( atoi( argv[ 2 ] ) == 0 && *argv[ 2 ] != '0' ) {
      printf( "error\n" );
      exit( 1 );
    }
    // Get value of iterations, and throw an error if it's negative
    int iterations = atoi ( argv[ 2 ] );
    if( iterations < 0 ) {
      printf( "error\n" );
      exit( 1 );
    }
    // Get int values for row and column
    int row = atoi( argv[ 3 ] );
    int col = atoi( argv[ 4 ] );
    // Call test command and print outcome
    bool status = test( gameBoard, iterations, row, col );
    if( status ) {
      printf( "success\n" );
    }
    else {
      printf( "error\n" );
      exit( 1 );
    }
  }
  // Case for invalid command
  else {
    printf( "error\n" );
    exit( 1 );
  }
  // Close the semaphore
  sem_close( lock );
  // Exit successfully!
  return 0;
}
