/*
   Takes in a list of integer values and finds the largest possible sum using threads and semaphore logic.
   @file maxsum-sem.c
   @author Madeline Snyder (mdsnyde3)
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// True if input is done being scanned in
bool doneReading = false;

// Number of times we have looked for a sum (how many indexes we have done)
int iterations = 0;

// Semaphore for changing max_sum value
sem_t lock;

// Semaphore for getting work to be done
sem_t counter;

// Semaphore for changing iteration
sem_t it;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );
    // Store the latest value.
    vList[ vCount++ ] = v;
    // Let others use vCount now
    sem_post( &counter );
  }
  // Mark that we have finished reading input
  doneReading = true;
  // Let us stop waiting if need be
  sem_post( &counter );
}

/** Assigns work to each worker thread when necessary, returns -1 if we're done */
int getWork() {
  // Allow only us access to iterations variable
  sem_wait( &it );
  // Check if we have gone through all possible input
  if( doneReading && iterations == vCount ) {
    // Call post for the iterations variable
    sem_post( &it );
    return -1;
  }
  // Wait for new input
  sem_wait( &counter );
  // Check again if we're done
  if( doneReading && iterations == vCount ) {
    // Call post for iterations
    sem_post( &it );
    return -1;
  }
  // Get the new index for where we start and increment it
  int idx = iterations++;
  // Allow some other thread access to iterations
  sem_post( &it );
  // Return the next index to calculate sums through
  return idx;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // Get first place to start with getWork()
  int idx = getWork();
  // Temporary maximum we find
  int tempMax = INT_MIN;
  // While getWork() gives us good indexes, start adding
  while( idx != -1 ) {
    // Create a sum
    int sum = 0;
    // Iterate backwards through the array from the point we were given
    for( int i = idx; i >= 0; i-- ) {
      sum += vList[ i ];
      if(sum > tempMax ) {
        tempMax = sum;
      }
    }
    // Figure out where to iterate from next
    idx = getWork();
  }
  // Lock critical section so we can change max_sum value
  sem_wait( &lock );
  // Change the value if we need to
  if( max_sum < tempMax ) {
    max_sum = tempMax;
  }
  // Someone else can change it now
  sem_post( &lock ); 
  // Print out if report flag is true
  if( report ) {
    printf( "I am thread %lu. The maximum sum I found was %d.\n", pthread_self(), tempMax ); 
  }
  return NULL;
}

/**
  Main thread, checks valid commands and then creates threads, reads values, 
  and prints a maximum.
*/
int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
 
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  
  // Initialize the lock semaphore
  sem_init( &lock, 0, 1 );
  // Initialize the work semaphore
  sem_init( &counter, 0, 0 );
  // Initialize the iterations semaphore
  sem_init( &it, 0, 1 );
  
  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0 ) {
      fail( "Can't create a child thread\n" );
    }

  // Then, start getting work for them to do.
  readList();
  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join( worker[ i ], NULL );
  }
  
  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  // Get rid of semaphore
  sem_destroy( &lock );
  // Get rid of work semaphore
  sem_destroy( &counter );
  // Get rid of iterations semaphore
  sem_destroy( &it );
  
  return EXIT_SUCCESS;
}
