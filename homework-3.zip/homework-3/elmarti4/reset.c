/**
 * @file reset.c
 * @author Eduardo Martinez (elmarti4)
 * @brief Creates a board from which an user can provide commands through
 *        lightsout.c. The board is created through shared memory.
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * @brief Creates a baord by using a provided text file
 * 
 * @param fileName Name of the text file
 * @param board Where the board is stored
 */
void createBoard( char *fileName, char board[ GRID_SIZE ][ GRID_SIZE + 1 ] ) {
  int fd = open( fileName, O_RDONLY );
  if ( !fd ) {
    fprintf( stderr, "Invalid input file: %s\n", fileName );
    exit( 1 );
  }
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE + 1; j++ ) {
      int check = read( fd, &board[ i ][ j ], 1 );
      if ( check == EOF ) {
        fprintf( stderr, "Invalid input file: %s\n", fileName );
        exit( 1 );
      }
      if ( board[ i ][ j ] != '*' && board[ i ][ j ] != '.' && j != 5 ) {
        fprintf( stderr, "Invalid input file: %s\n", fileName );
        exit( 1 );
      }
      if ( board[ i ][ j ] != '\n' && j == 5 ) {
        fprintf( stderr, "Invalid input file: %s\n", fileName );
        exit( 1 );
      }
    }
  }
  close( fd );
}

/**
 * @brief Starting point of the program
 * 
 * @param argc Amount of arguments
 * @param argv List of arguments
 * @return 0 on success or 1 on failure 
 */
int main( int argc, char *argv[] ) {
  if ( argc != 2 ) {
    usage();
  }

  sem_unlink( SEM_NAME );

  int shmid = shmget( ftok( SHMEM_NAME, 'a' ), sizeof( GameState ), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  GameState *gS = (GameState *) shmat( shmid, 0, 0 );

  sem_open( SEM_NAME, O_CREAT, 0600, 1 );

  if ( gS == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  gS->undoStatus = false;

  createBoard( argv[ 1 ], gS->currentBoard );

  shmdt( gS );

  return 0;
}
