/**
 * @file lightsout.c
 * @author Eduardo Martinez (elmarti4)
 * @brief Allows a user to change the Lights Out board through moves,
 *        report the current board, or undo a previous move.
 * 
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message, GameState *state ) {
  fprintf( stderr, "%s\n", message );
  shmdt( state );
  exit( 1 );
}

// Print out an error message and exit before a struct has been built.
static void failW( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief Prints the provided board to standard output
 * 
 * @param board 2D array of board chosen
 */
void printBoard( char board[ GRID_SIZE ][ GRID_SIZE + 1 ] ) {
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE + 1; j++ ) {
      printf( "%c", board[ i ][ j ] );
    }
  }
  printf( "\n" );
}

/**
 * @brief Make a move at the given row, column location, 
 *        returning true if successful.
 * 
 * @param state Struct that contains board information
 * @param r Row being edited
 * @param c Column being edited
 * @return true on success or false on failure 
 */
bool move( GameState *state, int r, int c ) {
  sem_t *choke = sem_open( SEM_NAME, 0 );
  #ifndef UNSAFE
    sem_wait( choke );
  #endif
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
      state->oldBoard[ i ][ j ] = state->currentBoard[ i ][ j ];
    }
  }
  // Check if the row and columns have valid values
  if ( 0 <= r && r < GRID_SIZE ) {
  } else {
    sem_post( choke );
    return false;
  }
  if ( 0 <= c && c < GRID_SIZE ) {
  } else {
    sem_post( choke );
    return false;
  }
  // Change the center of the cross
  if ( state->currentBoard[ r ][ c ] == '*' ) {
    state->currentBoard[ r ][ c ] = '.';
  } else {
    state->currentBoard[ r ][ c ] = '*';
  }
  // Change the value above the center
  if ( r - 1 >= 0 && r - 1 < GRID_SIZE ) {
    if ( state->currentBoard[ r - 1 ][ c ] == '*' ) {
      state->currentBoard[ r - 1 ][ c ] = '.';
    } else {
      state->currentBoard[ r - 1 ][ c ] = '*';
    }
  }
  // Change the value below the center
  if ( r + 1 >= 0 && r + 1 < GRID_SIZE ) {
    if ( state->currentBoard[ r + 1 ][ c ] == '*' ) {
      state->currentBoard[ r + 1 ][ c ] = '.';
    } else {
      state->currentBoard[ r + 1 ][ c ] = '*';
    }
  }
  // Change the value to the left of the center
  if ( c - 1 >= 0 && c - 1 < GRID_SIZE ) {
    if ( state->currentBoard[ r ][ c - 1 ] == '*' ) {
      state->currentBoard[ r ][ c - 1 ] = '.';
    } else {
      state->currentBoard[ r ][ c - 1 ] = '*';
    }
  }
  // Change the value to the right of the center
  if ( c + 1 >= 0 && c + 1 < GRID_SIZE ) {
    if ( state->currentBoard[ r ][ c + 1 ] == '*' ) {
      state->currentBoard[ r ][ c + 1 ] = '.';
    } else {
      state->currentBoard[ r ][ c + 1 ] = '*';
    }
  }
  state->undoStatus = true;
  sem_post( choke );
  return true;
}

/**
 * @brief Test method that does multiple moves in a row
 * 
 * @param state Struct that contains board information
 * @param n Amount of moves being done
 * @param r Row being edited
 * @param c Column being edited
 * @return true on success or false on failure 
 */
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

/**
 * @brief Undo the most recent move, returning true if successful.
 * 
 * @param state Struct that contains board information
 */
bool undo( GameState *state ) {
  sem_t *choke = sem_open( SEM_NAME, 0 );
  #ifndef UNSAFE
    sem_wait( choke );
  #endif
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      state->currentBoard[ i ][ j ] = state->oldBoard[ i ][ j ];
    }
  }
  state->undoStatus = false;
  sem_post( choke );
  return true;
}

/**
 * @brief Print the current state of the board.
 * 
 * @param state Struct that contains board information
 */
void report( GameState *state ) {
  sem_t *choke = sem_open( SEM_NAME, 0 );
  #ifndef UNSAFE
    sem_wait( choke );
  #endif
  printBoard( state->currentBoard );
  sem_post( choke );
}

/**
 * @brief Starting point of the program
 * 
 * @param argc Amount of arguments
 * @param argv List of arguments
 * @return 0 on success or 1 on failure 
 */
int main( int argc, char *argv[] ) {
  int shmid = shmget( ftok( SHMEM_NAME, 'a' ), sizeof( GameState ), 0 );
  if ( shmid == -1 )
    failW( "Can't create shared memory" );

  GameState *gS = (GameState *) shmat( shmid, 0, 0 );

  sem_t *choke = sem_open( SEM_NAME, 0 );

  if ( gS == (GameState *)-1 )
    failW( "Can't map shared memory segment into address space" );

  if ( argc == 4 && strcmp( argv[ 1 ], "move" ) == 0 ) {
    if ( strlen( argv[ 2 ] ) != 1 ) {
      fail( "error", gS );
    }
    if ( strlen( argv[ 3 ] ) != 1 ) {
      fail( "error", gS );
    } else {
      if ( move( gS, argv[ 2 ][ 0 ] - '0', argv[ 3 ][ 0 ] - '0' ) ) {
        printf( "success\n" );
      } else {
        fail( "error", gS );
      }
    }
  } else if ( argc == 2 && strcmp( argv[ 1 ], "report" ) == 0 ) {
    report( gS );
  } else if ( argc == 2 && strcmp( argv[ 1 ], "undo" ) == 0 && gS->undoStatus == true ) {
    if ( undo( gS ) ) {
      printf( "success\n" );
    } else {
      fail( "error", gS );
    }
  } else if ( argc == 5 && strcmp( argv[ 1 ], "test" ) == 0 ) {
    int argL = strlen( argv[ 2 ] );
    int arg2Val;
    int currentVal = 0;
    for ( int i = 0; i < argL; i++ ) {
      currentVal = argv[ 2 ][ i ] - '0';
      if ( currentVal < 0 || currentVal > 9 ) {
        fail( "error", gS );
      }
      if ( i == 0 ) {
        arg2Val = currentVal;
      } else {
        arg2Val *= 10;
        arg2Val += currentVal;
      }
    }
    if ( strlen( argv[ 3 ] ) != 1 ) {
      fail( "error", gS );
    }
    if ( strlen( argv[ 4 ] ) != 1 ) {
      fail( "error", gS );
    }
    int value1 = argv[ 3 ][ 0 ] - '0';
    int value2 = argv[ 4 ][ 0 ] - '0';
    if ( 0 <= value1 && value1 < GRID_SIZE ) {
    } else {
        fail( "error", gS );
    }
    if ( 0 <= value2 && value2 < GRID_SIZE ) {
    } else {
        fail( "error", gS );
    }
    if ( test( gS, arg2Val, argv[ 3 ][ 0 ] - '0', argv[ 4 ][ 0 ] - '0' ) ) {
      printf( "success\n" );
    } else {
      fail( "error", gS );
    }
  }

  sem_close( choke );
  shmdt( gS );

  return 0;
}
