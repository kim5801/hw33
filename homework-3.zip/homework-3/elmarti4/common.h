#include <semaphore.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// Name for a semaphore
#define SEM_NAME "/elmarti4-lightsout-lock"

// Name of a shared memory
#define SHMEM_NAME "/afs/unity.ncsu.edu/users/e/elmarti4"
 
typedef struct {
    char oldBoard[ GRID_SIZE ][ GRID_SIZE + 1 ];
    char currentBoard[ GRID_SIZE ][ GRID_SIZE + 1 ];
    bool undoStatus;
} GameState;
