/**
 * @file maxsum-sem.c
 * @author Eduardo Martinez (elmarti4)
 * @brief Calculates the maximum sum found in a list of values from a text file.
 *        Is special due to its ability to calculate the max sum while list
 *        of values is still being built.
 * 
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Let's getWork know if readList has returned EOF
int final = 1;

// Semaphores
sem_t newMax;
sem_t lock;
sem_t workPermit;
sem_t readPermit;

typedef struct {
    int workers;
    int currentWorker;
} WorkerValues;

// Read the list of values.
void readList( int workers ) {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    // Semaphore allows one worker's getWork to do its job
    sem_post( &workPermit );
    // Semaphore blocks readList until getWork is finished
    sem_wait( &readPermit );
  }
  // After EOF is reached, no more elements are being added
  // Therefore, all workers whose getWork requires an end index
  // will instead receive EOF.
  vList[ vCount ] = EOF;
  // Release all workers since synchronozation is no longer needed
  for ( int i = 0; i < workers; i ++ )
    sem_post( &workPermit );
}

/**
 * @brief Acquire the total elements that have been added to vList
 * @return total elements in vList, or EOF if no more input is left
 */
int getWork() {
  // Wait for readList to update vList
  sem_wait( &workPermit );
  // Store total amount of elements added to vList while readList is stopped
  int end = vCount;
  // Release readList
  sem_post( &readPermit );
  // Return index or EOF
  if ( vList[ end ] != EOF ) {
    return end;
  } else {
    return EOF;
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // ...
  // Struct
  int currentWorker = *((int *) arg );
  int currentValue = 0;
  int currentGreatest = 0;
  int end = 0;
  // Loop through various getWork calls in order to calculate the maximum sum
  while ( ( end = getWork() ) != EOF ) {
    for ( int i = end; i >= 0; i-- ) {
      //printf( "End: %d Thread: %d\n", end, workerVal.currentWorker + 1 );
      //fflush(stdout);
      currentValue += vList[ i ];
      if ( currentGreatest < currentValue ) {
        currentGreatest = currentValue;
      }
    }

    // Semaphores for making sure multiple workers take turn editing the max_sum variable
    sem_wait( &newMax );
    if (max_sum < currentGreatest ) {
      max_sum = currentGreatest;
    }
    sem_post( &newMax );

    currentValue = 0;
}
  if ( report == true ) {
    printf( "I’m thread %d. The maximum sum I found is %d.\n", currentWorker + 1, currentGreatest );
    free( arg );
  }
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  sem_init( &newMax, 0, 1 );
  sem_init( &workPermit, 0, 0 );
  sem_init( &readPermit, 0, 0 );

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    // Send each worker their worker ID
    int *currentWorker = malloc( sizeof ( *currentWorker ) );
    *currentWorker = i;
    if ( pthread_create( worker + i, NULL, workerRoutine, currentWorker ) != 0 )
      fail( "Can't create worker thread.\n" );
  }
    // ...

  // Then, start getting work for them to do.
  readList( workers );

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );
    // ...

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
