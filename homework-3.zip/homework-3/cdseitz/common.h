// Height and width of the playing area.
#define GRID_SIZE 5

typedef struct GameStateStruct {
  //game board represented by 2D array
  int board[GRID_SIZE][GRID_SIZE];
  //value of 1 means user can do an undo command, 0 if not
  int canUndo;
  //array for the row and column values of the last move command
  int lastMove[];
} GameState;

// home directory for cdseitz, used by ftok() during shared memory setup
#define HOME_DIR "/afs/unity.ncsu.edu/users/c/cdseitz"

//name of named semaphore
#define SEM_NAME "/cdseitz-lightsout-lock"

