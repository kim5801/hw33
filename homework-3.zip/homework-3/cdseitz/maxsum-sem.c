#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
volatile int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
volatile int vCount = 0;

// Current index of list to give out to a worker by getWork
volatile int indexGivenOut = -1;

// Semaphore locking the get work function to let only one thread in at a time
// Initialized to 1 in main
sem_t canWork;

// Semaphore locking the global max sum
// Initialized to 1 in main
sem_t updateSum;

//whether or not main thread is still open to reading input
volatile bool reading = true;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
  }
  //finished reading input
  reading = false;
}

// Returns the index of the list the worker is to sum from to 0
// Returns -1 if there's no new work and -2 if all work is done
int getWork() {

  //work is done and reading is done, so stop threads
  if (vCount == indexGivenOut + 1 && !reading) {
    return -2;
  }
  //more numbers have been read in
  if (vCount > indexGivenOut + 1) {
    //increase index by 1 and return it
    indexGivenOut++;
    return indexGivenOut;
  } 
  //no more numbers have been read in, so return -1
  else {
    return -1;
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  //max sum found by this thread
  int threadSum = INT_MIN;
  //index the thread starting summing vList from to 0
  int indexToStartAt = -3;
  do {

    //lock other threads out when updating index to give out
    sem_wait(&canWork);

    //get new largest index to sum from
    indexToStartAt = getWork();

    //unlock getWork so other threads can get in
    sem_post(&canWork);

    //if index returned from getWork() is a non-sentinel, find sum
    if (indexToStartAt >= 0) {

      //find every sum from start index to 0
      int sum = 0;
      for (int i = indexToStartAt; i >= 0; i--) {
        sum += vList[i];
        
        //update the thread's overall sum if appropriate
        if (sum > threadSum) {
          threadSum = sum;
        }
      }
    }
  }
  //if index is -2, work is done, so finish thread code
  while (indexToStartAt != -2);
  
  //report flag means we give process info 
  if (report) {
    printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), threadSum);
  }

  //update global sum if appropriate with largest sum found by thread
  //lock semaphore for updating global sum
  sem_wait(&updateSum);
  if (threadSum > max_sum) {
    max_sum = threadSum;
  }
  sem_post(&updateSum);

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;

  //initialize semaphores for getting work and updating sum to 1
  sem_init( &canWork, 0, 1 );
  sem_init( &updateSum, 0, 1 );
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers and start them on the workerRoutine
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( &worker[i], NULL, workerRoutine, NULL) != 0 )
      fail( "Can't create thread");
  }
   
  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
