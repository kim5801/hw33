#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>
#include <sys/ipc.h>


//global semaphore to lock before using game state
#ifndef UNSAFE
  sem_t *sem;
#endif


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// If it detects one of the error conditions, print error and
//exit unsuccessfully 
static void error() {
  printf("error\n");
  exit(EXIT_FAILURE);
}

// Request successfull so print and exit.
static void success() {
  printf("success\n");
  exit(EXIT_SUCCESS);
}

// Sets up the shared memory that reset.c created and returns
//pointer to it
GameState *initializeMemory(int size) {
  //get unique key based off home directory for cdseitz 
  key_t key = ftok(HOME_DIR, 1);
  if (key == -1)
    fail("ftok unsucessful with the directory");
  
  //get a GameState pointer to the shared memory
  int shmid = shmget(key, size, 0);
  if (shmid == -1)
    fail("shmget operation unsucessful with the given key and size");
  GameState *statePtr = (GameState*) shmat(shmid, 0,0);

  return statePtr;
}

// Prints out the game board stored in the struct row by row
void report(GameState *stateMem) {
  //aquire semaphore at start
  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  //start with empty string that we are going to add to
  char message[GRID_SIZE * GRID_SIZE] = "";
  
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      int cell = stateMem->board[i][j];
      //translate 0 to .
      if (cell == 0) {
        strncat(message, ".", 1);
      // 1 goes to *
      } else {
        strncat(message, "*", 1);
      }
    }
    strncat(message, "\n", 1);
  }
  printf("%s", message);

  //release semaphore and return
  #ifndef UNSAFE
    sem_post(sem);
  #endif
}

// Move operation using the game board and a row, column pair
// Returns true if successful
bool move(GameState *stateMem, int r, int c) {
  //aquire semaphore at start
  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  //bounds checking
  if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    //release semaphore and return
    #ifndef UNSAFE
      sem_post(sem);
    #endif
    return false;
  }

  //change exact spot
  stateMem->board[r][c] = (stateMem->board[r][c] == 0) ? 1 : 0;

  //get spot above if it is within bounds
  if (r > 0) {
    stateMem->board[r - 1][c] = (stateMem->board[r - 1][c] == 0) ? 1 : 0;
  }
  //get spot below if it is within bounds
  if (r < GRID_SIZE - 1) {
    stateMem->board[r + 1][c] = (stateMem->board[r + 1][c] == 0) ? 1 : 0;
  }
  //get spot to left if it is within bounds
  if (c > 0) {
    stateMem->board[r][c - 1] = (stateMem->board[r][c - 1] == 0) ? 1 : 0;
  }
  //get spot to right if it is within bounds
  if (c < GRID_SIZE - 1) {
    stateMem->board[r][c + 1] = (stateMem->board[r][c + 1] == 0) ? 1 : 0;
  }

  //fill in the last move spaces for undo operation
  stateMem->lastMove[0] = r;
  stateMem->lastMove[1] = c;

  //valid move, so now can undo
  stateMem->canUndo = 1;

  //release semaphore and return
  #ifndef UNSAFE
    sem_post(sem);
  #endif

  return true;
}

// Undoes the last move if a move has been done since the last undo
// Returns true if successful
bool undo (GameState *state) {
  //aquire semaphore at start
  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  //if the struct field says it's not time for an undo, don't do it
  if (state->canUndo != 1) {
    //release semaphore and return
    #ifndef UNSAFE
      sem_post(sem);
    #endif
    return false;
  
  //valid, lets do an undo
  } else {
    
    //all an undo is is doing another move with the last location
    int r = state->lastMove[0];
    int c = state->lastMove[1];

    //bounds checking
    if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
      //release semaphore and return
      #ifndef UNSAFE
        sem_post(sem);
      #endif
      return false;
    }

    //change exact spot
    state->board[r][c] = (state->board[r][c] == 0) ? 1 : 0;

    //get spot above if it is within bounds
    if (r > 0) {
      state->board[r - 1][c] = (state->board[r - 1][c] == 0) ? 1 : 0;
    }
    //get spot below if it is within bounds
    if (r < GRID_SIZE - 1) {
      state->board[r + 1][c] = (state->board[r + 1][c] == 0) ? 1 : 0;
    }
    //get spot to left if it is within bounds
    if (c > 0) {
      state->board[r][c - 1] = (state->board[r][c - 1] == 0) ? 1 : 0;
    }
    //get spot to right if it is within bounds
    if (c < GRID_SIZE - 1) {
      state->board[r][c + 1] = (state->board[r][c + 1] == 0) ? 1 : 0;
    }

    //fill in the last move spaces for undo operation
    state->lastMove[0] = r;
    state->lastMove[1] = c;

    //cause the undo flag to be false so you can't go back to back
    state->canUndo = 0;

    //release semaphore and return
    #ifndef UNSAFE
      sem_post(sem);
    #endif

    return true;
  }
}

// Test interface, for quickly making a given move over and over. Given by instructions.
// Returns true if successful
bool test( GameState *state, int n, int r, int c ) {

  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
    
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );

  return true;
}

int main( int argc, char *argv[] ) {
  #ifndef UNSAFE
    // Open the semaphore already made by reset.
    sem = sem_open( SEM_NAME, 0 );
    if ( sem == SEM_FAILED )
      fail( "Can't open semaphore" );
  #endif

  //Gamestate object just used for sizeof
  GameState state;

  //get GameState pointer to the shared memory
  GameState *stateMem = initializeMemory(sizeof(state));

  //user wants a report
  if (argc == 2 && (strcmp( argv[ 1 ], "report" ) == 0 )) {
    report(stateMem);
  }

  //user wants a move
  else if (argc == 4 && (strcmp( argv[ 1 ], "move" ) == 0 )) {
    //read in row and column
    int r, c;
    int status1 = sscanf(argv[2], "%d", &r);
    int status2 = sscanf(argv[3], "%d", &c);
    //if couldn't be read as integers, error
    if (status1 == -1 || status2 == -1) {
      error();
    }

    //perform move and exit according to success of move
    if (move(stateMem, r, c)) {
      success();
    } else {
      error();
    }
  
  //user wants an undo
  } else if (argc == 2 && (strcmp( argv[ 1 ], "undo" ) == 0 )) {
    //perform undo and exit according to success of move
    if (undo(stateMem)) {
      success();
    } else {
      error();
    }
  
  //test function
  } else if (argc == 5 && (strcmp( argv[ 1 ], "test" ) == 0 )) {
    //read in n, r, and c
    int n, r, c; 
    int status1 = sscanf(argv[2], "%d", &n);
    int status2 = sscanf(argv[3], "%d", &r);
    int status3 = sscanf(argv[4], "%d", &c);
    //if any of them cound't be read as an int, error
    if (status1 == -1 || status2 == -1 || status3 == -1) {
      error();
    }

    //perform test and exit according to success of move
    if (test(stateMem, n, r, c)) {
      success();
    } else {
      error();
    }
  }

  //not one of the allowed messages, so error it
  else {
    error();
  }

  return 0;
}
