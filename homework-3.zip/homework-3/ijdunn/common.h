/**
 * The common.h header file provides definitions and constants for the GameState struct, and various
 * paths, names, and constants for the Lights Out game.
 * @file common.h
 * @author Isaac Dunn (ijdunn)
 */

/** The height and width of the game board */
#define GRID_SIZE 5

/** The AFS file home directory used with ftok() to get the key for the shared memory */
#define AFS_PATH "/afs/unity.ncsu.edu/users/i/ijdunn/"

/** The named semaphore used to only allow one Lights Out instance to change the GameState at one time */
#define GS_SEM_NAME "/ijdunn-lightsout-lock"

/** The constant used with the proj_id parameter in the ftok() function to get the shared memory key */
#define PROJ_ID_CONST 123

/** GameState struct definition to hold the grid, undo flag, and the last move */
typedef struct {
  bool board[GRID_SIZE][GRID_SIZE];
  bool undoFlag;
  int lastRow;
  int lastCol;
} GameState ;
