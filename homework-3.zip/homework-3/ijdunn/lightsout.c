/**
 * The Lightsout program changes the state of the GameState struct in shared memory,
 * that was initialized by the reset program. The Lightsout program uses the move,
 * undo, and report commands to allow the user to interact with the Lightsout game.
 * This version uses a named semaphore to avoid race conditions when updating the GameState.
 * @file lightsout.c
 * @author Isaac Dunn (ijdunn)
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/** The semaphore used to provide mutual exclusion */
sem_t *gsLock;

/**
 * This function is used to print a custom error message to stderr and exit with
 * a failure status.
 * @param message  The message to print to stderr
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * This function is used to print 'error' to standard output and exit
 * with a failure status of 1. Used for errors in commands.
 */
static void clientError() {
  printf( "error\n" );
  exit( 1 );
}

/**
 * Updates the game board by playing the move at the row and column. Adjacent lights that
 * are off are turned on, and vise versa.
 * @param state The pointer to the GameState struct containing the state of the game board
 * @param row   The row to play the move from
 * @param col   The column to play the move from
 * @return true/false  True if the move was made successfully, false if move could not be made
 */
bool boardMove( GameState *state, int row, int col ) {
  // Only allow one instance to access the GameState struct at a time
  #ifndef UNSAFE
    sem_wait( gsLock );
  #endif

  // Check row and column indices, if they are out of bounds, return false
  if ( row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE ) {
    // We can now allow other instances to access the GameState struct
    #ifndef UNSAFE
      sem_post( gsLock );
    #endif
    return false;
  }

  // Play in top-left corner
  if ( row == 0 && col == 0 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row + 1][col] ) ? ( state->board[row + 1][col] = false ) : ( state->board[row + 1][col] = true );
    ( state->board[row][col + 1] ) ? ( state->board[row][col + 1] = false ) : ( state->board[row][col + 1] = true );
  }
  // Play in top-right corner
  else if ( row == 0 && col == 4 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row + 1][col] ) ? ( state->board[row + 1][col] = false ) : ( state->board[row + 1][col] = true );
    ( state->board[row][col - 1] ) ? ( state->board[row][col - 1] = false ) : ( state->board[row][col - 1] = true );
  }
  // Play in bottom-left corner
  else if ( row == 4 && col == 0 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row - 1][col] ) ? ( state->board[row - 1][col] = false ) : ( state->board[row - 1][col] = true );
    ( state->board[row][col + 1] ) ? ( state->board[row][col + 1] = false ) : ( state->board[row][col + 1] = true );
  }
  // Play in bottom-right corner
  else if ( row == 4 && col == 4 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row - 1][col] ) ? ( state->board[row - 1][col] = false ) : ( state->board[row - 1][col] = true );
    ( state->board[row][col - 1] ) ? ( state->board[row][col - 1] = false ) : ( state->board[row][col - 1] = true );
  }
  // Play on top edge
  else if ( row == 0 && col > 0 && col < 4 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row][col - 1] ) ? ( state->board[row][col - 1] = false ) : ( state->board[row][col - 1] = true );
    ( state->board[row][col + 1] ) ? ( state->board[row][col + 1] = false ) : ( state->board[row][col + 1] = true );
    ( state->board[row + 1][col] ) ? ( state->board[row + 1][col] = false ) : ( state->board[row + 1][col] = true );
  }
  // Play on left edge
  else if ( row > 0 && row < 4 && col == 0 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row][col + 1] ) ? ( state->board[row][col + 1] = false ) : ( state->board[row][col + 1] = true );
    ( state->board[row - 1][col] ) ? ( state->board[row - 1][col] = false ) : ( state->board[row - 1][col] = true );
    ( state->board[row + 1][col] ) ? ( state->board[row + 1][col] = false ) : ( state->board[row + 1][col] = true );
  }
  // Play on right edge
  else if ( row > 0 && row < 4 && col == 4 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row][col - 1] ) ? ( state->board[row][col - 1] = false ) : ( state->board[row][col - 1] = true );
    ( state->board[row - 1][col] ) ? ( state->board[row - 1][col] = false ) : ( state->board[row - 1][col] = true );
    ( state->board[row + 1][col] ) ? ( state->board[row + 1][col] = false ) : ( state->board[row + 1][col] = true );
  }
  // Play on bottom edge
  else if ( row == 4 && col < 4 && col > 0 ) {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row][col - 1] ) ? ( state->board[row][col - 1] = false ) : ( state->board[row][col - 1] = true );
    ( state->board[row - 1][col] ) ? ( state->board[row - 1][col] = false ) : ( state->board[row - 1][col] = true );
    ( state->board[row + 1][col] ) ? ( state->board[row + 1][col] = false ) : ( state->board[row + 1][col] = true );
  }
  // All other plays in the middle of the board
  else {
    ( state->board[row][col] ) ? ( state->board[row][col] = false ) : ( state->board[row][col] = true );
    ( state->board[row][col - 1] ) ? ( state->board[row][col - 1] = false ) : ( state->board[row][col - 1] = true );
    ( state->board[row][col + 1] ) ? ( state->board[row][col + 1] = false ) : ( state->board[row][col + 1] = true );
    ( state->board[row - 1][col] ) ? ( state->board[row - 1][col] = false ) : ( state->board[row - 1][col] = true );
    ( state->board[row + 1][col] ) ? ( state->board[row + 1][col] = false ) : ( state->board[row + 1][col] = true );
  }
  // Update undo flag and last moves, release semaphore and return true
  state->undoFlag = true;
  state->lastRow = row;
  state->lastCol = col;
  // We can now allow other instances to access the GameState struct
  #ifndef UNSAFE
    sem_post( gsLock );
  #endif
  return true;
}

/**
 * This function undos the previous move on the Lights Out board. If the move cannot be made, the function
 * returns false. Two undo operations cannot be done in a row without a new move.
 * @param state        The pointer to the GameState struct containing the state of the game board
 * @return true/false  Returns true if the undo operation was made successfully, false if the undo cannot be done
 */
bool boardUndo( GameState *state ) {
  // Only allow one instance to access the GameState struct at a time
  #ifndef UNSAFE
    sem_wait( gsLock );
  #endif

  // Error if undo flag is invalid
  if ( !state->undoFlag ) {
    // We can now allow other instances to access the GameState struct
    #ifndef UNSAFE
      sem_post( gsLock );
    #endif
    return false;
  }

  // Release the semaphore to allow the move to undo to occur
  #ifndef UNSAFE
    sem_post( gsLock );
  #endif
  // Undo move is valid, play the last row and column to undo
  boardMove( state, state->lastRow, state->lastCol );
  // Acquire the semaphore to make sure no other operations are made on the GameState
  #ifndef UNSAFE
    sem_wait( gsLock );
  #endif
  // Update undo flag and last moves to avoid undo operation again
  state->undoFlag = false;
  state->lastRow = -1;
  state->lastCol = -1;
  // We can now allow other instances to access the GameState struct
  #ifndef UNSAFE
    sem_post( gsLock );
  #endif
  return true;
}

/**
 * This prints the current status of the game board using asterisks and periods.
 * @param state          The pointer to the GameState struct containing the state of the game board
 * @param boardString    The string to hold the current state of the board
 */
void boardReport( GameState *state ) {
  // Only allow one instance to access the GameState struct at a time
  #ifndef UNSAFE
    sem_wait( gsLock );
  #endif
  for ( int row = 0; row < GRID_SIZE; row++ ) {
    for ( int col = 0; col < GRID_SIZE; col++ ) {
      // If light is on, print star, otherwise print dot
      ( state->board[row][col] ) ? ( printf( "*" ) ) : ( printf( "." ) );
    }
    // Print newline for each new row
    printf( "\n" );
  }
  // We can now allow other instances to access the GameState struct
  #ifndef UNSAFE
    sem_post( gsLock );
  #endif
}

/**
 * The test interface used to test for a race condition. It calls the move function n number of times
 * @param state  The pointer to the GameState struct
 * @param n  The number of times to call the move function
 * @param r  The row of where to make the move
 * @param c  The column of where to make the move
 * @return true if the moves were made, false if the move cannot be made 
 */
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    boardMove( state, r, c );

  return true;
}

/**
 * The main function links the shared memory from the reset program and parses the 
 * command-line arguments to either make a move on the board, undo the last move,
 * or report/print the current state of the board to the user.
 * @param argc  The number of command-line arguments
 * @param argv  The command-line arguments
 * @return Exit status, 0 for success, non-zero for failure
 */
int main( int argc, char *argv[] ) {
  // Create a unique shared memory ID using ftok()
  int memId = ftok( AFS_PATH, PROJ_ID_CONST );
  // Create the shared memory
  int shmId = shmget( memId, sizeof( GameState), 0666 | IPC_CREAT );
  if ( shmId == -1 ) {
    fail( "Can't create shared memory" );
  }
  // Map the shared memory into my address space
  GameState *state = (GameState *)shmat( shmId, 0, 0 );
  if ( state == (GameState *) - 1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  // Open the semaphore made by reset.c
  gsLock = sem_open( GS_SEM_NAME, 0 );
  if ( gsLock == SEM_FAILED )
    fail( "Cannot make named semaphore: gsLock" );

  // Parse command-line arguments
  if ( argc == 4 && strcmp( argv[1], "move" ) == 0 ) { // Move command
    int rowNum;
    int colNum;
    // Unable to parse integer, invalid command-line arguments
    if ( sscanf( argv[2], "%d", &rowNum ) != 1 || sscanf( argv[3], "%d", &colNum ) != 1 ) {
      clientError();
    }
    // Make the move on the board
    if ( boardMove( state, rowNum, colNum ) ) {
      // Print success message to standard output
      printf( "success\n" );
    } else {
      // If move was not made, print client error
      clientError();
    }
  } else if ( argc == 2 && strcmp( argv[1], "undo" ) == 0 ) { // Undo command
    if ( boardUndo( state ) ) {
      // Print success message to standard output
      printf( "success\n" );
    } else { 
      // Error occurred, undo operation could not be made, print client error
      clientError();
    }
  } else if ( argc == 2 && strcmp( argv[1], "report" ) == 0 ) { // Report command
    boardReport( state );
  } else if ( argc == 5 && strcmp( argv[1], "test" ) == 0 ) { // Test command/interface
    int rowNum;
    int colNum;
    int iterations;
    // Unable to parse integer, invalid command-line arguments
    if ( sscanf( argv[2], "%d", &iterations) != 1 || sscanf( argv[3], "%d", &rowNum ) != 1 || sscanf( argv[4], "%d", &colNum ) != 1 )
      clientError();

    // Run the test interface
    if ( test( state, iterations, rowNum, colNum ) ) {
      // Print success message to standard output
      printf( "success\n" );
    } else {
      // If move was not made, print client error
      clientError();
    }
  } else {
    // Invalid command-line argument(s), print to stdout and exit with failure code
    clientError();
  }

  // Exit success, with code 0
  return 0;
}
