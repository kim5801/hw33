/**
 * The maxsum-sem program calculates the maximum sum using threads that have calculations
 * allocated to them dynamically using semaphores. The program reads a list of numbers from
 * standard input (redirected at execution) and calculates the maximum continuous sum.
 * @file maxsum-sem.c
 * @author Isaac Dunn (ijdunn)
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

/**
 * Prints a message to standard error and exits the program with a failure exit code
 * @param message  The message to print to standard error
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * Prints a usage message to standard output and exits the program with a failure exit code
 */
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( EXIT_FAILURE );
}

/** Flag used to have the threads report to standard output */
bool report = false;

/** Flag used to terminate the threads once all of the input has been read */
bool terminate = false;

/** Maximum sum we've found from all of the threads */
int max_sum = INT_MIN;

/** Fixed-sized array for holding the sequence of integers */
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

/** Current number of values on the list */
int vCount = 0;

/** The index of where each worker should calculate the maximum sum to */
int workerIdx = 0;

/** Semaphore used to lock the vList when it is being edited by the main thread or vCount is used by worker threads */
sem_t valuesLock;

/** Semaphore used to lock the global max_sum to ensure the are no overwrites */
sem_t maxSumLock;

/** Semaphore used to lock other workers from getting work at the same time and accessing the worker index variable */
sem_t getWorkLock;

/**
 * The readList function reads the integers from standard input and places them into the global vList array.
 * readList will also release the getWorkLock semaphore after the first value has been read to allow worker
 * threads to start calculations. After all values have been read, readList will set the terminate flag to
 * true to tell all worker threads to exit after they have finished calculations
 */
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Before editing and accessing the values list, lock it to prevent other threads from messing with it
    sem_wait( &valuesLock );
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    // If this is the first value read in, allow workers to start getting work
    if ( vCount == 1 )
      sem_post( &getWorkLock );
    
    // Allow other threads to work with the values list
    sem_post( &valuesLock );
  }
  // Tell the worker threads to begin terminating
  terminate = true;
}

/**
 * The getWork function waits until work is ready to be assigned. After it has acquired getWorkLock, it then
 * acquires valuesLock to make sure vCount does not change. getWork then checks to see if there is work to be done,
 * and assigns the work to the worker using the next working index. If it is time to terminate, getWork
 * will return -1 as a sentinel value to the worker thread. If no work is to be done, getWork will busy wait until
 * more values are read in.
 * @returns thisWorkingIdx  The index of where the worker should start working at, -1 if no more work is to be done
 */
int getWork() {
  while ( true ) {
    // Only allow one worker to get work at a time
    sem_wait( &getWorkLock );
    // Make sure vCount doesn't change while we check it
    sem_wait( &valuesLock );
    // Pass sentinel value to worker threads when all work is complete
    if ( terminate && ( vCount == workerIdx ) ) {
      sem_post( &getWorkLock );
      sem_post( &valuesLock );
      return -1;  
    } else if ( vCount > workerIdx )  { // Give work to the worker
      // Save the worker index to return, increment the global workerIdx variable
      int thisWorkerIdx = workerIdx++;
      sem_post( &getWorkLock );
      sem_post( &valuesLock );
      return thisWorkerIdx;
    } else { // There is currently no work, release the getWorkLock and valuesLock to allow values to be added
      sem_post( &getWorkLock );
      sem_post( &valuesLock );
    }
  }
}

/**
 * The workerRoutine function is the function that is run by each worker thread. It will continue checking for
 * more work to complete using the getWork function. It then calculates the maximum sum from the index it
 * received from getWork, updating the worker max sum as it goes. After all the calculations are complete,
 * the thread will update the global max_sum if needed and report its findings if the report flag is true.
 * @param arg  A pointer to the thread's arguments, which are not used, NULL is passed through in the main function
 */
void *workerRoutine( void *arg ) {
  // Initialize the worker maximum sum for reporting
  int workerMaxSum = INT_MIN;
  // Continues to look for work until threads are instructed to terminate
  while ( true ) {
    // Gets the working index
    int thisWorkingIdx = getWork();
    // If getWork() passed -1 (sentinel value), break out of the loop
    if ( thisWorkingIdx == -1 )
      break;

    // Calculate the maxsum starting from the working index and going down to the first element
    int sum = 0;
    for (int i = thisWorkingIdx; i >= 0; i-- ) {
      sum += vList[ i ];
      // Update workerMaxSum if a new maximum sum was found
      if ( sum > workerMaxSum )
        workerMaxSum = sum;
    }
  }

  // Lock other threads from accessing the global max_sum variable 
  sem_wait( &maxSumLock );
  // Update if the worker found a higher maximum sum
  if ( workerMaxSum > max_sum )
    max_sum = workerMaxSum;

  // Unlock the global max_sum variable to allow other threads to use
  sem_post( &maxSumLock );

  // After all work has been finished, report if needed and return
  if ( report )
    printf( "I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), workerMaxSum );

  return NULL;
}

/**
 * The main function parses the command-line arguments for the number of workers and the report option.
 * The semaphores are then initialized and the threads are created and joined together. The main function
 * will then call the readList function to begin reading values from standard input (redirected at exeuction).
 * After all of the worker threads have finished executing, the main function will print the global max sum.
 * @param argc  The number of command-line arguments
 * @param argv  The command-line arguments stored as strings
 * @return Exit status  Returns 0 when successful, return non-zero on fail
 */
int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Initialize semaphores
  if ( sem_init( &valuesLock, false, 1 ) != 0 )
    fail( "Unable to initialize semaphore: valuesLock" );
  
  if ( sem_init( &maxSumLock, false, 1 ) != 0 )
    fail( "Unable to initialize semaphore: maxSumLock" );

  if ( sem_init( &getWorkLock, false, 0 ) != 0 )
    fail( "Unable to initialize semaphore: getWorkLock" );

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0 )
      fail( "Unable to create thread" );
  }

  // Start reading values before creating worker threads
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_join( worker[ i ], NULL ) != 0 )
      fail( "Unable to join threads" );
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  sem_destroy( &valuesLock );
  sem_destroy( &maxSumLock );
  sem_destroy( &getWorkLock );
  
  return EXIT_SUCCESS;
}
