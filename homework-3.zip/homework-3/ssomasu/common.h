#include <stdio.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// the semaphore
#define semaphoreName "/ssomasu-lightsout-lock"

// The struct to store the state of the board, it stores a 5x5 array of the current state and the previous state of the board
typedef struct Board {
  char boardState[ 5 ][ 5 ];
  char prevBoard[ 5 ][ 5 ];
  bool canUndo;
} GameState;

