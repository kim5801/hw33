#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// semaphore for mutual exclusion for modifying max_sum
sem_t maxSumSem;

// the semaphore for accessing the getWork function
sem_t getWorkSem;

// sempahore for notiying when values are available to be allocated to workers
sem_t valsAvailableSem;

// the number of values read in
int currVal = 0;


// my function for allocating work
int getWork() {
  // wait for values to be available to be allocated
  sem_wait(&valsAvailableSem);

  if (currVal < vCount) {
    int retVal = currVal;
    currVal++;
    return retVal;
  }
  else {
    return -1;
  }
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    // notify that there are values available.
    sem_post(&valsAvailableSem);
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {

  
  sem_wait(&getWorkSem);
  int indexVal = getWork();
  sem_post(&getWorkSem);

  int max = INT_MIN;


  while( indexVal >= 0 ) {
    sem_wait(&getWorkSem);
    indexVal = getWork();
    sem_post(&getWorkSem);


    // check the index
    if ( indexVal < 0 ) {
      break;
    }

    else {
      int tempMax = vList[ indexVal ];
      int tempSum = vList[ indexVal ];
      indexVal--;

      while ( indexVal > -1 ) {
        tempSum += vList[ indexVal ];
        if (tempSum > tempMax ) {
          tempMax = tempSum;
        }
        indexVal--;
      }

      // update local max
      sem_wait(&maxSumSem);
      if (tempMax > max)
        max = tempMax;
      sem_post(&maxSumSem);
    }
  }

  if (report) {
    printf("I'm thread %d. The maximum sum I found is %d.\n", (int)pthread_self(), max);
  }

  // update gloabl max
  // sem_wait(&maxSumSem);
  if (max > max_sum)
    max_sum = max;
  // sem_post(&maxSumSem);

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // initialize semaphores
  sem_init(&maxSumSem, 0, 1);
  sem_init(&getWorkSem, 0, 1);
  sem_init(&valsAvailableSem, 0, 0);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( &worker[i], NULL, workerRoutine, NULL ) != 0 )
      fail( "Can't create a thread" );
  }

  // Then, start getting work for them to do.
  readList();

  for (int i = 0; i < workers; i++) {
    sem_post(&valsAvailableSem);
  }

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_join( worker[i], NULL) != 0 )
      fail( "Can't join the thread" );
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  sem_destroy(&maxSumSem);
  sem_destroy(&getWorkSem);
  sem_destroy(&valsAvailableSem);
  
  return EXIT_SUCCESS;
}
