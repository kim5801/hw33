#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

//describes a job that has yet to be completed
typedef struct JobDescriptionStruct {
  //semaphore to lock this instance of the struct
  sem_t *lock;
  //the last index that was checked before the end of the list was reached
  int currIndex;
  //the total sum found so far for this job
  int totalSum;
  //the max sum found by this job
  int maxSum;
} JobDescription;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

//used to keep track of malloc'd structs. Near the end of execution a function
//goes thru and frees all elements in this buffer
JobDescription *freeBuffer[MAX_VALUES];
int numValsInFreeBuffer = 0;

//circular buffer of JobDescriptions which stores jobs ready for workers to complete and for producers to store jobs in
JobDescription *buffer[MAX_VALUES] = {NULL};
int bufEleCount = 0;
int bufFrontIndex = 0;
sem_t emptyCount;
sem_t fullCount;
sem_t lock;

//semaphore to lock max_sum variable
sem_t maxSumSem;

// Current number of values on the list.
int vCount = 0;

//puts a job into the bounded buffer. Inspired by lecture slides
void putWork(JobDescription *jd) {
  sem_wait(&emptyCount);
  sem_wait(&lock);

  int bufAddAtIndex = (bufFrontIndex + bufEleCount) % MAX_VALUES;
  buffer[bufAddAtIndex] = jd;
  bufEleCount++;

  sem_post(&lock);
  sem_post(&fullCount);
}

//gets a job from the bounded buffer. Inspired from lecture slides
JobDescription *getWork() {    
  sem_wait(&fullCount);
  sem_wait(&lock);

  JobDescription *retVal = buffer[bufFrontIndex];
  buffer[bufFrontIndex] = NULL;
  //make sure to use modulo since circular queue
  bufFrontIndex = (bufFrontIndex + 1) % MAX_VALUES;
  bufEleCount--;

  sem_post(&lock);
  sem_post(&emptyCount);
  
  return retVal;
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    //initialize the job description struct and put it into the queue as a new job
    JobDescription *newJob = (JobDescription *)malloc(sizeof(struct JobDescriptionStruct));
    newJob->maxSum = 0;
    newJob->totalSum = 0;
    newJob->currIndex = vCount - 1;
    newJob->lock = (sem_t *)malloc(sizeof(sem_t));
    sem_init(newJob->lock, 0, 1);

    freeBuffer[numValsInFreeBuffer++] = newJob;

    putWork(newJob);
  }
}

//find the highest sum in a list starting from the startIndex parameter. the job parameter should be locked
void highestContSumFrom(JobDescription *job) {
  for (; job->currIndex < vCount; job->currIndex++) {
    job->totalSum += vList[job->currIndex];
    if (job->totalSum > job->maxSum) {
      job->maxSum = job->totalSum; 
    } //else continue through the list (do not stop) cuz a future integer may be big and make a new highest sum
  }
}

//frees the JobDescriptions created
void freeJobBuffer() {
  for (int i = 0; i < numValsInFreeBuffer; i++) {
    sem_destroy(freeBuffer[i]->lock);
    free(freeBuffer[i]->lock);
    free(freeBuffer[i]);
  }
}

//waits for all the jobs to finish by busy waiting on all the job structs to see if the index they are on has reached the last index of the input.
void waitForJobsToFinish(int numWorkers) {
  bool allJobsFinished = false;

  //busy wait
  while (!allJobsFinished) {
    allJobsFinished = true;

    //see if any of the jobs are not yet complete
    for (int i = 0; i < numValsInFreeBuffer; i++) {
      sem_wait(freeBuffer[i]->lock);
      if (freeBuffer[i]->currIndex != vCount) {
        allJobsFinished = false;
      }
      sem_post(freeBuffer[i]->lock);
    }
  }

  //send a NULL JobDescription to each worker, which will tell the worker that the input is done
  for (int i = 0; i < numWorkers; i++) {
    putWork(NULL);
  }
}

/** 
 * Start routine for each worker. 
 * */
void *workerRoutine() {
  JobDescription *job = NULL;
  int maxFoundByThisWorker = INT_MIN;
  do {
    //get a job
    job = getWork();
    if (job == NULL) break; //end of input

    //lock job
    sem_wait(job->lock);

    int oldMaxSum = job->maxSum;

    //run algo
    highestContSumFrom(job);

    int newMaxSum = job->maxSum;

    //adjust maxSum if necessary
    sem_wait(&maxSumSem);

    if (job->maxSum > max_sum) {
      max_sum = job->maxSum;
    }

    //check if the new max sum is greater than the previous max sum of this worker and the old max sum before this worker worked
    if (newMaxSum > maxFoundByThisWorker && newMaxSum > oldMaxSum) {
      maxFoundByThisWorker = job->maxSum;
    }

    //unlock job
    sem_post(job->lock);

    //put back
    putWork(job);
    sem_post(&maxSumSem);
  } while (job != NULL);

  if (report) {
    printf("I'm thread %ld. The maximum sum I found is %d.\n", syscall( __NR_gettid ), maxFoundByThisWorker);
  }
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //initialize semaphores
  sem_init(&maxSumSem, 0, 1);

  sem_init(&emptyCount, 0, MAX_VALUES);
  sem_init(&fullCount, 0, 0);
  sem_init(&lock, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];

  for (int i = 0; i < workers; i++) {
    if (pthread_create(worker + i, NULL, workerRoutine, NULL)) {
      fail( "Can't create thread.\n" );
    }
  }

  // Then, start getting work for them to do.
  readList();
  
  waitForJobsToFinish(workers);

  // Wait until all the workers finish.
  for (int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );

  freeJobBuffer();
  sem_destroy(&emptyCount);
  sem_destroy(&fullCount);
  sem_destroy(&lock);
  sem_destroy(&maxSumSem);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
