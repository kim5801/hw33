// Height and width of the playing area.
#define GRID_SIZE 5

//path for ftok to make a unique id
#define SHARED_MEM_NAME "/afs/unity.ncsu.edu/users/a/abkadlof"

//second argument for ftok
#define PROJ_ID 'R'

//sem name
#define SEM_NAME "/abkadlof-lightsout-lock"

typedef struct GameStateStruct {
  char current[GRID_SIZE][GRID_SIZE + 2];
  char last[GRID_SIZE][GRID_SIZE + 2];
  bool lastDiff;
} GameState;