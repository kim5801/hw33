#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

//lock for game state
sem_t *gameStateLock;

// Print out an error message and exit.
static void fail( char const *message ) {
  sem_close(gameStateLock);
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/// @brief copies one 2d char array representation of the board to another
/// @param to the 2d char array to copy to
/// @param from the 2d char array to copy from
void copyBoard(char to[GRID_SIZE][GRID_SIZE + 2], char from[GRID_SIZE][GRID_SIZE + 2]) {
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE + 2; j++) {
      to[i][j] = from[i][j];
    }
  }
}

/// @brief Converts a string to an int. Sets the success flag if it parsed successfully
/// @param str the string to parse
/// @param success the success of the conversion
/// @return the integer if the parsing was successful, otherwise -1
int strToInt(char *str, bool *success) {
  char *endPtr = NULL;
  int retVal = strtol(str, &endPtr, 10);
  //check that errno is not set, that the string is not empty, and that the whole string was parsed
  if (errno == 0 && (str != endPtr) && *endPtr == '\0') {
    *success = true;
    return retVal;
  } else {
    *success = false;
    return -1;
  }
}

/// @brief flips the light on or off depending on its state. If it is not one of 
/// two expected chars, nothing happens
/// @param light a char pointer to either '*' or '.'
void flipLight(char *light) {
  if (*light == '*') {
    *light = '.';
  } else if (*light == '.') {
    *light = '*';
  }
}

/// @brief checks if a coordinate is out of bounds for the grid
/// @param coord the coord to check
/// @return true if out of bounds, otherwise false
bool isOutOfBounds(int coord) {
  return coord < 0 || coord > GRID_SIZE - 1;
}

/// @brief Executes a move at the specified coordinates
/// @param x the x coord
/// @param y the y coord
bool move(GameState *state, int x, int y) {
  #ifndef UNSAFE
    sem_wait(gameStateLock);
  #endif
  //error check coords
  if (isOutOfBounds(x)) {
    fail("error");
  }
  if (isOutOfBounds(y)) {
    fail("error");
  }

  //save board for undo
  copyBoard(state->last, state->current);

  //flip lights if possible
  flipLight(&state->current[x][y]);
  if (!isOutOfBounds(x + 1)) {
    flipLight(&state->current[x + 1][y]);
  }
  if (!isOutOfBounds(x - 1)) {
    flipLight(&state->current[x - 1][y]);
  }
  if (!isOutOfBounds(y + 1)) {
    flipLight(&state->current[x][y + 1]);
  }
  if (!isOutOfBounds(y - 1)) {
    flipLight(&state->current[x][y - 1]);
  }
  state->lastDiff = true;

  #ifndef UNSAFE
    sem_post(gameStateLock);
  #endif
  return true;
}

/// @brief Sets the current board state to the last board state
bool undo(GameState *state) {
  #ifndef UNSAFE
    sem_wait(gameStateLock);
  #endif

  if (!state->lastDiff) {
    fail("error");
  }
  copyBoard(state->current, state->last);
  state->lastDiff = false;

  #ifndef UNSAFE
    sem_post(gameStateLock);
  #endif
  return true;
}

/// @brief prints out the board to the viewer
void report(GameState *state) {
  #ifndef UNSAFE
    sem_wait(gameStateLock);
  #endif

  for (int i = 0; i < GRID_SIZE; i++) {
    printf(state->current[i]);
  }

  #ifndef UNSAFE
    sem_post(gameStateLock);
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

//initializes board
int main( int argc, char *argv[] ) {
  int sharedId = ftok(SHARED_MEM_NAME, PROJ_ID);
  int shmid = shmget(sharedId, 0, 0);
  GameState *state = (GameState *)shmat(shmid, 0, 0);

  gameStateLock = sem_open(SEM_NAME, 0);

  //parse command
  if (strcmp("move", argv[1]) == 0) {
    //parse and check the remaining arguments for move command
    if (argc != 4) {
      fail("error");
    }

    bool success;
    int xCoord = strToInt(argv[2], &success);
    if (!success) {
      fail("error");
    }
    int yCoord = strToInt(argv[3], &success);
    if (!success) {
      fail("error");
    }

    if (move(state, xCoord, yCoord))
      printf("success\n");
    else
      fail("error");

  } else if (strcmp("undo", argv[1]) == 0) {
    //if there are more arguments throw an error
    if (argc != 2) {
      fail("error");
    }
    if (undo(state))
      printf("success\n");
    else
      fail("error");

  } else if (strcmp("report", argv[1]) == 0) {
    //if there are more arguments throw an error
    if (argc != 2) {
      fail("error");
    }
    report(state);
    
  } else if (strcmp("test", argv[1]) == 0) {
    if (argc != 5) {
      fail("error");
    }
    bool success;
    int n = strToInt(argv[2], &success);
    if (!success)
      fail("error");
    int r = strToInt(argv[3], &success);
    if (!success)
      fail("error");
    int c = strToInt(argv[4], &success);
    if (!success)
      fail("error");
    
    test(state, n, r, c);
  } else {
    fail("error");
  }

  return 0;
}
