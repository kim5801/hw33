#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//------------------------------------------------------------------
// Whether or not all values have been read in
bool final = false;



// Semaphore used for locking critical section
sem_t lock;

//------------------------------------------------------------------

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
  }

  final = true;

}


// Number of values for which the work is done or being done for
int workDone = 0;

/** Returns index of value for worker to start working on */
int getWork() {
  if( final && workDone == vCount  ) {
    return -1;
  }
  while(workDone == vCount) {
    
  }
  return workDone++;
  
}




/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  //sum found by a thread
  long sum = 0;
  long max = 0;
  
  //printf("checkpoint X\n");
  //index 
  int index = getWork();

  //printf("initial index: %d\n", index);
  
  while(index != -1) {
    //printf("checkpoint Y\n");
    //printf("new index: %d\n", index);
  
    for(int i = 0; i <= index; i++ ) {
      for(int j = i; j <= index; j++) {
        sum += vList[j];
          if(sum > max) {
            max = sum;
          }
        
      }
      sum = 0;  
      
      
    }
    
   //GETS THE CORRECT ANSWER BUT DOES NOT SPLIT UP WORK CORRECTLY.
   
    index = getWork();

  }
  
  if (report) {
		  printf("I'm thread %lu. The maximum sum I found is %ld\n", pthread_self(), max);
  }
  // Use semaphore to update max
  sem_wait(&lock);
    
  if( max > max_sum ) {
    max_sum = max;
  }   
  sem_post(&lock);
 
  return NULL;
}





int main( int argc, char *argv[] ) {

  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  
  // Creating semaphores
  sem_init(&lock, 0, 1);

  for ( int i = 0; i < workers; i++ ) {
    if(pthread_create(worker + i, NULL, workerRoutine, NULL) != 0) {
        fail("Can't create a child worker");
    }

  }
  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(*(worker + i), NULL);
    //printf("Worker %d is done\n", i);
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  // Destroy semaphores
  sem_destroy(&lock);

  return EXIT_SUCCESS;
}
