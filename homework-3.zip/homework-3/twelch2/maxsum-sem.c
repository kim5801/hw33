/**
    @file maxsum-sem.c
    @author Thomas Welch
    maxsum-sem determines the greates contiguous sum of values in a file by delegating values to threads
    to calculate. Each thread compares the maximum sum found against the global sum, which is reported
    after all values have been read in and calculated
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

//Semaphore for controlling access to max value
sem_t updateMax;
//Semaphore denoting if work may be available
sem_t checkWork;
//Lock semaphore for changing and comparing assigned variable
sem_t assignment;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;
// Number of values that have been assigned
int assigned = 0;
// Boolean to determine if there are more values to be read
bool doneReading = false;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&checkWork);
  }
  //Indicate that all values have been read
  doneReading = true;
  sem_post(&checkWork);
}

//Function returns an index to begin sum calculations in vList
int getWork() {
  //Wait on queue to check for available work
  sem_wait(&checkWork);
  //Wait for access to assignment checks and variables
  sem_wait(&assignment);
  //Check if there is work left. Return -1 if not, and let the next thread through
  if (doneReading && (assigned >= vCount)) {
    sem_post(&checkWork);
    //Release assignment semaphore before early return
    sem_post(&assignment);
    return -1;
  } else {
    //Assign an index and increment the variable
    int index = assigned++;
    //Release the assignment semaphore
    sem_post(&assignment);
    return index;
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int localMax = INT_MIN;
  //Get a working index
  int index = getWork();
  // Calculate sums until there are no values left to assign
  while (index != -1) {
    //Set currentSum to first value, to be added to later
    int currentSum = vList[index];
    //Set localMax to currentSum if it's greater
    if (localMax < currentSum) {
      localMax = currentSum;
    }
    //Work down list finding contiguous sums
    for (int i = index - 1; i >= 0; --i) {
      currentSum += vList[i];
      //Change localMax if currentSum is greater
      if (currentSum > localMax) {
        localMax = currentSum;
      }
    }
    //Get next index
    index = getWork();
  }
  //Release any threads waiting on this semaphore
  if (report) {
    //Report local max
    printf("I’m process %lu. The maximum sum I found is %d.\n", pthread_self(), localMax);
  }

  //Compare localMax against global max and change if necessary, using semaphore for exclusion
  sem_wait(&updateMax);
  if (max_sum < localMax) {
    //Update the global max
    max_sum = localMax;
  }
  //Release semaphor to let next thread check against and update max_sum
  sem_post(&updateMax);
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    // ...
    pthread_create( &worker[i], NULL, workerRoutine, NULL );

  //Semaphore denoting that the maximum sum is being updated
  sem_init( &updateMax, 0, 1 );
  //Semaphore giving permission to check if work is available in getWork
  sem_init( &checkWork, 0, 0 );
  //Semaphore giving permission to view or alter the assigned variable
  sem_init( &assignment, 0, 1 );

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[i], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
