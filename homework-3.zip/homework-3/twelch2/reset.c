/**
    @file reset.c
    @author Thomas Welch
    Reset is responsible for reading in the state of a new board and storing it in shared memory
    The board may then be modified by lightsout. Reset creates a named semaphore to prevent race
    conditions in concurrent sessions of lightsout
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

int main(int argc, char *argv[]) {

    //Server should include one extra argument for board file info
    if (argc != 2) {
        usage();
    }
  
    //Open input file
    FILE *in;
    if ((in = fopen(argv[1], "r")) == NULL) {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit(1);
    }

    // Make a shared memory segment
    int key = ftok("/afs/unity.ncsu.edu/users/t/twelch2", 1);
    int shmid;
    if ((shmid = shmget( key, sizeof(GameState), IPC_CREAT | S_IRUSR | S_IWUSR | S_IWGRP)) == -1 ) {
        perror("Error: ");
        fail( "Could not create shared memory" );
    }

    //Attach shared memory segment
    GameState *gameBoard;
    if ( (gameBoard = (GameState *)shmat( shmid, NULL, 0 )) == (GameState *)-1 ) {
        perror("Error: ");
        fail( "Could not attach shared memory" );
    }

    //Unlink previous existing copy of semaphore
    sem_unlink( "/twelch2-lightsout-lock" );

    //Create the named semaphore, initialized to one
    sem_t *mySemaphore = sem_open( "/twelch2-lightsout-lock", O_CREAT, 0600, 1 );
    //Make sure semaphore successfully opened
    if ( mySemaphore == SEM_FAILED ) {
        fail( "Could not create semaphore.\n" );
    }

    //Initialize board state
    char current;
    //Read in input file and store in board array
    for (int i = 0; i < GRID_SIZE; ++i) {
        for (int j = 0; j < GRID_SIZE; ++j) {
            //Retrieve next character and fail if reaching EOF early
            if ((current = fgetc(in)) == EOF) {
                fprintf( stderr, "Invalid input file: %s", argv[1] );
                exit(1);
            } else if (current == '*' || current == '.') {
                //Add valid character to board
                gameBoard->grid[i][j] = current;
            } else {
                //Fail if invalid character read
                fprintf( stderr, "Invalid input file: %s", argv[1] );
                exit(1);
            }
        }
        current = fgetc(in);
        if (current != '\n') {
            //Wrong dimensions error
            fprintf( stderr, "Invalid input file: %s", argv[1] );
            exit(1);
        }
    }

    //Release the reference to shared memory
    shmdt(gameBoard);

    //Close input file
    fclose(in);

    //Exit after completion
    return 0;
}