/**
    @file lightsout.c
    @author Thomas Welch
    Lightsout is responsible for making a single change to the game board in shared memory and 
    then exiting. Lightsout ensures there are no race conditions by using a name semaphore created
    by reset. Some code has been adapted from my Homework 2 client and server code
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

sem_t *mySemaphore;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

//Returns the opposite character to the one provided (. or *)
char flip(char current) {
  if (current == '*') {
    return '.';
  } else {
    return '*';
  }
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int r, int c ) {
    #ifndef UNSAFE
    sem_wait( mySemaphore );
    #endif

    //Check bounds of indices
    if (r < 0 || c < 0 || r > 4 || c > 4) {
        //Release the semaphore
        #ifndef UNSAFE
        sem_post( mySemaphore );
        #endif
        //Return false, indicating error
        return false;
    }

    //Make the move and flip affected character
    int startCol = c - 1;
    int endCol = c + 1;

    //Flip the char left of chosen
    if (startCol < 0) {
        //Do nothing
    } else {
        state->grid[r][startCol] = flip(state->grid[r][startCol]);
    }
    //Flip the char right of chosen
    if (endCol > 4) {
        //Do nothing
    } else {
        state->grid[r][endCol] = flip(state->grid[r][endCol]);
    }
    //Flip the chosen char
    state->grid[r][c] = flip(state->grid[r][c]);
    int startRow = r - 1;
    int endRow = r + 1;
    //Flip the char above the chosen
    if (startRow < 0) {
        //Do nothing
    } else {
        state->grid[startRow][c] = flip(state->grid[startRow][c]);
    }
    //Flip the char below the chosen
    if (endRow > 4) {
        //Do nothing
    } else {
        state->grid[endRow][c] = flip(state->grid[endRow][c]);
    }

    //Set undo to true, indicating that undo command may be made
    state->undo = true;
    state->lastRow = r;
    state->lastCol = c;

    //Release the semaphore
    #ifndef UNSAFE
    sem_post( mySemaphore );
    #endif

    //Return true for successful completion
    return true;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ) {
    #ifndef UNSAFE
    sem_wait( mySemaphore );
    #endif

    //Check if undo is available
    if (!state->undo) {
        //Release the semaphore before returning
        #ifndef UNSAFE
        sem_post( mySemaphore );
        #endif
        //Return false, indicating failure
        return false;
    }

    int r = state->lastRow;
    int c = state->lastCol;

    //Make the move and flip affected character
    int startCol = c - 1;
    int endCol = c + 1;

    //Flip the char left of chosen
    if (startCol < 0) {
        //Do nothing
    } else {
        state->grid[r][startCol] = flip(state->grid[r][startCol]);
    }
    //Flip the char right of chosen
    if (endCol > 4) {
        //Do nothing
    } else {
        state->grid[r][endCol] = flip(state->grid[r][endCol]);
    }
    //Flip the chosen char
    state->grid[r][c] = flip(state->grid[r][c]);
    int startRow = r - 1;
    int endRow = r + 1;
    //Flip the char above the chosen
    if (startRow < 0) {
        //Do nothing
    } else {
        state->grid[startRow][c] = flip(state->grid[startRow][c]);
    }
    //Flip the char below the chosen
    if (endRow > 4) {
        //Do nothing
    } else {
        state->grid[endRow][c] = flip(state->grid[endRow][c]);
    }
    //Set undo to false
    state->undo = false;

    //Release semaphore before return
    #ifndef UNSAFE
    sem_post( mySemaphore );
    #endif

    //Return true after successful completion
    return true;
}

// Print the current state of the board.
void report( GameState *state ) {
    #ifndef UNSAFE
    sem_wait( mySemaphore );
    #endif

    //Send a report of the current board state
    char buffer[31] = {'\0'};
    int bufferPos = 0;
    //Iterate through board grid and add characters to buffer for printing
    for (int k = 0; k < GRID_SIZE; ++k) {
        for (int j = 0; j < GRID_SIZE; ++j) {
            buffer[bufferPos] = state->grid[k][j];
            ++bufferPos;
        }
        //Add a newline to facilitate printing
        buffer[bufferPos] = '\n';
        ++bufferPos;
    }
    //Print the final buffer
    printf(buffer);

    //Release semaphore before returning
    #ifndef UNSAFE
    sem_post( mySemaphore );
    #endif
}

// Test interface, for quickly making a given move over and over. 
// Code provided in assignment prompt
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
        return false;
    }
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ ) {
        move( state, r, c );
    }
    //Return true, indicating success
    return true;
}


int main( int argc, char *argv[] ) {

    mySemaphore = sem_open( "/twelch2-lightsout-lock", 0 );
    if ( mySemaphore == SEM_FAILED ) {
        fail( "Failed to open semaphore.\n" );
    }

    // Make a shared memory segment
    int key = ftok("/afs/unity.ncsu.edu/users/t/twelch2", 1);
    int shmid = shmget( key, 0, 0 );
    if ( shmid == -1 ) {
        fail( "Could not create shared memory" );
    }

    //Attach shared memory segment
    GameState *state = (GameState *)shmat( shmid, NULL, 0 );
    if ( state == (GameState *)-1 )
        fail( "Could not create shared memory" );

    //Check argument number
    if (argc < 2 ) {
        //Error, not enough arguments
        fail( "error, not enough arguments" );
    }

    //Store command
    char *command = argv[1];

    //Execute commmand
    if (strncmp(command, "move", 4) == 0) {

        //Check for necessary arguments (valid r and c values)
        if (argc != 4) {
            printf("error\n");
            exit(1);
        }

        //Convert the strings to integers
        int r = atoi(argv[2]);
        int c = atoi(argv[3]);

        //Check if indices were in bounds by function return value
        if ((move(state, r, c)) == false) {
            //Error, out of bounds
            printf("error\n");
            exit(1);
        } else {
            printf("success\n");
        }

    } else if (strncmp(command, "undo", 4) == 0) {
        //Error if undo was not available
        if ((undo(state)) == false) {
            printf("error\n");
            exit(1);
        } else {
            printf("success\n");
        }
    } else if (strncmp(command, "report", 6) == 0) {
        //Print report of current state
        report(state);
    } else if (strncmp(command, "test", 4) == 0) {

        //Check for necessary arguments (valid n, r, and c values)
        if (argc != 5) {
            printf("error\n");
            exit(1);
        }

        //Convert the strings to integers
        int n = atoi(argv[2]);
        int r = atoi(argv[3]);
        int c = atoi(argv[4]);

        //Check if indices were in bounds by function return value
        if ((test(state, n, r, c)) == false) {
            //Error, out of bounds
            printf("error\n");
            exit(1);
        }
    } else {
        //Unrecognized command
        printf("error\n");
        exit(1);
    }

    //Release the reference to shared memory
    shmdt(state);

    //Exit program
    return 0;
}
