#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// First item in buffer
int first = 0;

// Flag of whether all values have been read in from input
bool allRead = false;

// Semaphore to count the number of full spaces in vList
sem_t fullCount;

// Semaphor to let a thread change the global max_sum variable
sem_t changeMax;

// Semaphor to let a thread access vList
sem_t lock;

// Read the list of values.
void readList(int numThreads) {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Lock out any other threads from using the vCount list
    sem_wait(&lock);
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ first + vCount ] = v;
    // Increase the number of items in the list 
    vCount++;
    // Give away the lock on the list
    sem_post(&lock);
    // Increase the number of used / full spots in the list
    sem_post(&fullCount);
  }
  // All input has been read
  allRead = true;
  // Release all threads now with the allRead field as true.
  // This makes sure any waiting threads will be released from
  // waiting and know to terminate.
  for (int i = 0; i < numThreads; i++) {
    sem_post(&fullCount);
  }
}

int getWork () {
  // Locks the list from other threads from modifying
  sem_wait(&lock);
  // Index for the thread to sum
  int index = first;
  if (allRead && vCount == 0) {  // Thread needs to exit, the worker routine, will handle this
    index = -1;
  }
  else {
    // Increments, so that the next thread will get the next index
    // to sum
    first++;
    // Decrease number of used elements in the list
    vCount--;
  }
  sem_post(&lock);
  return index;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int localMax = INT_MIN;
  while (true) {
    // Waits until there is an element in the list to sum
    sem_wait(&fullCount);
    // Calls the get work method, which returns an index to sum from
    int index = getWork();
    if (index == -1) {  // All input has been read, thread will terminate
      break;
    }
    int sum = 0;
    //Summing all continuous sequences starting at index j
    for (int i = index; i >= 0; i--) {
      //Summing
      sum += vList[i];
      //Checking if adding another value increases the sum
      if (sum > localMax) {
          localMax = sum;
      }
    }
  }
  // Thread makes sure it can modify the global max_sum variable without
  // any other threads modifying it also
  sem_wait(&changeMax);
  if (localMax > max_sum) {
      max_sum = localMax;
  }
  sem_post(&changeMax);
  
  // Thread reports its maximum sum and terminates.
  // If the thread didn't get the chance to do any summing because
  // other threads had the chance first, it will print out the minimum
  // integer value as the sum.
  if (report) {
    printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), localMax);
  }
  
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  sem_init(&fullCount, 0, 0);
  sem_init(&changeMax, 0, 1);
  sem_init(&lock, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( &worker[i], NULL, workerRoutine, NULL ) != 0 ) 
      fail( "Can't create a worker thread" );
  }
  
  // Then, start getting work for them to do.
  readList(workers);

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
