#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/stat.h> 
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Main method.
int main( int argc, char *argv[] ) {
  //Checking the number of command line arguments
  if (argc != 2) {
    usage();
  }
  
  //Creating an input file
  FILE *in = fopen(argv[1], "r");
  //Exits if the input file given cannot be opened or doesn't exist
  if ( !in ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( EXIT_FAILURE );
  }
  
  // Initializing a block of shared memory based on a key in common.h
  int shmid = shmget(GET_KEY,  sizeof(GameState), 0666 | IPC_CREAT);
  // Gets the shared memory and makes it point to a struct.
  GameState *state = (GameState *) shmat(shmid, 0, 0);
  // Initializing fields of the GameState.
  state->rowUndo = -1;
  state->colUndo = -1;
  state->canUndo = false;
  
  // Using the input file to fill in each light of the GameState board.
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      char c = fgetc(in);
      //checking for invalid characters
      if (c != '.' && c != '*' && c != '\n') {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        exit( EXIT_FAILURE );
      }
      state->contents[i][j] = c;
    }
    fgetc(in);  //gets the newline character
  }
  
  // Creating and opening a new Semaphore
  // based on name from common.h
  sem_t *lock = sem_open(LOCK, O_CREAT, 0666, 1);
  if (lock == SEM_FAILED) {
    fprintf( stderr, "Can't create semaphor\n" );
    exit( EXIT_FAILURE );
  }

  // Returns and exits successfully.
  return 0;
}
