// Height and width of the playing area.
#define GRID_SIZE 5
// Common memory key
#define MEM_KEY "/afs/unity.ncsu.edu/users/j/jncoppet"
// Semaphore specific name
#define UNITY_LOCK "/jncoppet-lightsout-lock"