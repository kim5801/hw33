#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h>
#include <semaphore.h>
#include <pthread.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out two error messages and exit. Used only for invalid inputs
static void failInput( char const *message1, char const *message2 ) {
  fprintf( stderr, "%s %s\n", message1, message2 );
  exit( 1 );
}

typedef struct {
    bool canUndo;
    char prevBoard[GRID_SIZE][GRID_SIZE];
    char currentBoard[GRID_SIZE][GRID_SIZE];
    
} GameState;

// Mutual exclusion lock
sem_t * lock;

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  lock = sem_open(UNITY_LOCK, O_CREAT, 0666, 1);
  if(argc != 2) {
	    usage(); // Error if there are not exactly two command line arguments
	}
  FILE *fp = fopen(argv[1], "r");
  if( !fp ) {
	    failInput("Invalid input file: ", argv[1]); // Error if file can not open
	}
	int key = ftok(MEM_KEY, 0);
	if(key == -1) {
	    perror("error: ");
	}
  int shmid = shmget(key, sizeof(GameState), IPC_CREAT | 0666);
  if(shmid == -1) {
      perror("Error: ");
	    fail("Couldn't get memory");
	}
  GameState *sbuffer = (GameState *)shmat(shmid, 0, 0); // Initialize a GameState object to the memory that is returned
  sbuffer->canUndo = false; //Set the undo field to false 
  
  char current;
  for(int i = 0; i < GRID_SIZE; i++) {
	    for(int k = 0; k < GRID_SIZE + 2; k++) {
			    current = fgetc(fp);
			    if(k < GRID_SIZE) {
					    if(current != '*' && current != '.') {
							    failInput("Invalid input file: ", argv[1]); // Error if board is not correct
							}
					}																						    																												
		      if(current == '*' || current == '.') { // Copy input file to the current and previous boards
					    sbuffer->currentBoard[i][k] = current;
				      sbuffer->prevBoard[i][k] = current;
					}
			}
	}
  return 0;
}
