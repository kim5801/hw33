#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include <pthread.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flips from . or #
static char flip(char element) {
    if(element == '*') {
		    return '.';
		} else if(element == '.') {
		    return '*';
		} else {
		    fail("Invalid board");
		}
	  return 'x';
}
// GameState struct to keep track of the current board, previous board, and undo ability
typedef struct {
    bool canUndo;
    char prevBoard[GRID_SIZE][GRID_SIZE];
    char currentBoard[GRID_SIZE][GRID_SIZE];
    
} GameState;

// Lock for mutual exclusion
sem_t * lock;

// Keep track of lock value for debugging
int lockCount = 1;

/**
  This function makes a move for the board
  
  @param state The GameState struct to modify
  @param row The row to move at
  @param col The column to move at
  @return true if successful, false otherwise
*/
bool move( GameState *state, int row, int col) {
    #ifndef UNSAFE
        sem_wait( lock ); // Lock semaphore when tyring to move
    #endif
    state->canUndo = true;
    for(int i = 0; i < GRID_SIZE; i++) { // Firstly updates prevBoard to board before making changes to board
        for(int k = 0; k < GRID_SIZE; k++) {
				    state->prevBoard[i][k] = state->currentBoard[i][k];
			  }
    }
    if(row - 1 < 0) { // Deals with all cases when row == 0 i.e. left top row
        if(col - 1 < 0) {
				    state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
            state->currentBoard[row][col + 1] = flip(state->currentBoard[row][col + 1]);
       			state->currentBoard[row + 1][col] = flip(state->currentBoard[row + 1][col]);
				} else if(col + 1 > 4) {
            state->currentBoard[row][col - 1] = flip(state->currentBoard[row][col - 1]);
            state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
            state->currentBoard[row + 1][col] = flip(state->currentBoard[row + 1][col]);
				} else {
            state->currentBoard[row][col - 1] = flip(state->currentBoard[row][col - 1]);
            state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
            state->currentBoard[row][col + 1] = flip(state->currentBoard[row][col + 1]);
            state->currentBoard[row + 1][col] = flip(state->currentBoard[row + 1][col]);
        } 
    } else if(row + 1 > 4) { // Deals with all cases when row == 4 i.e. bottom row
        if(col - 1 < 0) {
				    state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
            state->currentBoard[row][col + 1] = flip(state->currentBoard[row][col + 1]);
   				  state->currentBoard[row - 1][col] = flip(state->currentBoard[row - 1][col]);
			  } else if(col + 1 > 4) {
            state->currentBoard[row][col - 1] = flip(state->currentBoard[row][col - 1]);
            state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
            state->currentBoard[row - 1][col] = flip(state->currentBoard[row - 1][col]);
				} else {
            state->currentBoard[row][col - 1] = flip(state->currentBoard[row][col - 1]);
            state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
            state->currentBoard[row][col + 1] = flip(state->currentBoard[row][col + 1]);
            state->currentBoard[row - 1][col] = flip(state->currentBoard[row - 1][col]);
				} 
    } else if(col - 1 < 0) { // Deals with all cases if col == 0 i.e. left column
        state->currentBoard[row - 1][col] = flip(state->currentBoard[row - 1][col]);
        state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
        state->currentBoard[row][col + 1] = flip(state->currentBoard[row][col + 1]);
        state->currentBoard[row + 1][col] = flip(state->currentBoard[row + 1][col]);
    } else if(col + 1 > 4) { // Deals with all cases if col == 4 i.e. right column
        state->currentBoard[row][col - 1] = flip(state->currentBoard[row][col - 1]);
        state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
        state->currentBoard[row + 1][col] = flip(state->currentBoard[row + 1][col]);
        state->currentBoard[row - 1][col] = flip(state->currentBoard[row - 1][col]);
    } else { // Deals with all remaining middle cases for col and row
        state->currentBoard[row][col - 1] = flip(state->currentBoard[row][col - 1]);
        state->currentBoard[row][col] = flip(state->currentBoard[row][col]);
        state->currentBoard[row][col + 1] = flip(state->currentBoard[row][col + 1]);
        state->currentBoard[row - 1][col] = flip(state->currentBoard[row - 1][col]);
        state->currentBoard[row + 1][col] = flip(state->currentBoard[row + 1][col]);
    }
    #ifndef UNSAFE
        sem_post( lock ); // Unlock semaphore when done moving
    #endif
    return true;
}

/**
  This function undoes a previously successful move
  
  @param state The GameState struct being modified
  @return true if successful, false otherwise
*/
bool undo( GameState *state) {
    #ifndef UNSAFE
        sem_wait( lock ); // Lock semaphore before undoing
    #endif
    if(state->canUndo) {
        for(int i = 0; i < GRID_SIZE; i++) { // Updates currentBoard to prevBoard 
            for(int k = 0; k < GRID_SIZE; k++) {
		            state->currentBoard[i][k] = state->prevBoard[i][k];
	  	      } 
        }
        state->canUndo = false;
        #ifndef UNSAFE
            sem_post( lock ); // Unlock semaphore before returning
        #endif
        return true;
    } else {
        #ifndef UNSAFE
            sem_post( lock ); // Unlock semaphore before returning
        #endif
        return false;
    }
}

/**
  This function reports the current state of the board
  
  @param state The GameState struct containing the board
*/
void report( GameState *state) {
    #ifndef UNSAFE
        sem_wait( lock ); // Lock semaphore before reporting
    #endif
    for(int i = 0; i < GRID_SIZE; i++) {
        for(int k = 0; k < GRID_SIZE; k++) {
            printf("%c", state->currentBoard[i][k]);
	      }
        printf("\n");
    }
    #ifndef UNSAFE
        sem_post( lock ); // Unlock semaphore before returning
    #endif
}

/**
  This function repeatedly calls move to test for deadlock
  
  @param n The number of times move is called
  @param r The row move is called at
  @param c The column move is called at
  @return true is successful, false otherwise
*/
bool test( GameState *state, int n, int r, int c) {
    if(r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
		    return false;
		}
	  for(int i = 0; i < n; i++) { // Call move n times
		    move(state, r, c);
		}
	  return true;
}

int main( int argc, char *argv[] ) {
    #ifndef UNSAFE
        lock = sem_open(UNITY_LOCK, O_CREAT, 0666, 1);
    #endif
    char buffer[7];
    if(argc == 5) {
        strcpy(buffer, "test");
        if(*argv[2] - 48 < 0 || *argv[3] - 48 < 0 || *argv[3] - 48 > 4 || *argv[4] - 48 < 0 || *argv[4] - 48 > 4) {
				    fail("Error: invalid move paramteres");
				}
			  buffer[4] = *argv[3];
			  buffer[5] = *argv[4];
		} else if(argc == 4) { // Checks number of commands
		    strcpy(buffer, "move");
	      if(*argv[2] - 48 < 0 || *argv[2] - 48 > 4 || *argv[3] - 48 < 0 || *argv[3] - 48 > 4) {
				    fail("Error: Invalid indices"); // Fails if move has invalid indices
				}
	      buffer[4] = *argv[2];
	      buffer[5] = *argv[3];
	     	if(atoi(argv[2]) < 0 || atoi(argv[2]) > 5 || atoi(argv[3]) < 0 || atoi(argv[3]) > 5) {
				    fail("Error: Invalid index"); // Fails if move has invalid indices
		    }
		} else if (argc == 2) {
		    if(strcmp(argv[1], "report") == 0) {
				    strcpy(buffer, "report");
				} else if(strcmp(argv[1], "undo") == 0) {
				    strcpy(buffer, "undo");
				} else {
				    fail("Error: Invalid command"); // Fails if bad command is entered
				}
		} else {
		    fail("Error: Invalid run parameters");
		}
    
    char cmd[4]; // Temporary string to hold first four characters for move
    cmd[0] = buffer[0];
    cmd[1] = buffer[1];
    cmd[2] = buffer[2];
    cmd[3] = buffer[3];
    cmd[4] = '\0';
    
    int shmid = shmget(ftok(MEM_KEY, 0), sizeof(GameState), IPC_CREAT | 0666);
    if(shmid == -1) {
        fail("Couldn't get memory");
	  }
    GameState *sbuffer = (GameState *)shmat(shmid, 0, 0);
    
	  if(strcmp("report", buffer) == 0) { // Prints the current state of the board
        report(sbuffer); // Call report to report the board
		} else if(strcmp("undo", buffer) == 0) { // Undoes move if possible
        if(undo(sbuffer)) { // Call undo to undo a move
				    printf("success\n");
				} else {
				    printf("error\n");
				}
		} else if(strcmp("move", cmd) == 0) { // Makes a move if possible
			   int row = buffer[4] - 48;
         int col = buffer[5] - 48;
         if(move(sbuffer, row, col)) { // Call move to make the move
				     printf("success\n");
				 } else {
				     printf("error\n");
				 }
		} else if(strcmp("test", cmd) == 0) {
			  int n = atoi(argv[2]);
		    int row = buffer[4] - 48;
        int col = buffer[5] - 48;
        if(test(sbuffer, n, row, col)) { // Call test to use test interface
	          printf("success\n");
				} else {
				    printf("error\n");
				}
		}
  return 0;
}
