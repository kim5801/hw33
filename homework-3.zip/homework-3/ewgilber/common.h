#ifndef _COMMON_H_
#define _COMMON_H_
#include <stdbool.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// Struct for game state
typedef struct GameState {
  char board[GRID_SIZE][GRID_SIZE]; 
} GameState;

#endif