#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

sem_t *shareSem;

bool move( GameState *state, int row, int col) {
       
  #ifndef UNSAFE
    sem_wait( shareSem );
  #endif

        char temp[GRID_SIZE][GRID_SIZE];
        
        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            temp[i][j] = state->board[i][j];
          }
        }
        
        //Left Side
        if(col == 0) {
          
          //Special Case 0 0
          if(row == 0) {
            if(temp[0][0] == '.') {
              temp[0][0] = '*';
            } else {
              temp[0][0] = '.';
            }
            if(temp[0][1] == '.') {
              temp[0][1] = '*';
            } else {
              temp[0][1] = '.';
            }
            if(temp[1][0] == '.') {
              temp[1][0] = '*';
            } else {
              temp[1][0] = '.';
            }
          }
          //Special Case 4 0
          else if(row == 4) {
            if(temp[4][0] == '.') {
              temp[4][0] = '*';
            } else {
              temp[4][0] = '.';
            }
            if(temp[4][1] == '.') {
              temp[4][1] = '*';
            } else {
              temp[4][1] = '.';
            }
            if(temp[3][0] == '.') {
              temp[3][0] = '*';
            } else {
              temp[3][0] = '.';
            }
          } else {
            //Special Case 1,2,3 0
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
          }
        }
          //Right side
          else if(col == 4) {
          //Special Case 0 4
          if(row == 0) {
            if(temp[0][4] == '.') {
              temp[0][4] = '*';
            } else {
              temp[0][4] = '.';
            }
            if(temp[0][3] == '.') {
              temp[0][3] = '*';
            } else {
              temp[0][3] = '.';
            }
            if(temp[4][1] == '.') {
              temp[4][1] = '*';
            } else {
              temp[4][1] = '.';
            }
          }
          //Special Case 4 4
          else if(row == 4) {
            if(temp[4][4] == '.') {
              temp[4][4] = '*';
            } else {
              temp[4][4] = '.';
            }
            if(temp[4][3] == '.') {
              temp[4][3] = '*';
            } else {
              temp[4][3] = '.';
            }
            if(temp[3][4] == '.') {
              temp[3][4] = '*';
            } else {
              temp[3][4] = '.';
            }
          } else {
            //Special Case 1,2,3 4
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
          }
        }
        //Top
        else if(row == 0 && (col != 0 || col != 4)) {
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row][col-1] == '.') {
              temp[row][col-1] = '*';
            } else {
              temp[row][col-1] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
        }

        //Bottom
        else if(row == 4 && (col != 0 || col != 4)) {
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col-1] == '.') {
              temp[row][col-1] = '*';
            } else {
              temp[row][col-1] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
        }
        else {
          if(temp[row][col] == '.') {
          temp[row][col] = '*';
          } else {
            temp[row][col] = '.';
          }
          if(temp[row-1][col] == '.') {
            temp[row-1][col] = '*';
          } else {
            temp[row-1][col] = '.';
          }
          if(temp[row+1][col] == '.') {
            temp[row+1][col] = '*';
          } else {
            temp[row+1][col] = '.';
          }
          if(temp[row][col-1] == '.') {
            temp[row][col-1] = '*';
          } else {
            temp[row][col-1] = '.';
          }
          if(temp[row][col+1] == '.') {
            temp[row][col+1] = '*';
          } else {
            temp[row][col+1] = '.';
          }
        }

        //printf("%s", *temp[0][0]);

        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            state->board[i][j] = temp[i][j];
          }
        }
        #ifndef UNSAFE
          sem_post( shareSem );
        #endif
        return true;
}

bool undo( GameState *state) {
  return true;
}

void report(GameState *state) {
  #ifndef UNSAFE
    sem_wait( shareSem );
  #endif
  
  for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            printf("%c", state->board[i][j]);
          }
  }

    #ifndef UNSAFE
    sem_post( shareSem );
    #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
// Make sure the row / colunn is valid.
if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
return false;
// Make the same move a bunch of times.
for ( int i = 0; i < n; i++ )
move( state, r, c );
return true;
}

int main( int argc, char *argv[] ) {

if ( argc < 2 || argc > 5 ) {
        fail( "usage: server <board-file>" );
    }
  
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/ewgilber", 1), sizeof(struct GameState), 0666 | IPC_CREAT );
  
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  struct GameState *gameState = (struct GameState *) shmat(shmid, 0, 0);
  
  if(gameState == ((struct GameState *)-1)) {
    fail("Can't map shared memory segment into address space");
  }

  shareSem = sem_open("/ewgilber-lightsout-lock", 1);
  if(shareSem == SEM_FAILED) {
    fail("Can't create shared semaphore");
  }
  
   // If move command is called
    if ( strcmp( argv[ 1 ] , "move" ) == 0 ) {
        if(argv[2] == NULL || argv[3] == NULL) {
            fail( "error" );
        }

        if(atoi(argv[2]) < 0 || atoi(argv[2]) > 4 || atoi(argv[3]) < 0 || atoi(argv[3]) > 4) {
            fail( "error" );
        }
        int row = atoi(argv[2]);
        int col = atoi(argv[3]);
        bool ret1 = move(gameState, row, col);
        if(ret1) {
            printf("success\n");
        } else {
          sem_close(shareSem);
            fail("error");
        }
    }

    //If undo command is called
    else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
        //Check too many arguments
        if ( argc != 2 ) {
          sem_close( shareSem );
            fail( "error" );
        }
        bool ret2 = undo(gameState);
        if(ret2) {
            printf("success\n");
        } else {
          sem_close(shareSem);
            fail("error");
        }
    }

    //If report command is called
    else if ( strcmp( argv[ 1 ], "report" ) == 0) {
        //Check too many arguments
        if ( argc != 2 ) {
          sem_close( shareSem );
            fail( "error" );
        }
        report(gameState);
    } 
    else if( strcmp( argv[ 1 ], "test" ) == 0 ) { 
            test( gameState, atoi(argv[2]), atoi(argv[3]),atoi(argv[4]) );
    } 
    
    else {
      sem_close( shareSem);
        fail( "usage: server <board-file>" );
    }

  shmdt(gameState);
  sem_close( shareSem );
  return 0;
}

