#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>

#define _GNU_SOURCE

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

int first = 0;

int num = 0;

int index = -1;

sem_t emptyCount;

sem_t fullCount;

sem_t lock;

sem_t sum;


// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES ) {
      fail( "Too many input values" );
    }
    sem_wait( &emptyCount );
    sem_wait ( &lock );
    index = vCount;
      // Store the latest value.
      vList[ vCount++ ] = v;
      num++;
      sem_post( &lock );
      sem_post( &fullCount);
  }
  
}

int getWork() {
  int returnIndex = index;
  first++;
  num--;
  return returnIndex;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int localSum = 0;
  int currentSum = 0;
  
  sem_wait(&fullCount);
  sem_wait(&lock);
    index = getWork();
    sem_post( &lock );
  sem_post( &emptyCount );
    for(int i = index; i >= 0; i--) {
      currentSum += vList[i];
      if(currentSum > localSum) {
        localSum = currentSum;
      }
    }

  if(report) {
    printf("I'm process %lu. The maximum sum I found is %d.\n", pthread_self(), localSum);
  }
  if(localSum > max_sum) {
        sem_wait(&sum);
        max_sum = localSum;
        sem_post( &sum );
  }
  
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  sem_init( &emptyCount, 0, MAX_VALUES);
  sem_init( &fullCount, 0, 0);
  sem_init( &lock, 0, 1);
 // sem_init( &sum, 0, 1);
  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0 ) 
      fail( "Can't create a child thread" );
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  sem_destroy( &emptyCount );
  sem_destroy( &fullCount );
  sem_destroy( &lock );
  sem_destroy( &sum );

  return EXIT_SUCCESS;
}
