#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// Current index that has yet to have been operated on
int workCount = 0;

// semaphore that keeps track of whether there is further input to operate on
sem_t hasValues;
// semaphore that allows only one thread to get work at a time
sem_t workLock;
// semaphore that allows only one thread to set max at a time
sem_t maxLock;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&hasValues);
  }
  sem_post(&hasValues);
}

/** determines what index the thread should work with, only allowing one thread at a time */
int getWork() {
  // acquire locks
  sem_wait(&workLock);
  sem_wait(&hasValues);
  // return value = index to operate on
  int rtn = -1;
  if (workCount < vCount) {
    rtn = workCount;
    workCount = workCount + 1;
  }
  // allow next thread to get work
  sem_post(&workLock);
  return rtn;
}

/** finds a max between 0 and given index */
int getMax(int index) {
  int max = vList[0];
  int temp = 0;
  for (int i = index; i >= 0; i--) {
    temp = temp + vList[i];
    if (temp > max) {
      max = temp;
    }
  }
  
  return max;
}

/** set the global maximum, allows only one thread to manipulate it at a time */
void setMax(int newMax) {
  // w/ semaphores
  sem_wait(&maxLock);
  max_sum = newMax;
  sem_post(&maxLock);
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // while there is work to be done
  int index = -1;
  
  int *thisMax = (int*)arg;
  
  while ((index = getWork()) >= 0) {
    int tempMax = getMax(index);
    // set max if the maximum found is greater
    if (tempMax > max_sum) {
      setMax(tempMax);
    }
    // set thisMax if necessary
    if (tempMax > *thisMax) {
      *thisMax = tempMax;
    }
  }
  // should only print once all values have been read from list
  if (report) {
    printf("I’m process %d. The maximum sum I found is %d.\n", (int)pthread_self(), *thisMax);
  }
  // let the rest of blocked threads finish
  sem_post(&hasValues);
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  
  // initialize the semaphores so only one thread can lock them.
  sem_init( &hasValues, 0, 0 );
  // initialize to 1 so first thread can do it
  sem_init( &workLock, 0, 1 );
  sem_init( &maxLock, 0, 1 );

  // Make each of the workers.
  pthread_t worker[ workers ];
  int maxes[workers];
  for ( int i = 0; i < workers; i++ ) {
    maxes[i] = INT_MIN;
    if ( pthread_create( &(worker[i]), NULL, workerRoutine, maxes + i ) != 0 ) 
      fail( "Can't create child thread" );
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }
  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
