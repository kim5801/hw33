/**
 * @file common.h
 * @author Alex Sawdy (adsawdy)
 * defines common structures between reset.c and lightsout.c
 */

// Height and width of the playing area.
#define GRID_SIZE 5

// maximum amount of characters that the user can type into the terminal
#define TERMINAL_MAX 1024

// name of semaphore
#define SEM_NAME "/adsawdy-lightsout-lock"

/** GameState, state of the game to store in shared memory with a pointer */
typedef struct {
  /** 2D array representation of the lights out game board */
  int gameBoard[GRID_SIZE][GRID_SIZE];
  /** the row of the last move that manipulated the board */
  int lastRow;
  /** the column of the last move that manipulated the board */
  int lastCol;
  /** boolean of whether undo can be done */
  bool canUndo;
} GameState;