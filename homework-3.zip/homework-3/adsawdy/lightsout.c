/**
 * @file lightsout.c
 * @author Alex Sawdy (adsawdy)
 * manipulates shared memory to play a game of "lights out"
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/ipc.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// variable marking what the user wishes to do
char todo = NULL;

/**
 * returns the opposite light
 * @param light current light condition
 * @return new light condition
 */
char toggle(char light) {
  if (light == '*') {
    return '.';
  } else {
    return '*';
  }
}

/** Make a move at the given row, column location, returning true if successful */
bool move( GameState *game, int r, int c ) {
  // "move" at row r, column c -> toggle light at that row and surrounding rows (if within board)
  
  //         (r-1)(c)
  //(r)(c-1)  (r)(c)  (r)(c+1)
  //         (r+1)(c)

  // toggle the middle
  game->gameBoard[r][c] = toggle(game->gameBoard[r][c]);
  
  // check, if valid toggle sides
  // row change:
  if ( (r - 1) >= 0 && (r - 1) < GRID_SIZE )
    game->gameBoard[r - 1][c] = toggle(game->gameBoard[r - 1][c]);
  if ( (r + 1) >= 0 && (r + 1) < GRID_SIZE )
    game->gameBoard[r + 1][c] = toggle(game->gameBoard[r + 1][c]);
  
  // col change:
  if ( (c - 1) >= 0 && (c - 1) < GRID_SIZE )
    game->gameBoard[r][c - 1] = toggle(game->gameBoard[r][c - 1]);
  if ( (c + 1) >= 0 && (c + 1) < GRID_SIZE )
    game->gameBoard[r][c + 1] = toggle(game->gameBoard[r][c + 1]);
  
  // can undo if got here from a move
  if (todo == 'm') {
    game->canUndo = true;
    game->lastRow = r;
    game->lastCol = c;
  }
  return true;
}

/** Undo the most recent move, returning true if successful */
bool undo( GameState *game ) {
  if (game->canUndo == false) {
    return false;
  } else {
    // do undo
    // no break, set r and c to previous r and c and "move" there again to undo
    int r = game->lastRow;
    int c = game->lastCol;
    // can't undo twice in a row
    game->canUndo = false;
    move(game, r, c);
  }
  return true;
}

// Print the current state of the board.
void report( GameState *game ) {
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", game->gameBoard[i][j]);
    }
    printf("\n");
  }
  return;
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}


/**
 * Main method
 * @param number of arguments
 * @param string list of arguments
 * @return exit status
 */
int main( int argc, char *argv[] ) {
  int n = -1;
  int r = -1;
  int c = -1;
  if (argc == 5 && (strcmp(argv[1], "test") == 0) && (sscanf( argv[ 3 ], "%d", &r ) == 1) && r >= 0 && r < GRID_SIZE &&
      (sscanf( argv[ 4 ], "%d", &c ) == 1) && c >= 0 && c < GRID_SIZE && (sscanf( argv[ 2 ], "%d", &n ) == 1)) {
    // test
    todo = 't';
  } else if (argc == 4 && (sscanf( argv[ 2 ], "%d", &r ) == 1) && r >= 0 && r < GRID_SIZE &&
      (sscanf( argv[ 3 ], "%d", &c ) == 1) && c >= 0 && c < GRID_SIZE && (strcmp(argv[1], "move") == 0)) {
    //move
    todo = 'm';
  } else if (argc == 2 && (strcmp(argv[1], "undo") == 0)) {
    // undo
    todo = 'u';
  } else if (argc == 2 && (strcmp(argv[1], "report") == 0)) {
    // report
    todo = 'r';
  } else {
    // no need to connect/disconnect from shared memory
    fail("error");
  }
  
  
  // set the shared memory key
  int memKey = ftok("/afs/unity.ncsu.edu/users/a/adsawdy/", 1);
  
  // get handle to shared memory
  int shmid = shmget(memKey, sizeof(GameState), 0);
  if (shmid < 0) {
    fail("failed to attach to shared memory with shmget()");
  }
  
  // create pointer to an Instance of GameState to more easily manipulate shared memory
  GameState *game = (GameState *)shmat(shmid, 0, 0);
  if ( *((int *)game) == -1) {
    fail("failed to operate on shared memory with shmat()");
  }
  
  // open shared semaphore
  sem_t *loSem = sem_open( SEM_NAME, 0 );
  if ( loSem == SEM_FAILED )
    fail( "Can't open lightsout semaphore" );

  // only one iteration of lightsout may edit the game structure at a time
  // done with the shared semephore
  // acquire
  
  #ifndef UNSAFE
    sem_wait( loSem );
  #endif
  
  switch (todo) {
    case 'u':
      if (undo(game)) {
        printf("success\n");
      } else {
        printf("error\n");
      }
      break;
    case 'm':
      if (move(game, r, c)) {
        printf("success\n");
      } else {
        printf("error\n");
      }
      break;
    case 'r':
      // report the current state of the game board
      report(game);
      break;
    case 't':
      // new implementation: test
      if (n > 0) {
        test(game, n, r, c);
      } else {
        printf("error\n");
      }
      break;
  }
  // release
  #ifndef UNSAFE
    sem_post( loSem );
  #endif
  
  // disconnect semaphore
  sem_close( loSem );
  
  // disconnect
  shmdt(game);

  return 0;
}
