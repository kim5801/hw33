#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Compile with
// gcc -Wall -g -std=c99 -o maxsum-sem maxsum-sem.c -lpthread 

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// Semaphore for global sum variable
sem_t sumSem;

// Semaphore for value list
sem_t workerLock;

// Semaphore which is 0 when the list is empty
sem_t fullCount;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Largest index that has been assigned to a worker
int assignedCount = 0;

// Number of values that still need to be assigned
int assignedRemaining = 0;

bool readListFinished = false;


// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    sem_wait(&workerLock);
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    assignedRemaining++;
    sem_post(&workerLock);
    //printf("reading\n");
    sem_post(&fullCount);
  }
}

// Assigns and index for the thread to work on
// Returns -1 if all work has been assigned
int getWork()
{
  if (readListFinished && assignedCount == vCount && assignedRemaining >= 1) { // Return -1 if no more work will enter the buffer and all work is assigned
    //printf("returning -1\n");
    return -1;
  }
  else {
    assignedRemaining--;
    //printf("waiting\n");
    sem_wait(&fullCount);
    sem_wait(&workerLock);
    assignedCount++;
    //printf("Aquired semaphores\n");
    sem_post(&workerLock);
    //printf("Returning %d\n", assignedCount);
    return assignedCount;
  }
}

/**
// Assigns and index for the thread to work on
// Returns -1 if all work has been assigned
int getWork()
{
  //printf("assignedCount: %d\n", assignedCount);
  //printf("vCount: %d\n", vCount);

  // Wait if all indexes have been assigned but there's the possibility
  // of more work
  while (assignedCount == vCount) {
    if (readListFinished) { // Return -1 if no more work will enter the buffer
      printf("readLineFinished\n");
      return -1;
    }
    else { // Wait if more work might enter
      printf("%d waiting in %ld\n", assignedCount + 1, pthread_self());
      printf("assignedCount: %d\n", assignedCount);

    }
    printf("looping\n");
  }
  printf("%d done waiting in %ld\n", assignedCount + 1, pthread_self());

  assignedCount++;
  //printf("returning from getWork\n");
  return assignedCount - 1;
}
*/

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int index = getWork();
  int localMaxSum = 0;
  int sum = 0;

  // While there is still work to do
  while (index != -1 && !readListFinished && assignedCount != vCount) {
    sum = 0;
    //printf("index: %d\n", index);
    // Calculate maxSum
    // For each value in the list, add to the sum
    for (int i = 0; i < index; i++) {
      sum += vList[i];
      // If the sum is greater than the current maxSum, update maxSum
      if (sum > localMaxSum) {
        localMaxSum = sum;
      }
    }



    index = getWork();
  }

  // Update maxSum if needed
  if (localMaxSum > max_sum) {
    sem_wait(&sumSem);
    max_sum = localMaxSum;
    sem_post(&sumSem);
  }

  if (report) {
    printf("I'm thread %ld. The maximum sum I found is %d\n", pthread_self(), localMaxSum);
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  // Initialize semaphores
  sem_init(&sumSem, 0, 1);
  sem_init(&workerLock, 0, 1);
  sem_init(&fullCount, 0, 0);

  int workers = 4;
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    pthread_create(&worker[i], NULL, workerRoutine, NULL);
  }

  // Then, start getting work for them to do.
  readList();
  readListFinished = true;

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join( worker[i], NULL );
    //printf("%d joined\n", i);
  }

  // Destroy semaphores
  sem_destroy(&sumSem);
  sem_destroy(&workerLock);
  sem_destroy(&fullCount);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
