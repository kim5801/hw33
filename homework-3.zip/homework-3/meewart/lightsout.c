#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Semaphore for the board struct
sem_t *boardSem;

// Compile with
// gcc -Wall -g -std=c99 -D_XOPEN_SOURCE=500 -o lightsout lightsout.c -lpthread

// Toggles a given row or col of the game board
// Handles error checking if row or col is invalid
// 0 1 2 3 4 5
// 6 7 8 9 10 11
// 12 13 14 15 16 17
// 18 19 20 21 22 23
// 24 25 26 27 28 29
static void toggle(GameState *board, int row, int col) {
  if (row >= 0 && row < 5 && col >= 0 && col < 5) {
    int rowStartingIndex = 6 * row;
    int stateIndex = rowStartingIndex + col;

    if (board->state[stateIndex] == '*') {
      board->state[stateIndex] = '.';
    }
    else {
      board->state[stateIndex] = '*';
    }
  }
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make a move at the given row, column location, returning true
// if successful.
bool move(GameState *state, int row, int col)
{
  if (row >= 0 && row < 5 && col >= 0 && col < 5) {
    #ifndef UNSAFE
    // Aquire
    sem_wait(boardSem);
    #endif

    // Save move
    state->prevRow = row;
    state->prevCol = col;

    // If row or col is out of bounds due to math, toggle doesn't do anything
    toggle(state, row, col);
    toggle(state, row - 1, col);
    toggle(state, row + 1, col);
    toggle(state, row, col - 1);
    toggle(state, row, col + 1);

    // Since a move has been made, set undo value to true
    state->undoAllowed = 1;

    #ifndef UNSAFE
    // Release
    sem_post(boardSem);
    #endif

    return true;
  }
  return false;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state )
{
  #ifndef UNSAFE
  // Aquire
  sem_wait(boardSem);
  #endif
  
  if (state->undoAllowed) {
    int row = state->prevRow;
    int col = state->prevCol;

    toggle(state, row, col);
    toggle(state, row - 1, col);
    toggle(state, row + 1, col);
    toggle(state, row, col - 1);
    toggle(state, row, col + 1);
    state->undoAllowed = 0;

    #ifndef UNSAFE
    // Release
    sem_post(boardSem);
    #endif

    return true;
  }
  else {
    #ifndef UNSAFE
    // Release
    sem_post(boardSem);
    #endif

    return false;
  }
}

// Print the current state of the board.
void report( GameState *state )
{
  #ifndef UNSAFE
  // Aquire
  sem_wait(boardSem);
  #endif

  // Report
  printf("%s", state->state);

  #ifndef UNSAFE
  // Release
  sem_post(boardSem);
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }

  return true;
}



int main( int argc, char *argv[] ) {
  // Create shared memory
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/m/meewart", 100), sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Open the semaphore already made by reset program
  //sem_t *boardSem = malloc(sizeof sem_t);
  boardSem = sem_open( "/meewart-lightsout-lock", 0 );
  if ( boardSem == SEM_FAILED ) {
    fail( "Can't open board semaphore" );
  }
    
  // Map the shared memory into address space
  GameState *gameBoard = (GameState *) shmat( shmid, 0, 0 );

  // Move command
    if (argc == 4 && strcmp(argv[1], "move") == 0
      && strlen(argv[2]) == 1 && argv[2][0] >= '0' && argv[2][0] <= '4'
      && strlen(argv[3]) == 1 && argv[3][0] >= '0' && argv[3][0] <= '4') {

      // Set to 5 to make sure that they are reset correctly by sscanf
      int row = 5;
      int col = 5;

      // Read in rows and cols
      if (sscanf(argv[2], "%d", &row) != 1 || sscanf(argv[3], "%d", &col) != 1) {
        printf("error\n");
      }
      else {
        // Move
        bool success = move(gameBoard, row, col);

        if(success)
          printf("success\n");
        else {
          printf("error\n");
        }
      }
    }
    // Undo command
    else if (argc == 2 && strcmp(argv[1], "undo") == 0 ) {
      // Undo
      bool success = undo(gameBoard);

      // Print status
      if (success) {
        printf("success\n");
      }
      else {
        printf("error\n");
      }
    }
    // Report command
    else if (argc == 2 && strcmp(argv[1], "report") == 0) {
      report(gameBoard);
    }
    // Test command
    else if (argc == 5 && strcmp(argv[1], "test") == 0) {
      int row = 0;
      int col = 0;
      int n = 0;

      // Read in rows and cols
      if (sscanf(argv[2], "%d", &n) != 1 || sscanf(argv[3], "%d", &row) != 1 || sscanf(argv[4], "%d", &col) != 1) {
        printf("error\n");
      }
      else {
        test(gameBoard, n, row, col);
      }
    }
    // Unrecognized command
    else {
      printf("error\n");
    }

  return 0;
}
