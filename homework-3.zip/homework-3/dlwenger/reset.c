/**
 * @file reset.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * The reset.c source file contains the code for loading/resetting a board
 * for the lights-out game. The program reads a file containing the board into a
 * board struct that can be accessed by other programs through shared memory. It also
 * creates the named semaphore that will be used in lightsout.c to prevent race conditions.
 *
 */
#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Print out a usage message and exit.
static void usage()
{
    fprintf(stderr, "usage: reset <game-state-file>\n");
    exit(1);
}
/**
 * Reads in a board from a file and stores it in a board struct
 *
 * @param b the board struct
 * @param file the name of the file
 */
static void readFile(Board *b, char *file)
{
    FILE *inFile = fopen(file, "r");
    if (inFile == NULL) {
        char message[strlen("Invalid input file: ") + strlen(file)];
        strcpy(message, "Invalid input file: ");
        strcat(message, file);
        fail(message);
    }

    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE + 1; j++) {
            char c = fgetc(inFile);
            if (j != GRID_SIZE && (c == '.' || c == '*')) {
                b->board[i][j] = c;
            }
            else if (j == GRID_SIZE && c == '\n') {
                continue;
            }
            else {
                char message[strlen("Invalid input file: ") + strlen(file)];
                strcpy(message, "Invalid input file: ");
                strcat(message, file);
                fclose(inFile);
                fail(message);
            }
        }
    }
    b->canUndo = false;
    fclose(inFile);
}
/**
 * The main function of reset which creates shared memory for the Board struct and then sets up that struct with
 * a board stored in a file.
 *
 * @param argc the number of command line arguments
 * @param argv the strings containing the command line arguments
 * @return int the exit status of the program.
 */
int main(int argc, char *argv[])
{
    if (argc != 2) {
        usage();
    }
    sem_open("/dlwenger-lightsout-lock", O_CREAT, 0600, 1);
    int smhid = shmget(ftok("/afs/unity.ncsu.edu/users/d/dlwenger", 1), sizeof(Board), 0666 | IPC_CREAT);
    Board *b = (Board *)shmat(smhid, 0, 0);
    readFile(b, argv[1]);

    return 0;
}
