#define _GNU_SOURCE
#include <sys/syscall.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}
//Used to keep track of how many values are left in the list
sem_t gettingIndex;

//Used to keep threads from changing the max at the same time
sem_t changeMax;

//Used to keep threads from entering getWork at the same time
sem_t work;

// True if we're supposed to report what we find.
bool report = false;

//True if the main thread is still reading in values
bool reading = true;

// Maximum sum we've found.
int max_sum = INT_MIN;

//Keeps track of the index to give to each worker
int idx = 0;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

/** Workers call this when they need more work to do */
int getWork() {
  //if the main thread is still reading input
  if(reading) {
    //check if there is a value to get from the list
    //printf("taking from idx1\n");
    sem_wait(&gettingIndex);
    //printf("taking from idx1 passed\n");
    //return the index to check and increment it
    return idx++;
  } else if(!reading && idx != vCount) {
    //printf("taking from idx2\n");
    sem_wait(&gettingIndex);
    //printf("taking from idx2 passed\n");
    return idx++;
  }
  //this means there is nothing left to do
  //printf("returning negative\n");
  return -1;
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES ) {
      fail( "Too many input values" );
    }

    // Store the latest value.
    vList[ vCount++ ] = v;
    
    //release sem
    //printf("adding to idx\n");
    sem_post(&gettingIndex);
  }
  //the main thread is no longer reading input
  reading = false;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  
  //make sure only one thread at a time can be getting work so that index is not
  //accessed by more than one thread at once.
  //printf("getting1 ");
  sem_wait(&work);
  int val = getWork();
  sem_post(&work);
  //printf(" done1\n");
  
  //values for local sum and max for each thread
  int localSum = INT_MIN;
  int localMax = INT_MIN;
  
  
  while(val > -1) {
    //loop through the list decrementing
    for (int i = val; i > 0; i--) {
    
      //if its the first iteration make localSum equal to the value at i
      if (i == val) {
        localSum = vList[i];
      } else {
        //increment the sum by the i'th value in the list
        localSum += vList[i];
      }
      
      //if the local sum is greater than the global max change the global max
      if (localSum > max_sum) {
        //make sure no two threads access max_sum at the same time
        sem_wait(&changeMax);
        max_sum = localSum;
        sem_post(&changeMax);
      }
      
      //change the local max if localSum is greater
      if(localSum > localMax) {
        localMax = localSum;
      }
    }
    //make sure only one thread at a time can be getting work so that index is not
    //accessed by more than one thread at once.
    //printf("getting2 ");
    sem_wait(&work);
    val = getWork();
    sem_post(&work);
    //printf(" done2\n");
  }

  if (report) {
    printf("I'm process %ld. The maximum sum I found is %d.\n", syscall(__NR_gettid), localMax);
  }
  
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  sem_init(&gettingIndex, 0, 0);
  sem_init(&changeMax, 0, 1);
  sem_init(&work, 0, 1);
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 ) {
    usage();
  }
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 || workers < 1 ) {
    usage();
  }

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 ) {
      usage();
    }
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( &worker[i], NULL, workerRoutine, NULL ) != 0 ) {
      fail( "Can't create a child thread\n" );
    }
  }
  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join( worker[i], NULL );
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}