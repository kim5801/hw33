#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <sys/stat.h>
#include <semaphore.h>

#define BLOCK_SIZE sizeof(GameState)

//global variable fro semaphore so functions can access it
sem_t *sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//Changes a . to a * or vice versa on the game board
static void makeMove(GameState *game, int idx) {
  if(game->newGame[idx] == '*') {
    game->newGame[idx] = '.';
  } else if (game->newGame[idx] == '.') {
    game->newGame[idx] = '*';
  }
}

//Makes newGame equal to oldGame
static void undoMove(GameState *game) {
  for(int i = 0; i < 25; i++) {
    game->newGame[i] = game->oldGame[i];
  }
}

//Makes oldGame equal to newGame
static void newBoard(GameState *game) {
  for(int i = 0; i < 25; i++) {
    game->oldGame[i] = game->newGame[i];
  }
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *game, int r, int c ) {
    #ifndef UNSAFE
      sem_wait( sem );
    #endif

    newBoard(game);

      //makes the move using the makeMove helper method
      int idx = (r * 5) + c;
      if (c > 0 && c < 4) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx - 1 >= 0) {
          makeMove(game, idx - 1);
        }
        
        if (idx + 1 <= 24) {
          makeMove(game, idx + 1);
        }

      }
      else if (c == 0) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx + 1 >= 0) {
          makeMove(game, idx + 1);
        }
      }
      else if (c == 4) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx - 1 >= 0) {
          makeMove(game, idx - 1);
        }
      }
      game->flag = 1;
      #ifndef UNSAFE
        sem_post( sem );
      #endif
      return true;
}
// Undo the most recent move, returning true if successful.
bool undo( GameState *game ) {
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  if(game->flag) {
    undoMove(game);
    game->flag = 0;
    #ifndef UNSAFE
      sem_post( sem );
    #endif
    return true;
  } else {
    #ifndef UNSAFE
      sem_post( sem );
    #endif
    return false;
  }
}
// Print the current state of the board.
void report( GameState *state ) {
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  int linecnt = 0;
    for (int i = 0; i <= 24; i++) {
      if (linecnt == 5) {
        printf("\n");
        linecnt = 0;
        i--;
        continue;
      }
      printf("%c", state->newGame[i]);
      linecnt++;
    }
    printf("\n");
    #ifndef UNSAFE
      sem_post( sem );
    #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= 5 || c < 0 || c >= 5 )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

//Starting point of the program receives information from the user and 
//outputs accordingly.
int main( int argc, char *argv[] ) {
  // Make a shared memory segment one GameState in size
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/t/ttheis2", 1), BLOCK_SIZE, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
    
  // Map the shared memory into my address space
  GameState* game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  sem = sem_open("/ttheis2-lightsout-lock", 0);
  
  if (argc == 4) {
    int row = argv[2][0] - '0';
    int col = argv[3][0] - '0';
    if (strcmp("move", argv[1])) {
      printf("error\n");
      exit(1);
    }
    //checks if the given row and col are valid
    if (argv[2][0] < '0' || argv[2][0] > '4') {
      shmdt(game);
      printf("Invalid row\n");
      exit(1);
    }
    if (argv[3][0] < '0' || argv[3][0] > '4') {
      shmdt(game);
      return false;
      printf("Invalid col\n");
      exit(1);
    }
    if (strlen(argv[2]) != 1 || strlen(argv[3]) != 1) {
      shmdt(game);
      printf("Invalid args\n");
      exit(1);
    }
    
    if(move(game, row, col)) {
      printf("success\n");
      shmdt(game);
      exit(0);
    } else {
      printf("error\n");
      exit(1);
    }

  }
  
  if (argc == 5) {
    int row = argv[3][0] - '0';
    int col = argv[4][0] - '0';
    int times = atoi(argv[2]);
    
    //checks if the given row and col are valid
    if (strlen(argv[3]) != 1 || strlen(argv[4]) != 1) {
      shmdt(game);
      printf("Invalid args\n");
      exit(1);
    }
    
//     if(times <= 0) {
//       exit(0);
//     }
    
    if (!strcmp("test", argv[1])) {
      if(test(game, times, row, col)) {
        exit(0);
      } else {
        printf("error\n");
        exit(1);
      }
    } else {
      printf("error\n");
      exit(1);
    }
    
  }
  
  if (argc == 2) {
  
    if(strcmp("undo", argv[1]) && strcmp("report", argv[1])) {
      printf("error\n");
      exit(1);
    }
    
    if (!strcmp("undo", argv[1])) {
      if(undo(game)) {
        printf("success\n");
        shmdt(game);
        exit(0);
      } else {
        printf("error\n");
        shmdt(game);
        exit(1);
      }
    }
    
    if (!strcmp("report", argv[1])) {
      report(game);
      shmdt(game);
      exit(0);
    }
  } else {
    printf("error\n");
    shmdt(game);
    exit(1);
  }
  return 0;
}