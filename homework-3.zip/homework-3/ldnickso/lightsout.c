/**
  @file lightsout.c
  @author Lane Nickson (ldnickso)
  @author Dr. Sturgill
  Homework 3, Problem 3
*/

// Includes all libraries and definitions
#include "common.h"

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Convert the board array into a string
static char *reportBoard(char (*board)[GRID_SIZE])
{
  // This malloc will be freed once the report printed.
  char *boardString = (char *)malloc((GRID_SIZE + 1) * (GRID_SIZE));
  int currentBoardX = 0;
  int currentBoardY = 0;
  // For each board tile, add its status and place newlines when needed
  for (int i = 0; i < (GRID_SIZE + 1) * (GRID_SIZE); i++)
  {
    boardString[i] = board[currentBoardX++][currentBoardY];
    if (currentBoardX == GRID_SIZE)
    {
      if (currentBoardY != GRID_SIZE - 1)
      {
        boardString[++i] = '\n';
      }
      else
      {
        // End the string with a null terminator
        boardString[++i] = '\0';
      }
      currentBoardX = 0;
      currentBoardY++;
    }
  }
  return boardString;
}

// Locking semaphore
sem_t *lock;

//Change board values (for move and undo)
static void editBoard(GameState *state, int r, int c) {
  GameState currentState = *state;
  char (*board)[GRID_SIZE] = currentState.board;
  int xPos = c;
  int yPos = r;
  // Update left, right, and center
  for (int i = xPos - 1; i <= xPos + 1; i++)
  {
    if (i >= 0 && i < GRID_SIZE)
    {
      if (board[i][yPos] == STAR)
      {
        board[i][yPos] = PERIOD;
      }
      else
      {
        board[i][yPos] = STAR;
      }
    }
  }
  // Update top and down
  for (int i = yPos - 1; i <= yPos + 1; i += 2)
  {
    if (i >= 0 && i < GRID_SIZE)
    {
      if (board[xPos][i] == STAR)
      {
        board[xPos][i] = PERIOD;
      }
      else
      {
        board[xPos][i] = STAR;
      }
    }
  }
  //Update associated variables
  currentState.lastX = xPos;
  currentState.lastY = yPos;
  *state = currentState;
}

// Toggles the state of the cell and surrounding cells
static void move(GameState *state, int r, int c)
{
  #ifndef UNSAFE
    sem_wait( lock );
  #endif
  editBoard(state, r, c);
  GameState currentState = *state;
  currentState.canUndo = true;
  *state = currentState;
  #ifndef UNSAFE
    sem_post( lock );
  #endif
}

// Undo the last move
static void undo(GameState *state)
{
  #ifndef UNSAFE
    sem_wait( lock );
  #endif
  GameState currentState = *state;
  if (currentState.canUndo)
    {
      // Revert to old board by making the same move again
      editBoard(state, currentState.lastY, currentState.lastX);
      currentState = *state;
      currentState.canUndo = false;
      *state = currentState;
    }
    else
    {
      printf("error\n");
    }
  #ifndef UNSAFE
    sem_post( lock );
  #endif
}

// Report the board to the terminal
static void report(GameState *state)
{
  #ifndef UNSAFE
    sem_wait( lock );
  #endif
  GameState currentState = *state;
  char *boardString = reportBoard(currentState.board);
  printf("%s\n", boardString);
  free(boardString);
  #ifndef UNSAFE
    sem_post( lock );
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

int main(int argc, char *argv[])
{
  //Get the shared semaphore
  lock = sem_open(SEMAPHORE_NAME, 0);
  // Get a unique ID
  key_t shareKey = ftok(PATH, ID);

  // Get the board from shared memory
  int shmid = shmget(shareKey, sizeof(GameState), 0);
  if (shmid == -1)
  {
    fail("Error locating shared memory. Please make sure ./reset has been executed before running this program.");
  }
  GameState *state = (GameState *)shmat(shmid, 0, 0);

  // DEBUG:
  // printf("CanUndo: %d\n", currentState.canUndo);
  // printf("X: %d\n", currentState.lastX);
  // printf("Y: %d\n", currentState.lastY);

  // Initial error handling - wrong number of args
  if (argc < 2 || argc > 5)
  {
    fail("error");
  }

  // Handle undo command
  if (strcmp(argv[1], UNDO) == 0 && argc == 2)
  {
    undo(state);
    printf("success\n");
  }
  // Handle report command
  else if (strcmp(argv[1], REPORT) == 0 && argc == 2)
  {
    report(state);
  }
  // Handle move command
  else if (strcmp(argv[1], MOVE) == 0 && argc == 4)
  {
    // Integer Check
    for (int i = 2; i <= 3; i++)
    {
      int number;
      int isNum = sscanf(argv[i], "%d", &number);
      if (isNum == 0 || number >= GRID_SIZE)
      {
        fail("error");
      }
    }

    int x = atoi(argv[3]);
    int y = atoi(argv[2]);

    // Make the move
    move(state, y, x);
    printf("success\n");
  }
   // Handle test command
  else if (strcmp(argv[1], TEST) == 0 && argc == 5)
  {
    // Integer Check
    for (int i = 2; i <= 4; i++)
    {
      int number;
      int isNum = sscanf(argv[i], "%d", &number);
      if (isNum == 0 || (number >= GRID_SIZE && i != 2))
      {
        fail("error");
      }
    }

    int x = atoi(argv[4]);
    int y = atoi(argv[3]);
    int n = atoi(argv[2]);

    // Go to test method
    test(state, n, y, x);
  }
  else
  {
    fail("error");
  }

  return 0;
}
