/**
  @file reset.c
  @author Lane Nickson (ldnickso)
  @author Dr. Sturgill
  Homework 3, Problem 3
*/

// Includes all libraries and definitions
#include "common.h"

// Print out a usage message and exit.
static void usage()
{
  fprintf(stderr, "usage: reset <game-state-file>\n");
  exit(1);
}

int main(int argc, char *argv[])
{
  // Create the GameState struct
  GameState initialGameState;
  initialGameState.canUndo = false;
  initialGameState.lastX = 0;
  initialGameState.lastY = 0;

  if (argc != 2)
  {
    usage();
  }
  // Read the input file
  int fd = open(argv[1], O_RDONLY);
  if (argc == 2 && fd != -1)
  {
    char boardBuf[(GRID_SIZE + 1) * (GRID_SIZE)];
    int count = read(fd, &boardBuf, sizeof(boardBuf));
    if (count != sizeof(boardBuf) || count == -1)
    {
      printf("Invalid input file: %s\n", argv[1]);
    }
    else
    {
      // Check to make sure all input is correct and transfer thre data to the baord[][] array
      int currentBoardX = 0;
      int currentBoardY = 0;
      for (int i = 0; i < sizeof(boardBuf); i++)
      {

        if (currentBoardX != GRID_SIZE)
        {
          // printf("%c", boardBuf[i]);
          if (boardBuf[i] != PERIOD && boardBuf[i] != STAR)
          {
            printf("Invalid input file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
          }
          else
          {
            initialGameState.board[currentBoardX][currentBoardY] = boardBuf[i];
            currentBoardX++;
          }
        }
        else
        {
          // printf("%c", boardBuf[i]);
          if (boardBuf[i] != '\n')
          {
            printf("Invalid input file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
          }
          else
          {
            currentBoardX = 0;
            currentBoardY++;
          }
        }
      }
    }
  }
  else
  {
    printf("Invalid input file: %s\n", argv[1]);
  }

  // Get a unique ID
  key_t shareKey = ftok(PATH, ID);

  // Send the board to shared memory
  int shmid = shmget(shareKey, sizeof(GameState), 0666 | IPC_CREAT);
  GameState *state = (GameState *)shmat(shmid, 0, 0);
  *state = initialGameState;

  // Create a shared semahphore
  sem_unlink(SEMAPHORE_NAME);
  sem_open(SEMAPHORE_NAME, O_CREAT, S_IRWXU, 1);

  return 0;
}
