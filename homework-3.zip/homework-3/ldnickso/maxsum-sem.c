#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum-sem <workers>\n");
  printf("       maxsum-sem <workers> report\n");
  exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Current index to be assigned to a worker thread
int currentAssignmentIndex;

// Anonymous semaphores for accessing globals and for uniterrupted execution
sem_t fullCount;
sem_t lock;
sem_t maxSumAccess;
sem_t getWorkAccess;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000

int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

//Has readList finished reading?
bool finishedReading = false;

// Read the list of values.
void readList()
{
  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1)
  {
    sem_wait(&lock);
    // Make sure we have enough room, then store the latest input.
    if (vCount > MAX_VALUES)
      fail("Too many input values");

    // Store the latest value.
    vList[vCount++] = v;
    sem_post(&lock);
    sem_post(&fullCount);
  }
  finishedReading = true;
}

// Get an index that a worker thread can find the max sum of
int getWork()
{
  //Make sure that this process isn't interrupted as to prevent currentAssignmentIndex assignment errors
  sem_wait(&getWorkAccess);
  int indexToReturn;
  // -1 is our sentinel value to return
  if (currentAssignmentIndex >= vCount && finishedReading)
  {
    indexToReturn = -1;
  }
  else
  {
    // Block until there is input to read from the pipe
    sem_wait(&fullCount);
    sem_wait(&lock);

    indexToReturn = currentAssignmentIndex;
    currentAssignmentIndex++;

    sem_post(&lock);
  }
  sem_post(&getWorkAccess);
  return indexToReturn;
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
  int maxFoundSum = 0;
  int index = getWork();
  while (index != -1)
  {

    // Find Maximum Sum
    int currentSum = 0;
    for (int i = index; i >= 0; i--)
    {
        currentSum += vList[i];
      // printf("Current Sum: %d\n", currentSum);
        if (currentSum > maxFoundSum)
        {
          maxFoundSum = currentSum;
        }
    }
    // Update max_sum
    sem_wait(&maxSumAccess);
      if (maxFoundSum > max_sum)
      {
        max_sum = maxFoundSum;
      }
    sem_post(&maxSumAccess);

    // get the next index
    index = getWork();
  }

  // Report maxFoundSum
    if (report)
    {
      printf("I'm thread %d. The maximum sum I found is %d\n", (int)pthread_self(), maxFoundSum);
    }

  return NULL;
}

int main(int argc, char *argv[])
{
  int workers = 4;
  currentAssignmentIndex = 0;

  // Initialize semaphore
  sem_init(&fullCount, 0, 0);
  sem_init(&lock, 0, 1);
  sem_init(&getWorkAccess, 0, 1);
  sem_init(&maxSumAccess, 0, 1);

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 ||
      workers < 1)
    usage();

  // If there's a second argument, it better be "report"
  if (argc == 3)
  {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[workers];
  for (int i = 0; i < workers; i++)
  {
    if (pthread_create(&worker[i], NULL, workerRoutine, NULL) != 0)
    {
      fail("Can't create a child thread");
    }
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for (int i = 0; i < workers; i++)
  {
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf("Maximum Sum: %d\n", max_sum);

  return EXIT_SUCCESS;
}