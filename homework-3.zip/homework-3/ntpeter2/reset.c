/**
 * initializes game board and a structure that can be used across
 * several client programs (lightsout.c). Accepts a filename parameter
 * that should store the initial game board to be set to
 * updated to protect shared memory when multiple operations 
 * are performed at once
 * @author Nolan Peters
 * @file reset.c
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * create a gameboard from the given input file fp
 * @param fp input file
 * @param gameBoard array to be filled
 * @param filename name of file fp points to
 */
static void createBoard(FILE *fp, char gameBoard[GRID_SIZE][GRID_SIZE], char *fileName) {
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
          char ch = fgetc(fp);
          gameBoard[i][j] = ch;
          if (gameBoard[i][j] != '*' && gameBoard[i][j] != '.') {
              fprintf(stderr, "Invalid input file: %s\n", fileName);
              exit( 1 );
          }
      }
      fgetc(fp); //newline char
    }
}

int main( int argc, char *argv[] ) {

    //check if num arguments are correct
    if (argc != 2) {
        usage();
    }
    //try creating file
    FILE *fp = fopen(argv[1], "r");
  
    //if file cannot be created, mark as invalid and exit
    if (fp == NULL) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
    }
    
    //create shared memory
    key_t key = ftok("/afs/unity.ncsu.edu/users/n/ntpeter2", 1);
    int shmid = shmget(key, sizeof(struct GameState), 0666 | IPC_CREAT);
    if (shmid == -1) {
        fail("Couldn't create shared memory");
    }
    struct GameState *game = (struct GameState*) shmat(shmid, 0, 0);
    createBoard(fp, game->board, argv[1]);
    game->canUndo = false;
    
    sem_open("/ntpeter2-lightsout-lock", O_CREAT, 0666, 1);
    
  return 0;
}
