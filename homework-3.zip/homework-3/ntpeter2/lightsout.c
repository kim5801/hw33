/**
 * manages operations on a lightsout game board, allowing for user to
 * view the board using report, make a move using move and allowing for
 * the previous move to be reverted
 * @author Nolan Peters
 * @file lightsout.c
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// semaphore used to protect memory
sem_t *sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}



/** 
 *prints out the current game board
 *@param gameBoard array
 */
static void report(struct GameState *state) {
    #ifndef UNSAFE
        sem_wait(sem);
    #endif

    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
          printf("%c", state->board[i][j]);
      }
      printf("\n");
    }
    #ifndef UNSAFE
        sem_post(sem);
    #endif
}

/** 
 * performs a move operation on the gameboard indicated by row/column
 * @param gameBoard board to be operated on
 * @param row row of move location
 * @param column column of move location
 */
static bool move(struct GameState *state, int r, int c) {

    #ifndef UNSAFE
        sem_wait(sem);
    #endif
    if ((r > 4 || r < 0) || (c > 4 || c < 0)) {
            #ifndef UNSAFE
                sem_post(sem);
            #endif
            fail("error");
        }

        state->row = r;
        state->column = c;
        state->canUndo = true;
        
    if (state->board[r][c] == '.') {
        state->board[r][c] = '*';
    } else { state->board[r][c] = '.';
    }
    
    if (r - 1 >= 0) {
        if (state->board[r - 1][c] == '.') {
            state->board[r - 1][c] = '*';
        } else { state->board[r - 1][c] = '.';
        }
    }
    
    if (r + 1 < GRID_SIZE) {
        if (state->board[r + 1][c] == '.') {
            state->board[r + 1][c] = '*';
        } else { state->board[r + 1][c] = '.';
        }
    }
    
    if (c - 1 >= 0 ) {
        if (state->board[r][c - 1] == '.') {
            state->board[r][c - 1] = '*';
        } else { state->board[r][c - 1] = '.';
        }
    }
    
    if (c + 1 < GRID_SIZE ) {
        if (state->board[r][c + 1] == '.') {
            state->board[r][c + 1] = '*';
        } else { state->board[r][c + 1] = '.';
        }
    }
    
    #ifndef UNSAFE
        sem_post(sem);
    #endif
    return true;
}

/**
 * undos the previous move, cannot be done consecutively without
 * a move operation between
 * @param state shared memory of gamestate
 * @param r row to undo
 * @param c column to undo
 * @return true if undo move was successful
 *
 */
static bool undo(struct GameState *state, int r, int c) {
    #ifndef UNSAFE
        sem_wait(sem);
    #endif
    if (!(state->canUndo)) {
          #ifndef UNSAFE
              sem_post(sem);
          #endif
          fail("error");
      }
    #ifndef UNSAFE
        sem_post(sem);
    #endif
    move(state, r, c);
    
     #ifndef UNSAFE
        sem_wait(sem);
    #endif
    state->canUndo = false;
    
    #ifndef UNSAFE
        sem_post(sem);
    #endif
    return true;
}

// Test interface, for quickly making a given move over and over.
bool test( struct GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
         return false;
    }
       
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ ) {
        move( state, r, c );
    }

    return true;
}



int main( int argc, char *argv[] ) {
    sem = sem_open("/ntpeter2-lightsout-lock", O_CREAT);
    //create key and access shared memory
    key_t key = ftok("/afs/unity.ncsu.edu/users/n/ntpeter2", 1);
    int shmid = shmget(key, sizeof(struct GameState), 0666);
    struct GameState *game = (struct GameState*) shmat(shmid, 0, 0);
    
    //check if number of arguments is invalid
 if (argc < 2 || argc > 5) {
        fail("error");
    }
    
    
    //process for if report is called
    if (strcmp(argv[1], "report") == 0) {
        report(game);
    // check if the process is move
   } else if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            fail("error");
        }
        int r = atoi(argv[2]);
        int column = atoi(argv[3]);
        move(game, r, column);
        printf("success\n");
    }
    
     else if (strcmp(argv[1], "undo") == 0) {
      //use GameState memory to repeat previous move (undoing it)
       undo(game, game->row, game->column);
       printf("success\n");
   }
     else if (strcmp(argv[1], "test") == 0) {
         if (argc != 5) {
             fail("error");
         }
         test(game, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
     
    } else { fail("error"); } //incorrect argument
    exit(0);
}
