#include <stdbool.h>
// Height and width of the playing area.
#define GRID_SIZE 5

struct GameState {
    int prevMove[2];
    char board[GRID_SIZE][GRID_SIZE];
    bool undoOK;
};