#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
sem_t emptyCount;
sem_t fullCount;
sem_t lock;

/** Represents first index */
int first = 0;
/** Represents whether the reader function has finished reading from input */
bool finished = false;
/** Represents the number of indexes already counted in the list */
int counted = 0;
/** True if we're supposed to report what we find. */
bool report = false;
/** Maximum sum we've found. */
int max_sum = INT_MIN;
/** Represents list of numbers from input file*/
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
    printf( "usage: maxsum-sem <workers>\n" );
    printf( "       maxsum-sem <workers> report\n" );
    exit( 1 );
}


// Read the list of values.
void readList() {
    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Make sure we have enough room, then store the latest input.
        if ( vCount > MAX_VALUES )
        fail( "Too many input values" );

        // Store the latest value.
        vList[ vCount++ ] = v;
    }
    finished = true; //signal that the reader has finished reading input from text file
}

/**
 * Finds and returns the maximum sum over a range of numbers.
 *
 * @return int representing max sum over a range of numbers in a list
 */
static int findMax(int first, int last) {
    //will store the sum of the current worker
    int sum;
    for(int i = first; i < last; i++) { //iterate over whole range
        int temp = vList[ i ]; //compute the sum of the range that starts and ends at index i
        for(int j = i + 1; j < last; j++) { //iterate over rest of the range
            temp += vList[ j ]; //compute the sum of the sequence that starts at index i and ends at index j
            if(temp > sum)
                sum = temp;
        }
    }
    return sum;
}

/**
 * Workers call this function when they become idle. It returns immediately if there’s more to work on, or, 
 * if all available work has already been given out, the function blocks the worker until more input has been
 * read by the main thread.
 * Returns the index that a worker should start at
 * 
 * @return int representing the index a worker should work from in the list
 */
int getWork() {
    // enter critical section:
    sem_wait(&lock);

    int idx = 0;

    // if reader has finished reading from input and we've counted all the indexes in the list
    if(finished && counted >= vCount) {
        sem_post(&lock); // exit critical section and tell workerRoutine we're done
        return -1;
    }
    // update return value to the number of indexes counted
    idx = counted;
    counted++; //increment counted to show we've counted another index

    sem_post(&lock); //exit critical section
    return idx;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
    int thismax = 0, toWork = 0;
    //consumer thread:
    while ( (toWork = getWork()) != -1 ) {
        int retVal = findMax(toWork, vCount); // get maximum sum over assigned range of indexes
        if(retVal > thismax) // if value returned from findMax() is larger than max on file...
            thismax = retVal; //update max value
        // first = ( first + 1 ) % vCount;
        // vCount--;
    }
    //check if local max is greater than global max sum value
    if(thismax > max_sum)
        max_sum = thismax; //if so, update global variable
    // printf("end of worker\n");
    if(report)
        printf( "I'm thread %lu. The maximum sum I found is %d\n", pthread_self(), thismax );
    return NULL;
}

int main( int argc, char *argv[] ) {
    int workers = 4;
    
    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();
    
    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 || workers < 1 )
        usage();

    // If there's a second argument, it better be "report"
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 )
        usage();
        report = true;
    }

    // sem_init(&emptyCount, 0, MAX_VALUES);
    // sem_init(&fullCount, 0, 0);
    sem_init(&lock, 0, 1);
    // Make each of the workers.
    pthread_t worker[ workers ];
    for ( int i = 0; i < workers; i++ )
        pthread_create( &worker[ i ], NULL, workerRoutine, NULL );

    // Then, start getting work for them to do.
    readList();

    void *ret;
    // Wait until all the workers finish.
    for ( int i = 0; i < workers; i++ )
        pthread_join( worker[i], &ret );

    // Report the max product and release the semaphores.
    printf( "Maximum Sum: %d\n", max_sum );
    
    return EXIT_SUCCESS;
}
