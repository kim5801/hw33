#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <semaphore.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Make a move at the given row, column location, returning true
// if successful.
bool move( struct GameState *state, int r, int c );
// Undo the most recent move, returning true if successful.
bool undo( struct GameState *state );
// Print the current state of the board.
void report( struct GameState *state );

sem_t *plzhold;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// If the command executes successfully print message and exit.
static int success() {
    printf("success\n");
    return 0;
}

// Checks if provided numbers are out of bounds for the board
static bool outofbound(int num) {
    if(num < 0 || num > 4)
        return true;
    return false;
}

// Prints board to stdout
void report(struct GameState *state ) {
    #ifndef UNSAFE
    sem_wait(plzhold);
    #endif

    for(int i = 0; i < GRID_SIZE; i++) {
        for(int j = 0; j < GRID_SIZE; j++)
            printf("%c", state->board[ i ][ j ]);
        putchar('\n');
    }

    #ifndef UNSAFE
    sem_post(plzhold);
    #endif
}

// Checks if provided character is a digit
//   returns true if digit, otherwise false
static bool isDigit(char curr) {
    if(curr >= '0' && curr <= '9')
        return true;
    return false;
}

// Updates provided space turn "lights" on or off
void updateSpace(char *curr) {
    if(*curr == '*')
        *curr = '.';
    else
        *curr = '*';
}

void makeMove( struct GameState *state, int r, int c ) {
    // check if space is a valid space on the board.
    // if it is, update space, otherwise don't
    if(!outofbound(r - 1))
        updateSpace(&(state->board[r - 1][c]));
    if(!outofbound(r + 1))
        updateSpace(&(state->board[r + 1][c]));
    if(!outofbound(c + 1))
        updateSpace(&(state->board[r][c + 1]));
    if(!outofbound(c - 1))
        updateSpace(&(state->board[r][c - 1]));
}

bool move( struct GameState *state, int r, int c ) {
    #ifndef UNSAFE
    sem_wait(plzhold);
    #endif

    state->undoOK = true;
    updateSpace(&(state->board[r][c]));
    // check if space is a valid space on the board.
    // if it is, update space, otherwise don't
    makeMove( state, r, c );
    // save move to prevMove in state struct
    state->prevMove[0] = r;
    state->prevMove[1] = c;
    //shmdt( state ); // release reference to shared memory
    
    #ifndef UNSAFE
    sem_post(plzhold);
    #endif

    return true;
}

bool undo( struct GameState *state ) {
    #ifndef UNSAFE
    sem_wait(plzhold);
    #endif

    int row = state->prevMove[0];
    int col = state->prevMove[1];

    makeMove( state, row, col );
    state->undoOK = false;
    
    #ifndef UNSAFE
    sem_post(plzhold);
    #endif

    return true;
}

// Test interface, for quickly making a given move over and over.
bool test( struct GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );
    return true;
}


int main( int argc, char *argv[] ) {
    if(argc != 4 && argc != 2 && argc != 5) { //must have 2 or 4 command line arguments
        fail("error");
    }
    char *command = argv[ 1 ];
    if(strcmp(command, "move") != 0 && strcmp(command, "undo") != 0 
        && strcmp(command, "report") != 0 && strcmp(command, "test") != 0) {
        fail("Out of bounds"); //if the second argument is an invalid option
    }
    
    int row = -1, col = -1;
    if(strcmp(command, "move") == 0) {
        if( argc != 4 || !isDigit(*argv[ 2 ]) || !isDigit(*argv[ 3 ]) )
            fail("error"); //if the arguments provided after move keyword are invalid
        //converts char to int
        row = atoi(argv[ 2 ]);
        col = atoi(argv[ 3 ]);
        
        if(outofbound( row ) || outofbound( col ))
            fail("error"); //if the arguments provided after move keyword are invalid
    }

    int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/evmurphy", 0), sizeof( struct GameState ), 0 ); //create segment of memory for GameState
    if ( shmid == -1 )
        fail( "Can't create shared memory" );
    
    struct GameState *game = (struct GameState *) shmat( shmid, 0, 0 ); //cast pointer to GameState struct
    if ( game == (struct GameState *) - 1 ) //if memory segment fails to map successfully
        fail( "Can't map shared memory segment into address space" );

    #ifndef UNSAFE
    plzhold = sem_open("/evmurphy-lightsout-lock", 1);
    #endif

    if(strcmp(command, "move") == 0) { // if provided command is to make a move
        move( game, row, col );
        return success();
    }
    if(strcmp(command, "undo") == 0) { // if provided command is to undo the last move
        if(!game->undoOK) // if there isn't a move to undo, exit unsuccessfully
            fail("error");
        undo( game );
        return success();
    }
    if(strcmp(command, "report") == 0)
        report( game );
    if(strcmp(command, "test") == 0)
        test( game, atoi(argv[ 2 ]), atoi(argv[3]), atoi(argv[4]) );
    // Release our reference to the shared memory segment.
    shmdt( game );
    return 0;
}
