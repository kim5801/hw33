#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Status on if the list has been finished reading in
bool finished = false;

// The current index the next worker should do
int count = 0;

// Used for a critical section in updating the maximum sum
sem_t maxLock;

// Used for a critical section in updating the count index
sem_t workLock;

// Used for signifying a new value was read
sem_t valLock;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    sem_post(&valLock);
  }

  finished = true;
  sem_post(&valLock);
}

// Get the next index for the list
int getWork() {
  // Wait until the next value is read
  sem_wait(&workLock);
  sem_wait(&valLock);

  if (finished && count == vCount) {
    sem_post(&valLock);
    sem_post(&workLock);
    return -1;
  }

  // Increment and return the index
  int index = count++;
  sem_post(&workLock);
  return index;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int start = -1, sum = 0, max = 0;

  do {
    // Reset the start index and sum
    start = getWork();
    sum = 0;

    // Calculate a sum
    for (int i = start; i >= 0; i--) {
      sum += vList[i];

      if (sum > max) {
        max = sum;
      }
    }
  } while (start != -1);

  // Update the maximum sum
  sem_wait(&maxLock);
  if (max > max_sum) {
    max_sum = max;
  }
  sem_post(&maxLock);

  if (report) {
    printf("I'm thread %ld. The maximum sum I found was %d.\n", syscall(__NR_gettid), max);
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Create semaphores
  if (sem_init(&maxLock, 0, 1) == -1 || sem_init(&workLock, 0, 1) == -1 || sem_init(&valLock, 0, 0) == -1) {
    fail("Failed to create semaphores");
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if (pthread_create(&worker[i], NULL, workerRoutine, NULL) != 0) {
      fail("Failed to create worker");
    }
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    if (pthread_join(worker[i], NULL) != 0) {
      fail("Failed to join worker");
    }
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  if (sem_destroy(&maxLock) == -1 || sem_destroy(&workLock) == -1 || sem_destroy(&valLock) == -1) {
    fail("Failed to destroy semaphores");
  }

  return EXIT_SUCCESS;
}
