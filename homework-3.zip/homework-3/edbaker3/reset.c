#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Populate a board from a given file path
int populateBoard(GameState *board, char *path) {
  // Open the file
  FILE *fp = fopen(path, "r");
  if (fp == NULL) {
    return -1;
  }

  char c;
  int i = 0;

  // Read line by line and populate the board
  while ((c = fgetc(fp)) > 0) {
    // Populate the board on a '.' or '*' and ignore '\n', return error on anything else
    switch (c) {
      case '.':
      case '*':
        *(*(board->current + i / GRID_SIZE) + i % GRID_SIZE) = c == '*';
        i++;
        break;

      case '\n':
        break;

      default:
        return -1;
    }
  }

  // Return status on the count representing a square of length GRID_SIZE
  return (i == GRID_SIZE * GRID_SIZE) - 1;
}

int main( int argc, char *argv[] ) {
  // Sanity check and get the arguments
  if (argc != 2) {
    usage();
  }
  char *path = argv[1];

  // Get the id for the shared memory segment
  key_t key = ftok(PATH, PROJ_ID);

  int shmid;
  // Attempt to get the memory segment (if it already exists) to prevent seg faults
  if ((shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT)) == -1) {
    fail("Cannot create shared memory");
  }

  // Map the shared memory into address space
  GameState *game = (GameState *) shmat(shmid, 0, 0);
  if (game == (GameState *) -1) {
    fail("Cannot get game state");
  }

  // Create the shared semaphore
  sem_unlink(SEM_PATH);
  sem_t *lock = sem_open(SEM_PATH, O_CREAT, 0666, 1);
  if (lock == SEM_FAILED) {
    printf("%d - %d\n", errno, EACCES);
    fail("Cannot open the semaphore");
  }

  GameState g = {.undo = false};
  *game = g;

  // Attempt to populate the board, and print an error if it exists
  if (populateBoard(game, path) == -1) {
    char errStr[1024] = "Invalid input file: ";
    strncat(errStr, path, strlen(path));
    fail(errStr);
  }

  if (shmdt(game) == -1) {
    fail("Cannot detach from shared memory");
  }

  return 0;
}
