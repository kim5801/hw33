// Height and width of the playing area.
#define GRID_SIZE 5

// Pathname for shared memory key
#define PATH "/afs/unity.ncsu.edu/users/e/edbaker3"

// Pathname for semaphore
#define SEM_PATH "/edbaker3-lightsout-lock"

// Project ID for shared memory key
#define PROJ_ID 1

// Struct that represents the board that will be stored in shared memory
typedef struct gameState {
  bool current[GRID_SIZE][GRID_SIZE];
  bool previous[GRID_SIZE][GRID_SIZE];
  bool undo;
} GameState;

