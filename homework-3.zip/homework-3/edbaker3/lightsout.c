#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out the usage message and exit
static void usage() {
  printf("usage: lightsout move <row> <column>\n");
  printf("       lightsout undo\n");
  printf("       lightsout rpeort\n");
  exit(1);
}

// Semaphore for mutual exclusion
sem_t *lock;

// Print out the current state of the board
bool printBoard(GameState *game) {
#ifndef UNSAFE
  sem_wait(lock);
#endif

  // Add characters from each row and column
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", '*' + (*(*(game->current + i) + j) - 1) * -4);
    }
    // Add a newline at the end of each row
    printf("\n");
  }

#ifndef UNSAFE
    sem_post(lock);
#endif
    return true;
}

// Make a move on a board and populate a status message
bool move(GameState *game, int row, int col) {
#ifndef UNSAFE
  sem_wait(lock);
#endif

  // Check if the positions are in bounds
  if (row < 0 || col < 0 || row >= GRID_SIZE || col >= GRID_SIZE) {
#ifndef UNSAFE
    sem_post(lock);
#endif
    return false;
  }

  // Set the previous board to the current one before a move is made
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      game->previous[i][j] = game->current[i][j];
    }
  }

  // Invert the corrent spots on the board
  *(*(game->current + row) + col) = !*(*(game->current + row) + col);
  if (col > 0) *(*(game->current + row) + col - 1) = !*(*(game->current + row) + col - 1);
  if (col < GRID_SIZE - 1) *(*(game->current + row) + col + 1) = !*(*(game->current + row) + col + 1);
  if (row > 0) *(*(game->current + row - 1) + col) = !*(*(game->current + row - 1) + col);
  if (row < GRID_SIZE - 1) *(*(game->current + row + 1) + col) = !*(*(game->current + row + 1) + col);

  // Return success and update undo status
  game->undo = true;

#ifndef UNSAFE
    sem_post(lock);
#endif
  return true;
}

// Undo the latest move
bool undo(GameState *game) {
#ifndef UNSAFE
  sem_wait(lock);
#endif

  // Return error if the board cannot be undone
  if (!(game->undo)) {
#ifndef UNSAFE
    sem_post(lock);
#endif
    return false;
  }
  game->undo = false;

  // Change every element from previous to current
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      game->current[i][j] = game->previous[i][j];
    }
  }

#ifndef UNSAFE
    sem_post(lock);
#endif
  return true;
}

// Test interface to check for race conditions
bool test(GameState *game, int n, int row, int col) {
  if (!move(game, row, col)) {
    return false;
  }

  for (int i = 1; i < n; i++) {
    move(game, row, col);
  }

  return true;
}

int main( int argc, char *argv[] ) {
  // Sanity check and get the arguments
  if (argc != 2 && argc != 4 && argc != 5) {
    usage();
  }

  int n = -1, row = -1, col = -1;
  if (argc == 4 &&
      (sscanf(argv[2], "%d", &row) == -1 || sscanf(argv[3], "%d", &col) == -1)) {
    usage();
  } else if (argc == 5 &&
      (sscanf(argv[2], "%d", &n) == -1 || sscanf(argv[3], "%d", &row) == -1 || sscanf(argv[4], "%d", &col) == -1)) {
    usage();
  }

  // Get the semaphore
  lock = sem_open(SEM_PATH, 0);
  if (lock == SEM_FAILED) {
    fail("Cannot open the semaphore");
  }

  // Get the id for the shared memory segment
  key_t key = ftok(PATH, PROJ_ID);

  // Get the shared memory segment id
  int shmid = shmget(key, 0, 0);
  if (shmid == -1) {
    fail("Cannot get memory");
  }

  // Map the shared memory into address space
  GameState *game = (GameState *) shmat(shmid, 0, 0);
  if (game == (GameState *) -1) {
    fail("Cannot map shared memory segment");
  }

  // Parse the command, exit if the command is successful, return if not
  if (
      (strcmp(argv[1], "move") == 0 && move(game, row, col)) ||
      (strcmp(argv[1], "undo") == 0 && undo(game)) ||
      (strcmp(argv[1], "test") == 0 && test(game, n, row, col))
    ) {
    printf("success\n");
  } else if (strcmp(argv[1], "report") == 0 && printBoard(game)) {
    // Don't print success for report queries
  } else {
    printf("error\n");
  }

  if (shmdt(game) == -1) {
    fail("Cannot detach from shared memory");
  }

  return 0;
}
