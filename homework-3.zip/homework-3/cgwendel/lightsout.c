#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

sem_t *sem1;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

typedef struct {
    char board[ 5 ][ 5 ];
    int row;
    int col;
    _Bool undoAllowed;
} GameState;

void makeMove( GameState *b, int row, int col ) {
    #ifndef UNSAFE
        sem_wait( sem1 );
    #endif
    if ( b->board[ row ][ col ] == '.' ) {
        b->board[ row ][ col ] = '*';
    } else {
        b->board[ row ][ col ] = '.';
    }
    if ( row != 0 ) {
        if ( b->board[ row - 1 ][ col ] == '.' ) {
            b->board[ row - 1 ][ col ] = '*';
        } else {
            b->board[ row - 1 ][ col ] = '.';
        }                    
    }
    if ( col != 0 ) {
        if ( b->board[ row ][ col - 1 ] == '.' ) {
            b->board[ row ][ col - 1] = '*';
        } else {
            b->board[ row ][ col - 1] = '.';
        }                    
    }
    if ( row != 4 ) {
        if ( b->board[ row + 1 ][ col ] == '.' ) {
            b->board[ row + 1 ][ col ] = '*';
        } else {
            b->board[ row + 1 ][ col ] = '.';
        }                    
    }
    if ( col != 4 ) {
        if ( b->board[ row ][ col + 1 ] == '.' ) {
            b->board[ row ][ col + 1 ] = '*';
        } else {
            b->board[ row ][ col + 1 ] = '.';
        }                    
    }  
    #ifndef UNSAFE
        sem_post( sem1 );
    #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {

// Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;
        
// Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        makeMove( state, r, c );
        
    return true;
}

int main( int argc, char *argv[] ) {

    key_t key = ftok( "/afs/unity.ncsu.edu/users/c/cgwendel" , 1 );
    int shmid = shmget( key, sizeof( GameState ), 0666 );
    GameState *gameState = ( GameState * )shmat( shmid, 0, 0 );
    sem1 = sem_open( "/cgwendel-lightsout-lock", 0 );
    
    if ( argc != 2 && argc != 4 && argc != 5 ) {
        fail( "error" );
    }

    if ( strcmp( "move", argv[ 1 ] ) == 0 && argc == 4 ) {
        if ( atoi( argv[ 2 ] ) > 4 || atoi( argv[ 2 ] ) < 0 || 
             atoi( argv[ 3 ] ) > 4 || atoi( argv[ 3 ] ) < 0) {
            fail( "error" );
        } else {
            gameState->row = atoi( argv[ 2 ] );
            gameState->col = atoi( argv[ 3 ] );
            gameState->undoAllowed = 0;
            makeMove( gameState, atoi( argv[ 2 ] ), atoi( argv[ 3 ] ) );
            printf( "success\n" );
        }
    } else if ( strcmp( "undo" , argv[ 1 ] ) == 0 && argc == 2) {
        if ( gameState->undoAllowed == 1 ) {
            printf( "error\n" );
        } else {
            gameState->undoAllowed = 1;
            makeMove( gameState, gameState->row, gameState->col );
            printf( "success\n" );
        }
    } else if ( strcmp( "report", argv[ 1 ] ) == 0 && argc == 2 ) {
        char board[ 30 ];
        int place = 0; 
        #ifndef UNSAFE
            sem_wait( sem1 );
        #endif
        for ( int i = 0; i < 5; i++ ) {
            for ( int j = 0; j < 5; j++ ) {
                *( board + place ) = gameState->board[ i ][ j ];
                place++;
            }
            *( board + place ) = '\n';
            place++;
        }
        *( board + place ) = '\0';
        printf( "%s", board );
        #ifndef UNSAFE
            sem_post( sem1 );
        #endif
    } else if ( strcmp( "test", argv[ 1 ] ) == 0 ) {
        test( gameState, atoi( argv[ 2 ] ), atoi( argv[ 3 ] ), atoi( argv[ 4 ] ) );
    } else {
        fail( "error" );
    }

    return 0;
}
