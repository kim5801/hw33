#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

typedef struct {
    char board[ 5 ][ 5 ];
    int row;
    int col;
    _Bool undoAllowed;
} GameState;


int main( int argc, char *argv[] ) {

    int boardFile = open( argv[ 1 ], O_RDWR, 0600 );
    if ( argc != 2 ) {
        usage();
    } else if ( boardFile == -1 ) {
        printf( "Invalid input file: %s\n", argv[ 1 ] );
        exit( 1 );
    }
    
    key_t key = ftok( "/afs/unity.ncsu.edu/users/c/cgwendel" , 1 );
    int shmid = shmget( key, sizeof( GameState ), 0666 | IPC_CREAT );
    GameState *shMem = ( GameState * )shmat( shmid, 0, 0 );
    sem_open( "/cgwendel-lightsout-lock", O_CREAT, 0600, 1 );
    
    char *format = malloc( sizeof( char ) );
    for ( int i = 0; i < 5; i++ ) {
        for ( int j = 0; j < 6; j++ ) {
            read( boardFile, format, 1 );
            if ( *format != '*' && *format != '.' && *format != '\n' ) {
                printf( "Invalid input file: %s\n", argv[ 1 ] );
                exit( 1 );
            } else if ( *format == '\n' && j != 5 ) {
                printf( "Invalid input file: %s\n", argv[ 1 ] );
                exit( 1 );      
            } else if ( j != 5 ) {
                shMem->board[ i ][ j ] = *format;
            }
        }
    }    
    free( format );

  return 0;
}
