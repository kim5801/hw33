// Height and width of the playing area.
#define GRID_SIZE 5

struct GameStateStruct 
{
  bool grid[ GRID_SIZE ][ GRID_SIZE ];
  int lastY;
  int lastX;
} typedef GameState;
