#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

//semaphore for blocking worker from accessing data before it has been collected
sem_t semaphore;

//the starting index for a worker
int index = 0;

//says if there is work left for the workers to do
bool isWorkLeft = true;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&semaphore);
  }
  isWorkLeft = false;
}

int getWork() {
  if (index >= vCount) 
    sem_wait(&semaphore);
  if (!isWorkLeft && index >= vCount)
    return -1;
  return index++;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int maxLocalSum = INT_MIN;
  int i = getWork();
  while ( i >= 0 ) {
    //printf("i %d\n", i);
    int sum = 0;
    for (; i >= 0; i--) {
      sum += vList[ i ];
      if ( sum > maxLocalSum )
        maxLocalSum = sum;
    }
    
    i = getWork();
  }
  if (maxLocalSum == INT_MIN)
      maxLocalSum = 0;
  
  if (maxLocalSum > max_sum)
    max_sum = maxLocalSum;
  
  if ( report )
    printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), maxLocalSum);
  
  
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  sem_init(&semaphore, 0, 0);
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(worker + i, NULL, workerRoutine, NULL);
  
  // Then, start getting work for them to do.
  readList();
  
  for ( int i = 0; i < workers; i++ )
    sem_post(&semaphore);
  
  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[i], NULL );
  
  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
