#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

//shared semaphore to prevent GameState being accessed at same time
sem_t *sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

bool move( GameState *game, int x, int y ) 
{
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  if ( x - 1 >= 0 ) {
    if ( game->grid[ x - 1 ][ y ] == 0 ) {
      game->grid[ x - 1 ][ y ] = 1 ;
    } else {
      game->grid[ x - 1 ][ y ] = 0 ;
    }
  }
  if ( x + 1 < GRID_SIZE ) {
    if ( game->grid[ x + 1 ][ y ] == 0 ) {
      game->grid[ x + 1 ][ y ] = 1 ;
    } else {
      game->grid[ x + 1 ][ y ] = 0 ;
    }
  }
  if ( y - 1 >= 0 ) {
    if ( game->grid[ x ][ y - 1 ] == 0 ) {
      game->grid[ x ][ y - 1 ] = 1 ;
    } else {
      game->grid[ x ][ y - 1 ] = 0 ;
    }
  }
  if ( y + 1 < GRID_SIZE ) {
    if ( game->grid[ x ][ y + 1 ] == 0 ) {
      game->grid[ x ][ y + 1 ] = 1 ;
    } else {
      game->grid[ x ][ y + 1 ] = 0 ;
    }
  }
  if ( game->grid[ x ][ y ] == 0 ) {
      game->grid[ x ][ y ] = 1 ;
  } else {
      game->grid[ x ][ y ] = 0 ;
  }
  game->lastX = x;
  game->lastY = y;
  
  #ifndef UNSAFE
    sem_post( sem );
  #endif
  return true;
}

bool undo( GameState *game )
{
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  if ( game->lastX < 0 || game->lastY < 0 ) {
    #ifndef UNSAFE
      sem_post( sem );
    #endif
    return false;
  }
  
  if ( game->lastX - 1 >= 0 ) {
    if ( game->grid[ game->lastX - 1 ][ game->lastY ] == 0 ) {
      game->grid[ game->lastX - 1 ][ game->lastY ] = 1 ;
    } else {
      game->grid[ game->lastX - 1 ][ game->lastY ] = 0 ;
    }
  }
  if ( game->lastX + 1 < GRID_SIZE ) {
    if ( game->grid[ game->lastX + 1 ][ game->lastY ] == 0 ) {
      game->grid[ game->lastX + 1 ][ game->lastY ] = 1 ;
    } else {
      game->grid[ game->lastX + 1 ][ game->lastY ] = 0 ;
    }
  }
  if ( game->lastY - 1 >= 0 ) {
    if ( game->grid[ game->lastX ][ game->lastY - 1 ] == 0 ) {
      game->grid[ game->lastX ][ game->lastY - 1 ] = 1 ;
    } else {
      game->grid[ game->lastX ][ game->lastY - 1 ] = 0 ;
    }
  }
  if ( game->lastY + 1 < GRID_SIZE ) {
    if ( game->grid[ game->lastX ][ game->lastY + 1 ] == 0 ) {
      game->grid[ game->lastX ][ game->lastY + 1 ] = 1 ;
    } else {
      game->grid[ game->lastX ][ game->lastY + 1 ] = 0 ;
    }
  }
  if ( game->grid[ game->lastX ][ game->lastY ] == 0 ) {
      game->grid[ game->lastX ][ game->lastY ] = 1 ;
  } else {
      game->grid[ game->lastX ][ game->lastY ] = 0 ;
  }

  game->lastX = -1;
  game->lastY = -1;
  
  #ifndef UNSAFE
    sem_post( sem );
  #endif
  
  return true;
}

void report( GameState *game )
{
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      if ( game->grid[ i ][ j ] ) {
        printf( "%c", '*' );
      } else {
        printf( "%c", '.' );
      }
    }
    printf( "\n" );
  }
  #ifndef UNSAFE
    sem_post( sem );
  #endif
}

bool test( GameState *game, int n, int r, int c ) {
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  
  for ( int i = 0; i < n; i++ )
    move( game, r, c );
  
  return true;
}



int main( int argc, char *argv[] ) {
  
  sem = sem_open( "/jrbrefka-lightsout-lock", 0 );
  if ( sem == SEM_FAILED )
    fail( "Can't open semaphore" );
  
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/j/jrbrefka", 1 ), 0, 0 );
  if ( shmid == -1 )
    fail( "Failed to create memory" );
  
  GameState *game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Failed to map shared memory segment into address space" );
  
  if ( strcmp( argv[ 1 ], "test" ) == 0 ) {
    int n = atoi( argv[ 2 ] );
    int r = atoi( argv[ 3 ] );
    int c = atoi( argv[ 4 ] );
    if ( test(game, n, r, c) ) {
      //printf("Success\n");
    } else {
      fail("error");
    }
  } else if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    if ( argc != 4 ) {
      fail("error");
    }
    
    int x = atoi( argv[ 2 ] );
    int y = atoi( argv[ 3 ] );
    //make sure it did not parse garbage
    if ( x == 0 && !( strcmp( argv[ 2 ], "0" ) == 0 ) ) {
      fail("error");
    } else if ( y == 0 && !( strcmp( argv[ 3 ], "0" ) == 0 ) ) {
      fail("error");
    } else if ( x >= GRID_SIZE || x < 0 || y >= GRID_SIZE || y < 0 ) {
      //make sure x and y are valid
      fail("error");
    } else {
      //flip lights
      move( game, x, y );
      printf("success\n");
    } 
    
  } else if ( strcmp( argv[ 1 ], "undo" ) == 0  ) {
    if ( argc != 2 )
      fail("error");
    //check if an undo can be done
    if ( undo( game ) ) {
      printf("success\n");
    } else {
      fail("error");
    }
  } else if ( strcmp( argv[ 1 ], "report" ) == 0  ) {
    if ( argc != 2 )
      fail("error");
    
    //report lights
    report( game );
    
  } else {
    fail("error");
  }
  
  shmdt(game);
  sem_close( sem );
  
  return 0;
}
