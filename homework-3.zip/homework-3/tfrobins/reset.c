#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  //unlink from the last game
  sem_unlink(NAME);
  //check for proper args
  if(argc != 2){
    usage();
  }
  //open up file for reading
  int input = open(argv[1], O_RDONLY|O_CREAT);
  //if file cannot be open
  if(input == -1){
    fail("Can't open file");
  }
  //get the shared memory segment for the game state
  key_t skey = PATH
  int shmid = shmget(skey, sizeof(GameState), 0666 | IPC_CREAT);
  //configure the memory to the struct type
  GameState *game = (GameState *) shmat(shmid, 0, 0);

  //prevent a race condition
  sem_t *order = sem_open(NAME, O_CREAT, 0600, 1);
  if ( order == SEM_FAILED )
  fail( "Can't open order semaphore" );

  char newLine;
  //load the file into the GameState
  for(int i=0; i<GRID_SIZE; i++){
    for(int j=0; j<GRID_SIZE; j++){
      read(input, &game->board[i][j], sizeof(char));
      //check if input board is valid
      if(game->board[i][j] != '.' && game->board[i][j] != '*'){
        printf("Invalid input file: %s\n", argv[1]);
        exit(1);
      }
    }
    //scrap the newline char
    read(input, &newLine, sizeof(char));
  }
  return 0;
}
