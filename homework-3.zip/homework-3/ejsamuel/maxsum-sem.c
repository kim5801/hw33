#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * Function that determines the max of the two numbers
 * @param a number one
 * @param b number two
 * @return the max of the two
 */
int maxOfTwo(int a, int b) {
  if(a > b) {
    return a;
  } else if (b > a) {
    return b;
  } else {
    return a;
  }
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];
bool coverage[ MAX_VALUES];
// Current number of values on the list.
int vCount = 0;



sem_t semWaiting;
sem_t semCovered;
sem_t semMax;
int current = 0;
int reading;
int index;

//where the thread is


/**
 * 
 * @return the index
 */
int getWork() {
   
    if(current == vCount && !reading) {
      return -1;
    }
    sem_wait(&semWaiting);
    // printf("got work\n");
    current++;
    // printf("Current: %d\n", current); 
    return current;
  
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  reading = true;

  while ( scanf( "%d", &v ) == 1 ) {
    
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );
    
    vList[ vCount++ ] = v;
    sem_post(&semWaiting);
    
  }
  reading = false;
  
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {

  int test =  *((int *)arg);  
  int threadMax;
  while(true) {
    
    sem_wait(&semCovered);
    index = getWork();
    sem_post(&semCovered);
   
    if(index == -1) {
      break;
    }
      int curr = 0;
      int total = 0;
      // threadMax = 0;
      
    for(int i = index; i >= 0; i--) {

          curr = maxOfTwo(curr, total + vList[i]);
          total += vList[i];
          
    }
    
    threadMax = maxOfTwo(threadMax, curr); 
    // printf("%d\n",threadMax);
    sem_wait(&semMax);
    test = threadMax;
    max_sum = maxOfTwo(max_sum, threadMax);
    sem_post(&semMax);
    // *((int *)arg) = threadMax;
    
  }

  if(report)
        printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), test);
 
  return NULL;
}



int main( int argc, char *argv[] ) {
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];

  //initialize semaphores
  sem_init(&semWaiting, 0, 0);
  sem_init(&semCovered, 0, 1);
  sem_init(&semMax, 0, 1);
  
  int threadArg[workers];
  for(int i = 0; i < workers; i++) {
    threadArg[i] = 0;
  }
  for ( int i = 0; i < workers; i++ )
    // threadArg[i] = 0;
    if(pthread_create(&worker[i], NULL, workerRoutine, threadArg + i) != 0) {
      fail("Can't make child thread");
    }

  // Then, start getting work for them to do.
  readList();

  
  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
