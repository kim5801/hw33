/**
	@file reset.c
	@author Eric Samuel (ejsamuel)
	Resets the game board and sends to shared memory
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/**
 * The game state struct of the board
 */
struct GameState {
  char current[GRID_SIZE][GRID_SIZE + 1];
  char past[GRID_SIZE][GRID_SIZE + 1];
};
// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Code that prints error message for invalid input file
 * @param message the name of the invalid file
 */
static void invalidFile(char const *message) {
  fprintf(stderr, "Invalid input file: %s\n", message);
  exit(1);
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}



/**
 * This functions brings everything together and performs operations
 * @param argc the number of command line arguments
 * @param argv the array of command line arguments
 * @return exit or failure
 */
int main( int argc, char *argv[] ) {

    //too many arguments or missing board file name
    if(argc < 2 || argc > 2) {
        usage();
    }
    struct GameState *board;
    sem_unlink( "/ejsamuel-lightsout-lock" );
    sem_t *lock = sem_open("/ejsamuel-lightsout-lock", O_CREAT, 0600, 1);
    if(lock == SEM_FAILED)
        fail("Can't make tag semaphore");
    // sem_wait( lock );
    sem_close(lock);
    // sem_unlink( "/ejsamuel-lightsout-lock" );
    int fd = open( argv[1], O_RDONLY );
        if ( fd < 0 )
    invalidFile(argv[1]);
    key_t key = ftok("/afs/unity.ncsu.edu/users/e/ejsamuel/CSC246/hw3", 1);
    int shmid = shmget(key, sizeof(struct GameState), 0666 | IPC_CREAT);
    if(shmid == -1) {
      fail("Can't create shared memory.");
    }
    board = shmat(shmid, NULL, 0);
    //error check initBoard

    // code from hw1
    if ( fd < 0 )
      invalidFile(argv[1]);
    char buffer[30];
    // char buffer[ 30 ];
    int len = read( fd, buffer, sizeof( buffer ) );
    int xLength = 0;
    int yLength = 0;
    while ( len > 0 ) {
      for ( int i = 0; i < len; i++ ) {
        if(buffer[ i ] != '*' && buffer[ i ] != '.' && buffer[ i ] != '\n' ) {
          invalidFile(argv[1]);
        }
        board->current[yLength][xLength] = buffer[i];
        if(buffer[i] == '\n') {
          if(xLength != 5) {
            invalidFile(argv[1]);
          }
          xLength = 0;
          yLength++;
        } else {
          xLength++;
        }
      }
      len = read( fd, buffer, sizeof( buffer ) );
    }
    if(yLength != 5) {
      invalidFile(argv[1]);
    }
    // We read up to the end-of-file, close the file and exit.
    close( fd );
    memcpy(board->past, board->current, sizeof (char) * GRID_SIZE * GRID_SIZE + 1);




    return 0;
}
