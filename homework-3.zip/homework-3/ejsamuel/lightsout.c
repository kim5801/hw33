/**
	@file lightsout.c
	@author Eric Samuel (ejsamuel)
	Performs the operations on the lightsout program game
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"
#include "semaphore.h"

/**
 * The game state struct of the board
 */
struct GameState {
  char current[GRID_SIZE][GRID_SIZE + 1];
  char past[GRID_SIZE][GRID_SIZE + 1];
};

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
bool move( struct GameState *board, int row, int col ){
    sem_t *lock = sem_open("/ejsamuel-lightsout-lock", 0);
    bool returnVal = false;
    if(lock == SEM_FAILED)
        fail("Can't make tag semaphore");
    #ifndef UNSAFE
        sem_wait( lock );
    #endif
      
 

    if(row <= 4 && row >= 0 && col <= 4 && col >= 0 ) {

    //copy current to undo array
    //perform the move
    
        memcpy(board->past, board->current, sizeof (char) * 5 * 6);
        if(board->current[row][col] == '.') {
            board->current[row][col] = '*';
        } else {
            board->current[row][col] = '.';
        }
        //bottom piece
        if((row - 1) >= 0 && (row - 1) <= 4){
            if(board->current[row - 1][col] == '.') {
            board->current[row - 1][col] = '*';
            } else {
            board->current[row - 1][col] = '.';
            }
        }

        //top piece
        if((row + 1) >= 0 && (row + 1) <= 4){
            if(board->current[row + 1][col] == '.') {
            board->current[row + 1][col] = '*';
            } else {
            board->current[row + 1][col] = '.';
            }
        }
        //right piece
        if((col + 1) >= 0 && (col + 1) <= 4){
            if(board->current[row][col + 1] == '.') {
            board->current[row][col + 1] = '*';
            } else {
            board->current[row][col + 1] = '.';
            }
        }
        //left piece
        if((col - 1) >= 0 && (col - 1) <= 4){
            if(board->current[row][col - 1] == '.') {
            board->current[row][col - 1] = '*';
            } else {
            board->current[row][col - 1] = '.';
            }
        }
                returnVal = true;
                
    } 
    #ifndef UNSAFE
    sem_post(lock);
    sem_close(lock);
    #endif  
    return returnVal;

    
}

// Undo the most recent move, returning true if successful.
bool undo( struct GameState *board ) {
    sem_t *lock = sem_open("/ejsamuel-lightsout-lock", 0);
    if(lock == SEM_FAILED)
        fail("Can't make tag semaphore");
    #ifndef UNSAFE
        sem_wait( lock );
    #endif
     if(memcmp(board->past, board->current, sizeof(board->current)) == 0) {

        #ifndef UNSAFE
        sem_post(lock);
        sem_close(lock);
        #endif  
        return false;
      } else {
        memcpy(board->current, board->past, sizeof(char) * 5 * 6);
        #ifndef UNSAFE
        sem_post(lock);
        sem_close(lock);
        #endif  
        return true;
      } 

}
// Print the current state of the board.
void report( struct GameState *board ) {
      
      for(int i = 0; i < GRID_SIZE; i++) {
        for(int j = 0; j < GRID_SIZE + 1; j++) {
       
          printf("%c", board->current[i][j]);
         
        }
      }
}


// Test interface, for quickly making a given move over and over.
bool test( struct GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    
    return false;
   
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );
    return true;
}



/**
 * This functions brings everything together and performs operations
 * @param argc the number of command line arguments
 * @param argv the array of command line arguments
 * @return exit or failure
 */
int main( int argc, char *argv[] ) {
    //error checks for command line
    if(argc > 5) 
    fail("error");
    

    if(strcmp(argv[1], "move") != 0 &&strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0 && strcmp(argv[1], "test") != 0)
    fail("error");

    if(strcmp(argv[1], "test") == 0 && argc != 5) {
        fail("error");
    }
        
    if(strcmp(argv[1], "move") == 0 && argc != 4) {
        fail("error");
    }

    if((strcmp(argv[1], "report") == 0 || strcmp(argv[1], "undo") == 0 ) && argc > 2) {
      fail("error");
    }

   

    //start shared memory stuff
    struct GameState *board;
    key_t key = ftok("/afs/unity.ncsu.edu/users/e/ejsamuel/CSC246/hw3", 1);
    int shmid = shmget(key, sizeof(struct GameState), 0666 | IPC_CREAT);
     if(shmid == -1) {
      fail("Can't create shared memory.");
    }
    board = shmat(shmid, NULL, 0);
    //error check baord

    //check what to do 
    if(strcmp(argv[1], "move") == 0) {

      
        int row = argv[2][0] - '0';
        int col = argv[3][0] - '0';
        bool success = move(board, row, col);
       if(isdigit(argv[2][0]) <= 0 || isdigit( argv[3][0]) <= 0 || !success) {
            printf("error\n");
       } else {
            printf("success\n");
       }
       
              
    } else if(strcmp(argv[1], "report") == 0) {
      report(board);

    } else if(strcmp(argv[1], "undo") == 0) {
      
      bool canUndo = undo(board);
      if(canUndo) {
        printf("success\n");
      } else {
        printf("error\n");
      }
    
    } else if (strcmp(argv[1], "test") == 0){
        int nPass = atoi(argv[2]);
        int row = argv[3][0] - '0';
        int col = argv[4][0] - '0';
        test(board, nPass, row, col);
    
      
    }

    shmdt(board);

  return 0; 
}
