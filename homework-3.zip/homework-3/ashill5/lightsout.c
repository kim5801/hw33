#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

int dl[] = {-1, 0, 1, 0}, cl[] = {0, 1, 0, -1};

//semaphore for locking
sem_t *boardSem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Method to check for valid int input
 * @param str string to parse
 * @return int converted int from string
 */
int checkInt(char const *str) {
  if (strcmp("0", str) == 0) {
    return 0;
  }
  int val = atoi(str);
  if (val == 0) {
    return -1;
  }
  return val;
}

/**
 * Method to check bounds in grid
 * @param x coordinate
 * @param y coordinate
 * @return true if in bounds
 */
bool inBounds(int x, int y) {
  return (x >= 0 && x < GRID_SIZE && y >= 0 && y < GRID_SIZE);
}

/**
 * Method to help swap characters
 * @param ch the initial char
 * @return the swapped char
 */
char swapChar(char ch) {
  return (ch == '*') ? '.' : '*';
}

/**
 * Method to apply operation on board
 * @param board the board state
 * @param x coordinate to move
 * @param y coordinate to move
 */
void applyOperation(Board *state, int x, int y) {
  state->board[x][y] = swapChar(state->board[x][y]);
  for (int i = 0; i < 4; i++) {
    int nx = x + dl[i], ny = y + cl[i];
    if (!inBounds(nx, ny))
      continue;
    state->board[nx][ny] = swapChar(state->board[nx][ny]);
  }
}

/* Method to move operation
 * @param board the board state
 * @param x coordinate to move
 * @param y coordinate to move
 * @return true if success
 */
bool move(Board *state, int x, int y) {

  #ifndef UNSAFE
  sem_wait(boardSem);
  #endif
  if (!inBounds(x, y)) {

    #ifndef UNSAFE
    sem_post(boardSem);
    #endif
    return false;
  }
  applyOperation(state, x, y);
  state->lx = x;
  state->ly = y;

  #ifndef UNSAFE
  sem_post(boardSem);
  #endif
  return true;
}

/* Method to undo last move
 * @param board the board state
 * @return true if success
 */
bool undo(Board *state) {

  #ifndef UNSAFE
    sem_wait(boardSem);
  #endif
  if (state->lx == -1) {
    #ifndef UNSAFE
      sem_post(boardSem);
    #endif
    return false;
  }
  applyOperation(state, state->lx, state->ly);
  state->lx = -1;
  state->ly = -1;
  #ifndef UNSAFE
    sem_post(boardSem);
  #endif
  return true;
}

/* 
 * Method to report state of board
 * @param board the board state
 * @return true if success
 */
void report(Board *state) {
  #ifndef UNSAFE
    sem_wait(boardSem);
  #endif
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", state->board[i][j]);
    }
    printf("\n");
  } 
  #ifndef UNSAFE
    sem_post(boardSem);
  #endif
}

/* Test method
 * @param board the board state
 * @param x coordinate to move
 * @param y coordinate to move
 * @param n number of times to move
 */
bool test(Board *state, int n, int x, int y) {
  if (!inBounds(x, y)) {
    return false;
  }
  while (n--) {
    move(state, x, y);
  }
  return true;
}

int main(int argc, char *argv[]) {

  //get board state
  Board *state;
  key_t id = ftok(path, FTOK_ID);

  //Make a shared memory segment of struct size
  int shmid = shmget(id, 0, 0);
  if (shmid == -1)
    fail("Can't create shared memory");

  Board *sbuffer = (Board *)shmat(shmid, 0, 0);
  if (sbuffer == (Board *)-1)
    fail( "Can't map shared memory segment into address space"  );
  
  state = sbuffer;
  
  //making the semaphore
  boardSem = sem_open(SEM_NAME, 0, 0644, 1);
  if (boardSem == (void *)-1) {
    fail("semaphore creation failed\n");
  }

  //error check arguments
  int operation = 0, x = 0, y = 0, n = 0;
  if (argc < 2 || argc > 5) {
    fail("error");
  }
  if (strcmp("move", argv[1]) == 0) {
    operation = 1;
    if (argc != 4) {
      fail("error");
    }
    x = checkInt(argv[2]);
    y = checkInt(argv[3]);
  } else if (strcmp("undo", argv[1]) == 0) {
    operation = 2;
    if (argc != 2 || state->lx == -1) {
      fail("error");
    }
  } else if (strcmp("report", argv[1]) == 0) {
    operation = 3;
    if (argc != 2) {
      fail("error");
    }
  } else if (strcmp("test", argv[1]) == 0) {
    operation = 4; 
    if (argc != 5) {
      fail("error");
    }
    n = checkInt(argv[2]);
    x = checkInt(argv[3]);
    y = checkInt(argv[4]);
  } else {
    fail("error");
  }
  
  //apply operations
  if (operation == 1) {
    if (!move(state, x, y)) {
      fail("error");
    }
  } else if (operation == 2) {
    if (!undo(state)) {
      fail("error");
    }
  } else if (operation == 4) {
    if (!test(state, n, x, y)) {
      fail("error");
    }
  } else {
    report(state);
    return 0;
  }
  
  //save state to shared memory
  sbuffer = state; 
  
  //release reference
  shmdt(sbuffer);

  if (operation != 4) {
    printf("success\n");
  }

  return 0;
}
