#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Print out an error message and exit.
static void failFile(char const *message, char *filename) {
  fprintf( stderr, "%s %s\n", message, filename );
  exit(1);
}

/**
 * Method to read board from file
 * @param fp the file pointer
 * @param filename name of file
 * @param board char 2d array to fill up
 */
void readBoard(FILE *fp, char *filename, Board *state) {
  for (int i = 0; i < GRID_SIZE; i++) {
    char ch; 
    for (int j = 0; j < GRID_SIZE; j++) {
      ch = fgetc(fp);
      if (ch != '.' && ch != '*') {
        failFile("Invalid input file:", filename);
      }
      state->board[i][j] = ch;
    }
    ch = fgetc(fp);
  }
  state->lx = -1;
  state->ly = -1;
}

int main( int argc, char *argv[] ) {
  
  //check arguments
  if (argc != 2) {
    usage();
  } 
  FILE *fp = fopen(argv[1], "r");
  if (fp == NULL) {
    failFile("Invalid input file:", argv[1]);
  }

  Board state;

  //read the board
  readBoard(fp, argv[1], &state);

  key_t id = ftok(path, FTOK_ID);
  size_t struct_size = sizeof(Board);
  
  //Make a shared memory segment of struct size
  int shmid = shmget(id, struct_size, 0666 | IPC_CREAT);
  if (shmid == -1)
    fail("Can't create shared memory");

  //create named semaphore
  sem_t *mySem = sem_open(SEM_NAME, O_CREAT, 0644, 1);
  
  if (mySem == (void *)-1) {
    fail("semaphore creation failed\n");
  }

  Board *sbuffer = (Board *)shmat(shmid, 0, 0);
  if (sbuffer == (Board *)-1)
    fail("Can't map shared memory segment into address space");

  *sbuffer = state;
  
  return 0;
}
