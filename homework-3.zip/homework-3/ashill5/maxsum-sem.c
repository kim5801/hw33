#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

//semaphores
sem_t lock, ans_sem;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Current value processed
int count = 0;

// done counter
int done = 0; 

int nr = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
  }
}

/**
 * Method to distribute work to threads
 * @return -1 to block
 * @return -2 to  stop
 * @return id to calculate
 */
int getWork() {
  
  sem_wait(&lock); 
  
  if (count < vCount) {
    return ++count;
  }
  if (done) {
    return -2;
  }
  return -1;
}

/* Start routine for each worker. */
void *workerRoutine() {
  
  int num = 0, max = 0, maxsum = 0;
  while (true) {

    int id = getWork();
    sem_post(&lock);

    if (id == -1) {
      continue;
    }
    if (id == -2) {
      break;
    }
    
    int sum = 0;
    maxsum = vList[id];
    for (int i = id; i >= 0; i--) {
      sum += vList[i];
      if (sum > maxsum) {
        maxsum = sum;
      }
    }

    if (maxsum > max || ++num == 1) {
      max = maxsum;
    }
  }
  
  if (report) {
    printf("I'm thread %ld. The maximum sum I found is %d.\n", pthread_self(), max);
  }

  sem_wait(&ans_sem);

  if (max > max_sum) {
    max_sum = max;
  }

  sem_post(&ans_sem);

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //init semaphores
  sem_init(&lock, 0, 1);
  sem_init(&ans_sem, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    pthread_create(worker + i, NULL, workerRoutine, NULL);
  }

  // Then, start getting work for them to do.
  readList();

  done = 1;

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  sem_destroy(&lock);
  sem_destroy(&ans_sem);
  
  return EXIT_SUCCESS;
}
