#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage() {
    printf("usage: maxsum-sem <workers>\n");
    printf("       maxsum-sem <workers> report\n");
    exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// emptyCount semaphore for BB
sem_t emptyCount;

// fullCount semaphore for BB
sem_t fullCount;

// lock semaphore for BB
sem_t lock;

// lock semaphore for max_sum
sem_t lockMaxSum;

// Current number of values on the list.
int vCount = 0;

// int to hold the next index for processing
int nextIndex = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
    while (scanf("%d", &v) == 1) {
        sem_wait(&emptyCount);
        sem_wait(&lock);
        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");

        // Store the latest value.
        vList[vCount++] = v;
        sem_post(&lock);
        sem_post(&fullCount);
    }

}

// returns the index the worker should start at for calculating the sum
int getWork() {

    sem_wait(&fullCount);
    sem_wait(&lock);

    int localIndex = nextIndex;

    nextIndex++;

    sem_post(&lock);
    sem_post(&emptyCount);

    return localIndex;

}

/** Start routine for each worker. */
void *workerRoutine(void *arg) {
    
    // true if there are still numbers to be processed
    bool processing = true;

    // holds the possible localMaxSum
    int possibleLocalMaxSum = 0;

    // holds the current localMaxSum
    int localMaxSum = INT_MIN;

    while(processing) {

        // reset possibleLocalMaxSum
        possibleLocalMaxSum = 0;

        // holds the start index
        int startIndex = 0;

        // try to access getWork(), or wait if another thread is accessing getWork()
        startIndex = getWork();
        
        // if there are no more number to be processed
        if(vList[startIndex] == INT_MAX) {

            processing = false;

        }

        // if there are more numbers to be processed
        else {

            // say startIndex = 2
            // this will check:
            // vList[2]
            // vList[2] + vList[1]
            // vList[2] + vList[1] + vList[0]
            // say startIndex = 1
            // this will check:
            // vList[1]
            // vList[1] + vList[0]
            // say startIndex = 0
            // this will check:
            // vList[0]
            // given 3 indexes, there are 6 possible contiguous summations
            // given each index will be checked, and assuming n = 3, all 6 summations will be checked by this method
            for(int i = startIndex; i >= 0; i--) {

                possibleLocalMaxSum = possibleLocalMaxSum + vList[i];

                // see if localMaxSum should be updated
                if(possibleLocalMaxSum > localMaxSum) {
                    localMaxSum = possibleLocalMaxSum;
                }
                
            }

        }

    }

    // lock access to max_sum and update it if necessary
    sem_wait(&lockMaxSum);
    if(localMaxSum > max_sum) {
        max_sum = localMaxSum;
    }
    sem_post(&lockMaxSum);

    // if report was passed in as a command-line argument
    if(report) {

        // if the worker didn't do any work
        if(localMaxSum == INT_MIN) {
            printf("I'm thread %ld. I did not do any work.\n", syscall(__NR_gettid));
        }

        // the worker did do work
        else {
            printf("I'm thread %ld. The maximum sum I found is %d.\n", syscall(__NR_gettid), localMaxSum);
        }

    }

    return NULL;

}

int main(int argc, char *argv[]) {
    int workers = 4;
  
    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();
  
    if (sscanf(argv[1], "%d", &workers) != 1 ||
        workers < 1)
        usage();

    // If there's a second argument, it better be "report"
    if (argc == 3) {
        if (strcmp(argv[2], "report") != 0)
        usage();
        report = true;
    }

    // initialize lockMaxSum to 1
    if(sem_init(&lockMaxSum, 0, 1) == -1) {
        fail("Can't make lockGetWork semaphore");
    }

    // initialize emptyCount to MAX_VALUES
    if(sem_init(&emptyCount, 0, MAX_VALUES) == -1) {
        fail("Can't make emptyCount semaphore");
    }
    
    // initialize fullCount to 0
    if(sem_init(&fullCount, 0, 0) == -1) {
        fail("Can't make fullCount semaphore");
    }

    // initialize lock to 1
    if(sem_init(&lock, 0, 1) ==  -1) {
        fail("Can't make lock semaphore");
    }

    // Make each of the workers.
    pthread_t worker[workers];
    for (int i = 0; i < workers; i++) {

        pthread_create(&worker[i], NULL, workerRoutine, NULL);

    }

    // Then, start getting work for them to do.
    readList();

    for(int i = 0; i < workers; i++) {

        sem_wait(&emptyCount);
        sem_wait(&lock);
        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");

        // Store the latest value.
        vList[vCount++] = INT_MAX;
        sem_post(&lock);
        sem_post(&fullCount);

    }

    // Wait until all the workers finish.
    for (int i = 0; i < workers; i++) {
        pthread_join(worker[i], NULL);
    }

    // destory semaphores
    sem_destroy(&lockMaxSum);
    sem_destroy(&emptyCount);
    sem_destroy(&fullCount);
    sem_destroy(&lock);

    // Report the max product and release the semaphores.
    printf("Maximum Sum: %d\n", max_sum);
  
    return EXIT_SUCCESS;

}
