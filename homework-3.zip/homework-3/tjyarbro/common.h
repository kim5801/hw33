#ifndef SPR_COMMON_H
#define SPR_COMMON_H

// Height and width of the playing area.
#define GRID_SIZE 5

// define a struct to hold board state
typedef struct {

  // 2D array of characters
  // the first array corresponds to the row
  // the second array corresponds to the column plus a null terminator (so each row can be used as a string)
  char boardLayout[5][6];

  // hold the last move
  int lastR;
  int lastC;

  // flag to see if the current boardState accepts an undo operation
  // initially false because no move has been made to undo
  int undoOK;

} GameState;

// a pathname for all ftok() calls
#define PATHNAME "/afs/unity.ncsu.edu/users/t/tjyarbro"

// an int for all to use when calling ftok()
#define PROJ_ID 4

// define a name for the named semaphore
#define SEMAPHORE "/tjyarbro-lightsout-lock"

#endif