#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// define a swap method
void swap(char* swapChar) {

  if(*swapChar == '.') {
    *swapChar = '*';
  } else {
    *swapChar = '.';
  }

}

// define a board toString method
void boardToString(char* boardString, GameState* board) {
  // clear junk in boardString
  for(int i = 0; i < 31; i++) {
    boardString[i] = '\0';
  }

  // add board->boardLayout strings to boardString
  // NOTE: strcat null terminates the string, so boardString is null terminated after this
  for(int i = 0; i < 5; i++) {
    strcat(boardString, board->boardLayout[i]);
    strcat(boardString, "\n");
  }
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int r, int c ) {

  // initialize lightsOutSem semaphore
  sem_t* lightsOutSem = sem_open(SEMAPHORE, 0);

  if(lightsOutSem == SEM_FAILED) {
    fail("Can't open tag semaphore");
  }

  // acquire lightsOutSem semaphore
  #ifndef UNSAFE
    sem_wait(lightsOutSem);
  #endif

  // define new variables in the + pattern for moves
  // NOTE: if up, down, left, or right is out of the range of the board, their position is not swapped
  int up = r + 1;
  int down = r - 1;
  int left = c - 1;
  int right = c + 1;

  // make initial swap
  swap(&(state->boardLayout[r][c]));

  // make sure up index is valid then swap
  if(up >= 0 && up <= 4) {
    swap(&(state->boardLayout[up][c]));
  }

  // make sure down index is valid then swap
  if(down >= 0 && down <= 4) {
    swap(&(state->boardLayout[down][c]));
  }

  // make sure left index is valid then swap
  if(left >= 0 && left <= 4) {
    swap(&(state->boardLayout[r][left]));
  }

  // make sure right index is valid then swap
  if(right >= 0 && right <= 4) {
    swap(&(state->boardLayout[r][right]));
  }

  // update lastR and lastC
  state->lastR = r;
  state->lastC = c;

  // update undoOK to true
  state->undoOK = 1;

  // done editing the game state, release the lightsOutSem semaphore
  #ifndef UNSAFE
    sem_post(lightsOutSem);
  #endif

  // return true, this will always work
  return true;

}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

// Make a move at the given row, column location, returning true
// if successful.
bool moveForUndo( GameState *state, int r, int c ) {

  // define new variables in the + pattern for moves
  // NOTE: if up, down, left, or right is out of the range of the board, their position is not swapped
  int up = r + 1;
  int down = r - 1;
  int left = c - 1;
  int right = c + 1;

  // make initial swap
  swap(&(state->boardLayout[r][c]));

  // make sure up index is valid then swap
  if(up >= 0 && up <= 4) {
    swap(&(state->boardLayout[up][c]));
  }

  // make sure down index is valid then swap
  if(down >= 0 && down <= 4) {
    swap(&(state->boardLayout[down][c]));
  }

  // make sure left index is valid then swap
  if(left >= 0 && left <= 4) {
    swap(&(state->boardLayout[r][left]));
  }

  // make sure right index is valid then swap
  if(right >= 0 && right <= 4) {
    swap(&(state->boardLayout[r][right]));
  }

  // update lastR and lastC
  state->lastR = r;
  state->lastC = c;

  // update undoOK to true
  state->undoOK = 1;

  // return true, this will always work
  return true;

}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ) {

  // initialize lightsOutSem semaphore
  sem_t* lightsOutSem = sem_open(SEMAPHORE, 0);

  if(lightsOutSem == SEM_FAILED) {
    fail("Can't open tag semaphore");
  }

  // acquire lightsOutSem semaphore
  #ifndef UNSAFE
    sem_wait(lightsOutSem);
  #endif

  // see if undo is valid
  if(state->undoOK == 1) {

    // undo will be completed by calling move on with lastR and lastC
    moveForUndo(state, state->lastR, state->lastC);

    // update undoOK to 0 (false)
    state->undoOK = 0;

    // done editing the game state, release the lightsOutSem semaphore
    #ifndef UNSAFE
      sem_post(lightsOutSem);
    #endif

    return true;

  } else {
    // undo is not valid

    // done editing the game state, release the lightsOutSem semaphore
    #ifndef UNSAFE
      sem_post(lightsOutSem);
    #endif

    return false;

  }

}
// Print the current state of the board.
void report( GameState *state ) {

  // initialize lightsOutSem semaphore
  sem_t* lightsOutSem = sem_open(SEMAPHORE, 0);

  if(lightsOutSem == SEM_FAILED) {
    fail("Can't open tag semaphore");
  }

  // acquire lightsOutSem semaphore
  #ifndef UNSAFE
    sem_wait(lightsOutSem);
  #endif

  // to hold the board as a string
  char boardString[31];

  // see boardToString()
  boardToString(boardString, state);

  // print the string boardToString() created
  printf(boardString);

  // detatch from the shared memory
  shmdt(state);

  // done editing the game state, release the lightsOutSem semaphore
  #ifndef UNSAFE
    sem_post(lightsOutSem);
  #endif

  // exit with success
  exit(0);

}

int main( int argc, char *argv[] ) {

    // make sure a command-line argument was given and it is "move", "undo", or "report"
    if(argc >= 2) {
        // argv[1] is the first command
        if(strcmp("move", argv[1]) != 0 && strcmp("undo", argv[1]) != 0 && strcmp("report", argv[1]) != 0 && strcmp("test", argv[1]) != 0) {
            printf("error\n");
            exit(1);
        } else {
            // do nothing, the command was valid
        }
    } else {
        printf("error\n");
        exit(1);
    }

    // at this point, "move", "undo", "report", or "test" was received

    // make sure further arguments for move are ok
    if(strcmp("move", argv[1]) == 0) {
        // the command is move
        if(argc != 4) {
            // should be exactly 4 arguments, "client", "move", "r", "c"
            printf("error\n");
            exit(1);
        }

        // check argv[2]; r
        if(strlen(argv[2]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[2][0] >= 53 || argv[2][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

        // check argv[3]; c
        if(strlen(argv[3]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[3][0] >= 53 || argv[3][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

    }

    // make sure further arguments for test are ok
    if(strcmp("test", argv[1]) == 0) {
        // the command is test
        if(argc != 5) {
            // should be exactly 4 arguments, "client", "move", "n", "r", "c"
            printf("error\n");
            exit(1);
        }

        // check argv[2]; n
        for(int i = 0; i < strlen(argv[2]); i++) {
          if(argv[2][0] >= 58 || argv[2][0] <= 47) {
            // if the character is not 0-9 it is invalid
            printf("error\n");
            exit(1);
          }
        }

        // check argv[3]; r
        if(strlen(argv[3]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[3][0] >= 53 || argv[3][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

        // check argv[4]; c
        if(strlen(argv[4]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[4][0] >= 53 || argv[4][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

    }

    // open shared memory for GameState
    int shmid = shmget(ftok(PATHNAME, PROJ_ID), sizeof(GameState), 0);

    // make sure shared memory was opened
    if(shmid == -1) {
        fail("Can't create shared memory");
    }

    // cast the shared memory to a GameState
    GameState* board = (GameState*)shmat(shmid, 0, 0);

    // make sure proper space was allocated for a GameState
    if(board == (GameState*)-1) {
        fail("Can't map shared memory segment into address space");
    }

    // run the command

    // run report
    if(strcmp("report", argv[1]) == 0) {

        report(board);

    }

    // run move
    if(strcmp("move", argv[1]) == 0) {

        int r = atoi(argv[2]);
        int c = atoi(argv[3]);

        // call move with r and c
        if(move(board, r, c)) {

          // move was successful, print
          printf("success\n");

          // detatch from the shared memory
          shmdt(board);

          // exit with success
          exit(0);

        }

    }

    // run undo
    if(strcmp("undo", argv[1]) == 0) {

      if(undo(board)) {
        // undo was successful, print
        printf("success\n");

        // detatch from the shared memory
        shmdt(board);

        // exit with success
        exit(0);

      } else {

        // undo was unsuccessful, print
        printf("error\n");

        // detatch from the shared memory
        shmdt(board);

        // exit with failure
        exit(1);

      }

    }

    // run test
    if(strcmp("test", argv[1]) == 0) {

      int n = atoi(argv[2]);

      int r = atoi(argv[3]);

      int c = atoi(argv[4]);

      test(board, n, r, c);

    }

    return 0;

}
