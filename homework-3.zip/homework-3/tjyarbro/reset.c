#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

// invalid file message and exit with error
static void badFile(char const* message) {
  printf("Invalid input file: %s\n", message);
  exit(1);
}

// define a board toString method
void boardToString(char* boardString, GameState* board) {
  // clear junk in boardString
  for(int i = 0; i < 31; i++) {
    boardString[i] = '\0';
  }

  // add board.boardLayout strings to boardString
  // NOTE: strcat null terminates the string, so boardString is null terminated after this
  for(int i = 0; i < 5; i++) {
    strcat(boardString, board->boardLayout[i]);
    strcat(boardString, "\n");
  }
}

int main( int argc, char *argv[] ) {

  // check for valid command line arguments
  // should be 2 arguments, process name and the original board state
  if(argc != 2) {
    // print usage message and exit with error
    usage();
  }

  // read in original board state
  // second argument to argv should hold the name of the file location (index 1)
  int initBoardFD = open(argv[1], O_RDWR);

  // error occured if initBoardFD == -1
  if(initBoardFD == -1) {
    badFile(argv[1]);
  }

  // buffer to read input file
  char buffer[1024];

  // read input
  read(initBoardFD, buffer, 1024);

  // count through file
  int countFile;

  // flag for invalid characters; initially is set to false
  int invalidChars = 0;

  // if the file has the right amount of characters, countFile should == 30 when the loop is over
  // countFile == 30 because there are 30 characters up until the null terminator (0 - 29), but countFile is incremented again at the end of the for-loop before the coniditonal evaluates to false
  for(countFile = 0; buffer[countFile] != '\0'; countFile++) {
    // if the character is not a valid character update invalidChars to true
    if(buffer[countFile] != '.' && buffer[countFile] != '*' && buffer[countFile] != '\n') {
      invalidChars = 1;
    }
  }

  // file is invalid if countFile != 30 or invalidChars == 1
  if(countFile != 30 || invalidChars == 1) {
    badFile(argv[1]);
  }

  // destroy old copies of the semaphore in case it
  // is in an unknown state
  sem_unlink(SEMAPHORE);

  // create the named semaphore with an initial value of 1
  sem_t* lightsOutSem = sem_open(SEMAPHORE, O_CREAT, 0600, 1);

  // make sure lightsOutSem was created successfully
  if(lightsOutSem == SEM_FAILED) {
    fail("can't make ligtsOutSem semaphore");
  }

  // make a shared memory segment with the size of a GameState
  int shmid = shmget(ftok(PATHNAME, PROJ_ID), sizeof(GameState), 0666 | IPC_CREAT);

  // make sure shared memory was successfully created
  if(shmid == -1) {
    fail("Can't create shared memory");
  }

  // cast the shared memory to a GameState
  GameState* board = (GameState*)shmat(shmid, 0, 0);

  // make sure proper space was allocated for a GameState
  if(board == (GameState*)-1) {
    fail("Can't map shared memory segment into address space");
  }

  // char array to hold board values
  char boardChars[25];

  // used to look through the buffer
  int countBuffer = 0;

  // used to count through the chars added to boardChars
  int countBoardChars = 0;

  while(buffer[countBuffer] != '\0') {
    // add to boardChars if the character is not '\n' and update countBoardChars
    if(buffer[countBuffer] != '\n') {
      boardChars[countBoardChars] = buffer[countBuffer];
      countBoardChars++;
    }
    // move to next char in buffer
    countBuffer++;
  }

  // testing for board->boardLayout
  // printf("%s\n", buffer);
  // for(int i = 0; i < 25; i++) {
  //   printf("%c", boardChars[i]);
  //   if(i == 4 || i % 5 == 4) {
  //     printf("\n");
  //   }
  // }
  // printf("\n");

  // initialize board from file
  for(int i = 0; i < 25; i++) {
    board->boardLayout[i / 5][i % 5] = boardChars[i];
  }

  // null terminate board values
  for(int i = 0; i < 5; i++) {
    board->boardLayout[i][5] = '\0';
  }

  // initialize undoOK to false because no move has been made yet
  board->undoOK = 0;

  // testing for board->boardLayout
  // for(int i = 0; i < 5; i++) {
  //   for(int j = 0; j < 5; j++) {
  //     printf("%c", board->boardLayout[i][j]);
  //   }
  //   printf("\n");
  // }
  // printf("\n");

  // detatch from the shared memory
  shmdt(board);

  return 0;
}
