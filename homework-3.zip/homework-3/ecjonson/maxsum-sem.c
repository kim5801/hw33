/**
 * @author Evan Jonson (ecjonson)
 * @author CSC 246
 * @file maxsum-sem.c
 * Calculates the maximum contiguous sum of a list of integer values. Uses semaphores to
 * release work for worker threads to do as each value is read from file.
 */

#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>

/** The maximum number of values that can be read from file */
#define MAX_VALUES 500000

// Maximum sum we've found.
int max_sum = INT_MIN;
// Fixed-sized array for holding the sequence.
int vList[ MAX_VALUES ];
// Current number of values on the list.
int vCount = 0;
// the next index of available work
int task;

// true when the main thread has read all integers from file
bool done = false;
// True if we're supposed to report what we find.
bool report = false;

// semaphore used to block threads with no work to do
sem_t work;
// semaphore used to block when updating the max_sum global variable
sem_t update;
// semaphore used to block threads accessing the next global variable
sem_t gAccess;

/**
 * Print out an error message and exit.
 * @param message The error message to print.
 */
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

/**
 * Print out a usage message, then exit.
 */
static void usage() {
    printf( "usage: maxsum-sem <workers>\n" );
    printf( "       maxsum-sem <workers> report\n" );
    exit( EXIT_FAILURE );
}

/**
 * Read the list of values.
 */
static void readList() {
    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Make sure we have enough room, then store the latest input.
        if ( vCount >= MAX_VALUES )
            fail( "Too many input values" );

        // Store the latest value.
        vList[ vCount++ ] = v;

        // release work as each value is read.
        sem_post( &work );
    }
}

/**
 * Calculates and returns the maximum contiguous sum from start
 * to the provided finish. Assumes valid parameters.
 * @param f The finish point of the range.
 * @return The maximum contiguous sum from start to the provided finish.
 */
static int maxSumEndingAt( int f ) {

    // tracks the current max sum in this range
    int temp = 0, max = INT_MIN;

    // check all ranges from this ending point
    for ( int i = f; i >= 0; --i ) {

        // sum the range
        temp += vList[ i ];

        // new max found
        if ( temp > max )
            max = temp;
    }

    return max;
}

/**
 * Blocks a worker thread until there is work to do.
 * Returns -1 if there is no more work for this thread.
 * @return The index of the task to complete, or -1.
 */
static int getWork() {

    int index;

    // block while accessing the global task variable
    sem_wait( &gAccess );

    // if work is available, return immediately
    if ( task < vCount ) {
        index = task++;
        sem_post( &gAccess );
        return index;
    }

    // release the lock
    sem_post( &gAccess );

    // wait for work
    sem_wait( &work );

    // block while accessing the global task variable
    sem_wait( &gAccess );
    index = task++;
    sem_post( &gAccess );

    // done is true when all values have been read from file
    if ( done && index >= vCount ) {
        // wake up any threads still waiting, special case that can happen before done is set to true
        sem_post( &work );

        // no more work!
        return -1;
    }

    // get to work!
    return index;
}

/**
 * Start routine for each worker.
 * @param arg NULL.
 * @return NULL.
 */
void *workerRoutine( void *arg ) {
    // helper variables
    int index, temp, max = INT_MIN;

    // true if a thread did any work
    bool didWork = false;

    // while there is work to do
    while ( (index = getWork()) != -1 ) {
        // do work
        temp = maxSumEndingAt( index );

        // this thread should report if asked to
        didWork = true;

        // new max found
        if ( temp > max )
            max = temp;
    }

    // acquire the update lock, to prevent errors with multiple threads accessing the same global variable
    sem_wait( &update );
    
    // update the max
    if ( max > max_sum )
        max_sum = max;
    
    // release the lock
    sem_post( &update );

    // print a report if specified by the user, and if the thread did anything
    if ( report ) {
        // did this thread do any work?
        if ( didWork )
            printf( "I'm thread %ld. The maximum sum I found is %d.\n", syscall(__NR_gettid), max );
        else
            printf( "I'm thread %ld. I didn't contribute.\n", syscall(__NR_gettid) );
    }

    return NULL;
}

/**
 * Program starting point. Calculates the maximum contiguous sum of a list of integer values.
 * Uses semaphores to release work for worker threads to do as each value is read from file.
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 * @return The exit status.
 */
int main( int argc, char *argv[] ) {
    // the default number of workers
    int workers = 4;
    
    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();
    
    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 || workers < 1 )
        usage();

    // If there's a second argument, it better be "report"
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 )
            usage();
        report = true;
    }

    // initialize the semaphores
    sem_init( &work, 0, 0 ); // to zero
    sem_init( &update, 0, 1 ); // to one
    sem_init( &gAccess, 0, 1 ); // to one

    // Make each of the workers.
    pthread_t worker[ workers ];

    // for each worker
    for ( int i = 0; i < workers; i++ ) {
        // start this worker thread
        if ( pthread_create( &worker[ i ], NULL, workerRoutine, NULL ) )
            fail( "failed to create a thread" );
    }

    // then, start getting work for them to do.
    readList();

    // the main thread is done reading all values
    done = true;

    // wake up a thread, special case deadlock that can happen before done is set to true
    sem_post( &work );

    // Wait until all the workers finish.
    for ( int i = 0; i < workers; i++ ) {
        if ( pthread_join( worker[ i ], NULL ) )
            fail( "failed to join a thread" );
    }

    // Report the max product and release the semaphores.
    printf( "Maximum Sum: %d\n", max_sum );

    // destroy the semaphores
    sem_destroy( &work );
    sem_destroy( &update );
    sem_destroy( &gAccess );
    
    return EXIT_SUCCESS;
}
