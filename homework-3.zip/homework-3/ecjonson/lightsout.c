/**
 * @file lightsout.c
 * @author Evan Jonson (ecjonson)
 * User program for my shared memory lightsout game. Provided that a board
 * already exists, it runs the given command to play the game. This implementation
 * of the game uses a named semaphore to prevent race conditions when two games are
 * playing at the same time. You can use the -DUNSAFE compile flag to disable the
 * semaphore and obserse its behavior.
 */

#include "common.h"

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <semaphore.h>

/** ASCII char to int conversion difference */
#define CHAR_TO_I 48

/** Base value for decimal integers */
#define BASE 10

// a named semaphore to prevent race conditions
sem_t *lock;

/**
 * Prints the given error message to standard error and exits unsuccessfully.
 * @param msg The given error message to print.
 */
static void fail( char *msg ) {
    fprintf( stderr, "%s\n", msg );
    exit( EXIT_FAILURE );
}

/**
 * Prints error to standard output and exits unsuccessfully.
 */
static void error() {
    printf( "error\n" );
    exit( EXIT_FAILURE );
}

/**
 * Flip the lights for the given character. Changes
 * '.' to '*' and vice versa. Any other characters results in
 * error.
 * @param c The character to flip.
 * @return '.' or '*'. The flipped light.
 */
static char flip( char c ) {
    
    switch( c ) {
        // on to off
        case '*':
            c = '.';
            break;
        // off to on
        case '.':
            c = '*';
            break;
        // invalid character
        default:
            error();
    }

    return c;
}

/**
 * The logic for the move command. Make a move. Updates the board with the given move.
 * Does not check for valid input.
 * @param board The board to update.
 * @param r The row of the move.
 * @param c The collumn of the move.
 */
static void moveLogic( GameState *board, int r, int c ) {

    // flip the lights
    board->state[ r ][ c ] = flip(board->state[ r ][ c ]);

    // edge case r = 0
    if ( r )
        board->state[ r - 1 ][ c ] = flip(board->state[ r - 1 ][ c ]);
    
    // edge case r = 4
    if ( r != 4 )
        board->state[ r + 1 ][ c ] = flip(board->state[ r + 1 ][ c ]);

    // edge case c = 0
    if ( c )
        board->state[ r ][ c - 1 ] = flip(board->state[ r ][ c - 1 ]);

    // edge case c = 4
    if ( c != 4 )
        board->state[ r ][ c + 1 ] = flip(board->state[ r ][ c + 1 ]);

    // update undo flag
    board->undo = true;

    // update the last move tracker
    board->last[ 0 ] = r;
    board->last[ 1 ] = c;
}

/**
 * Make a move. Updates the board with the given move. The logic has
 * been moved to a seperate function so that undo() can also use it
 * without interfering with the semaphore lock logic. Returns true,
 * simply to meet program specifications. Does not check for valid input.
 * @param board The board to update.
 * @param r The row of the move.
 * @param c The collumn of the move.
 * @return True.
 */
static bool move( GameState *board, int r, int c ) {

    // wrap blocking with conditional compilation code for testing
    #ifndef UNSAFE
        // acquire the lock
        sem_wait( lock );
    #endif

    // make a move
    moveLogic( board, r, c );

    // wrap blocking with conditional compilation code for testing
    #ifndef UNSAFE
        // release the lock
        sem_post( lock );
    #endif

    return true;
}

/**
 * Undo the last move. Repeats the last move if there was one.
 * @param board The board to update.
 * @return True if no errors occured.
 */
static bool undo( GameState *board ) {
    
    // wrap blocking with conditional compilation code for testing
    #ifndef UNSAFE
        // acquire the lock
        sem_wait( lock );
    #endif

    // true if the undo was successful
    bool ret = false;

    // check if there was a previous move
    if ( board->undo ) {

        // undo the last move
        moveLogic( board, board->last[ 0 ], board->last[ 1 ] );

        // update the boards undo flag
        board->undo = false;

        ret = true;
    }

    // wrap blocking with conditional compilation code for testing
    #ifndef UNSAFE
        // release the lock
        sem_post( lock );
    #endif

    return ret;
}

/**
 * Prints a report of the current state of the board.
 * @param board The board to report.
 */
static void report( GameState *board ) {

    // wrap blocking with conditional compilation code for testing
    #ifndef UNSAFE
        // acquire the lock
        sem_wait( lock );
    #endif

    // print the board state
    for ( int i = 0; i < GRID_SIZE; ++i ) {
        for ( int j = 0; j < GRID_SIZE; ++j )
            printf( "%c", board->state[ i ][ j ] );

        printf( "\n" );
    }

    // wrap blocking with conditional compilation code for testing
    #ifndef UNSAFE
        // release the lock
        sem_post( lock );
    #endif
}

/**
 * Executes the move command n times as quickly as possible.
 * @param board The board to test.
 * @param n The number of times to execute the move.
 * @param r The row of the move.
 * @param c The collumn of the move.
 * @return True if no errors occured
 */
static bool test( GameState *board, int n, int r, int c ) {

    // check range
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;

    // make the same move a bunch of times
    for ( int i = 0; i < n; ++i )
        move( board, r, c );

    return true;
}

/**
 * Recursive helper function for myPow().
 * Recursively calls itself until b^n is calculated.
 * @param sum The current sum of b^n. Pass the base here to start.
 * @param b The base value. Pass the base here as well to start.
 * @param n The number of times remaining to multiply the base times the exponent. Pass the exponent here to start.
 * @return The current value of b*b*n.
 */
static int powRecursive( int sum, int b, int n ) {
    // base case: b ^ 0 = 1, ignore negative special cases
    if ( n <= 0 )
        return 1;

    // base case: all recursive calls complete
    if ( n == 1 )
        return sum;

    // recursive case: multiply sum by the base and decrement n
    return powRecursive( sum * b, b, --n );
}

/**
 * My power function. Uses a recursive helper function to calculate b^e.
 * Negative exponents are treated as 0.
 * @param b The base value.
 * @param e The exponent value.
 * @return b to the power of e.
 */
static int myPow( int b, int e ) {
    // call powRecursive to calculate b^e
    return powRecursive( b, b, e );
}

/**
 * Parses a positive integer from the passed string.
 * @param str The string to parse.
 * @return The parsed postive integer.
 */
static int parse( char const *str ) {

    // helper variables
    int len = strlen( str ), temp, sum = 0;

    // parse the string
    for ( int i = 0, j = len - 1; i < len; ++i, --j ) {

        // check for a valid digit
        if ( !isdigit( str[ i ] ) )
            error();
        
        // parse the char to an int
        temp = str[ i ] - CHAR_TO_I;

        // add the digit to the sum with the appropriate base value
        sum += temp * myPow( BASE, j );
    }

    // return the parsed int
    return sum;
}

/**
 * Program starting point. Run the given command. Plays the lightsout game.
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 */
int main( int argc, char *argv[] ) {

    // get a unique id for my shared memory
    key_t key = ftok( "/afs/unity.ncsu.edu/users/e/ecjonson", PROJ_ID );
    // check for errors
    if ( key == -1 )
        fail( strerror( errno ) );

    // get the id of the shared memory
    int shmid = shmget( key, 0, 0 );
    // check for errors
    if ( shmid == -1 )
        fail( strerror( errno ) );

    // map the address of the attached shared memory segment
    GameState *board = (GameState *)shmat( shmid, 0, 0 );
    // check for errors
    if ( board == (GameState *)-1 )
        fail( strerror( errno ) );

    // open the semaphore that reset.c made
    lock = sem_open( "/ecjonson-lightsout-lock", 0 );
    if ( lock == SEM_FAILED )
        fail( strerror( errno ) );

    // true if the command was successful
    bool ret = false;

    // false if a report was called
    bool rep = true;

    // true when testing
    bool t = false;

    // move command
    if ( argc == 4 && strcmp( "move", argv[ 1 ] ) == 0 ) {
        int r = parse( argv[ 2 ] );
        int c = parse( argv[ 3 ] );
        // check range, this is not done inside of move to speed up the test command.
        if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
            error();
        ret = move( board, r, c );
    }

    // undo command
    else if ( argc == 2 && strcmp( "undo", argv[ 1 ] ) == 0 )
        ret = undo( board );

    // report command
    else if ( argc == 2 && strcmp( "report", argv[ 1 ] ) == 0 ) {
        report( board );
        rep = false;
    }

    // test command
    else if ( argc == 5 && strcmp( "test", argv[ 1 ] ) == 0 ) {
        // parse can now handle large numbers!
        int n = parse( argv[ 2 ] );
        int r = parse( argv[ 3 ] );
        int c = parse( argv[ 4 ] );
        t = test( board, n, r, c );
    }

    // detach from the shared memory
    shmdt( board );

    // skip printing when
    if ( !t ) {
        // valid command
        if ( ret )
            printf( "success\n" );

        // invalid command
        else if ( rep )
            error();
    }

    return EXIT_SUCCESS;
}
