/**
 * @file maxsum-sem.c
 * @author Rose Xiao
 * @brief Same concept as the Maxsum from previous HWs but will be assigning the work as the integers are being read in. This requires synchronization between thread using POSIX anonymous semaphores.
 * @date 2022-10-02
 */

 //cmd to run
 // gcc -Wall -g -std=c99 -o maxsum-sem.c maxsum-sem -lpthread
 //gcc -Wall -std=c99 -D_SVID_SOURCE maxsum-sem.c -o maxsum-sem -lpthread
 //(sed -n '1,95000p' input-5.txt; sleep 2; sed -n '95001,$p' input-5.txt) | time -p ./maxsum-sem 4
 //(sed -n '1,5000p' input-5.txt; sleep 2; sed -n '5001,$p' input-5.txt) | time -p ./maxsum-sem 4

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

#include <unistd.h> //to use pthread_self()
// Print out an error message and exit.
static void fail( char const* message )
{
	fprintf( stderr, "%s\n", message );
	exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage()
{
	printf( "usage: maxsum-sem <workers>\n" );
	printf( "       maxsum-sem <workers> report\n" );
	exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList [ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//current position in the list for the worker to start on the new sequence
int pos = 0;

//indicating a thread can change the position
sem_t incrPos;

//indicating a thread can view the overall sum
sem_t sumLock;

//indicating a thread can change the overall sum
sem_t sumChange;

//to keep track whether all the values have been read or not
bool allRead = false;

//semaphore to act like a monitor and allow a thread to grab the next integer available
sem_t waitLine;

// Read the list of values.
void readList()
{
	// Keep reading as many values as we can.
	int v;
	while ( scanf( "%d", &v ) == 1 ) {
		// Make sure we have enough room, then store the latest input.
		if ( vCount > MAX_VALUES )
			fail( "Too many input values" );

		// Store the latest value.
		vList [ vCount++ ] = v;
	}

	// printf( "DONE\n" );
}

//worker calls this function when it becomes idle
//returns the current position of the array to start the new sequence
//else returns a sentinel value of -1 to indicate no integers to compute with
int working()
{
	//if threads have caught up && no more input read in > exit
	if ( ( pos >= vCount && allRead ) ) {
		return -1;
	}
	//if the position is the same as count but no need integers have been read in yet | busy waiting
	while ( pos == vCount && !allRead ) { }

	sem_wait( &waitLine );
	sem_wait( &incrPos );
	// printf( "ID: %lu IN\n", pthread_self() );
	int startIndex = pos++; //to make sure the return index has not been altered prior to its usage in the start routine
	sem_post( &incrPos );
	// printf( "ID: %lu OUT\n", pthread_self() );
	sem_post( &waitLine );
	return startIndex;

}

/** Start routine for each worker. */
void* workerRoutine( void* arg )
{
	//the local maximum sum
	int localMax = 0;
	//check if the thread can work or not
	int position = working();
	//while the working() does not return -1
	while ( position >= 0 ) {
		int sum = 0;
		//compute the sequence from right to left
		for ( int j = position; j >= 0; j-- ) {
			sum += vList [ j ];
			if ( sum > localMax ) {
				localMax = sum;
			}
		}

		//allows the thread to enter the sum monitor
		sem_wait( &sumLock );
		if ( localMax > max_sum ) {
			sem_wait( &sumChange );
			max_sum = localMax;
			sem_post( &sumChange );
		}

		//checks to see if the thread needs to work again
		position = working();
		sem_post( &sumLock );
	}

	if ( report ) {
		printf( "I'm process %lu. The maximum sum I found is %d.\n", pthread_self(), localMax );
	}

	return NULL;
}

int main( int argc, char* argv [ ] )
{
	int workers = 4;

	// Parse command-line arguments.
	if ( argc < 2 || argc > 3 )
		usage();

	if ( sscanf( argv [ 1 ], "%d", &workers ) != 1 ||
		workers < 1 )
		usage();

	// If there's a second argument, it better be "report"
	if ( argc == 3 ) {
		if ( strcmp( argv [ 2 ], "report" ) != 0 )
			usage();
		report = true;
	}

	//initialize all the semaphores to be shared within threads and all available
	sem_init( &sumLock, 0, 1 );
	sem_init( &sumChange, 0, 1 );
	sem_init( &incrPos, 0, 1 );
	sem_init( &waitLine, 0, 1 );

	// Make each of the workers.
	pthread_t worker [ workers ];
	for ( int i = 0; i < workers; i++ ) {
		int val = pthread_create( &worker [ i ], NULL, workerRoutine, NULL );
		if ( val < 0 ) {
			fail( "Failed to create thread" );
		}

	}

	// Then, start getting work for them to do.
	readList();

	//read everything from the list
	allRead = true;

	// Wait until all the workers finish.
	for ( int i = 0; i < workers; i++ ) {
		pthread_join( worker [ i ], NULL );
	}

	// Report the max product and release the semaphores.
	printf( "Maximum Sum: %d\n", max_sum );

	//destroy the semaphores
	sem_destroy( &sumLock );
	sem_destroy( &incrPos );
	sem_destroy( &waitLine );
	return EXIT_SUCCESS;
}
