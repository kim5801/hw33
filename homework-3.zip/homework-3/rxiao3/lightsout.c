/**
 *@file lightsout.c
 * @author Rose Xiao
 * @brief Will interpret a user command given in the command-line args and make requested changes to the game board stored in shared memory. Other copies of this program running on the same host will automatcally see the changes in the game.
 * @date 2022-09-15
 *
 * @copyright Copyright (c) 2022
 *
 */
#include <stdbool.h>
#include <stdlib.h> //to include the exit macros
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"


 // #include <sys/ipc.h>
#include <semaphore.h> //to allow usage of the sem_open

//decimal value of the open bracket
//this is the mask used to toggle between '*' and '.'
#define MASK 4
//length of the status string to report back
#define STR_LEN 8
//valid number of command line arguments for 'move'
#define VALID_MV_CT 4
//valid number of command line arguments for 'test'
#define VALID_TEST_CT 5
//name when unable to parse an integer from the command line args
#define INVALID_SCAN 1

 //gcc -g -Wall -std=c99 -D_XOPEN_SOURCE lightsout.c -o lightsout -lpthread
 //./lightsout test 5000000 2 1 & ./lightsout test 5000000 2 1

//the named semaphore to act as a lock
static sem_t* lock;

// Print out an error message and exit.
static void fail( char const* message )
{
	fprintf( stderr, "%s\n", message );
	exit( EXIT_FAILURE );
}

/**
 * @brief function for the move command
 *
 * @param row the row value
 * @param col the column value
 * @param buffer the GameState struct for the game
 * @return returns true if the move arguments are valid and was succesful. Else return false
 */
bool move( int row, int col, GameState* buffer )
{

#ifndef UNSAFE
	// printf( "SEM IN\n" );
	sem_wait( lock );
#endif

	//decimal value of the open bracket
	//this is the mask used to toggle between '*' and '.'
	int mask = MASK;

	//if the integers read in are out of bounds for the board
	if ( row < FIRST_ROW || row > LAST_ROW || col < FIRST_COL || col > LAST_COL ) {
		// fail( "error" );

#ifndef UNSAFE
		sem_post( lock );
#endif
		return false;
	}

	// printf( "MOVEIN\n" );

	//save the move into Gamestate
	buffer->rowMove = row;
	buffer->colMove = col;

	//check where the move requested is located at the corner
	if ( ( row == FIRST_ROW || row == LAST_ROW ) && ( col == FIRST_COL || col == LAST_COL ) ) {
		if ( row == FIRST_ROW && col == FIRST_COL ) {
			//upper left
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else if ( row == FIRST_ROW && col == LAST_COL ) {
			//upper right
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		}
		else if ( row == LAST_ROW && col == FIRST_COL ) {
			//lower left
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else {
			//lower right
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		}

	}
	//check where the move requested is located at the sides
	else if ( row == FIRST_ROW || row == LAST_ROW || col == FIRST_COL || col == LAST_COL ) {
		if ( row == 0 ) {
			//top row
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;

		}
		else if ( row == LAST_ROW ) {
			//bottom row
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else if ( col == FIRST_COL ) {
			//left col
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else {
			//right col
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		}
	}
	//the move requested is inner
	else {
		buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
		buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
		buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;

	}
	//change the center symbol
	buffer->board [ row ][ col ] = ( buffer->board [ row ][ col ] ) ^ mask;
	// printf( "MOVEOUT\n" );

	//set the undo boolean to true
	buffer->undo = true;

#ifndef UNSAFE
	// printf( "SEM OUT\n" );
	sem_post( lock );
#endif
	return true;

}


/**
 * @brief Reverses the previous move once
 *
 * @param buffer the Gamestate to be passed in
 * @return true if the undo operation was succesful. Else returns false
 */
bool undo( GameState* buffer )
{
	// printf( "UNDO\n" );

#ifndef UNSAFE
	// printf( "SEM IN\n" );
	sem_wait( lock );
#endif


	if ( buffer->undo ) {
		//call the move function to undo it

#ifndef UNSAFE
		// printf( "SEM OUT TRUE\n" );
		sem_post( lock );
#endif

		move( buffer->rowMove, buffer->colMove, buffer );
		buffer->undo = false;

#ifndef UNSAFE
		// printf( "SEM OUT TRUE\n" );
		sem_post( lock );
#endif

		return true;
	}
#ifndef UNSAFE
	// printf( "SEM OUT FALSE\n" );
	sem_post( lock );
#endif
	return false;
}

/**
 * @brief Reports the state of the board
 *
 * @param buffer the Gamestate to be passed in
 */
void report( GameState* buffer )
{
	// printf( "REPORT\n" );
#ifndef UNSAFE
	sem_wait( lock );
#endif

	for ( int i = 0; i < GRID_SIZE; i++ ) {
		for ( int j = 0; j < GRID_SIZE; j++ ) {
			printf( "%c", buffer->board [ i ][ j ] );
		}
		printf( "\n" );
	}

#ifndef UNSAFE
	sem_post( lock );
#endif
}

//Test interface,, for quickly making a given move over and over
bool test( GameState* buffer, int n, int row, int col )
{
	// printf( "TESTING\n" );

	// Make sure the row / colunn is valid.
	if ( row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE ) {
		return false;
	}
	// Make the same move a bunch of times.
	for ( int i = 0; i < n; i++ ) {
		move( row, col, buffer );
	}
	return true;
}

int main( int argc, char* argv [ ] )
{
	// Open the semaphore already made by reset.c
	lock = sem_open( SEM_NAME, 0 );
	if ( lock == SEM_FAILED ) {
		fail( "Failed to open lock semaphore" );
	}

	// //generate a unique key
	key_t key = ftok( "/afs/unity.ncsu.edu/users/r/rxiao3/CSC246/HW/HW3", 0 );
	if ( key < 0 ) {
		exit( EXIT_FAILURE );
	}
	// Make a shared memory segment 1024KB in size
	int shmid = shmget( key, BLOCK_SIZE, 0666 | IPC_CREAT );
	if ( shmid < 0 ) {
		fail( "Can't create shared memory" );
	}

	//Mapping the shared memory struct into the address space
	GameState* buffer = ( GameState* )shmat( shmid, 0, 0 );
	if ( buffer == ( GameState* )-1 ) {
		fail( "Can't map the memory segment into address space." );
	}

	//string to return if the command is invalid
	char status [ ] = "error";

	//checking if the command was move
	if ( strcmp( "move", argv [ 1 ] ) == 0 ) {
		if ( argc > VALID_MV_CT ) {
			fail( "Invalid number of arguments for move command" );
		}
		//read in the two int values that will be used
		int rowTemp, colTemp;
		int rowScan = sscanf( argv [ 2 ], "%d", &( rowTemp ) );
		int colScan = sscanf( argv [ 3 ], "%d", &( colTemp ) );

		//if not an integer
		if ( rowScan != INVALID_SCAN || colScan != INVALID_SCAN ) {
			fail( "error" );
		}

		//call the move function
		bool result = move( rowTemp, colTemp, buffer );

		if ( result ) {
			strncpy( status, "success", STR_LEN );
		}
		printf( "%s\n", status );
	}
	//the client requests to undo
	else if ( strcmp( "undo", argv [ 1 ] ) == 0 ) {
		bool result = undo( buffer );
		if ( result ) {
			strncpy( status, "success", STR_LEN );
		}
		printf( "%s\n", status );
	}
	//the client requests to report the board state
	else if ( strcmp( "report", argv [ 1 ] ) == 0 ) {
		report( buffer );
	}
	else if ( strcmp( "test", argv [ 1 ] ) == 0 ) {
		if ( argc > VALID_TEST_CT ) {
			printf( "%d\n", argc );
			fail( "Invalid number of arguments for test command" );
		}
		//read in the 3 int values that will be used
		int count, tempRow, tempCol;
		int numScan = sscanf( argv [ 2 ], "%d", &count );
		int rowScan = sscanf( argv [ 3 ], "%d", &( tempRow ) );
		int colScan = sscanf( argv [ 4 ], "%d", &( tempCol ) );

		//if not an integer
		if ( rowScan != INVALID_SCAN || colScan != INVALID_SCAN || numScan != INVALID_SCAN ) {
			fail( "error" );
		}

		test( buffer, count, tempRow, tempCol );
	}
	//if the user did not input a valid cmd
	else {
		fail( "error" );
	}

	// // Release our reference to the shared memory segment.
	// shmdt( buffer );

	 // Close the semaphore and exit.
	sem_close( lock );
	// sem_unlink( "/rxiao3-lightsout-lock" );

	return EXIT_SUCCESS;
}


