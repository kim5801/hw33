#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

#define MOVE "move"
#define UNDO "undo"
#define REPORT "report"
#define TEST "test"

sem_t *mutex;

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

/// Prints the 5x5 board out to stdout
/// @param board board represented as a 1D array of lights
static void reportBoard(char *board)
{
  for (int r = 0; r < GRID_SIZE; r++)
  {
    for (int c = 0; c < GRID_SIZE; c++)
    {
      printf("%c", board[GRID_SIZE * r + c]);
    }
    printf("\n");
  }
}

// changes the light as per the 'lights out' rules
static void invertLight(char *board, int row, int col)
{
  int lightIndex = GRID_SIZE * row + col;
  if (board[lightIndex] == LIGHT_OFF)
  {
    board[lightIndex] = LIGHT_ON;
  }
  else
  {
    board[lightIndex] = LIGHT_OFF;
  }
}

// checks for edge cases and then inverts the light's state
static void editNeighbor(char *board, int row, int col)
{
  if (row < 0 || col < 0 || row >= GRID_SIZE || col >= GRID_SIZE)
    return;

  invertLight(board, row, col);
}

/// Edits all the chosen light's neighbors to be inverted
/// @param board board array
/// @param message move command received from client containing move row & col
/// @return status of the success of the move
bool makeMove(char *board, int r, int c)
{
  // directional array representing positions of neighbors
  int dirs[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
  // make the initial move
  invertLight(board, r, c);
  for (int i = 0; i < GRID_SIZE - 1; i++)
  {
    // change state of left, right, up, and down neighbors
    editNeighbor(board, r + dirs[i][0], c + dirs[i][1]);
  }

  return true;
}

// Makes a move at the provided row and column
// on the board
bool move(GameState *state, int r, int c)
{
#ifndef UNSAFE
  sem_wait(mutex);
#endif
  // change undoboard
  memcpy(state->undoBoard, state->board, sizeof(state->board));
  // MOVE
  if (makeMove(state->board, r, c))
  {
    if (state->lastMoveUndo)
    {
      state->lastMoveUndo = false;
    }
#ifndef UNSAFE
    sem_post(mutex);
#endif
    return true;
  }
  else
  {
#ifndef UNSAFE
    sem_post(mutex);
#endif
    return false;
  }
}

// Undoes the previous move command
// provided undo isn't being called 2 times in a row
bool undo(GameState *state)
{
#ifndef UNSAFE
  sem_wait(mutex);
#endif
  // UNDO
  if (state->lastMoveUndo)
  {
#ifndef UNSAFE
    sem_post(mutex);
#endif
    return false;
  }
  else
  {
    memcpy(state->board, state->undoBoard, sizeof(state->undoBoard));
    state->lastMoveUndo = true;
#ifndef UNSAFE
    sem_post(mutex);
#endif
    return true;
  }
}

// Reports the current state of the board
void report(GameState *state)
{
#ifndef UNSAFE
  sem_wait(mutex);
#endif
  reportBoard(state->board);
#ifndef UNSAFE
  sem_post(mutex);
#endif
}

// Test interface, for quickly making a given move over and over.
bool test(GameState *state, int n, int r, int c)
{
  // Make sure the row / colunn is valid.
  if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
    return false;
  // Make the same move a bunch of times.
  for (int i = 0; i < n; i++)
    move(state, r, c);
  return true;
}

int main(int argc, char *argv[])
{
  if (argc < 2)
  {
    fail("No args given.");
  }

  GameState *state;

  // Get key of shared memory
  key_t key = ftok("/afs/unity.ncsu.edu/users/c/cjcuddy/", 'c');
  int shmid = shmget(key, sizeof(GameState), IPC_CREAT | 0666);

  // get pointer to block of memory and save state
  state = (GameState *)shmat(shmid, 0, 0); // attach shared memory
  mutex = sem_open(NAMED_SEMAPHORE, O_WRONLY);

  // Move
  if (strcmp(argv[1], MOVE) == 0)
  {
    // missing coordinate args
    if (argc < 4)
    {
      fail("Not enough coordinates provided for move.");
    }
    // check that coords are within bounds
    int r = argv[2][0] - '0';
    int c = argv[3][0] - '0';
    if (r < 0 || r > 4 || c < 0 || c > 4)
    {
      fail("error");
    }
    if (move(state, r, c))
    {
      printf("success\n");
    }
    else
    {
      printf("error\n");
    }
  }
  // Undo command
  else if (strcmp(argv[1], UNDO) == 0)
  {
    if (undo(state))
    {
      printf("success\n");
    }
    else
    {
      printf("error\n");
    }
  }
  // print board from shared memory
  else if (strcmp(argv[1], REPORT) == 0)
  {
    report(state);
  }
  // Test command
  else if (strcmp(argv[1], TEST) == 0)
  {
    int n = atoi(argv[2]);
    int r = argv[3][0] - '0';
    int c = argv[4][0] - '0';
    if (test(state, n, r, c))
    {
      printf("success\n");
    }
    else
    {
      printf("error\n");
    }
  }
  // Command issued isn't in scope of client
  else
  {
    fail("Invalid command.");
  }

  exit(0);
}
