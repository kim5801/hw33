#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum-sem <workers>\n");
  printf("       maxsum-sem <workers> report\n");
  exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

bool noMoreInput = false;

// Maximum sum we've found.
// GUARD WITH SEMAPHORE WHEN CHANGING
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000

// Value signifying there's no more input left
#define SENTINEL -727

int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

int workIndex = 0;

// Semaphore to guard max_sum
sem_t maxSumSem;

static int findMaxSum(int index)
{
  int localMax = -1;
  int sum = 0;
  for (int i = index; i >= 0; i--)
  {
    sum += vList[i];
    if (sum > localMax)
    {
      localMax = sum;
    }
  }

  return localMax;
}

// Semaphore for reading in values
sem_t producer;
// Semaphore for eating values
sem_t consumer;
// Lock semaphore for access to getWork()
sem_t lock;

// Read the list of values.
void readList()
{
  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1)
  {
    // Make sure we have enough room, then store the latest input.
    if (vCount >= MAX_VALUES)
      fail("Too many input values");

    sem_wait(&producer);
    // Store the latest value.
    vList[vCount++] = v;
    sem_post(&consumer);
  }
  // Acount for the last element read
  sem_wait(&producer);
  sem_post(&consumer);
  noMoreInput = true;
}

// request for last index is being phased out by line 104
// this is because input has stopped being read, but there's a trailing index
// that needs to be looked at
int getWork()
{
  if (noMoreInput)
    return SENTINEL;
  sem_wait(&consumer);
  int indexToReturn = workIndex;
  // There's work to be done
  if (workIndex < vCount)
  {
    workIndex++;
  }

  sem_post(&producer);
  return indexToReturn;
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
  int index = INT_MIN;
  int threadMax = 0;

  while (index != SENTINEL)
  {
    sem_wait(&lock);
    index = getWork();
    sem_post(&lock);
    // No more work to be had
    if (index != INT_MIN)
    {
      // Find max
      int localMax = findMaxSum(index);
      if (localMax > threadMax)
        threadMax = localMax;
    }
  }

  if (threadMax > max_sum)
  {
    // Wait to update max sum
    sem_wait(&maxSumSem);
    max_sum = threadMax;
    sem_post(&maxSumSem);
  }

  if (report)
    printf("I'm thread %d. The maximum sum I found is %d.\n", *(int *)pthread_self(), threadMax);

  return NULL;
}

int main(int argc, char *argv[])
{
  int workers = 4;

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 ||
      workers < 1)
    usage();

  // If there's a second argument, it better be "report"
  if (argc == 3)
  {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  sem_init(&maxSumSem, 0, 1);

  sem_init(&producer, 0, 1);
  sem_init(&consumer, 0, 0);
  sem_init(&lock, 0, 1);
  // Make each of the workers.
  pthread_t worker[workers];
  for (int i = 0; i < workers; i++)
    if (pthread_create(&worker[i], NULL, workerRoutine, NULL) != 0)
    {
      fail("Can't create ping thread.");
    }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for (int i = 0; i < workers; i++)
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf("Maximum Sum: %d\n", max_sum);
  sem_post(&maxSumSem);

  return EXIT_SUCCESS;
}
