/**
* @file lightsout.c
* @author dsmathur
* This file includes all the operations of the 
* board game ranging from move to report.
* It takes in the commands from the user and uses
* a shared memory segment created from reset.c 
* in order to make the corresponding updates 
* to the board.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** String used for printing success to the terminal */
#define SUCCESS "success\n"

/** String  used for representing the move command in the server message queue*/
#define MOVE "move"

/** String used for representing the undo command in the server message queue*/
#define UNDO "undo"

/** String used for representing the report command in the server message queue*/
#define REPORT "report"

/** String used for representing the test command in the server message queue*/
#define TEST "test"

/** A constant used for the error message */
#define ERROR_MESSAGE "error"

/** Used for recording the values from the board file */
#define MESSAGE_LIMIT 37

sem_t *lock;
// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/**
* This function performs the move operation 
* and switches the lights according to 
* the row and column number provided.
* @param state the current board struct
* @param r the row number
* @param c the column number
* @return a boolean of whether the move operation was successful or not
*/
bool move (GameState *state, int r , int c){
    #ifndef UNSAFE
    sem_wait(lock);
    #endif
    
    //Save the previous state of the board before making any changes
    for(int i = 0 ; i < GRID_SIZE;i++){
        for(int j=0; j < GRID_SIZE;j++){
            state-> previousboard[i][j] = state ->currentboard[i][j];
        }
    }
            
    //Perform the move operations required for the
    // current place in the board
    if(state -> currentboard[r][c] == '.'){
        state->currentboard[r][c] = '*'; 
    }
    else if(state->currentboard[r][c] == '*'){
        state->currentboard[r][c] = '.';
    }    
    //Check the place above, the current row,column index
    //Perform this only if there is an available row above
    if(r -1 >= 0 ){
        if(state->currentboard[r -1][c] == '.'){
            state->currentboard[r-1][c] = '*';
        }
        else if(state->currentboard[r - 1][c] == '*'){
            state->currentboard[r-1][c] = '.';
        }    
    }    
    //Check the place below
    //Perform this only when a row is available below
    if(r + 1 <= GRID_SIZE -1  ){
        if(state->currentboard[r + 1][c] == '.'){
            state->currentboard[r+1][c] = '*';
        }
        else if(state->currentboard[r + 1][c] == '*'){
            state->currentboard[r+1][c] = '.';
        } 
    }    
    //Check the place to the right
    //Perform this only when a column is available to the right
    if(c + 1 <= GRID_SIZE -1){
        if(state->currentboard[r][c + 1] == '.'){
            state->currentboard[r][c + 1] = '*';
        }
        else if(state->currentboard[r][c + 1] == '*'){
            state->currentboard[r][c + 1] = '.';
        }
    }
         
    //Check the place to the left
    //Perform this only when a column is available to the left 
    if(c - 1 >= 0 ){
        if(state->currentboard[r][c - 1] == '.'){
            state->currentboard[r][c - 1] = '*';
        }
        else if(state->currentboard[r][c -1] == '*'){
            state->currentboard[r][c - 1] = '.';
        }
    }
    //Since a move operation has been performed 
    // we can set undo to true indicating that an undo  
    // operation can be performed after this
    state->undo = 1;
        
    #ifndef UNSAFE
    sem_post(lock);
    #endif
    
    return true;
       
}

/**
* Test interface, for quickly making a given move over and over.
* @param state the current board struct
* @param r the row number
* @param c the column number
* @return a boolean of whether the move operation was successful or not
*/
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );
    return true;
}

/**
* This function undo's the previous move 
* and returns a boolean corresponding 
* to whether it was successful or not.
* @param state the current state of the game
* @return a boolean representing whether the undo
*        operation was successful or not 
*/
bool undo (GameState * state){
    #ifndef UNSAFE
    sem_wait(lock);
    #endif

    if(state->undo == 0){
        #ifndef UNSAFE
        sem_post(lock);
        #endif
        return false;
    }
        
    //Copying the items in the previous state of the gameboard
    // to the current state in order for the undo operation 
    // to be carried out successfully.
    for(int i = 0  ; i < GRID_SIZE;i++){
        for(int j = 0; j < GRID_SIZE;j++){
            state->currentboard[i][j] = state->previousboard[i][j];
        }
    } 
    //Set undo back to false as undo has been performed now
     
    state->undo = 0;
    #ifndef UNSAFE
    sem_post(lock);
    #endif
    
    return true;

}

/**
* This function generates a report of the current state 
* of the board 
* @param state the board struct
*/
void report (GameState *state){
    //Initializing a char array to hold the current state of the board
    #ifndef UNSAFE
    sem_wait(lock);
    #endif
    
    char sendReport[MESSAGE_LIMIT];
    int charcount = 0;
    for(int i = 0 ; i < GRID_SIZE;i++){
        for(int j = 0 ; j < GRID_SIZE;j++){
            sendReport[charcount++] = state -> currentboard[i][j];
        }
        sendReport[charcount++] = '\n';
    }
    //Putting a null terminator at the end of this character array
    sendReport[charcount] = '\0';
    printf("%s",sendReport);
    #ifndef UNSAFE
    sem_post(lock);
    #endif
}
/**
* The main program in lightsout.c that takes in arguments
* and accesses the shared memory created by reset.c 
* in order to update the boards according to the commands
* entered by the user.
* @param argc  the number of arguments
* @param argv the arguments in a char pointer array
* @return an int of  whether the program successfully exited or not
*/
int main( int argc, char *argv[] ) {
    //Access the shared created memory segment
    int shmid = shmget(ftok(SHARED_MEMORY,0),0,0);
    if ( shmid == -1 )
        fail( "Can't create shared memory" );
    
    lock = sem_open(SEM_NAME, 1 );
    
    if ( lock == SEM_FAILED )
        fail( "Can't open tag semaphore" );
        
    //Similar to creating a new instance of GameState
    GameState *board = (GameState * )shmat(shmid,0,0);
    // To represent whether a given command entered is valid or not
    bool invalidCommand = 0;
    
    if(argc  == 1){
        fail(ERROR_MESSAGE);
    }
    //if the operation performed was move , then 
    //follow the given approach 
    if(strcmp(argv[1],MOVE) == 0){
        if(argc != 4){
            fail(ERROR_MESSAGE);
        }
        
        //Read the arguments related to the rows and columns
        // in integer terms
        int row = atoi(argv[2]);
        int column = atoi(argv[3]);
        
        //Performing some invalid checks
        //If the row was not zero and the return value of 
        // atoi() function is 0 , this indicates that 
        // an error occurred with regards to processing the 
        // row value as an integer.
        if(strcmp(argv[2], "0") != 0){
            if(row <= 0  || row >= GRID_SIZE){
                invalidCommand = 1;
            }
        }
        
        //If the column was not zero and the return value of 
        // atoi() function is 0 , this indicates that 
        // an error occurred with regards to processing the 
        // column value as an integer.
        if(strcmp(argv[3], "0") != 0){
            if(column<=0  || column >= GRID_SIZE){
                invalidCommand = 1;
            }
        }
        
        //If it was an invalid move command, 
        // the program should fail
        if(invalidCommand){
            fail(ERROR_MESSAGE);
        }
        bool returnvalue = move(board, row,column);
        
        if(returnvalue){
            //Print success if the move operation was successful
            printf("success\n");
            
        }
        
    }
    
    //If the command to be performed is undo
    else if(strcmp(argv[1],UNDO) == 0){
        //Performing invalid checks on the undo operation command
        if(argc != 2){
            fail(ERROR_MESSAGE);
        }
        bool returnValue = undo(board);
        if(!returnValue){
            fail(ERROR_MESSAGE);
        }
        else{
             printf("success\n");
        }
    }
    
    //If the command issued was report instead , then the program   
    //should print  the current state of the board.
    else if(strcmp(argv[1],REPORT) == 0){
        if(argc != 2){
            fail(ERROR_MESSAGE);
        }
        
        report(board);

    }
    else if(strcmp(argv[1],TEST) == 0){
         int n = atoi(argv[2]);
        int row = atoi(argv[3]);
        int column = atoi(argv[4]);
        test(board,n,row,column);
    }
    else{ 
        fail(ERROR_MESSAGE);
    }
    // Close and destroy the tag semaphore.
      sem_close( lock );

}
