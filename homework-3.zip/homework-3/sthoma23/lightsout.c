#include <semaphore.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Required number of arguments for 'move' command */
#define MOVE_ARGS 4

/** Number of arguments for 'undo' and 'report' commands */
#define NUM_ARGS 2

/** Required number of arguments for 'test' command */
#define TEST_ARGS 5

/** Row number argv index for 'move' command */
#define MOV_ROW_IDX 2 

/** Col number argv index for 'move' command */
#define MOV_COL_IDX 3

/** n number argv index for 'test' command */
#define TES_N_IDX 2 

/** Row number argv index for 'test' command */
#define TES_ROW_IDX 3 

/** Col number argv index for 'test' command */
#define TES_COL_IDX 4

sem_t *lock; //Semaphore for preventing race conditions

// Print out an error message and exit.
static void fail( char const *message )
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
* Change the char at the specified index
* in the board as well as adjacent chars
*
* @param state pointer the GameState struct in shared memory
* @param row index of the row in the board
* @param col index of the column in the board
* @return true upon completion
*/
static bool move( GameState *state, int row, int col ) 
{

  if ( row < 0 || col < 0 ) {
    //Negative index
    return false;
  }
  else if ( row >= GRID_SIZE || col >= GRID_SIZE ) {
    //Index too large
    return false;
  }

  //WAIT
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  //Initialize/update the previous state of the board
  state->last_move[ 0 ] = row;
  state->last_move[ 1 ] = col;

  for ( int i = row - 1; i <= row + 1; i++ ) {

    //Flip "on/off" at the named index,
    //the index above (if in bounds), and
    //the index below (if in bounds) 
    if ( i >= 0 && i < GRID_SIZE ) { //Bound check
      if ( state->cells[ i ][ col ] == '.' ) {
        state->cells[ i ][ col ] = '*'; //Switch on
      }
      else {
        state->cells[ i ][ col ] = '.'; //Switch off
      }
    }
  }

  for ( int i = col - 1; i <= col + 1; i += 2 ) {

    //Flip "on/off" at the left and
    //the right of the named index
    //if they are in bounds
    if ( i >= 0 && i < GRID_SIZE ) { //Bound check
      if ( state->cells[ row ][ i ] == '.' ) {
        state->cells[ row ][ i ] = '*'; //Switch on
      }
      else {
        state->cells[ row ][ i ] = '.'; //Switch off
      }
    }
  }

  //User can undo
  state->flag = 1;

  //POST
  #ifndef UNSAFE
    sem_post( lock );
  #endif

  return true;
}

/**
* Change the char at the last changed index
* in the board as well as adjacent chars
*
* @param game pointer the GameState struct in shared memory
* @return true upon completion
*/
static bool undo( GameState *game )
{

  //WAIT
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  if ( game->flag ) {

    //Set the game state back by one move
    int row = game->last_move[ 0 ];
    int col = game->last_move[ 1 ];

    for ( int i = row - 1; i <= row + 1; i++ ) {

      //Flip "on/off" at the named index,
      //the index above (if in bounds), and
      //the index below (if in bounds) 
      if ( i >= 0 && i < GRID_SIZE ) { //Bound check
        if ( game->cells[ i ][ col ] == '.' ) {
          game->cells[ i ][ col ] = '*'; //Switch on
        }
        else {
          game->cells[ i ][ col ] = '.'; //Switch off
        }
      }
    }

    for ( int i = col - 1; i <= col + 1; i += 2 ) {

      //Flip "on/off" at the left and
      //the right of the named index
      //if they are in bounds
      if ( i >= 0 && i < GRID_SIZE ) { //Bound check
        if ( game->cells[ row ][ i ] == '.' ) {
          game->cells[ row ][ i ] = '*'; //Switch on
        }
        else {
          game->cells[ row ][ i ] = '.'; //Switch off
        }
      }
    }

    //Cannot undo twice in a row
    game->flag = 0;

    //POST
    #ifndef UNSAFE
      sem_post( lock );
    #endif

    return true; //Undo was successful
  }

  //POST
  #ifndef UNSAFE
    sem_post( lock );
  #endif

  return false; //Undo was not successful
}

/**
* Print out the current state of the game
*
* @param state pointer to the struct in shared memory
*/
static void report( GameState *state )
{
  //WAIT
  #ifndef UNSAFE
    sem_wait( lock );
  #endif

  //Print out the game board char by char
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", state->cells[ i ][ j ] );
    }
    printf( "\n" );
  }

  //POST
  #ifndef UNSAFE
    sem_post( lock );
  #endif
}

/**
* Test race conditions by calling the move function n
* times as fast as possible
*
* @param n number of times move() will be called
* @param r row number
* @param c column number
*/
static bool test( GameState *state, int n, int r, int c )
{

  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }

  return true;
}

/**
* Access the shared memory created by reset.c and 
* handle a game-related command by parsing command line arguments
* 
* @param argc Number of command line arguments
* @param argv Array of command line arguments
* @return 1 upon successful execution
*/
int main( int argc, char *argv[] ) {

  //Open the semaphore
  lock = sem_open( SEM_PATH, 1 );
  if ( lock == SEM_FAILED ) {
    fail( "Can't open semaphore" );
  }

  //Access shared memory
  key_t key = ftok( SHM_PATH, 0 );
  int shmid = shmget( key, sizeof( GameState ), 0 );

  //Create a pointer to the shared memory
  GameState *game = ( GameState * ) shmat( shmid, 0, 0 );

  if ( strcmp( argv[ 1 ], "move" ) == 0 ) { //"move" command

    if ( argc != MOVE_ARGS ) { 
      //Invalid number of command line args
      fail("error");
    }

    //Check for valid row and column indeces
    int row = 0;
    int col = 0;
    int rmatch = sscanf( argv[ MOV_ROW_IDX ], "%d", &row );
    int cmatch = sscanf( argv[ MOV_COL_IDX ], "%d", &col );

    if ( !rmatch || !cmatch ) {
      //Not an integer
      fail( "error" );
    }
    else if ( row < 0 || col < 0 ) {
      //Negative index
      fail( "error" );
    }
    else if ( row >= GRID_SIZE || col >= GRID_SIZE ) {
      //Index too large
      fail( "error" );
    }
    else {
      //Command is valid

      //Helper methods will handle "flipping" the chars
      if ( move( game, row, col ) ) {
        printf( "success\n" ); //Move was successful
      }
      else {
        fail( "error" ); //Move was unsuccessful
      }

    }
  } 
  else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) { //"undo" command

    if ( argc != NUM_ARGS ) {
      //Invalid number of command line args
      fail( "error" );
    }

    if ( undo( game ) ) {
      printf( "success\n" ); //Undo was successful
    }
    else {
      printf( "error\n" ); //Undo was not successful
    }

  }
  else if ( strcmp( argv[ 1 ], "report" ) == 0 ) { //"report" command

    if ( argc != NUM_ARGS ) {
      //Invalid number of command line args
      fail( "error" );
    }
    
    report( game );

  }
  else if ( strcmp( argv[ 1 ], "test" ) == 0 ) { //"test" command

    if ( argc != TEST_ARGS ) { 
      //Invalid number of command line args
      fail("error");
    }

    //Check for valid row and column indeces
    int n = 0;
    int row = 0;
    int col = 0;
    int nmatch = sscanf( argv[ TES_N_IDX ], "%d", &n );
    int rmatch = sscanf( argv[ TES_ROW_IDX ], "%d", &row );
    int cmatch = sscanf( argv[ TES_COL_IDX ], "%d", &col );

    if ( !nmatch || !rmatch || !cmatch ) {
      //Not an integer
      fail("error");
    }
    else if ( n < 1 || row < 0 || col < 0 ) {
      //Argument value too small
      fail("error");
    }
    else if ( row >= GRID_SIZE || col >= GRID_SIZE ) {
      //Index too large
      fail( "error" );
    }
    else {
      //Command is valid

      //Helper methods will handle "flipping" the chars
      if ( test( game, n, row, col ) ) {
        printf( "success\n" ); //Move was successful
      }

    }
  }
  else { //Invalid command
    fail( "error" );
  }

  //Close the semaphore
  sem_close( lock );

  return 0;
}
