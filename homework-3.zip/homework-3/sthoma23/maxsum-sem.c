#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <assert.h>

// Print out an error message and canexitfuck.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then canexitfuck.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

sem_t work; // Halts a thread while there is no work

sem_t lock; // Lock for accessing max_sum variable

sem_t index_lock; // Lock for accessing index variable

int index = -1; // Index for a thread to start search

int flag = 0; // Indicates whether readList is finished reading

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    // More work to be done
    sem_post( &work );
  }
  // Finished reading
  flag = 1;

  // Let the last thread escape the wait
  sem_post( &work );
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {

  int thread_max = vList[ 0 ];
  while ( vCount < 1 ); // Wait for at least one int
  while ( true ) {

    sem_wait( &index_lock );

    // Are we done here?
    if ( index >= vCount && flag ) {
      // Yes
      sem_post( &index_lock );
      break;
    }
    int end = ++index; // Get snapshot of index variable
    sem_post( &index_lock );

    sem_wait( &work ); // Wait for work

    int max = INT_MIN;
    int sum = 0;

    // Each thread starts at an index that is + 1
    // from the last and will search backwards
    // inside its range
    for ( int i = end; i >= 0; i-- ) {
      sum += vList[ i ]; 
      if ( max < sum ) {
        max = sum;
      }
    }
    if ( thread_max < max ) {
      thread_max = max; // Update max_sum
    }

    // sem_wait( &lock );
    // if ( max_sum < max ) {
    //   max_sum = max; // Update max_sum
    // }
    // sem_post( &lock );
  }

  sem_wait( &lock );
    if ( max_sum < thread_max ) {
      max_sum = thread_max; // Update max_sum
    }
  sem_post( &lock );

  if ( report ) {
    int tid = ( int ) pthread_self();
    // if ( thread_max == INT_MIN ) {
    //   thread_max = vList[ 0 ];
    // }
    printf( "I'm thread %d. The maximum sum I found is %d.\n", tid, thread_max );
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 ) {
    usage();
  }

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 || workers < 1 ) {
    usage();
  }

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 ) {
      usage();
    }
    report = true;
  }

  // Intialize all semaphores
  sem_init( &work, 0, 0 );
  sem_init( &lock, 0, 1 );
  sem_init( &index_lock, 0, 1 );

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create( &( worker[ i ] ), NULL, workerRoutine, NULL );

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  sem_destroy( &work );
  sem_destroy( &lock );
  sem_destroy( &index_lock );
  
  return EXIT_SUCCESS;
}
