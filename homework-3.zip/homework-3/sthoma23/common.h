/** Height and width of the playing area. */
#define GRID_SIZE 5

/** No. of variables used to describe a location
* on the board (i.e. row and column)
*/
#define COORDINATE 2

/** Default max size for a general message */
#define MESSAGE_LIMIT 1024

/** Path for shared memory */
#define SHM_PATH "/afs/unity.ncsu.edu/users/s/sthoma23"

/** Path for interprocess semaphore */
#define SEM_PATH "/sthoma23-lightsout-lock"

#ifndef GAMESTATE
#define GAMESTATE

/**
* Struct holding current state of the board, the
* previous move, and a flag indicating whether
* the last move can be undone
*/
typedef struct GameState
{
  char cells[ GRID_SIZE ][ GRID_SIZE ];
  int last_move[ COORDINATE ];
  int flag;
} GameState;

#endif