#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/** Appropriate number of command line args for execution */
#define NUM_ARGS 2

// Print out an error message and exit.
static void fail( char const *message ) 
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() 
{
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
* Read in the file specified in the command line args
* and initialize the game board stored that will be 
* stored in shared memory
*
* @param argc Number of command line args
* @param argv Array of command line args
* @return 1 upon successful execution
*/
int main( int argc, char *argv[] ) 
{
  sem_unlink( SEM_PATH );
  sem_t *lock = sem_open( SEM_PATH, O_CREAT, 0600, 1 );
  if ( lock == SEM_FAILED ) {
    fail( "Can't make semaphore" );
  }

  if ( argc != NUM_ARGS ) { 
    //Invalid number of command line args
    usage();
  }
  
  //Open the named board file 
  char *file = argv[ 1 ];
  int fd = open( file, O_RDONLY, 0600 );

  if ( fd < 0 ) {
    //Could not open the file
    char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
    strcat( err, file );
    fail( err );
  }

  //Create a buffer to read in the chars from the file
  int fsize = ( GRID_SIZE + 1 ) * GRID_SIZE;
  char fbuffer[ fsize + 1 ];

  //Read in the starting state of the game
  read( fd, fbuffer, fsize );

  if ( strlen( fbuffer ) != fsize ) {
    //Invalid number of characters in board file
    char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
    strcat( err, file );
    fail( err );
  }

  //Verify that the provided file has
  //the proper board file format
  for ( int i = 0; i < GRID_SIZE; i++ ) { //Board has 5 rows

    int j = 0;
    int idx = 0;
    char ch = '\0';

    for ( j = 0; j < GRID_SIZE; j++ ) { //Board has 5 columns

      idx = i * ( GRID_SIZE + 1 ) + j;
      ch = fbuffer[ idx ];

      //Only '.' and '*' are valid 
      if ( ch != '*' && ch != '.' ) { 

        //Illegal character in the board
        char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
        strcat( err, file );
        fail( err );
      }
    }

    //Newline chars are required and 
    //only allowed at the end of each
    //sequence of '*' and '.'
    idx = i * ( GRID_SIZE + 1 ) + j;
    ch = fbuffer[ idx ];
    if ( ch != '\n' ) {

      //Newline not found
      char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
      strcat( err, file );
      fail( err );
    }
  }

  //Create section of shared memory
  key_t key = ftok( SHM_PATH, 0 );
  int shmid = shmget( key, sizeof( GameState ), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    //shmget() encountered an error
    fail( "Can't create shared memory" );
  }

  //Start a new game
  GameState *game = ( GameState * ) shmat( shmid, 0, 0 );

  //Initialize the integer value inside the GameState struct
  game->flag = 0;

  //Divide the string into substrings
  char *buffer = strtok( fbuffer, "\n" );
  int row = 0;
  
  //Iterate through strings with a buffer
  while ( buffer != NULL ) {

    //Initialize the board and copy from
    //buffer to board cells
    for ( int col = 0; col < GRID_SIZE; col++ ) {
      game->cells[ row ][ col ] = buffer[ col ];
    }
    row++;
    buffer = strtok( NULL, "\n" ); 
  }

  // Close the tag semaphore.
  sem_close( lock );

  return 0;
}
