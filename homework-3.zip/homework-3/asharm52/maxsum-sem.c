/**
 * @file maxsum-sem.c
 * @author Arul Sharma (asharm52)
 * This program calculates largest continous sum from a list of numbers, using concurrent running dynamic threads
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message) {
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage() {
  printf("usage: maxsum-sem <workers>\n");
  printf("       maxsum-sem <workers> report\n");
  exit(1);
}

// semaphore to keep track of values as they are read in
sem_t values;
// semaphore to make sure that the getWork function is only accessed by one thread at a time
sem_t access;
// semaphore to make sure that the global max variable is only accessed one at a time
sem_t globalAccess;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// this keeps track of how many times the getWork function is called to get some work
int workCalls = 0;
// keeps track of how many workers the user wants
int workers = 4;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1) {
    // Make sure we have enough room, then store the latest input.
    if (vCount > MAX_VALUES)
      fail("Too many input values");
    // Store the latest value.
    vList[vCount++] = v;
    sem_post(&values);
  }
  for (int i = 0; i < workers; i++) {
    sem_post(&values);
  }
}

/**
 * this method gets work for a thread and gives it numbers to work with
 * @return index of value to work with in list, or -1 if all work is allocated
 */
int getWork() {
  // wait until values are available 
  sem_wait(&values);

  // return the index of new value read in from the list
  if (workCalls < vCount) {
    int ret = workCalls;
    workCalls++;
    return ret;
  }
  else {
    return -1;
  }
}

/** Start routine for each worker. */
void *workerRoutine(void *arg) {
  int max = INT_MIN;

 // get intial index value
  sem_wait(&access);
  int index = getWork();
  sem_post(&access);

  while (workCalls != -1) {
    sem_wait(&access);
    index = getWork();
    sem_post(&access);
    if (index == -1) {
      break;
    }
    else {
      // o(n) solution
      int localMax = vList[index];
      int localSum = vList[index];
      index--;
      while (index >= 0) {
        localSum += vList[index];
        if (localSum > localMax) {
          localMax = localSum;
        }
        index--;
      }
      // write to global max
      sem_wait(&globalAccess);
      if (localMax > max) {
        max = localMax;
      }
      sem_post(&globalAccess);
    }
  }

  if (report) {
    printf("I'm thread %d. The maximum sum I found is %d.\n", (int)pthread_self(), max);
  }

  if (max > max_sum) {
    max_sum = max;
  }
  return NULL;
}

/**
 * this main method makes the workers and sends them to the function so they can complete their work
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main(int argc, char *argv[]) {
  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 ||
      workers < 1)
    usage();

  sem_init(&values, 0, 0);
  sem_init(&access, 0, 1);
  sem_init(&globalAccess, 0, 1);

  // If there's a second argument, it better be "report"
  if (argc == 3) {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[workers];
  for (int i = 0; i < workers; i++) {
    if (pthread_create(&worker[i], NULL, workerRoutine, NULL) != 0)
      fail("Can't create a thread");
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for (int i = 0; i < workers; i++) {
    if (pthread_join(worker[i], NULL) != 0) {
      fail("Can't join a thread");
    }
  }

  // Report the max product and release the semaphores.
  printf("Maximum Sum: %d\n", max_sum);

  sem_destroy(&values);
  sem_destroy(&access);
  sem_destroy(&globalAccess);

  return EXIT_SUCCESS;
}
