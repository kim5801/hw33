// Height and width of the playing area.
#define GRID_SIZE 5

#define MY_SEM "/asharm52-lightsout-lock"

// the gameboard struct
typedef struct {
  char board[ GRID_SIZE ][ GRID_SIZE ];
  char oldBoard[ GRID_SIZE ][ GRID_SIZE ];
  bool undoAvailable;
} GameState;
