/**
 * @file lightsout.c
 * @author Arul Sharma (asharm52)
 * This program reads from the shread memory created in reset.c and does the commands given by the user
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "incorrect number of arguments given\n" );
  exit( 1 );
}

sem_t *sem;

/**
 * this method prints the current board
 * @param state the stuct containing the current state of the board
 */
static void report (GameState *state) {

  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", state -> board[i][j]);
    }
    printf("\n");
  }
  printf("\n");

  #ifndef UNSAFE
    sem_post(sem);
  #endif
}

/**
 * this method checks to make sure that the bounds given for rows and cols are within the 5 by 5 board
 * @param rows rows val for the position that needs to be checked
 * @param cols cols val for the posititon that needs to be checked
 * @return true if the position is valid, false if not
 */
static bool verify (int rows, int cols) {
  if (rows < 0 || rows >= GRID_SIZE || cols < 0 || cols >= GRID_SIZE) {
    return false;
  }
  return true;
}

/**
 * this method performs the move operation by loading in the game state and switching all valid positions' symbols
 * @param state the struct containing board info
 * @param rows rows val for the position that needs to be switched
 * @param cols cols val for the posititon that needs to be switched
 */
static bool move (GameState *state, int rows, int cols) {

  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  //printing the current board to the old board
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      state -> oldBoard[i][j] = state -> board[i][j];
    }
  }

  if (state -> board[rows][cols] == '*') {
    state -> board[rows][cols] = '.';
  } else {
    state -> board[rows][cols] = '*';
  }

  if (verify(rows + 1, cols)) {
    if (state -> board[rows + 1][cols] == '*') {
      state -> board[rows + 1][cols] = '.';
    } else {
      state -> board[rows + 1][cols] = '*';
    }
  }

  if (verify(rows - 1, cols)) {
    if (state -> board[rows - 1][cols] == '*') {
      state -> board[rows - 1][cols] = '.';
    } else {
      state -> board[rows - 1][cols] = '*';
    }
  }

  if (verify(rows, cols + 1)) {
    if (state -> board[rows][cols + 1] == '*') {
      state -> board[rows][cols + 1] = '.';
    } else {
      state -> board[rows][cols + 1] = '*';
    }
  }

  if (verify(rows, cols - 1)) {
    if (state -> board[rows][cols - 1] == '*') {
      state -> board[rows][cols - 1] = '.';
    } else {
      state -> board[rows][cols - 1] = '*';
    }
  }
  state -> undoAvailable = true;

  // printf("%s\n", "success");

  #ifndef UNSAFE
    sem_post(sem);
  #endif

  return true;
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

/**
 * this method undos the users last action by restoring the previous board
 * @param state the struct containing board info
 */
static bool undo (GameState *state) {

  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  if (state -> undoAvailable) {
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
        state -> board[i][j] = state -> oldBoard[i][j];
      }
    }
    // printf( "success\n" );
    state -> undoAvailable = false;
    #ifndef UNSAFE
      sem_post(sem);
    #endif
    return true;
  } else {
    #ifndef UNSAFE
      sem_post(sem);
    #endif
    // printf( "error\n" );
    return false;
  }

  
}

/**
 * this main method looks at the users input, and sends the relevant information to the specific function that will take care of it
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main( int argc, char *argv[] ) {

  sem = sem_open(MY_SEM, 0);

  key_t key = ftok("/afs/unity.ncsu.edu/users/a/asharm52", 1);
  int shmid = shmget( key, 0, 0 );
  GameState *state = (GameState *) shmat( shmid, NULL, 0 );

  if (strcmp(argv[1], "report") == 0) {
    if (argc != 2) {
      usage();
    }
    report(state);
  } else if (strcmp(argv[1], "move") == 0) {
    if (argc != 4) {
      usage();
    }
    int rows, cols;
    // converting the row number string to an int
    if (strcmp(argv[2], "0") != 0) {
      rows = atoi(argv[2]);
      if (rows == 0) {
        fail("error");
      }
    } else {
      rows = 0;
    }
    //converting the col number string to an int
    if (strcmp(argv[3], "0") != 0) {
      cols = atoi(argv[3]);
      if (cols == 0) {
        fail("error");
      }
    } else {
      cols = 0;
    }
    // checking bounds
    if (!verify(rows, cols)) {
      fail("error");
    }
    if (move(state, rows, cols)) {
      printf( "success\n" );
    } else {
      printf( "error\n" );
    }
  } else if (strcmp(argv[1], "undo") == 0) {
    if (argc != 2) {
      usage();
    }
    if (undo(state)) {
      printf( "success\n" );
    } else {
      printf( "error\n" );
    }
  } else if ( strcmp( argv[1], "test") == 0) {
    if (argc != 5) {
      usage();
    }

    // indexes for values
    int num = atoi(argv[2]);
    int idx = atoi(argv[3]);
    int idx1 = atoi(argv[4]);

    if (!test(state, num, idx, idx1)) {
      fail("error");
    }
    else {
      printf("success\n");
    }

  } else {
    usage();
  }
  exit(0);
} 
