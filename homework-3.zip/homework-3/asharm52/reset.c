/**
 * @file reset.c
 * @author Arul Sharma (asharm52)
 * This program reads in the file given by the user, and stores the data in the GameState struct, 
 * so that it can be accessed the by the file which makes chnages to the game
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * main method initiates and connects to shared memory
 * this method also reads in the board and stores it in the shared memory
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main( int argc, char *argv[] ) {

  if (argc < 2 || argc > 2) {
    usage();
  }
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/asharm52", 1), sizeof(GameState), IPC_CREAT | 0666);
  if ( shmid < 0 ) {
    fail("Error with shmget");
  }

  // sem_destroy(MY_SEM);

  sem_open(MY_SEM, O_CREAT, 0600, 1);

  GameState *state = (GameState *)shmat(shmid, NULL, 0);

  // opening a file stream to read the txt file for the board
  FILE *fp;
  if ((fp = fopen(argv[1],"r")) == NULL) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit(1);
  }

  // reading in a char at a time from fp, then storing it in the 2d array in the GameState struct
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      char ch = fgetc(fp);
      if (ch != '.' && ch != '*') {
          fprintf( stderr, "Invalid input file: %s\n", argv[1] );
          exit(1);
      }
      state -> board[i][j] = ch;
    }
    if(fscanf( fp, "%*c" ) == 1 ) {
      fprintf( stderr, "Invalid input file: %s\n", argv[1] );
      exit(1);
    }
  }
  fclose(fp);

  // printing the current board to the old board
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      state -> oldBoard[i][j] = state -> board[i][j];
    }
  }

  state -> undoAvailable = false;
  return 0;
}