/**
 * @file maxsum-sem.c
 * @author Christina Albores (ccalbore)
 * @brief This program finds a contiguous non-empty
 * subsequence within the sequence that has the largest sum.
 * @date 2022-10-12
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// True if the readList() function is finished reading input
bool done = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values in the list.
int vCount = 0;

// Holds the number of empty slots available in the buffer
sem_t emptyCount;
// Hold the number of values read in
sem_t fullCount;
// Lock for accessing vCount
sem_t lock;
// Lock for accessing max_sum
sem_t lockMaxSum;
// Lock for accessing index
sem_t lockIndex;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES ) {
      fail( "Too many input values" );
    }
    
    //acquire(emptyCount)
    sem_wait(&emptyCount);
    //acquire(lock)
    sem_wait(&lock);
    // Store the latest value.
    vList[ vCount++ ] = v;
     //release(lock)
    sem_post(&lock);
    //release(fullCount)
    sem_post(&fullCount);
  }
  // Set done to true since finished reading input
  done = true;
}

// Count of currrent index to give to workers
int indexCount = 0;
/**
 * @brief Workers call this function when they become idle.
 * It returns immediately if there’s more to work on, or, if all 
 * available work has already been given out, the function blocks
 * the worker until more input has been read by the main thread. 
 * 
 * @return int returns the new index for the worker
 */
int getWork() {
  
  // Lock access to indexCount
  sem_wait(&lockIndex);
  // If the list is done and all the work has been allocated
  if (done == true && (indexCount > (vCount - 1))) {
    sem_post(&lockIndex);
    return -1;
  }

  // Wait for more values to be read in
  sem_wait(&fullCount);
  int indexRtn = indexCount;
  indexCount++;
  sem_post(&lockIndex);
  sem_post(&emptyCount);
  return indexRtn;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // The max sum found in ranges
  int maxSum = 0;
  // The starting index for the worker
  int startIndex = getWork();
  //While getWork isn't returning sentinal values
  while (startIndex != -1) {
    // Keeps track of the current sum of the range
    int totalSum = 0;

    // For each k get the sum of the range from startIndex to 0
    for (int k = 0; k <= startIndex; k++) {
        
        // Add the value at the index to the range
        // Lock access to vList
        sem_wait(&lock);
        totalSum += vList[startIndex - k];
        sem_post(&lock);
        
        // If the current sum range is bigger than the max sum
        // make that the new max sum range
        if (totalSum > maxSum) {
            maxSum = totalSum;
        }
    }
    // Wait or get more work
    startIndex = getWork();
  }
  // If the report flag is true, report the max sum found by the worker
  if (report == true) {
    printf("I'm thread %lu.The maximum sum I found is: %d\n", pthread_self(), maxSum);
  } 
  
  // Lock access to max_sum
  sem_wait(&lockMaxSum);
  if (maxSum > max_sum) {
    max_sum = maxSum;
  }
  sem_post(&lockMaxSum);

  return NULL;
} 

/**
 * @brief The main program.
 * 
 * @param argc The number of arguments
 * @param argv The list of arguments
 * @return returns 0 if executed correctlu
 */
int main( int argc, char *argv[] ) {
  // Initalize the semaphores.
  sem_init(&emptyCount, 0, MAX_VALUES);
  sem_init(&fullCount, 0, 0);  
  sem_init(&lock, 0, 1);
  sem_init(&lockMaxSum, 0, 1);
  sem_init(&lockIndex, 0, 1);
  
  // The number of workers
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  // Create the workers and give them a thread id
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( &worker[i], NULL, workerRoutine, NULL ) != 0 ) {
        fail( "Can't create a child thread\n" );
    }
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
      pthread_join( worker[i], NULL );
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  // Free the semaphores
  sem_destroy( &emptyCount );
  sem_destroy( &fullCount );
  sem_destroy( &lock );
  sem_destroy( &lockMaxSum );
  sem_destroy( &lockIndex );

  return EXIT_SUCCESS;
}