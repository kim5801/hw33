/**
 * @file lightsout.c
 * @author Christina Albores (ccalbore)
 * @brief  This program's job is to interpret a user command given in
 * the commandline arguments and make requested changes to the game board
 * stored in shared memory.
 * @date 2022-09-22
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <sys/ipc.h>
#include <semaphore.h>

//POSIX named semaphore to provide mutual exclusion
sem_t *gameSem;

/**
 * @brief Print out an error message and exit.
 * 
 * @param message the message to print
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief Prints out the game board
 * 
 * @param board the board to print
 */
void report(GameState* state)
{
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif
    // Print out the game board by row and column
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            char c = state->board[i][j];
            printf("%c", c);
            
        }
        printf("\n");
    }
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif
}

/**
 * @brief Updates the game board by performing the given move
 * 
 * @param board the board to update
 * @param row the row the move is on
 * @param col the column the move is on
 * @return status returns status
 */
bool move(GameState* state, int r, int c) 
{
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif
  // Return successful if moves are valid
  bool status = true;
  //Check the row and column values
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    #ifndef UNSAFE
      sem_post(gameSem);
    #endif
    return false;
  }

  // Toggles the on/off for row and col
  if (state->board[r][c] == '.') {
      state->board[r][c] = '*';
  } else {
      state->board[r][c] = '.';
  }

  // Toggles the on/off for row - 1 and col if possible
  if ((r - 1) >= 0) {
    if (state->board[(r - 1)][c] == '.') {
      state->board[(r - 1)][c] = '*';
    } else {
        state->board[(r - 1)][c] = '.';
    }
  }

  // Toggles the on/off for row + 1 and col if possible
  if ((r + 1) <= 4) {
    if (state->board[(r + 1)][c] == '.') {
      state->board[(r + 1)][c] = '*';
    } else {
        state->board[(r + 1)][c] = '.';
    }
  }

  // Toggles the on/off for row and col + 1 if possible
  if ((c + 1) <= 4) {
    if (state->board[r][(c + 1)] == '.') {
      state->board[r][(c + 1)] = '*';
    } else {
        state->board[r][(c + 1)] = '.';
    }
  }

  // Toggles the on/off for row and col - 1 if possible
  if ((c - 1) >= 0) {
    if (state->board[r][(c - 1)] == '.') {
      state->board[r][(c - 1)] = '*';
    } else {
        state->board[r][(c - 1)] = '.';
    }
  }
  // If move successfully made update old moves
  if (status == true) {
    // Update the last move row and column
    state->lastRow = r;
    state->lastCol = c;
    // Set the undoFlag to indicate that an undo has not been done
    state->undoFlag = 0;
  }
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif
  return status;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state )
{
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif
  // The last row accessed
  int r = state->lastRow;
   // The last column accessed
  int c = state->lastCol;

  // If the undo move has already been done return false
  if (state->undoFlag == 1) {
    #ifndef UNSAFE
      sem_post(gameSem);
    #endif
    return false;
  }
  //Check the row and column values
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    #ifndef UNSAFE
      sem_post(gameSem);
    #endif
    return false;
  }
  // Set status to true. Means move made successfully
  bool status = true;

  // Toggles the on/off for row and col
  if (state->board[r][c] == '.') {
      state->board[r][c] = '*';
  } else {
      state->board[r][c] = '.';
  }

  // Toggles the on/off for row - 1 and col if possible
  if ((r - 1) >= 0) {
    if (state->board[(r - 1)][c] == '.') {
      state->board[(r - 1)][c] = '*';
    } else {
        state->board[(r - 1)][c] = '.';
    }
  }

  // Toggles the on/off for row + 1 and col if possible
  if ((r + 1) <= 4) {
    if (state->board[(r + 1)][c] == '.') {
      state->board[(r + 1)][c] = '*';
    } else {
        state->board[(r + 1)][c] = '.';
    }
  }

  // Toggles the on/off for row and col + 1 if possible
  if ((c + 1) <= 4) {
    if (state->board[r][(c + 1)] == '.') {
      state->board[r][(c + 1)] = '*';
    } else {
        state->board[r][(c + 1)] = '.';
    }
  }

  // Toggles the on/off for row and col - 1 if possible
  if ((c - 1) >= 0) {
    if (state->board[r][(c - 1)] == '.') {
      state->board[r][(c - 1)] = '*';
    } else {
        state->board[r][(c - 1)] = '.';
    }
  }
  // If move successfully made update undoflag
  if (status == true) {
    // Set the undoFlag to indicate that an undo has been done
    state->undoFlag = 1;
  }

  #ifndef UNSAFE
    sem_post(gameSem);
  #endif
  return status;
}

/**
 * @brief After checking the board location, it just calls the move() function over and over.
 * 
 * @param state the game state used
 * @param n the number of times the move command is executed
 * @param r the row given
 * @param c the column given
 * @return true if test done successfully
 * @return false if not
 */
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    #ifndef UNSAFE
      sem_post(gameSem);
    #endif
    return false;
  }

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
      move( state, r, c );
  }
  return true;
}

/**
 * @brief Takes in arguments from command line for game commands,
 * executes them and messages back if they are successful or not.
 * 
 * @param argc the number of arguments
 * @param argv the list of arguments
 * @return int returns success
 */
int main( int argc, char *argv[] ) {

  // The GameState struct pointer
  GameState *gameState;

  // Personal key for shared memory
  key_t key;
  // Set the key with personal afs pathname
  key = ftok("/afs/unity.ncsu.edu/users/c/ccalbore", 'b');

  // Get the shared memory segment of one GameState struct
  int shmid = shmget(key, sizeof(GameState), 0);
  // Call fail if error
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Set the GameState pointer to the shared memory
  gameState = (GameState *) shmat(shmid, 0, 0);

  //sem_t *gameSem
  gameSem = sem_open("/ccalbore-lightsout-lock", 0);
  if (gameSem == SEM_FAILED) {
      fail( "Can't open semaphore" );
  }


  // If there are 4 arguments, that means its a move command
  if (argc == 4) {
    // Error checking. If the command is not move, print error
    if (strcmp(argv[1], "move") == 0) {
        // Get the int values for row and column
        int row = atoi(argv[2]);
        int col = atoi(argv[3]);

        // Update the game state with the valid move
        if (move(gameState, row, col) == false) {
          printf("error\n");
        } else {
          printf("success\n");
        }    
    } else {
      printf("error\n");
    }
  } else if (argc == 5) {
    // Error checking. If the command is not move, print error
    if (strcmp(argv[1], "test") == 0) {
        // Get the int values for n run times, row and column
        int n = atoi(argv[2]);
        int row = atoi(argv[3]);
        int col = atoi(argv[4]);

        // Update the game state with the valid  move
        if (test(gameState, n, row, col) == false) {
          printf("error\n");
        } else {
          printf("success\n");
        }    
    } else {
      printf("error\n");
    }
  } else if (argc == 2) {
    // If there are 2 arguments, that means its a report or undo command
    if (strcmp(argv[1], "report") == 0) {
      // Print the game board state
      report(gameState);
          
    } else if (strcmp(argv[1], "undo") == 0) {
      // Update the game board state with the previous moves
      // If the undoFlag is true, print an error
      if (undo(gameState) == false) {
          printf("error\n");
      } else {
        printf("success\n");
      }
    } else {
        printf("error\n");
    }
  } else {
      printf("error\n");
      exit(1);
  }

  // Release our reference to the shared memory segment.
  shmdt(gameState);
  sem_close(gameSem);
  return 0;
}