#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

//move command, r/row, c/column, checks valid r c and move with mutual exclusion semaphores
//gameState state is the lightsout board to move, flips lights above, below, to the left and right
//of row column coordinates, if on edge, it does not flip anything outside the board
//includes semaphore based mutual exclusion, also a test function and command for testing
bool move( GameState *state, int r, int c ){

    //opens semaphore, and gets the lock, custom ifndef for testing
#ifndef UNSAFE
    sem_t *lock = sem_open(LOCK, 0);
    if (lock == SEM_FAILED)
        fail("Can't open semaphore");
    sem_wait( lock );
#endif

    //initialization of variables
    GameState *board = state;
    int row = r;
    int column = c;

    //checks row col for validity
    if(row >= 0 && row <= 4 && column >= 0 && column <= 4){
        //flips middle
        if(board->board[row][column] == '*'){
            board->board[row][column] = '.';
        }
        else{
            board->board[row][column] = '*';
        }
        //flips top
        if(row - 1 >= 0){
            if(board->board[row - 1][column] == '*'){
                board->board[row - 1][column] = '.';
            }
            else{
                board->board[row - 1][column] = '*';
            }
        }
        //flips left
        if(column - 1 >= 0){
            if(board->board[row][column - 1] == '*'){
                board->board[row][column - 1] = '.';
            }
            else{
                board->board[row][column - 1] = '*';
            }
        }
        //flips bottom
        if(row + 1 <= 4){
            if(board->board[row + 1][column] == '*'){
                board->board[row + 1][column] = '.';
            }
            else{
                board->board[row + 1][column] = '*';
            }
        }
        //flips right
        if(column + 1 <= 4){
            if(board->board[row][column + 1] == '*'){
                board->board[row][column + 1] = '.';
            }
            else{
                board->board[row][column + 1] = '*';
            }
        }
        // enables undo after a move
        if(board->ableToUndo != 'y'){
            board->ableToUndo = 'y';
        }
        board->lastMoveRow = row;
        board->lastMoveColumn = column;

        //frees the lock, custom ifndef for testing
#ifndef UNSAFE
        sem_post( lock );
#endif
        return true;
    }
    else{
        //frees the lock, custom ifndef for testing
#ifndef UNSAFE
        sem_post( lock );
#endif
        return false;
    }
}
bool undo( GameState *state ){

    //opens semaphore, and gets the lock, custom ifndef for testing
#ifndef UNSAFE
    sem_t *lock = sem_open(LOCK, 0);
    if (lock == SEM_FAILED)
        fail("Can't open semaphore");
    sem_wait( lock );
#endif

    //gamestate initialization
    GameState *board = state;

    //checks for able to undo condition
    if(board->ableToUndo == 'y'){

        //sets variables for undo, and change undo to no
        board->ableToUndo = 'n';
        int lastMoveRow = board->lastMoveRow;
        int lastMoveColumn = board->lastMoveColumn;
        //does an undo by moving the row/col from last move

        //flips middle
        if(board->board[lastMoveRow][lastMoveColumn] == '*'){
            board->board[lastMoveRow][lastMoveColumn] = '.';
        }
        else{
            board->board[lastMoveRow][lastMoveColumn] = '*';
        }

        //flips top
        if(lastMoveRow - 1 >= 0){
            if(board->board[lastMoveRow - 1][lastMoveColumn] == '*'){
                board->board[lastMoveRow - 1][lastMoveColumn] = '.';
            }
            else{
                board->board[lastMoveRow - 1][lastMoveColumn] = '*';
            }
        }
        //flips left
        if(lastMoveColumn - 1 >= 0){
            if(board->board[lastMoveRow][lastMoveColumn - 1] == '*'){
                board->board[lastMoveRow][lastMoveColumn - 1] = '.';
            }
            else{
                board->board[lastMoveRow][lastMoveColumn - 1] = '*';
            }
        }
        //flips bottom
        if(lastMoveRow + 1 <= 4){
            if(board->board[lastMoveRow + 1][lastMoveColumn] == '*'){
                board->board[lastMoveRow + 1][lastMoveColumn] = '.';
            }
            else{
                board->board[lastMoveRow + 1][lastMoveColumn] = '*';
            }
        }
        //flips right
        if(lastMoveColumn + 1 <= 4){
            if(board->board[lastMoveRow][lastMoveColumn + 1] == '*'){
                board->board[lastMoveRow][lastMoveColumn + 1] = '.';
            }
            else{
                board->board[lastMoveRow][lastMoveColumn + 1] = '*';
            }
        }
        //frees the lock, custom ifndef for testing
#ifndef UNSAFE
        sem_post( lock );
#endif
        return true;
    }
    else{
        //frees the lock, custom ifndef for testing
#ifndef UNSAFE
        sem_post( lock );
#endif
        return false;
    }
}

//prints out the gamestate stored in shared memory
void report( GameState *state ){
    for(int i = 0; i < GRID_SIZE; i++){
        for(int j = 0; j < GRID_SIZE; j++){
            fprintf(stdout, "%c", state->board[i][j]);
        }
        fprintf(stdout, "\n");
    }
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );
    return true;
}

int main( int argc, char *argv[] ) {
    //uses unique generated key by path to home directory
    key_t key = ftok("/afs/unity.ncsu.edu/users/h/hqi5", 1);
    //key_t key = ftok("C:/Users/Hongwei Qi", 1);
    if(key == -1){
        fail("Cannot create ftok key");
    }

    // make a shared memory segment
    int shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);

    //casts the pointer to a gamestate
    GameState *board = (GameState *)shmat(shmid, 0, 0);
    if(board == (GameState *) -1){
        fail("Cannot map shared memory into address space");
    }

    //no board loaded = error
    if(board->flag != 1){
        fail("error");
    }

    //report command, just prints, no additional checks
    if(strcmp(argv[1], "report") == 0 && argc == 2){
        //prints the board
        report(board);
    }
    //move command, checks for the next two to be integers
    else if(strcmp(argv[1], "move") == 0 && argc == 4){

        //assign row and col to variables
        char *rowSC= argv[2];
        char *columnSC = argv[3];

        //checks valid row/col
        if(strcmp(rowSC, "0") == 0 || strcmp(rowSC, "1") == 0 ||
                strcmp(rowSC, "2") == 0 || strcmp(rowSC, "3") == 0
                || strcmp(rowSC, "4") == 0){
            //do nothing
        }
        else{
            fail("error");
        }

        //initializing varibles
        char rowS = rowSC[0];
        char columnS = columnSC[0];
        int row = rowS - '0';
        int column = columnS - '0';

        //delegates to move function
        bool result = move(board, row, column);
        if(result){
            printf("success\n");
        }
        else{
            fail("error");
        }

    }

    //undo command, checks for ableToUndo
    else if(strcmp(argv[1], "undo") == 0 && argc == 2){
        //delegates to undo function
        bool result = undo(board);

        if(result){
            printf("success\n");
        }
        else{
            fail("error");
        }
    }
    //test command for testing, delegates to test function
    else if(strcmp(argv[1], "test") == 0 && argc == 5){
        //assign row and col to variables
        char *number = argv[2];
        int numberInt = atoi(number);
        char *rowSC= argv[3];
        char *columnSC = argv[4];

        //checks for row col validity
        if(strcmp(rowSC, "0") == 0 || strcmp(rowSC, "1") == 0 ||
           strcmp(rowSC, "2") == 0 || strcmp(rowSC, "3") == 0
           || strcmp(rowSC, "4") == 0){
            //do nothing
        }
        else{
            fail("error");
        }

        //initializing variables
        char rowS = rowSC[0];
        char columnS = columnSC[0];
        int row = rowS - '0';
        int column = columnS - '0';

        //delegates to test function
        test(board, numberInt, row, column);
    }
    else{
        fail("error");
    }
    return 0;
}
