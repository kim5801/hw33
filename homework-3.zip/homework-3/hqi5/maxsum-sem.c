#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
    printf( "usage: maxsum-sem <workers>\n" );
    printf( "       maxsum-sem <workers> report\n" );
    exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;
bool readDone = false;
// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Current index of values calculated so far.
int doneCount = 0;

// number of times the threads has run a calculation, includes exit ones
int indexDone = 0;

//circular buffer variables and semaphores
#define BUFFER_SIZE 10
int buffer[BUFFER_SIZE];
sem_t full;
sem_t empty;
sem_t lock;
int first = 0;
int num = 0;

//lock for global variable
sem_t total;

// Read the list of values.
void readList() {
    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Make sure we have enough room, then store the latest input.
        if ( vCount > MAX_VALUES )
            fail( "Too many input values" );

        // Store the latest value.
        vList[ vCount++ ] = v;
    }
}

/** getWork function that gets the index and blocks using circular buffer */
void *getWork(void *arg) {
    int workerNum = *(int *) arg;
    while (1) {
        //case 1, has not assigned all the index to workers yet
        //puts index into buffer and sizes count variables
        if (doneCount < vCount) {
            sem_wait(&empty);
            sem_wait(&lock);
            buffer[(first + num) % BUFFER_SIZE] = doneCount++;
            num++;
            sem_post(&lock);
            sem_post(&full);
        }
        //case 2, everything has been assigned to workers, exit function
        //allows this producer thread to put -2/exit number to buffer workerNum amount of times
        //in order to kill workers once they are done
        else if (doneCount == vCount && readDone) {
            while(doneCount + workerNum != indexDone){
                sem_wait(&empty);
                sem_wait(&lock);
                buffer[(first + num) % BUFFER_SIZE] = -2;
                num++;
                sem_post(&lock);
                sem_post(&full);
            }
            //printf("I'm thread producer and i have exited\n");
            break;
        }
        //case 3, workers have did every job, but not finished reading, try producing again
        else {
            continue;
        }
    }
    return NULL;
}


/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
    //initializing local variables
    int totalSum = 0;
    int indexResponsible = -1;

    //gets an index from the producer buffer, and works on it
    while( 1 ){

        //gets an index from the producer buffer, and assign to indexResponsible
        //using circular buffer techniques
        sem_wait(&full);
        sem_wait(&lock);
        indexResponsible = buffer[first];
        first = (first + 1) % BUFFER_SIZE;
        num--;
        sem_post(&lock);
        sem_post(&empty);

        //-2 is the exit index, performs the exit function and print max sum if report is enabled
        if(indexResponsible == -2){
            //locks and see if local is bigger than everyone elses sum, if true then local becomes new sum
            sem_wait(&total);
            if(totalSum > max_sum) {
                max_sum = totalSum;
            }
            indexDone++;
            sem_post(&total);
            //report option, prints the local sum and thread id
            if(report){
                printf("I'm thread %ld. The maximum sum I found is %d.\n", pthread_self(), totalSum);
            }
            break;
        }
        //keep waiting
        else if(indexResponsible == -1){
            continue;
        }
        //performs calculation
        else{
            //initializing local variables
            int localSum = 0;
            //for loop to add to sum from 0 to indexResponsible, checks every time for bigger local sum
            for(int a = 0; a < indexResponsible; a++) {
                int index = a;
                localSum += vList[index];
                if(localSum > totalSum) {
                    totalSum = localSum;
                }
                index++;
            }
            //for loop to subtract from sum from 0 to indexResponsible, checks every time for bigger local sum
            for(int a = 0; a < indexResponsible; a++) {
                int index = a;
                localSum -= vList[index];
                if(localSum > totalSum) {
                    totalSum = localSum;
                }
                index++;
            }
            //aquire a lock for global variable
            sem_wait(&total);
            indexDone++;
            sem_post(&total);
        }
    }
    return NULL;
}


int main( int argc, char *argv[] ) {
    int workers = 4;

    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();

    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
         workers < 1 )
        usage();

    // If there's a second argument, it better be "report"
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 )
            usage();
        report = true;
    }

    //initializing semaphores for circular buffer, and an extra lock for global variables
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);
    sem_init(&lock, 0, 1);

    sem_init(&total, 0, 1);

    // Make each of the workers and producer thread
    pthread_t worker[ workers ];
    pthread_t producer;
    for ( int i = 0; i < workers; i++ ){
        if(pthread_create( &worker[i], NULL, workerRoutine, NULL) != 0)
            fail("Can't create a new thread\n");
        if(i == 0){
            if(pthread_create( &producer, NULL, getWork, (void *) &workers) != 0)
                fail("Can't create producer thread\n");
        }
    }

    // Then, start getting work for them to do.
    readList();
    readDone = true;

    // Wait until all the workers and producer to finish
    for ( int i = 0; i < workers; i++ ){
        pthread_join(worker[i], NULL);
        if(i == 0){
            pthread_join(producer, NULL);
        }
    }

    // Report the max product and release the semaphores.
    printf( "Maximum Sum: %d\n", max_sum );

    //destroy all the semaphores
    sem_destroy(&full);
    sem_destroy(&empty);
    sem_destroy(&lock);
    sem_destroy(&total);

    return EXIT_SUCCESS;
}
