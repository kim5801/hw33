// Height and width of the playing area.
#define GRID_SIZE 5

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

//semaphore lock name
#define LOCK "/hqi5-lightsout-lock"

//GameState struct contains a 2d array that is representative of the board
//and a flag int to synchronize busy waiting for reader and writer
typedef struct GameState {
    int board[5][5];
    int flag;
    char ableToUndo;
    int lastMoveRow;
    int lastMoveColumn;
} GameState;