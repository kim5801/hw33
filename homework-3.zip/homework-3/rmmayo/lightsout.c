#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <errno.h>
#include <string.h>
#include "common.h"

sem_t *gameSem;//Pointer to the named semaphore

// Quick check to make sure the given string is a one digit num.
bool isNum(char *str)
{
  if (strlen(str) > 1)
  {
    return false;
  }
  return str[0] >= 48 || str[0] <= 57;
}

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}
//Perform the "move action"
static bool move(GameState *instance, int val1, int val2)
{
#ifndef UNSAFE
  sem_wait(gameSem);
#endif
  if (val1 > 4 || val1 < 0)
  {
    return 0;
  } // If they're greater than 5 or less than 0, they aren't valid.
  if (val2 > 4 || val2 < 0)
  {
    return 0;
  }

  val1++;
  val2++;

  memmove(instance->prevGrid, instance->grid, sizeof(instance->grid)); // Copy the current state of the board to the previous state
  instance->undo = true;

  // Switch the specified lights
  instance->grid[val1][val2] = !(instance->grid[val1][val2]);
  instance->grid[val1 + 1][val2] = !(instance->grid[val1 + 1][val2]);
  instance->grid[val1 - 1][val2] = !(instance->grid[val1 - 1][val2]);
  instance->grid[val1][val2 + 1] = !(instance->grid[val1][val2 + 1]);
  instance->grid[val1][val2 - 1] = !(instance->grid[val1][val2 - 1]);
#ifndef UNSAFE
  sem_post(gameSem);
#endif
  return true;
}

//perform the undo action
static bool undo(GameState *instance)
{
#ifndef UNSAFE
  sem_wait(gameSem);
#endif
  if (!instance->undo)
  { // If a "move" has not been called since the last undo, invalid command.
    sem_post(gameSem);
    return false;
  }

  instance->undo = false;
  memmove(instance->grid, instance->prevGrid, sizeof(instance->grid)); // Copy the memory from the previous state to the current state
#ifndef UNSAFE
  sem_post(gameSem);
#endif
  return true;
}

// Test interface, for quickly making a given move over and over.
bool test(GameState *state, int n, int r, int c)
{
  // Make sure the row / colunn is valid.
  if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
    return false;
  // Make the same move a bunch of times.
  for (int i = 0; i < n; i++)
    move(state, r, c);
  return true;
}
//Print the state of the board
static void report(GameState *instance)
{
#ifndef UNSAFE
  sem_wait(gameSem);
#endif
  for (int i = 1; i < GRID_SIZE + 1; i++)
  {
    for (int j = 1; j < GRID_SIZE + 1; j++)
    {
      if (instance->grid[i][j])
      {
        putchar('*');
      }
      else
      {
        putchar('.');
      }
    }
    putchar('\n');
  }
#ifndef UNSAFE
  sem_post(gameSem);
#endif
}

int main(int argc, char *argv[])
{

  if (argc < 2)
  { // before trying anything, double check there are arguments
    fail("error");
  }

  key_t key = ftok(HOME_PATH, PATH_ID); // Access the shared memory
  int shmid = shmget(key, sizeof(GameState), 0);
  GameState *instance = (GameState *)shmat(shmid, 0, 0);

  gameSem = sem_open("/rmmayo-lightsout-lock", 0);
  if (gameSem == SEM_FAILED)
    fail("Can't open game semaphore");

  if (strcmp(argv[1], "move") == 0)
  { // If the command was move, perform the process.
    if (argc != 4 || strlen(argv[2]) != 1 || strlen(argv[3]) != 1)
    {
      fail("error\n");
    }

    if (!isNum(argv[2]) || !isNum(argv[3]))
    { // Make sure that the args for move are single digit numbers
      fail("error\n");
    }

    int val1 = atoi(argv[2]); // Find their values
    int val2 = atoi(argv[3]);

    if (!move(instance, val1, val2))
    {
      fail("error\n");
    }

    printf("success\n");
  }

  else if (strcmp(argv[1], "report") == 0)
  { // Print the current state of the board
    report(instance);
  }
  else if (strcmp(argv[1], "undo") == 0)
  {
    if (!undo(instance))
    {
      fail("error\n");
    }
    printf("success\n");
  }

  else if (strcmp(argv[1], "test") == 0)
  {

    if (argc != 5 || strlen(argv[3]) != 1 || strlen(argv[4]) != 1)
    {
      fail("error2\n");
    }

    if (!isNum(argv[3]) || !isNum(argv[4]))
    { // Make sure that the args for move are single digit numbers
      fail("error3\n");
    }

    int val1 = atoi(argv[3]); // Find their values
    int val2 = atoi(argv[4]);
    int testN = atoi(argv[2]);
    if (testN == 0)
    {
      fail("error4\n");
    }

    if (!test(instance, testN, val1, val2))
      fail("error\n");
  }

  else
  {
    fail("error5\n");
  }

  return 0;
}
