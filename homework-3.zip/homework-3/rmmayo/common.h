// Height and width of the playing area.
#define GRID_SIZE 5
#define HOME_PATH "/afs/unity.ncsu.edu/users/r/rmmayo"
#define PATH_ID 'R'

typedef struct
{ // The GameState struct. The board is a grid of booleans representing on and off lights
  //The board has padding to simplify the "move" command
  bool grid[GRID_SIZE + 2][GRID_SIZE + 2];
  bool prevGrid[GRID_SIZE + 2][GRID_SIZE + 2];
  bool undo;
} GameState;