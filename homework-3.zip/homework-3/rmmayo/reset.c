#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Print out a usage message and exit.
static void usage()
{
  fprintf(stderr, "usage: reset <board-file>\n");
  exit(1);
}

int main(int argc, char *argv[])
{
  if (argc != 2)
  { // Check for the correct number of args
    usage();
  }

  key_t key = ftok(HOME_PATH, PATH_ID); // Create or reset the shared memory
  int shmid = shmget(key, sizeof(GameState), 0600 | IPC_CREAT);

  if (sem_open("/rmmayo-lightsout-lock", O_CREAT, 0600, 1) == SEM_FAILED)
  {
    fail("Can't open game semaphore");
  }

  GameState *instance = (GameState *)shmat(shmid, 0, 0); // Get the pointer to the GameState

  for (int i = 0; i < GRID_SIZE + 2; i++)
  { // Fill the board with false, all lights are off
    for (int j = 0; j < GRID_SIZE + 2; j++)
    {
      instance->grid[i][j] = false;
      instance->prevGrid[i][j] = false;
    }
  }

  instance->undo = false;

  FILE *fp = fopen(argv[1], "r"); // open the specified file.
  if (fp == NULL)
  {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  char c = 0; // Read the file and copy it to the GameState
  for (int i = 1; i < GRID_SIZE + 1; i++)
  {
    for (int j = 1; j < GRID_SIZE + 1; j++)
    {
      c = fgetc(fp);
      if (!(c == '.' || c == '*' || c == '\n'))
      { // If the currect character is invalid
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
      }
      instance->grid[i][j] = (c == '*');
      instance->prevGrid[i][j] = (c == '*');
    }
    c = fgetc(fp); // Eat the newline character
  }

  fclose(fp);

  return 0;
}
