#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message)
{
	fprintf(stderr, "%s\n", message);
	exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
	printf("usage: maxsum-sem <workers>\n");
	printf("       maxsum-sem <workers> report\n");
	exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

int workers = 4;

sem_t workLock;	 // lock from getWork
sem_t inputLock; // Wait for new
sem_t maxLock;	 // Lock to set the new overall maximum

bool doneFlag = false;

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList()
{
	// Keep reading as many values as we can.
	int v;

	while (scanf("%d", &v) == 1)
	{

		// Make sure we have enough room, then store the latest input.
		if (vCount > MAX_VALUES)
			fail("Too many input values");

		// Store the latest value.
		vList[vCount++] = v;

		sem_post(&inputLock);
	}

	for (int i = 0; i < workers; i++)
	{ // Make sure all the threads are released after all the input is read
		sem_post(&inputLock);
	}
}

int index = 0;//Index shared among threads to get their starting position from

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{

	// ...
	int localMax = INT_MIN;
	int task;//This threads current position to start from

	while (true)
	{

		sem_wait(&inputLock); // Wait for more input
		sem_wait(&workLock);  // index is being modified, so wait for it to be available
		index++;

		if (index > vCount)
		{
			if (!doneFlag)
				doneFlag = true;
		}
		task = index;
		sem_post(&workLock);

		int sum = 0;

		for (int j = task; j >= 0; j--) // Perform the maxsum algo backwards
		{

			sum = sum + vList[j];
			if (sum > localMax)
			{
				localMax = sum;
			}
		}
		if (doneFlag)
		{ // All input is read and there isnt any more work
			break;
		}
	}

	if (report)
	{
		printf("I'm thread %d, the max I found is %d\n", (int)pthread_self(), localMax);
	}

	sem_wait(&maxLock); // Set the overall max

	if (localMax > max_sum)
	{
		max_sum = localMax;
	}

	sem_post(&maxLock);

	return NULL;
}

int main(int argc, char *argv[])
{

	sem_init(&workLock, false, 1);
	sem_init(&inputLock, false, 0);
	sem_init(&maxLock, false, 1);

	// Parse command-line arguments.
	if (argc < 2 || argc > 3)
		usage();

	if (sscanf(argv[1], "%d", &workers) != 1 ||
		workers < 1)
		usage();

	// If there's a second argument, it better be "report"
	if (argc == 3)
	{
		if (strcmp(argv[2], "report") != 0)
			usage();
		report = true;
	}

	// Make each of the workers.
	pthread_t worker[workers];
	for (int i = 0; i < workers; i++)
		pthread_create(&worker[i], NULL, workerRoutine, NULL);
	// ...

	// Then, start getting work for them to do.
	readList();

	// Wait until all the workers finish.
	for (int i = 0; i < workers; i++)
	{
		pthread_join(worker[i], NULL);
	}
	// ...

	sem_close(&workLock);
	sem_close(&inputLock);
	sem_close(&maxLock);

	// Report the max product and release the semaphores.
	printf("Maximum Sum: %d\n", max_sum);

	return EXIT_SUCCESS;
}
