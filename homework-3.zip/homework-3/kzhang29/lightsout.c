#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// shared semaphore
sem_t *smphore;

/**
 * @brief Writes the second 2d array's content into the first 2d array
 *
 * @param oldGrid the 2d array being written over
 * @param newGrid the 2d array copied
 */
static void saveGrid(char oldGrid[5][5], char newGrid[5][5])
{
#ifndef UNSAFE
  sem_wait(smphore);
#endif
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      oldGrid[i][j] = newGrid[i][j];
    }
  }
#ifndef UNSAFE
  sem_post(smphore);
#endif
}

/**
 * @brief Make a move at the given row, column location, returning true
 * if successful.
 *
 * @param state the board where data is stored
 * @param row the row
 * @param col the column
 * @return true if able to move
 * @return false otherwise
 */
bool move(struct board *board1, int row, int col)
{
  // bounds check if the move is valid
  if ((row < 0 || row > 4) || (col < 0 || col > 4))
  {
    return false;
  }
  // save current grid and set previous = 1
  saveGrid(board1->previousBoard, board1->currentBoard);
  board1->hasPrevious = 1;
// now flipping the light switches
#ifndef UNSAFE
  sem_wait(smphore);
#endif
  if (board1->currentBoard[row][col] == '*')
  {
    board1->currentBoard[row][col] = '.';
  }
  else
  {
    board1->currentBoard[row][col] = '*';
  }
  if (row - 1 >= 0)
  {
    if (board1->currentBoard[row - 1][col] == '*')
    {
      board1->currentBoard[row - 1][col] = '.';
    }
    else
    {
      board1->currentBoard[row - 1][col] = '*';
    }
  }
  if (row + 1 < GRID_SIZE)
  {
    if (board1->currentBoard[row + 1][col] == '*')
    {
      board1->currentBoard[row + 1][col] = '.';
    }
    else
    {
      board1->currentBoard[row + 1][col] = '*';
    }
  }
  if (col - 1 >= 0)
  {
    if (board1->currentBoard[row][col - 1] == '*')
    {
      board1->currentBoard[row][col - 1] = '.';
    }
    else
    {
      board1->currentBoard[row][col - 1] = '*';
    }
  }
  if (col + 1 < GRID_SIZE)
  {
    if (board1->currentBoard[row][col + 1] == '*')
    {
      board1->currentBoard[row][col + 1] = '.';
    }
    else
    {
      board1->currentBoard[row][col + 1] = '*';
    }
  }
#ifndef UNSAFE
  sem_post(smphore);
#endif
  return true;
}

/**
 * @brief undo the most recent move, return true if successful
 *
 * @param state
 * @return true
 * @return false
 */
bool undo(struct board *state)
{
  if (state->hasPrevious == 1)
  {
    saveGrid(state->currentBoard, state->previousBoard);
    state->hasPrevious = 0;
    printf("success\n");
    return true;
  }
  return false;
}

/**
 * @brief reports the current state of the board
 *
 * @param state the struct where the state is stored
 */
void report(struct board *state)
{
#ifndef UNSAFE
  sem_wait(smphore);
#endif
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      printf("%c", state->currentBoard[i][j]);
    }
    printf("\n");
  }
#ifndef UNSAFE
  sem_post(smphore);
#endif
}

/**
 * @brief Test interface, for quickly making a given move over and over.
 *
 * @param state the board
 * @param n the number of times it gets ran
 * @param r row
 * @param c column
 */
bool test(struct board *state, int n, int r, int c)
{
  // Make sure the row / colunn is valid.
  if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
    return false;
  // Make the same move a bunch of times.
  for (int i = 0; i < n; i++)
    move(state, r, c);
  return true;
}

/**
 * @brief Receives and processes command from user
 *
 * @param argc the number of commands user gives
 * @param argv the arguments
 * @return int 0 if successful
 */
int main(int argc, char *argv[])
{
  // error checking
  if (argc != 2 && argc != 4 && argc != 5)
  {
    fail("usage: lightsout move r c| undo | report");
  }
  // retrieves the board from memory into address space
  struct board *board1;
  int shmid = shmget(ftok(PATH, 1), sizeof(board1), 0);
  board1 = (struct board *)shmat(shmid, 0, 0);
  // retrieves the shared semaphore
  smphore = sem_open(smName, 0);
  // matches each of the commands to a set of processes
  if (argc == 2 && strcmp(argv[1], "report") == 0)
  {
    report(board1);
  }
  else if (argc == 2 && strcmp(argv[1], "undo") == 0)
  {
    if (!undo(board1))
    {
      shmdt(board1);
      fail("error");
    }
  }
  else if (argc == 4 && strcmp(argv[1], "move") == 0)
  {
    int row = 0;
    int col = 0;
    if (sscanf(argv[2], "%d", &row) == 0 || sscanf(argv[3], "%d", &col) == 0)
    {
      // disconnect from the shared memory before exiting
      shmdt(board1);
      fail("error");
    }
    if (!move(board1, row, col))
    {
      shmdt(board1);
      fail("error");
    }
    printf("success\n");
  }
  else if (argc == 5 && strcmp(argv[1], "test") == 0)
  {
    int row = 0;
    int col = 0;
    int n = 0;
    if (sscanf(argv[2], "%d", &n) == 0 || sscanf(argv[3], "%d", &row) == 0 || sscanf(argv[4], "%d", &col) == 0)
    {
      // disconnect from the shared memory before exiting
      shmdt(board1);
      fail("error");
    }
    if (!test(board1, n, row, col))
    {
      shmdt(board1);
      fail("error");
    }
    printf("success\n");
  }
  else
  {
    shmdt(board1);
    fail("usage: lightsout move r c| undo | report");
  }
  shmdt(board1);

  return 0;
}
