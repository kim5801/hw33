#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
    printf("usage: maxsum-sem <workers>\n");
    printf("       maxsum-sem <workers> report\n");
    exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// if there are anymore inputs
bool moreInputs = true;

// Sempahore for number of new values that needs to be checked
sem_t number;
// Semaphore for locking the index
sem_t lock;
// Semaphore for locking max_sum
sem_t max;

// semaphore for locking vList
// sem_t vListLock;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// Current index checked up to
int indexx = 0;

/**
 * @brief checks if there is work available, returns the index if there is, else block
 *
 * @return int the index a worker checks up to
 */
static int getWork()
{
    int temp = 0;
    sem_wait(&number);
    sem_wait(&lock);
    if (indexx < vCount)
    {
        indexx += 1;
    }
    temp = indexx;
    sem_post(&lock);
    return temp;
}

// Read the list of values.
void readList()
{
    // Keep reading as many values as we can.
    int v;
    while (scanf("%d", &v) == 1)
    {
        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");

        // Store the latest value.
        vList[vCount++] = v;
        sem_post(&number);
    }
    // posting a dummy node into the array
    vList[vCount++] = INT_MIN;
    sem_post(&number);
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
    int localMax = INT_MIN;
    while (true)
    {
        int inde = getWork();
        if (vList[inde - 1] == INT_MIN)
        {
            break;
        }
        int current = 0;
        for (int i = inde - 1; i >= 0; i--)
        {
            current += vList[i];
            if (current > localMax)
            {
                localMax = current;
            }
        }
    }
    sem_wait(&max);
    if (localMax > max_sum)
    {
        max_sum = localMax;
    }
    sem_post(&max);
    if (report)
    {
        printf("%s%d%s%d%s\n", "I'm worker ", (int)pthread_self(), ". The maximum sum I found is ", localMax, ".");
    }
    sem_post(&number);
    return NULL;
}

/**
 * @brief finds the maximum contiguous sum
 *
 * @param argc number of arguments
 * @param argv the arguments
 * @return int  0 if succesful
 */
int main(int argc, char *argv[])
{
    int workers = 4;
    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 ||
        workers < 1)
        usage();

    // If there's a second argument, it better be "report"
    if (argc == 3)
    {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    // creating the sempaphores
    sem_init(&max, 0, 1);
    sem_init(&lock, 0, 1);
    sem_init(&number, 0, 0);
    // sem_init(&vListLock, 0, 1);

    // Make each of the workers.
    pthread_t worker[workers];
    int arr[workers];
    for (int i = 0; i < workers; i++)
    {
        arr[i] = i;
    }
    for (int i = 0; i < workers; i++)
    {
        if (pthread_create(worker + i, NULL, workerRoutine, arr + i) != 0)
            fail("Can't create a new thread\n");
    }

    // Then, start getting work for them to do.
    readList();

    // Wait until all the workers finish.
    for (int i = 0; i < workers; i++)
        pthread_join(worker[i], NULL);

    // Report the max product and release the semaphores.
    printf("Maximum Sum: %d\n", max_sum);

    sem_destroy(&max);
    sem_destroy(&lock);
    sem_destroy(&number);

    return EXIT_SUCCESS;
}
