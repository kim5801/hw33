// Height and width of the playing area.
#define GRID_SIZE 5

// the file path to use for ftok()
#define PATH "/desktop"

// name for shared semaphore
#define smName "/kzhang29-lightsout-lock"

// the board struct
struct board
{
  char previousBoard[GRID_SIZE][GRID_SIZE];
  char currentBoard[GRID_SIZE][GRID_SIZE];
  int hasPrevious;
};