/**
 * lightsout.c 
 * Homework 3 - Problem 3 - CSC 246
 * @author Ian Murray (iwmurray)
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <semaphore.h>
#include "common.h"

/** Semaphore used to lock access to game state. */
sem_t *semaphore;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Parse a string to an interger, with error checking.
 * Adapted from my Homework 1 problem 4 solution.
 * @return parsed interger, or -1 if error.
 */
int atoi_chk( char *str ) {
  char *ch = str;
  
  // Check for non digits
  while( *ch != '\0')
    if( isdigit(*ch) )
      ch++;
    else
      return -1;
  
  return atoi(str);
}

/**
 * Prints the current state of the game board.
 * @param state the current game state.
 */
void report( GameState *state ) {
  #ifndef UNSAFE
    sem_wait( semaphore );
  #endif

  for (size_t i = 0; i < GRID_SIZE; i++) {
    for (size_t j = 0; j < GRID_SIZE; j++) {
      printf(state->board[i][j] ? "*" : ".");
    }

    printf("\n");
  }

  #ifndef UNSAFE
    sem_post( semaphore );
  #endif
}

/**
 * Inverts a cell at the given row and column. Invalid arguments are ignored.
 * Adapted from my Homework 1 problem 4 solution.
 * @param state the current game state.
 * @param row the row to make a move at.
 * @param col the column to make a move at.
 */
void invert( GameState *state, int row, int col ) {
  // Check for invaild coordinates
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE)
    return;

  state->board[row][col] = !state->board[row][col];
}

/**
 * Makes a move at the given row and column.
 * Adapted from my Homework 1 problem 4 solution.
 * @param state the current game state.
 * @param row the row to make a move at.
 * @param col the column to make a move at.
 * @returns if successful
 */
bool move( GameState *state, int row, int col ) {
  #ifndef UNSAFE
    sem_wait( semaphore );
  #endif

  // Check for invaild coordinates
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE) {
    #ifndef UNSAFE
      sem_post( semaphore );
    #endif
    return false;
  }

  // Invert this cell and any adjacent cells, any invalid ones will be ignored.
  invert(state, row, col);
  invert(state, row-1, col);
  invert(state, row+1, col);
  invert(state, row, col-1);
  invert(state, row, col+1);

  // Clear the last move
  state->last_move_row = row;
  state->last_move_col = col;
  
  #ifndef UNSAFE
    sem_post( semaphore );
  #endif
  return true;
}

/**
 * Undos the last move.
 * @param state the current game state.
 * @returns if successful
 */
bool undo( GameState *state ) {
  #ifndef UNSAFE
    if( sem_wait( semaphore ) < 0)
      fail("Failed to wait on semaphore.");
  #endif

  // Check for invaild coordinates
  if(state->last_move_row < 0 || state->last_move_col < 0) {
    #ifndef UNSAFE
      sem_post( semaphore );
    #endif
    return false;
  }

  // Invert this cell and any adjacent cells, any invalid ones will be ignored.
  invert(state, state->last_move_row, state->last_move_col);
  invert(state, state->last_move_row-1, state->last_move_col);
  invert(state, state->last_move_row+1, state->last_move_col);
  invert(state, state->last_move_row, state->last_move_col-1);
  invert(state, state->last_move_row, state->last_move_col+1);

  // Clear the last move
  state->last_move_row = -1;
  state->last_move_col = -1;

  #ifndef UNSAFE
    sem_post( semaphore );
  #endif
  return true;
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );

  return true;
}

/**
 * Entrypoint of program.
 * @param argc count of arguments
 * @param argv array of arguments
 */
int main( int argc, char *argv[] ) {
  // Create shared memory
  int shmid = shmget( SHM_KEY, 0, 0 );
  if( shmid < 0)
    fail("Failed to create shared memory.");

  // Map shared memory
  struct game_state *state = (struct game_state *) shmat( shmid, 0, 0 );
  if(state == NULL)
    fail("Failed to map shared memory.");

  // Open semaphore
  semaphore = sem_open( SEM_NAME, 0 );
  if ( semaphore == SEM_FAILED )
    fail( "Can't open semaphore" );

  // Parse arguments and call respective function
  if( argc == 2 && strcmp(argv[1], "report") == 0)
    report(state);
  else if( argc == 2 && strcmp(argv[1], "undo") == 0) {
    if(!undo(state))
      fail("error");
  }
  else if( argc == 4 && strcmp(argv[1], "move") == 0) {
    int row = atoi_chk(argv[2]);
    int col = atoi_chk(argv[3]);

    if(!move(state, row, col))
      fail("error");
  } else if( argc == 5 && strcmp(argv[1], "test") == 0) {
    int num = atoi_chk(argv[2]);
    int row = atoi_chk(argv[3]);
    int col = atoi_chk(argv[4]);

    if(!test(state, num, row, col))
      fail("error");
  } else
    fail("error"); // invalid argument 1 or count

  // Close the semaphore 
  sem_close( semaphore );

  return 0;
}
