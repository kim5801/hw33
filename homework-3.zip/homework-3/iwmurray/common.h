/**
 * common.h 
 * Homework 3 - Problem 3 - CSC 246
 * @author Ian Murray (iwmurray)
 */

// Height and width of the playing area.
#define GRID_SIZE 5

// The shared memory key to use for this project, 11731 is arbitrary. 
#define SHM_KEY ftok("/afs/unity.ncsu.edu/users/i/iwmurray", 11731 )

// The name of the named sephamore
#define SEM_NAME "/iwmurray-lightsout-lock"

// Struct that holds the game state, including board and last move
typedef struct game_state {
    // The game board itself, as 2D array of on and off
    bool board[GRID_SIZE][GRID_SIZE];

    // The last move made, row and column 
    int last_move_row;
    int last_move_col;
} GameState;
