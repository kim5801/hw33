// Height and width of the playing area.
#define GRID_SIZE 5

// Key for the shared memory segment
#define MEMORY_ID 1030

// Define a struct for a game so we can use external methods to do operations on the board
typedef struct {
  char board[5][5];

  int lastMoveCol;
  int lastMoveRow;

  bool undoOK;
} Game;