#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// Semaphore to wait for more work
sem_t workSem;

// Semaphore to prevent multiple workers from accessing the global max sum
sem_t sumSem;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Next index that needs to be checked
int nextWork;

// This semaphore only allows one thread at a time to be *in the process* of obtaining work
sem_t nextWorkSem;

// If all of the input has been read in
bool doneReading = false;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&workSem);
  }

}

// Returns the index that this worker is to be responsible for
int getWork() {

  // Check if there is still work to do
  if (doneReading && nextWork >= vCount) {
    // Free all waiting workers by freeing the worker behind this one, which frees the worker behind it, and so on
    sem_post(&workSem);
    return -1;
  }

  sem_wait(&nextWorkSem); // This semaphore only allows one worker to be in the process of obtaining work at at time
  sem_wait(&workSem); // This semaphore blocks threads until there is another index to process
  int assignedWork = nextWork; // Get the next index to check ranges to
  nextWork++; // This index has been given out; set it to the next work
  sem_post(&nextWorkSem); // Allow another worker to obtain work

  return assignedWork;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int currIdx = getWork();
  int workerMaxSum = vList[currIdx]; // Start the max at the first value this worker sees

  while (currIdx != -1) { // -1 is the chosen sentinel value saying that there is no more work
    int subRangeSum = 0; // 0 doesn't change the sum when added to
    // Process all ranges of values ending at currIdx
    for (int i = currIdx; i >= 0; i--) { // Start at the given index and check all ranges that end in that index
      subRangeSum += vList[i]; // Sum as we go; this sum resets for each range

      // If the new value makes the range sum larger than the worker's sum so far, update the worker's sum
      if (subRangeSum > workerMaxSum) {
        workerMaxSum = subRangeSum;
      }
    }

    currIdx = getWork(); // After finishing the previous range, ask for another
  }

  // Attempt to update the global max sum
  sem_wait(&sumSem); // Only allow one worker to update the max sum at a time
  if (workerMaxSum > max_sum) {
    max_sum = workerMaxSum;
  }
  sem_post(&sumSem);

  // Report the max sum if requested
  if (report) {
    printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), workerMaxSum);
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Init the semaphores
  sem_init(&workSem, false, 0);
  sem_init(&sumSem, false, 1);
  sem_init(&nextWorkSem, false, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, NULL);

  // Then, start getting work for them to do.
  readList();
  doneReading = true;
  // All workers might be waiting for another input, so wake one up just in case, even though it will wake up and immediately receive a sentinel
  sem_post(&workSem);

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
