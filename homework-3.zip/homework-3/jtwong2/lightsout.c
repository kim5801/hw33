#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Semaphore to only allow one thread at a time to access the game state
static sem_t *gameSem;

// Print out the command error message and exit
static void error() {
  printf("error\n");
  exit(1);
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Prints the board.
static void printGame(Game *g) {
  // Acquire the lock on the game struct
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif

  // Prints one cell at a time, starting from 0,0 (top left)
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      printf("%c", g->board[i][j]);
    }

    printf("\n");
  }

  // Release lock on the game struct
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif
}

// This method assumes that the move is valid
static bool makeMove(Game *g, int row, int col) {
  // Get the lock on the game struct
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif

  // Flip the light at the move's coordinates
  if (g->board[row][col] == '.') {
    g->board[row][col] = '*';
  } else { // Must be set to '*' currently
    g->board[row][col] = '.';
  }


  // Flip the light above the move's coordinates
  if (row + 1 <= 4) { // If there's another cell on the board above the move's coordinate
    if (g->board[row + 1][col] == '.') {
      g->board[row + 1][col] = '*';
    } else { // Must be set to '*' currently
      g->board[row + 1][col] = '.';
    }
  }

  // Flip the light below the move's coordinates
  if (row - 1 >= 0) { // If there's another cell on the board below the move's coordinate
    if (g->board[row - 1][col] == '.') {
      g->board[row - 1][col] = '*';
    } else { // Must be set to '*' currently
      g->board[row - 1][col] = '.';
    }
  }

  // Flip the light to the right of the move's coordinates
  if (col + 1 <= 4) { // If there's another cell on the board to the right of the move's coordinate
    if (g->board[row][col + 1] == '.') {
      g->board[row][col + 1] = '*';
    } else { // Must be set to '*' currently
      g->board[row][col + 1] = '.';
    }
  }

  // Flip the light to the left of the move's coordinates
  if (col - 1 >= 0) { // If there's another cell on the board to the left of the move's coordinate
    if (g->board[row][col - 1] == '.') {
      g->board[row][col - 1] = '*';
    } else { // Must be set to '*' currently
      g->board[row][col - 1] = '.';
    }
  }

  // Set the game's last move
  g->lastMoveRow = row;
  g->lastMoveCol = col;
  g->undoOK = true;

  // Finished editing the game struct, release it
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif

  // Return success or failure
  return true;
}

// Undo the most recent move, returning true if successful. This is the same code as in the move()
// function, since making the last move again is the same as undoing a move
bool undo( Game *g) {
  // Get the lock on the game struct
  #ifndef UNSAFE
    sem_wait(gameSem);
  #endif

  // Check if we are allowed to undo a move
  if (!g->undoOK) {
    #ifndef UNSAFE
      sem_post(gameSem);
    #endif
    return false;
  }

  // Get the row and col of the move to undo
  int row = g->lastMoveRow;
  int col = g->lastMoveCol;

  // Flip the light at the move's coordinates
  if (g->board[row][col] == '.') {
    g->board[row][col] = '*';
  } else { // Must be set to '*' currently
    g->board[row][col] = '.';
  }

  // Flip the light above the move's coordinates
  if (row + 1 <= 4) { // If there's another cell on the board above the move's coordinate
    if (g->board[row + 1][col] == '.') {
      g->board[row + 1][col] = '*';
    } else { // Must be set to '*' currently
      g->board[row + 1][col] = '.';
    }
  }

  // Flip the light below the move's coordinates
  if (row - 1 >= 0) { // If there's another cell on the board below the move's coordinate
    if (g->board[row - 1][col] == '.') {
      g->board[row - 1][col] = '*';
    } else { // Must be set to '*' currently
      g->board[row - 1][col] = '.';
    }
  }

  // Flip the light to the right of the move's coordinates
  if (col + 1 <= 4) { // If there's another cell on the board to the right of the move's coordinate
    if (g->board[row][col + 1] == '.') {
      g->board[row][col + 1] = '*';
    } else { // Must be set to '*' currently
      g->board[row][col + 1] = '.';
    }
  }

  // Flip the light to the left of the move's coordinates
  if (col - 1 >= 0) { // If there's another cell on the board to the left of the move's coordinate
    if (g->board[row][col - 1] == '.') {
      g->board[row][col - 1] = '*';
    } else { // Must be set to '*' currently
      g->board[row][col - 1] = '.';
    }
  }

  g->undoOK = false; // Since we just undid a move, we are not allowed to undo another move

  // Finished editing the game struct, release it
  #ifndef UNSAFE
    sem_post(gameSem);
  #endif

  // Return success
  return true;
}

// Test interface, for quickly making a given move over and over.
bool test( Game *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    makeMove( state, r, c );
  
  return true;
}

int main( int argc, char *argv[] ) {
  // Attach to the shared memory segment to access the game
  int memId = shmget(ftok("/afs/unity.ncsu.edu/users/j/jtwong2/", 0), 0, 0);

  // Get the semaphore
  gameSem = sem_open("/jtwong2-lightsout-lock", 0);
  if (gameSem == SEM_FAILED) {
    fail("Could not open game semaphore");
  }

  // Get the memory for the game
  if (memId == -1) {
    fail("Could not attach shared memory");
  }

  // Attach the shared memory so this program can access it
  Game *sharedGame = (Game*)shmat(memId, 0, 0);

  // Validate number of arguments
  if (argc < 2 || argc > 5) {
    error();
  }

  // Parse the command
  if (strcmp("move", argv[1]) == 0) {
    // Validate arguments for the move command
    if (argc != 4) {
      error();
    }

    // Make sure the arguments are integers between 0 and 4, inclusive
    if (argv[2][0] < '0' || argv[2][0] > '4' || argv[2][1] != '\0' || argv[3][0] < '0' || argv[3][0] > '4' || argv[3][1] != '\0') {
      error();
    }

    // Make the move on the shared board
    int col = argv[2][0] - '0';
    int row = argv[3][0] - '0';
    bool status = makeMove(sharedGame, col, row);

    // Print exit status of command
    if (status) {
      printf("success\n");
    } else {
      error();
    }
  } else if (strcmp("report", argv[1]) == 0) { // Handles the report command
    // Validate arguments for the report command
    if (argc != 2) {
      error();
    }

    // No need to print out any success/error message; just print out the board
    printGame(sharedGame);
  } else if (strcmp("undo", argv[1]) == 0) {
    // Validate arguments for the undo command
    if (argc != 2) {
      error();
    }

    // Undo the move
    bool status = undo(sharedGame);

    // Print the success message
    if (status) {
      printf("success\n");
    } else {
      error(); // Not allowed to undo twice in a row
    }
  } else if (strcmp("test", argv[1]) == 0) { // test command
    // Validate arguments for the test command, similar to the move command
    if (argc != 5) {
      error();
    }

    // Make sure the arguments are integers between 0 and 4, inclusive
    if (argv[3][0] < '0' || argv[3][0] > '4' || argv[3][1] != '\0' || argv[4][0] < '0' || argv[4][0] > '4' || argv[4][1] != '\0') {
      error();
    }

    // Parse the n argument and throw an error if it is not a valid integer
    int numRepeats = 0;
    for (int i = 0; i < strlen(argv[2]); i++) {
      if (argv[2][i] < '0' || argv[2][i] > '9') {
        error();
      } else {
        numRepeats *= 10;
        numRepeats += argv[2][i] - '0';
      }
    }

    // Parse the move instructions
    int col = argv[3][0] - '0';
    int row = argv[4][0] - '0';

    // Now perform the testing sequence, which is making numRepeats moves on the board
    test(sharedGame, numRepeats, col, row);

  } else {
    error(); // Must not have been a valid command, so error
  }

  shmdt(sharedGame); // This program no longer needs the shared memory (since it's about to terminate) so detach it
  return 0;
}
