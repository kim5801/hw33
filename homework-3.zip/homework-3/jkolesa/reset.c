/**
 * @file reset.c
 * @author Jonathan Kolesar (jkolesa)
 * This component contains the main function.
 * It reads in a given board text file to a shared memory segment
 * and initializes the game state semaphore.
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"


/**
 * A helper function that prints out the given error message
 * and terminates the program with a exit status of 1
 * 
 * @param message the given error message to print to standard error
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}


/**
 * This helper function prints the usage message
 * and exits with a status of 1.
 * 
 */
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}


/**
 * Start of program.
 * 
 * @param argc number of command line arguments.
 * @param argv list of pointers to the command line arguments.
 * @return int exit success if the user provides valid command line arguments. 
 *              Otherwise, exit failure.
 */
int main( int argc, char *argv[] ) {

  // Checks for the correct number of arguments.
  // It expects an argument for the board file name.
  if ( argc != 2 )
    usage();

  // Gets the key for the shared memory segment
  key_t key = ftok( "/afs/unity.ncsu.edu/users/j/jkolesa", 1 );

  // Make a shared memory segment of the GameBoard size
  int shmid = shmget( key, GAME_SIZE, 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  // Map the shared memory into my address space
  GameState *gameBoard = shmat( shmid, 0, 0 );
  if ( gameBoard == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  // Open a file for reading.
  int fd = open( argv[ 1 ], O_RDONLY );
  if ( fd < 0 ) {
    fprintf( stderr, "%s%s\n", "Invalid input file: ", argv[ 1 ] );
    exit( 1 );
  }

  // Creates an empty 2D char array to store the board in
  char board[ GRID_SIZE ][ GRID_SIZE ];

  // Reads in the board from the given text file and validates it
  char input[ 35 ];
  bool readSomething = false;
  int i = 0;
  while ( read( fd, &input[ i ], sizeof( char ) ) > 0 ) {
    // The input file is invalid if it contains characters other than '.', '*', or '\n'
    if ( input[ i ] != '.' && input[ i ] != '*' && input[ i ] != '\n' ) {
      fprintf( stderr, "%s%s\n", "Invalid input file: ", argv[ 1 ] );
      exit( 1 );
    }

    readSomething = true;
    if ( input[ i ] != '\n' ) {
      i++;
    }
  }

  input[ i ] = '\0';

  if ( !readSomething ) {
    fprintf( stderr, "%s%s\n", "Invalid input file: ", argv[ 1 ] );
    exit( 1 );
  }

  int pos = 0;
  for ( int j = 0; j < GRID_SIZE; j++ ) {
    for ( int k = 0; k < GRID_SIZE; k++ ) {
      board[ j ][ k ] = input[ pos ];
      pos++;
    }
  }

  // Puts the read in game board into the shared memory segment.
  for ( int j = 0; j < GRID_SIZE; j++ ) {
    for ( int k = 0; k < GRID_SIZE; k++ ) {
      gameBoard->board[ j ][ k ] = board[ j ][ k ];
    }
  }

  // Initializes the abitily to undo a move to disabled
  gameBoard->undo = false;

  // Release our reference to the shared memory segment.
  shmdt( gameBoard );

  // First, destroy any old copies the gamestate semaphore, just in case
  // a previous execution of this program crashed and left the
  // semaphore in an unknown state.
  sem_unlink( "/jkolesa-lightsout-lock" );

  // Make a named semaphore.  The tagSrc program uses the same name
  // when it calls sem_open, so it will get access to the same
  // semaphore (provided we're running on the same host).
  sem_t *useGameState = sem_open( "/jkolesa-lightsout-lock", O_CREAT, 0600, 1 );
  if ( useGameState == SEM_FAILED )
    fail( "Can't make tag semaphore" );

  // Close the semaphore and exit.
  sem_close( useGameState );

  // Tell the OS we no longer need the segment.
  //shmctl( shmid, IPC_RMID, 0 );
  
  return 0;
}
