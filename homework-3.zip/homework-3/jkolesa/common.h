// Height and width of the playing area.
#define GRID_SIZE 5
// Size of the shared block of memory is the size of the GameState struct
#define GAME_SIZE sizeof( GameState )

typedef struct
{
  int board[GRID_SIZE][GRID_SIZE];
  bool undo;
  int prevMov[2];
} GameState;
