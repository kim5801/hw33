/**
 * @file lightsout.c
 * @author Jonathan Kolesar (jkolesa)
 * This component contains the main function.
 * It reads in a game board from the shared memory segment and 
 * performs actions for the lights out game using command line arguements.
 * The actions modify the GameState stored in the shared memory segment. 
 * In addition, this version allows the enabling of semaphores for testing 
 * for race conditions when running two multiple lightsout.c programs cocurrently.
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/** Conversition multiplier for the string to integer converter function */
#define CONVERT_MULTIPLIER 10

// Declaration of the semaphore used to access the game state in shared memory.
sem_t *useGameState;

/**
 * A helper function that prints out the given error message
 * and terminates the program with a exit status of 1
 * 
 * @param message the given error message to print to standard error
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * A helper function to convert the given string to an integer.
 * 
 * @param statusStr number string to be validated as an integer
 * @return whether the given string was a valid integer
 */
int validateInt( char statusStr[] ) {
    // Length of the given string.
    int stringLen = strlen(statusStr);

    if (stringLen > 1 ) {
      return -1;
    }

    if ( statusStr[ 0 ] < '0' || statusStr[ 0 ] > '9' ) {
      return -1;
    } else {
      return 0;
    }
}



// Make a move at the given row, column location, returning true
// if successful.

/**
 * This function performs the move command with using the given pointer
 * to the game state in shared memory, and a row and a col int of the 
 * location in the board to execute the move command.
 * 
 * @param state pointer to the game state in shared memory
 * @param r int of the row to execute the move command at
 * @param c int of the col to execute the move command at
 * @return true if the move command is succesful
 * @return false if the move command fails
 */
bool move( GameState *state, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  
  // Perform the given move if the row / col is valid
  } else {

    #ifndef UNSAFE
      //printf( "Sem In Use\n" );
      sem_wait( useGameState );
    #endif

    //printf("Given: %d %d\n", row, col );
    if ( state->board[ r ][ c ] == '*' ) {
      state->board[ r ][ c ] = '.';
    } else {
      state->board[ r ][ c ] = '*';
    }

    int aboveRow = r - 1;
    int aboveCol = c;
    //printf("Above: %d %d\n", aboveRow, aboveCol );
    if ( aboveRow >= 0 ) {
      if ( state->board[ aboveRow ][ aboveCol ] == '*' ) {
        state->board[ aboveRow ][ aboveCol ] = '.';
      } else {
        state->board[ aboveRow ][ aboveCol ] = '*';
      }
    }

    int leftRow = r;
    int leftCol = c - 1;
    //printf("Left: %d %d\n", leftRow, leftCol );
    if ( leftCol >= 0 ) {
      if ( state->board[ leftRow ][ leftCol ] == '*' ) {
        state->board[ leftRow ][ leftCol ] = '.';
      } else {
        state->board[ leftRow ][ leftCol ] = '*';
      }
    }

    int rightRow = r;
    int rightCol = c + 1;
    //printf("Right: %d %d\n", rightRow, rightCol );
    if ( rightCol < GRID_SIZE ) {
      if ( state->board[ rightRow ][ rightCol ] == '*' ) {
        state->board[ rightRow ][ rightCol ] = '.';
      } else {
        state->board[ rightRow ][ rightCol ] = '*';
      }
    }

    int bellowRow = r + 1;
    int bellowCol = c;
    //printf("Bellow: %d %d\n", bellowRow, bellowCol );
    if ( bellowRow < GRID_SIZE ) {
      if ( state->board[ bellowRow ][ bellowCol ] == '*' ) {
        state->board[ bellowRow ][ bellowCol ] = '.';
      } else {
        state->board[ bellowRow ][ bellowCol ] = '*';
      }
    }

    // Remember to set undo to true in here
    state->undo = true;

    // Saves the previous move command
    state->prevMov[ 0 ] = r;
    state->prevMov[ 1 ] = c;

    #ifndef UNSAFE
      //printf( "Sem In Use\n" );
      sem_post( useGameState );
    #endif

    return true;
  }
}



// Undo the most recent move, returning true if successful.

/**
 * This function performs the undo command with using the given pointer
 * to the game state in shared memory.
 * 
 * @param state pointer to the game state in shared memory
 * @return true if the undo command is succesful
 * @return false if the undo command fails
 */
bool undo( GameState *state ) {
  #ifndef UNSAFE
    sem_wait( useGameState );
  #endif

  // Run the undo command
  if ( state->undo == true ) {
    // Sets the board back to the previous board state
    int r = state->prevMov[ 0 ];
    int c = state->prevMov[ 1 ];

    if ( state->board[ r ][ c ] == '*' ) {
      state->board[ r ][ c ] = '.';
    } else {
      state->board[ r ][ c ] = '*';
    }

    int aboveRow = r - 1;
    int aboveCol = c;
    if ( aboveRow >= 0 ) {
      if ( state->board[ aboveRow ][ aboveCol ] == '*' ) {
        state->board[ aboveRow ][ aboveCol ] = '.';
      } else {
        state->board[ aboveRow ][ aboveCol ] = '*';
      }
    }

    int leftRow = r;
    int leftCol = c - 1;
    if ( leftCol >= 0 ) {
      if ( state->board[ leftRow ][ leftCol ] == '*' ) {
        state->board[ leftRow ][ leftCol ] = '.';
      } else {
        state->board[ leftRow ][ leftCol ] = '*';
      }
    }

    int rightRow = r;
    int rightCol = c + 1;
    if ( rightCol < GRID_SIZE ) {
      if ( state->board[ rightRow ][ rightCol ] == '*' ) {
        state->board[ rightRow ][ rightCol ] = '.';
      } else {
        state->board[ rightRow ][ rightCol ] = '*';
      }
    }

    int bellowRow = r + 1;
    int bellowCol = c;
    if ( bellowRow < GRID_SIZE ) {
      if ( state->board[ bellowRow ][ bellowCol ] == '*' ) {
        state->board[ bellowRow ][ bellowCol ] = '.';
      } else {
        state->board[ bellowRow ][ bellowCol ] = '*';
      }
    }

    state->undo = false;

    #ifndef UNSAFE
      sem_post( useGameState );
    #endif

    return true;
  } else {
    #ifndef UNSAFE
      sem_post( useGameState );
    #endif

    return false;
  }
}



// Print the current state of the board.

/**
 * This function performs the report command with using the given pointer
 * to the game state in shared memory.
 * 
 * @param state pointer to the game state in shared memory
 * @return true if the undo command is succesful
 * @return false if the undo command fails
 */
void report( GameState *state ) {
  #ifndef UNSAFE
    //printf( "Sem In Use\n" );
    sem_wait( useGameState );
  #endif

  // Prints the current state of the game board.
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", state->board[ i ][ j ] );
      if ( j == 4 )
        printf( "\n" );
    }
  }

  #ifndef UNSAFE
    //printf( "Sem In Use\n" );
    sem_post( useGameState );
  #endif
}



// Test interface, for quickly making a given move over and over.

/**
 * This function performs the move command n number of times with using the 
 * given pointer to the game state in shared memory, and a row and a col int of the 
 * location in the board to execute the move command.
 * 
 * @param state pointer to the game state in shared memory
 * @param n int number of times to call the move command
 * @param r int of the row to execute the move command at
 * @param c int of the col to execute the move command at
 * @return true if the move command is succesful
 * @return false if the move command fails
 */
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;

  //printf("n = %d\n", n );

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );

  return true;
}



/**
 * Start of program.
 * 
 * @param argc number of command line arguments.
 * @param argv list of pointers to the command line arguments.
 * @return int exit success if the user provides valid command line arguments. 
 *              Otherwise, exit failure.
 */
int main( int argc, char *argv[] ) {

  // Gets the key for the shared memory segment
  key_t key = ftok( "/afs/unity.ncsu.edu/users/j/jkolesa", 1 );

  // Make a shared memory segment 1KB in size
  int shmid = shmget( key, GAME_SIZE, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  // Map the shared memory into my address space
  GameState *gameBoard = shmat( shmid, 0, 0 );
  if ( gameBoard == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );



  #ifndef UNSAFE
    // Make a named semaphore.  The tagSrc program uses the same name
    // when it calls sem_open, so it will get access to the same
    // semaphore (provided we're running on the same host).
    useGameState = sem_open( "/jkolesa-lightsout-lock", 1 );
    if ( useGameState == SEM_FAILED )
      fail( "Can't make tag semaphore" );
  #endif



  // Checks that the correct number of command line arguments are given by the user
  if ( argc < 2 || argc > 5 ) {
    fail( "error" );
  }

  // TEST
  if ( strcmp( argv[ 1 ], "test" ) == 0 ) {
    // Checks that there are 5 command line arugments
    if ( argc != 5 ) {
      fail( "error" );
    }

    // N
    // Checks that the given character is a digit
    // This argument should represent n, which is how many times the move command is to be ran as quickly as possible.
    if ( atoi( argv[ 2 ] ) == 0 ) {
      fail( "error" );
    }

    // ROW
    // Checks that the 4th argument is only one character long
    if ( strlen( argv[ 3 ] ) != 1 ) {
      fail( "error" );
    }
    // Checks that the given character is a digit
    if ( validateInt( argv[ 3 ] ) == -1 ) {
      fail( "error" );
    }

    // COL
    // Checks that the 5th argument is only one character long
    if ( strlen( argv[ 4 ] ) != 1 ) {
      fail( "error" );
    }
    // Checks that the given character is a digit
    if ( validateInt( argv[ 4 ] ) == -1 ) {
      fail( "error" );
    }

    int n = atoi( argv[ 2 ] );
    int row = *argv[ 3 ] - '0';
    int col = *argv[ 4 ] - '0';

    // Calls the test interface with the givens.
    bool isValidCommand = test( gameBoard, n, row, col );

    // Terminates the program successfully or unsuccessfully depending on whether the given command is valid.
    if ( isValidCommand ) {
      printf("success\n");
    } else {
      fail( "error" );
    }
  


  // Checks if 2nd command line argument is "move"
  } else if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    // Checks that there are 4 command line arugments
    if ( argc != 4 ) {
      fail( "error" );
    }

    // ROW
    // Checks that the 3rd argument is only one character long
    if ( strlen( argv[ 2 ] ) != 1 ) {
      fail( "error" );
    }
    // Checks that the given character is a digit
    if ( validateInt( argv[ 2 ] ) == -1 ) {
      fail( "error" );
    }

    // COL
    // Checks that the 4th argument is only one character long
    if ( strlen( argv[ 3 ] ) != 1 ) {
      fail( "error" );
    }
    if ( validateInt( argv[ 3 ] ) == -1 ) {
      fail( "error" );
    }

    int row = *argv[ 2 ] - '0';
    int col = *argv[ 3 ] - '0';

    // Calls the move() with the givens.
    bool isValidCommand = move( gameBoard, row, col );

    // Terminates the program successfully or unsuccessfully depending on whether the given command is valid.
    if ( isValidCommand ) {
      printf("success\n");
    } else {
      fail( "error" );
    }



  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    if ( argc != 2 ) {
      fail( "error" );
    }

    // Calls the undo() with the givens.
    bool isValidCommand = undo( gameBoard );

    // Terminates the program successfully or unsuccessfully depending on whether the given command is valid.
    if ( isValidCommand ) {
      printf("success\n");
    } else {
      fail( "error" );
    }



  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    if ( argc != 2 ) {
      fail( "error" );
    }

    // Calls the report() with the givens.
    report( gameBoard );



  } else {
    fail( "error" );
  }



  // Release our reference to the shared memory segment.
  shmdt( gameBoard );

  // Close the semaphore and exit.
  sem_close( useGameState );

  // Tell the OS we no longer need the segment. (DON'T DELETE SHARED MEMORY SEGMENT IN HERE)
  //shmctl( shmid, IPC_RMID, 0 );
  
  return 0;
}
