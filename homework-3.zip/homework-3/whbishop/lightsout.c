#include <sys/stat.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

//Constant used for the test, the grid size of the board
#define GRID_SIZE 5

//Global shared memory semaphore to communicate between reset and lightsout
sem_t *sharedSem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//Print out an error message, free the board, and exit unstuccessfully
static void error(GameState *g) {
    printf("error\n");
    shmdt(g);
    exit(1);
}

//Print out the success message, free the board, and exit successfully
static void success(GameState *g, char *s) {
    shmdt(g);
    printf("%s", s);
    exit(0);
}

//Replaces the board, got this from my last homework
static void replaceBoard(GameState *g) {
	for (int i = 0; i < 25; i++) g->oldBoard[i] = g->newBoard[i];
}

//Deprecated -> moved this to undo
/*
//Function to undo the board, got this from my last homework
static void undoBoard(GameState *g) {
	for (int i = 0; i < 25; i++) g->newBoard[i] = g->oldBoard[i];
}
*/

//Function to replace the character of the game, got this from my last homework
static void replaceChar(GameState *g, int index) {

    //If the char at index i is a * replace with ., and vice versa
	if (g->newBoard[index] == '*') g->newBoard[index] = '.';
	else if (g->newBoard[index] == '.') g->newBoard[index] = '*';
}

//Function that replaces the section that I used to have in main
//Takes in a gameState, rows, and columns
//returns true if it was successfully able to make the move, false if not
bool move( GameState *state, int r, int c) {

    //Macro that was given in the writeup
    #ifndef UNSAFE
        sem_wait( sharedSem );
    #endif
    replaceBoard(state);

    //This next portion is also taken from my server.c
    //Index into the rowes and columns
    int index = r*5 + c;
    if (c > 0 && c < 4) {
           
        //Replace the character for the index
        replaceChar(state, index);

        //Replace the character for the one above the index
        if (index - 5 >= 0) replaceChar(state, index - 5);

        //Replace the character for the one below the index
        if (index + 5 <= 24) replaceChar(state, index + 5);

        //Replace the character for the one to the left of the index
        if (index - 1 >= 0) replaceChar(state, index - 1);

        //Replace the character for the one to the right of the index
        if (index + 1 <= 24) replaceChar(state, index + 1);

    }

    //Special case if we want to replace the first column
    else if (c == 0) {

        //Replace the character for the index
        replaceChar(state, index);

        //Replace the character for the one above the index
        if (index - 5 >= 0) replaceChar(state, index - 5);\

        //replace the character for the one below the index
        if (index + 5 <= 24) replaceChar(state, index + 5);

        //Replace the character to the right of the index
        if (index + 1 <= 24) replaceChar(state, index + 1);
    }

    //Special case if we want to replace the last column
    else if (c == 4) {

    //Replace the character for the index
        replaceChar(state, index);

        //Replace the character above the index
        if (index - 5 >= 0) replaceChar(state, index - 5);

        //Replace the character below the index
        if (index + 5 <= 24) replaceChar(state, index + 5);

        //Replace the character to the left of the index
        if (index - 1 >= 0) replaceChar(state,index -1);
    }

    //Set the undo to 0, so we cannot undo
    state->undo = 0;

    //Macro that was given in the writeup
    #ifndef UNSAFE
        sem_post( sharedSem );
    #endif
    return true;
}

//Function that replaces our previous undo function
//Takes in a gameState and returns true if successful, false if not
bool undo( GameState* state) {

    //Macro that was given in the writeup
    #ifndef UNSAFE
        sem_wait( sharedSem );
    #endif
    //Get the current state of undo
    int i = state->undo;
    if (i == 0) {
        for (int i = 0; i < 25; i++) state->newBoard[i] = state->oldBoard[i];
        state->undo = 1;
        #ifndef UNSAFE
            sem_post( sharedSem );
        #endif
        return true;
    }

    //Macro that was given in the writeup
    #ifndef UNSAFE
        sem_post( sharedSem );
    #endif
    return false;
}

//Function that replaces our report report function 
//Takes in a gameState, returns nothing
void report( GameState* state) {

    //Macro that was given in the writeup
    #ifndef UNSAFE
        sem_wait( sharedSem );
    #endif

    int count = 0;
    //Loop through each character, and change the loop at every 6th, to print the new line
    for (int i = 0; i < 25; i++) {        
        /*
        if (count == 5) {
            printf("\n");
            reset = 0;
          
        }
        if (reset) {
            i--;
            count = 0;
            reset = 1;
            continue;
        }
        */
                
        //Print the new line logic
        if (count == 5) {
            count = 0;
            i--;
            printf("\n");
            continue;
        }

        //Increment count and print the character
        count++;
        printf("%c", state->newBoard[i]);
                
    }

    //Macro that was given in the writeup
    #ifndef UNSAFE
        sem_post( sharedSem );
    #endif

    //Send to shared mem and exit
    success(state, "\n");
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;

    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );

    return true;
}


//Main method for the program, accesses shared memory to do move, report, and undo 
//operations for the lightsout game
int main( int argc, char *argv[] ) {

    //Open our shared memory semaphore
    sharedSem = sem_open("/whbishop-lightsout-lock", 0);

    //Create the shared memory segment
    int shmid = shmget(ftok(unityID, 1), sizeof(GameState), 0666 | IPC_CREAT);
	if (shmid == -1) fail("Cannot create shared mem");
        
    //Map the shared memory
    GameState* currentGame = (GameState *)shmat(shmid, 0 ,0);
	if (currentGame == (GameState *)-1) fail("Can't map the shared memory into the address space");



    //If there are 2 command line args, the user wnats either report or udno
    if (argc == 2) {

        //To help if we want report

        //int reset = 1;

        //If it isn't report or undo, tell the user and exit
        if (strcmp("report", argv[1]) != 0 && strcmp("undo", argv[1]) != 0) error(currentGame);

        //If the user wants report, call our new report function
        if (!strcmp("report", argv[1])) {
            //printf("reached report");
            //exit(0);
            report(currentGame);           
        }

        //If the user wants undo
        if (!strcmp("undo", argv[1])) {


            //undo(currentGame);
            
            //printf("%d", i);

            //If we can undo, undo the board, and set undo to 1
            //Send to shared and exit
            
            //Call our new undo function
            if (undo(currentGame)) {
                success(currentGame, "success\n");
            }
            //Otherwise we cannot undo, let the user know and exit
            else {
                error(currentGame);
            }
        }
    }
    
    //If the user wants test, there better be 5 command line args
    else if (argc == 5) {
        
        //Firstly get the number of times to test
        int n = atoi(argv[2]);

        //Get the rows
        int r = argv[3][0] - 48;

        //Get the columns
        int c = argv[4][0] - 48;

        //Error handling 
        if (strlen(argv[4]) != 1 || strlen(argv[3]) != 1) error(currentGame);

        //Check if they said "test", if not, throw an error
        if (!strcmp("test", argv[1])) {
            if (test(currentGame, n, r, c)) exit(0);
        }
        else error(currentGame);
    }

    //This next part is just taken from my previous client.c
    //Check if the user wanted the move command
    else if (argc == 4) {
        if (strcmp("move", argv[1])) {
          printf("error\n");
          exit(1);
        }
    
        //Check to make sure the indicies of the rows columns are right
        if (argv[2][0] < '0' || argv[2][0] > '4') {
          printf("error\n");
          exit(1);
        }
        //Error handling
        if (argv[3][0] < '0' || argv[3][0] > '4') {
          printf("error\n");
          exit(1);
        }
    
        //Error handling
        if (strlen(argv[2]) > 1 || strlen(argv[3]) > 1) {
          printf("error\n");
          exit(1);
        }
        
        //set our row and columns
        char rows = argv[2][0] - 48;
        char columns = argv[3][0] - 48;

        //get the rows and the columns
        int r = rows;
        int c = columns;

        //Call the new move function
        if (move(currentGame, r, c)) {
            success(currentGame, "success\n");
        }

        else {
            error(currentGame);
        }

        //Replace the board with the new board
        /*
        //This next portion is also taken from my server.c
        //Index into the rowes and columns
        int index = rows*5 + columns;
        if (columns > 0 && columns < 4) {
            
            //Replace the character for the index
            replaceChar(currentGame, index);

            //Replace the character for the one above the index
            if (index - 5 >= 0) replaceChar(currentGame, index - 5);

            //Replace the character for the one below the index
            if (index + 5 <= 24) replaceChar(currentGame, index + 5);

            //Replace the character for the one to the left of the index
            if (index - 1 >= 0) replaceChar(currentGame, index - 1);

            //Replace the character for the one to the right of the index
            if (index + 1 <= 24) replaceChar(currentGame, index + 1);

        }

        //Special case if we want to replace the first column
        else if (columns == 0) {

            //Replace the character for the index
            replaceChar(currentGame, index);

            //Replace the character for the one above the index
            if (index - 5 >= 0) replaceChar(currentGame, index - 5);\

            //replace the character for the one below the index
            if (index + 5 <= 24) replaceChar(currentGame, index + 5);

            //Replace the character to the right of the index
            if (index + 1 <= 24) replaceChar(currentGame, index + 1);
        }

        //Special case if we want to replace the last column
        else if (columns == 4) {

        //Replace the character for the index
            replaceChar(currentGame, index);

            //Replace the character above the index
            if (index - 5 >= 0) replaceChar(currentGame, index - 5);

            //Replace the character below the index
            if (index + 5 <= 24) replaceChar(currentGame, index + 5);

            //Replace the character to the left of the index
            if (index - 1 >= 0) replaceChar(currentGame,index -1);
        }

        //Set the undo to 0, so we cannot undo
        currentGame->undo = 0;
        */
        //Send to shared mem, print, and exit
        //success(currentGame, "success\n");
        
    }

    //All other cases are errors, tell the user and exit
    else error(currentGame);


  //Return successfully
  return 0;
}
