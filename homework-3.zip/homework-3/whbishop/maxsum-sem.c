/**
 * Q2 for HW 3 CSC 246
 * File that computes the maximum sum of a given file using workers (threads) and semaphores
 * @author William Bishop 
 * 10/13/22 Original Version
 */

 //Got this from the piazza
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>

#include <sys/syscall.h>


#include <unistd.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

//First semaphore to check make sure that workers work with getWork.
sem_t syncronize;

//Second semaphore to make sure workers aren't accessing the max value at the same time.
sem_t workerSync;

//Final semaphore to make sure that no thread is accessing getwork at the same time.
sem_t getWorkSync;

//Flag to check if we are done reading the input file.
bool notDoneReading = true;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//Tells us what the next index to start checking the sum is.
int nextVal = 0;

//Function that gives us the index of the next number to start calculating the sum from
int getWork() {
    
    //If we are not done reading the input file, wait and then get the return the next value.
    if (notDoneReading) {
        //printf("NotDONEREADING"); 
        sem_wait(&syncronize);
        //printf("notDoneReadingWOPRIKES\n");
        
        
        return nextVal++;
    }

    //If we are done reading, and the next input is the final one, return a sentinal -1 to the worker
    //sem_wait(&sync);
    if (!notDoneReading && nextVal == vCount) {
        
        return -1;
    }

    //Otherwise return the next value
    else { 
        //printf("DONEREADING");
        sem_wait(&syncronize);
        //printf("DoneReadingWORKS\n");
        return nextVal++;
    }
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  //printf("READLIST\n");
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&syncronize);
  }
  notDoneReading = false;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
    //Wait to ensure each worker doens't access getwork at the same time.
    //sem_wait(&sync);
    sem_wait(&getWorkSync);
    int index = getWork();
    sem_post(&getWorkSync);
    //sem_post(&sync);
    //sem_post(&sync);
    //if (!notDoneReading) sem_post(&sync);

    //Define our worker variables
    int workerSum = INT_MIN;
    int workerMaxSum = INT_MIN;

    //While there are still values to work through
  while(index > -1) {
      
      //Logic to calculate the max sum, taken from my previous maxsum, except
      //this time we will count backwards from the index. We cannot count forwards since
      //we have no idea how long they will need to go.
      for (int i = index; i > 0; i--) {

          //If this is the first iteration, set the maxsum.
          if (i == index) workerSum = vList[i];
          else {
              //Otherwise add
              workerSum += vList[i];
          }
          
          //If our calculated sum is > our max sum, wait to ensure no worker accesses both, and change them.
          if (workerSum > max_sum) {

              sem_wait(&workerSync);
              max_sum = workerSum;
              workerMaxSum = workerSum;
              sem_post(&workerSync);
          }

          else if (workerSum > workerMaxSum) workerMaxSum = workerSum;
      }
      //Continue to get the indeces
      sem_wait(&getWorkSync);
      index = getWork();
      sem_post(&getWorkSync);
      //if (!notDoneReading) sem_post(&getWorkSync);
  }

  //Print out the thread's id if the user specifies
  if (report) printf("I'm process %lu. The maximum sum I found is %d.\n", pthread_self(), workerMaxSum);
  return NULL;
}


//Starting point for the program, initializes the semaphores.
int main( int argc, char *argv[] ) {
  int workers = 4;

  //Initialize our semaphores
  sem_init(&syncronize, 0, 0);
  sem_init(&workerSync, 0, 1);
  sem_init(&getWorkSync, 0, 1);
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
      if (pthread_create(&worker[i], NULL, workerRoutine, NULL) != 0) fail("Can't create child thread\n");
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
