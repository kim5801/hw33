// Height and width of the playing area.
#define GRID_SIZE 5

/**
 * Struct to hold our board, which maintains the old board, and 
 * the new board, as well as a flag to use in undo operations.
 */
typedef struct {
	char oldBoard[25];
	char newBoard[25];
	int undo;
} GameState;

//My unityID to be used with ftok()
#define unityID "/afs/unity.ncsu.edu/users/w/whbishop"