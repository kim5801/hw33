/**
 * @file maxsum-sem.c
 * @author Abhinav Pratap, aspratap
 *
 * find a contiguous non-empty subsequence within the sequence that has the largest sum.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum-sem <workers>\n");
  printf("       maxsum-sem <workers> report\n");
  exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// number of indexes to buffer
#define BUFFER_LENGTH 25000

// available index to work on
int availIndexes[BUFFER_LENGTH];
// number of elements in buffer
int num = 0;
// index of first element in buffer
int first = 0;

// semaphore to determine if a producer can put in an element
sem_t prod_avail;
// semaphore to determine a consumer can remove an element
sem_t cons_avail;
// semaphore to lock the buffer for reads or writes
sem_t buffer_lock;
// semaphore to lock the max_sum variable for reads or writes
sem_t max_sum_lock;

// Read the list of values.
void readList()
{
  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1)
  {
    // Make sure we have enough room, then store the latest input.
    if (vCount >= MAX_VALUES)
      fail("Too many input values");

    // Store the latest value.
    vList[vCount++] = v;

    sem_wait(&prod_avail);
    sem_wait(&buffer_lock);
    availIndexes[(first + num) % BUFFER_LENGTH] = vCount;
    num++;
    sem_post(&buffer_lock);
    sem_post(&cons_avail);
  }

  sem_wait(&prod_avail);
  sem_wait(&buffer_lock);
  availIndexes[(first + num) % BUFFER_LENGTH] = -1;
  num++;
  sem_post(&buffer_lock);
  sem_post(&cons_avail);
}

/**
 * Function for worker routine to call that gives the index to work on or -1 if no more work is to be done.
 */
int getWork()
{
  sem_wait(&cons_avail);
  int index;
  sem_wait(&buffer_lock);
  index = availIndexes[first];
  if (index != -1)
  {
    first = (first + 1) % BUFFER_LENGTH;
    num--;
  }
  sem_post(&buffer_lock);
  sem_post(&prod_avail);
  if (index == -1)
  {
    sem_post(&cons_avail);
  }

  return index;
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
  int index = getWork();

  while (index != -1)
  {
    int maxSum = vList[index];
    int sum = vList[index];

    for (int i = index - 1; i >= 0; i--)
    {
      sum += vList[i];
      if (sum > maxSum)
        maxSum = sum;
    }

    sem_wait(&max_sum_lock);
    if (maxSum > max_sum)
    {
      max_sum = maxSum;
    }
    sem_post(&max_sum_lock);

    if (report)
      printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), maxSum);

    index = getWork();
  }

  return NULL;
}

/**
 * starts maxsum-sem
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{
  int workers = 4;

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 ||
      workers < 1)
    usage();

  // If there's a second argument, it better be "report"
  if (argc == 3)
  {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  sem_init(&prod_avail, 0, BUFFER_LENGTH);
  sem_init(&cons_avail, 0, 0);
  sem_init(&buffer_lock, 0, 1);
  sem_init(&max_sum_lock, 0, 1);

  // Make each of the workers.
  pthread_t worker[workers];
  for (int i = 0; i < workers; i++)
  {
    if (pthread_create(&worker[i], NULL, workerRoutine, NULL) != 0)
      fail("Can't create thread");
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for (int i = 0; i < workers; i++)
  {
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf("Maximum Sum: %d\n", max_sum);

  sem_destroy(&prod_avail);
  sem_destroy(&cons_avail);
  sem_destroy(&buffer_lock);
  sem_destroy(&max_sum_lock);

  return EXIT_SUCCESS;
}
