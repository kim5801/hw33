/**
 * @author Abhinav Pratap, aspratap
 * @file lightsout.c
 * Start out a lights out game
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <sys/shm.h>
#include <semaphore.h>

// lock to use for mutual exclusion
sem_t *lock = NULL;

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stdout, "%s\n", message);
  exit(1);
}

/**
 * Prints the current grid in a formatted manner
 * @param state the current board state
 */
void printGrid(struct BoardState *state)
{
#ifndef UNSAFE
  sem_wait(lock);
#endif
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      printf("%c", state->currGrid[i][j]);
    }

    printf("\n");
  }

#ifndef UNSAFE
  sem_post(lock);
#endif
}

/**
 * Updates the prev game state so that it reflects the current game state.
 * Copies the current grid into the prev grid so that undos are possible.
 *
 * @param state the current board state
 */
void updatePrevBoard(struct BoardState *state)
{
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      state->prevGrid[i][j] = state->currGrid[i][j];
    }
  }
}

/**
 * flips the light at specific location of the board.
 * returns without making changes if invalid row and column is provided.
 * @param r row number
 * @param c column number
 * @param state the current board state
 */
void flip(int r, int c, struct BoardState *state)
{
  if (r > GRID_SIZE - 1 || r < 0 || c < 0 || c > GRID_SIZE - 1)
    return;
  if (state->currGrid[r][c] == '*')
  {
    state->currGrid[r][c] = '.';
  }
  else
  {
    state->currGrid[r][c] = '*';
  }
}

/**
 * plays a move on the gameboard
 * @param r the row of the light
 * @param c the column of the light
 * @param state the current board state
 */
void move(int r, int c, struct BoardState *state)
{
#ifndef UNSAFE
  sem_wait(lock);
#endif

  updatePrevBoard(state);

  flip(r, c, state);
  flip(r - 1, c, state);
  flip(r, c + 1, state);
  flip(r, c - 1, state);
  flip(r + 1, c, state);
  state->undoAvailable = true;

#ifndef UNSAFE
  sem_post(lock);
#endif
}

/**
 * Play undo and copy previous board into current board
 * @param state the current board state
 */
void undoBoard(struct BoardState *state)
{

  if (!state->undoAvailable)
  {
    fail("error");
  }

#ifndef UNSAFE
  sem_wait(lock);
#endif

  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      state->currGrid[i][j] = state->prevGrid[i][j];
    }
  }

  state->undoAvailable = false;

#ifndef UNSAFE
  sem_post(lock);
#endif
}

// Test interface, for quickly making a given move over and over.
void test(int n, int r, int c, struct BoardState *state)
{
  // Make sure the row / colunn is valid.
  if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
    fail("error");
  // Make the same move a bunch of times.
  for (int i = 0; i < n; i++)
    move(r, c, state);
}

/**
 * converts a string to an int and returns the value
 * @param str the string to convert
 * @return the converted string
 */
int str_to_int(char *str)
{
  int multiplier = 1;
  int accumulator = 0;
  for (int i = strlen(str) - 1; i >= 0; i--)
  {
    int num = str[i] - '0';
    if (num < 0 || num > 9)
    {
      fail("error");
    }
    accumulator += num * multiplier;
    multiplier *= 10;
  }

  return accumulator;
}

/**
 * starts the client for lights out
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/aspratap", ID), sizeof(struct BoardState), 0);

  struct BoardState *state = (struct BoardState *)shmat(shmid, 0, 0);

  lock = sem_open("/aspratap-lightsout-lock", 0);

  if (argc < 2 || argc > 5)
  {
    fail("Invalid arguments");
  }

  if (strcmp(argv[1], "move") == 0)
  {
    if (argc != 4)
      fail("error");

    int r = *argv[2] - '0';
    int c = *argv[3] - '0';

    if (r > GRID_SIZE - 1 || r < 0 || c < 0 || c > GRID_SIZE - 1)
      fail("error");
    // printf("row: %d\n", r);
    // printf("col: %d\n", c);

    move(r, c, state);
    printf("success\n");
  }
  else if (strcmp(argv[1], "test") == 0)
  {
    if (argc != 5)
      fail("error");

    int n = str_to_int(argv[2]);
    int r = *argv[3] - '0';
    int c = *argv[4] - '0';

    test(n, r, c, state);
    printf("success\n");
  }
  else if (strcmp(argv[1], "undo") == 0)
  {
    if (argc != 2)
    {
      fail("error");
    }
    undoBoard(state);
    printf("success\n");
  }
  else if (strcmp(argv[1], "report") == 0)
  {
    if (argc != 2)
    {
      fail("Too many arguments for report");
    }

    printGrid(state);
  }
  else
  {
    fail("error");
  }

  shmdt(state);
  sem_close(lock);

  return 0;
}