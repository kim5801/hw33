/**
 * @file common.h
 * @author Abhinav Pratap, aspratap
 *
 * contains some constants and structs that are used in the lightsout and reset programs
 */

#include <stdbool.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// ID to use for ftok
#define ID 2648

// struct to hold board state
struct BoardState
{
    char currGrid[GRID_SIZE][GRID_SIZE];
    char prevGrid[GRID_SIZE][GRID_SIZE];
    bool undoAvailable;
};
