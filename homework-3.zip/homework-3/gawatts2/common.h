// Height and width of the playing area.
#define GRID_SIZE 5
//for sharing board is current board, state is if moved, prev is for undo
typedef struct GameState {
    char board[31];
    char prev[31];
    int state;
} GameState;
  