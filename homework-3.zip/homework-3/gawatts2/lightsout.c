#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

sem_t *namedSem;
// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// move operation based on position given, assumed position is correct; take advantage
//of referene semantics 
//THIS FUNCTION IS FROM PREVIOUS ASSIGNMENT (FROM ME)
void moveF(int rowIdx, int colIdx, char* lineRepofGrid  ) {
  //game matrix is in grid
  int tick = 0;
  char grid[5][6];
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      grid[row][col] = lineRepofGrid[tick];
      //putchar(grid[row][col]); //to test in printing
      tick++;
    }
  }
  // putchar('\n'); //to test in printing
  //!!grid[][] mirrors like how it is in game here !!
  bool top = false;
  bool bottom = false;
  bool left = false;
  bool right = false;
  //top row
  if (rowIdx == 0) {
    //top left corner
    if (colIdx == 0 ) {
      bottom = true;
      right = true;
    }
    //top right corner
    else if (colIdx == 4) {
      bottom = true;
      left = true;
    }
    //top internal
    else {
      bottom = true;
      left = true;
      right = true;
    } 
  } //top row close
  //bottom row
  else if ( rowIdx == 4) { 
    //bottom left corner
    if ( colIdx == 0 ) {
      top = true;
      right = true;
    }
    //bottom right corner
    else if (colIdx == 4) {
      left = true;
      top = true;
    } 
    //bottom internal
    else {
      left = true;
      top = true;
      right = true;
    }
  } //bottom row close
  //in middle
  else {
  //middle left side
    if ( colIdx == 0 ) {
      bottom = true;
      top = true;
      right = true;
    }
    //middle right side
    else if ( colIdx == 4 ) {
      bottom = true;
      top = true;
      left = true;
    }
    //internal middle - all change
    else {
      bottom = true;
      top = true;
      left = true;
      right = true;
    }
  }
  //!up to here determined the valid changeable positions
  if (top) {
    if (grid[rowIdx - 1][colIdx] == '.') {
      grid[rowIdx - 1][colIdx] = '*';
    } else {
      grid[rowIdx - 1][colIdx] = '.';
    }
  }
  if (bottom) {
    if (grid[rowIdx + 1][colIdx] == '.') {
      grid[rowIdx + 1][colIdx] = '*';
    } else {
      grid[rowIdx + 1][colIdx] = '.';
    }
  }
  if (left) {
    if (grid[rowIdx][colIdx - 1] == '.') {
      grid[rowIdx][colIdx - 1] = '*';
    } else {
      grid[rowIdx][colIdx - 1] = '.';
    }
  }
  if (right) {
    if (grid[rowIdx][colIdx + 1] == '.') {
      grid[rowIdx][colIdx + 1] = '*';
    } else {
      grid[rowIdx][colIdx + 1] = '.';
    }
  }
  //now change the position itself given
  if (grid[rowIdx][colIdx] == '.') {
    grid[rowIdx][colIdx] = '*';
  } else {
    grid[rowIdx][colIdx] = '.';
  }
  //!! AT THIS POINT ALL MOVES PUT IN GRID[][]
  tick = 0;
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      lineRepofGrid[tick] = grid[row][col];
      //putchar(lineRepofGrid[tick]); //to test in printing
      tick++;
    }
  }
  
}





// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *structbuffer, int r, int c ) {
  
  #ifndef UNSAFE
  // Wait /acquire
  sem_wait( namedSem );
  #endif

  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    #ifndef UNSAFE
    // Tell the sem it can continue.
    sem_post( namedSem );
    #endif
    return false;
  }

  int tick = 0;
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      structbuffer->prev[tick] = structbuffer->board[tick];
      //putchar(lineRepofGrid[tick]); //to test in printing
      tick++;
    }
  }
  structbuffer->state = 1; //indicates moved
  moveF( r, c, structbuffer->board);
  
  #ifndef UNSAFE
  // Tell the sem it can continue.
  sem_post( namedSem );
  #endif
  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *structbuffer ) {
  #ifndef UNSAFE
  // Wait /acquire
  sem_wait( namedSem );
  #endif
  if ( structbuffer->state == 0 ) { //fail
    return false;
    #ifndef UNSAFE
    // Tell the sem it can continue.
    sem_post( namedSem );
    #endif
  } else { //success

   int tick = 0;
   for (int row = 0; row < 5; row++) {
     for (int col = 0; col < 6; col++) {
        structbuffer->board[tick] = structbuffer->prev[tick];
        //putchar(readInput[tick]); //to test in printing
        tick++;
      }
    }
   structbuffer->state = 0;
   return true;
   #ifndef UNSAFE
    // Tell the sem it can continue.
    sem_post( namedSem );
    #endif
  }
  return true;
  #ifndef UNSAFE
    // Tell the sem it can continue.
    sem_post( namedSem );
    #endif
}

// Print the current state of the board.
void report( GameState *structbuffer ) {
  #ifndef UNSAFE
  // Wait /acquire
  sem_wait( namedSem );
  #endif
  printf("%s",structbuffer->board);
  #ifndef UNSAFE
    // Tell the sem it can continue.
    sem_post( namedSem );
    #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }
  
  return true;
}







//start of program
int main( int argc, char *argv[] ) {

  // creating a shared memory w/ permissions - w special key //
  char name[50] = "/afs/unity.ncsu.edu/users/g/gawatts2";
  key_t key = ftok( name, 'e');
  int shmid = shmget( key, 0, 0 );
  if ( shmid == -1 ) {
    printf("%d", errno);
    fail( "Can't create shared memory" );
  }
  // creating a shared memory w/ permissions - w special key //
  
  
  // connect to created named semaphore //
  namedSem = sem_open( "/gawatts2-lightsout-lock", 0 );
  if ( namedSem == SEM_FAILED ) {
    fail( "Can't open semaphore" );
  }
    
  
  
  // connect to created named semaphore //
  
  
  
  //into adress space
  GameState *structbuffer = (GameState *)shmat( shmid, 0, 0 );
  if ( structbuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
 

  

  
  //check params
  bool moved = false;
  bool undod = false;
  bool reportd = false;
  bool testd = false;

  int row;
  int col;
  int n;
  //check if argument is ./client test n r c
  if ( argc == 5 ) {
    //now check the position
    n = atoi(argv[2]);
    row = atoi(argv[3]);
    col = atoi(argv[4]);
    
    testd = true;
  }//END OF 5 ARG  CHECK 
  //check if argument is ./client move r c
  if ( argc == 4 ) {
    //now check the position
    row = atoi(argv[2]);
    col = atoi(argv[3]);
    moved = true;
  }//END OF 4 ARG  CHECK  
  else if ( argc == 2) { //either undo or report
    //check if move is correct
    if ( strcmp(argv[1], "undo") == 0 ) {
      undod = true;
    }
    else {
      reportd = true; 
    } 
  } 
  
  
  
  
  
    //    OPTION REPORT   ///
  if ( reportd ) {
    report( structbuffer );
  }
  
  //    OPTION UNDO   ///
  else if (undod) {
    bool isUndo = undo(structbuffer);
    if (isUndo) {
      printf("sucess\n");

    } else {
      printf("error\n");
    }
      
  } 
  
  //    OPTION MOVE   ///
  else if (moved) {
    //call helper
    bool isMoved = move( structbuffer, row, col );
    if (isMoved) {
      printf("sucess\n");
    } else {
      printf("error\n");
      exit(1);
    }
  } else if (testd) {
    //call helper
    bool isTested = test( structbuffer, n, row, col );
    if (isTested) {
      printf("sucess\n");
    } else {
      printf("error\n");
      exit(1);
    }
  } else {
    printf("error\n");
  }
  
  // Close the semaphore and exit.
  sem_close( namedSem );
  //no longer need
  shmdt( structbuffer );
  //shmctl( shmid, IPC_RMID, 0 );
  
  return 0;
}