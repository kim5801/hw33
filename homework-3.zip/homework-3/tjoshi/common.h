// Height and width of the playing area.
#include <semaphore.h>
#define GRID_SIZE 5

sem_t *stateSem;




typedef struct GameState {
    bool prevUndo;
    char currArray[GRID_SIZE][GRID_SIZE];
    char prevArray[GRID_SIZE][GRID_SIZE];
} GameState;