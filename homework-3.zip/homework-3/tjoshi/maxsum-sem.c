#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;


sem_t lockMaxValue;
sem_t lockUntilRead;
sem_t lock;

int maxValue = 0;
int readUpTill = 0;
int workers = 4;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  // printf("gets to readList\n");
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    //unlocks the get work method letting the workers know that there is something in the array
    sem_post(&lockUntilRead);
  }
  for (int i = 0; i < workers; i++) {
    //posts for each worker to reach the sentinel value
    sem_post(&lockUntilRead);
  }
}

int getWork() {
  // waits until there is more work to be found
  sem_wait(&lockUntilRead);
  // locks to make sure only one worker can update the amount that has been read up till
  sem_wait(&lock);
  // updates the amount of of the array that the workers have collectively read up till
  int index = readUpTill;
  // updates read up till
  readUpTill++;
  // if the the amount read up till is greater than the vCount, return a sentinel value
  if (readUpTill > vCount) {
    sem_post(&lock);
    // printf("gets out of getWork with centinel value\n");
    return MAX_VALUES;
  }
  // releases to allow other workers to get a chance to get more work
  sem_post(&lock);
  // printf("gets out of getWork\n");
  return index;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // 
  int actMax = 0;
  while (true) {
    // while loop that keeps checking for more work
    int countTill = getWork();
    // gets the work until sentinel value is reached then breaks out of loop
    if (countTill == MAX_VALUES) {
      break;
    }
    int currSum = 0;
    int maxSum = vList[countTill];
    // calculates sum for this time 
    for (int j = countTill; j >= 0; j--) {
        currSum += vList[j];
        if (currSum > maxSum) {
            maxSum = currSum;
        }
    }
    // updates the maxSum found by this thread
    if (maxSum > actMax) {
      actMax = maxSum;
      // printf("Max Sum: %d\n", actMax);
    }
  }
  // reports the max sum found by the thread
  if (report) {
    printf("I'm Thread %lu. The maximum sum I found is %d. \n", pthread_self(), actMax);
  }
  // waits until no other thread is editing maxValue
  sem_wait(&lockMaxValue);
  if (actMax > maxValue) {
    // updates max value if this thread has found a higher max value than previously
    maxValue = actMax;
  }
  // locks max value
  sem_post(&lockMaxValue);
  pthread_exit(EXIT_SUCCESS);
}

int main( int argc, char *argv[] ) {
  //printf("gets into main method\n");
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  // initializing all semephores
  if (sem_init(&lockMaxValue, 0, 1) != 0 ) {
    fail("sem2 not working");
  }

  if (sem_init(&lockUntilRead, 0, 0) != 0 ) {
    fail("sem2 not working");
  }

  if (sem_init(&lock, 0, 1) != 0 ) {
    fail("sem2 not working");
  }
  // Make each of the workers.
  maxValue = 0;
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0 ) 
      fail( "Can't create a child thread\n" );

  // Then, start getting work for them to do.
  readList();


  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", maxValue );
  
  return EXIT_SUCCESS;
}
