/**
 * @file lightsout.c
 * @author Tej Joshi (tjoshi)
 * 
 * This program as the server for the popular game "lights out" and it communicates with the reset.c program which resets the board using allocated memory
 * This file was made with inspiration from the following example files from moodle:
 * shmReader.c
 * shmWriter.c
 * 
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
// Print out an error message and exit.
static void error() {
  printf( "error\n" );
  exit( 1 );
}

/**
 * saves the current array into the previous array
 * 
 * @param currArray the array needed to be saved
 * @param prevArray the location of saving the previous array
 */
void saveCurr(char currArray[5][5],char prevArray[5][5]) {
  for (int r = 0; r < 5; r++) {
    for (int c = 0; c < 5; c++) {
      prevArray[r][c] = currArray[r][c];
    }
  }
}


/**
 * Performs the move functions on the current Board
 * 
 * @param row the row of the move
 * @param col the column of the move
 */
void changeCurr(int row, int col, char currArray[5][5]) {
  int left = col - 1;
  int right = col + 1;
  int up = row - 1;
  int down = row + 1;
  //changes the current index of the move
  if(currArray[row][col] == '.') {
    currArray[row][col] = '*';
  } else {
    currArray[row][col] = '.';
  }
  //changes the left index of the change (if necessary)
  if (left < 5 && left >= 0) {
    if(currArray[row][left] == '.') {
      currArray[row][left] = '*';
    } else {
      currArray[row][left] = '.';
    }
  }
  //changes the right index of the change (if necessary)
  if (right < 5 && right >= 0) {
    if(currArray[row][right] == '.') {
      currArray[row][right] = '*';
    } else {
      currArray[row][right] = '.';
    }
  }
  //changes the upper index of the change (if necessary)
  if (up < 5 && up >= 0) {
    if(currArray[up][col] == '.') {
      currArray[up][col] = '*';
    } else {
      currArray[up][col] = '.';
    }
  }
  //changes the lower index of the change (if necessary)
  if (down < 5 && down >= 0) {
    if(currArray[down][col] == '.') {
      currArray[down][col] = '*';
    } else {
      currArray[down][col] = '.';
    }
  }
}

/**
 * moves the current board into a 1D array to be sent in 
 * mq_receive
 * 
 * @param queueSend the 1D output array
 */
void outputCurr(char *queueSend, char currArray[5][5]) {
  int outputIndex = 0;
  for (int r = 0; r < 5; r++) {
    for (int c = 0; c < 5; c++) {
      queueSend[outputIndex++] = currArray[r][c];
    }
    queueSend[outputIndex++] = '\n';
  }
  queueSend[outputIndex++] = '\0';
}

/**
 * This method is used to convert the numbers given in move 
 * This method was pulled from hw 0 from my previous submission
 * 
 * @param input 
 * @return int 
 */
int atoiTej(char input[]) {
    // the counter for index in the while loop of input
    int i = 0;
    //the output number
    int number = 0;
    // if first value is negative, switch the value to negative one so we can multiply that value at the end to convert the value to a negative number
    while (input[i] != '\0') {
        if (input[i] < '0' || input[i] > '9') {
            //error message if the string contains any non integers and exits
            error();
        }
        //operation to add the consecutive digits of the number (first part multiplies the existing number by 10 to clear a space in the ones space)
        // second part converts the input number into an ascii value and adds it to the existing number (filling the number in the ones place)
        number = number * 10 + (input[i] - '0');
        i++;
    }
    return number;
}

/**
 * This function encapsulates the move function 
 * 
 * @param state This denotes the state function
 * @param r the given row that the move is being made in
 * @param c the given column that the move is being made in
 * @return true if successful
 * @return false if unsuccessful
 */
bool move( GameState *state, int r, int c) {
  if (r > 4 || c > 4) {
    return false;
  }
  #ifndef UNSAFE
    sem_wait( stateSem );
  #endif
  saveCurr(state->currArray, state->prevArray);
  changeCurr(r, c, state->currArray);
  state->prevUndo = false;
  #ifndef UNSAFE
    sem_post( stateSem );
  #endif
  return true;
}

/**
 * This function encapsulates the report functionality
 * 
 * @param state the game state
 */
void report(GameState *state) {
  #ifndef UNSAFE
    sem_wait( stateSem );
  #endif  
  char output[31];
  outputCurr(output, state->currArray);
  printf("%s", output);
  #ifndef UNSAFE
    sem_post( stateSem );
  #endif
}

/**
 * This function encapsulates the undo functionality
 * 
 * @param state the game state given
 * @return true if successful
 * @return false if unsucessful
 */
bool undo(GameState *state) {
  //locks the stateSem so other processes cannot access it
  #ifndef UNSAFE
    sem_wait( stateSem );
  #endif 
  if (state->prevUndo) {
    return false;
  }
  //saves the current board as the previous board
  saveCurr(state->prevArray, state->currArray);
  state->prevUndo = true;
  //unlocks the stateSem so other processes cannot access it
  #ifndef UNSAFE
    sem_post( stateSem );
  #endif
  return true;
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

int main( int argc, char *argv[] ) {
  stateSem = sem_open("/tjoshi-lightsout-lock", 0);
  if ( stateSem == SEM_FAILED )
    fail( "Can't open tag semaphore" );
  key_t key = ftok("/afs/unity.ncsu.edu/users/t/tjoshi/", 911);
  int shmid = shmget( key, 0, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  GameState *gameState = (GameState *)shmat( shmid, 0, 0 );
  if ( gameState == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  if (strcmp(argv[1], "move") == 0) {
    // error checking to see if the second and third command line arguments the right numbers
    int row = atoiTej(argv[2]);
    int col = atoiTej(argv[3]);
    if (move(gameState, row, col)) {
      printf("success\n");
    }
    else {
      error();
    }
  }  
  //logic for report
  else if (strcmp(argv[1], "report") == 0) {
    if (argc > 2) {
      error();
    }
    report(gameState);
    
  }
  // logic for undo
  else if (strcmp(argv[1], "undo") == 0) {
    if (argc > 2) {
      error();
    }
    if (undo(gameState)) {
      printf("success\n");
    }
    else {
      error();
    }
  }
  else if (strcmp(argv[1], "test") == 0) {
    if (argc != 5) {
      error();
    }
    int n = atoiTej(argv[2]);
    int row = atoiTej(argv[3]);
    int col = atoiTej(argv[4]);
    test(gameState, n, row, col);
  }
  else {
    error();
  }
  shmdt( gameState );
  // Make both the server and client message queues.
  return 0;
}
