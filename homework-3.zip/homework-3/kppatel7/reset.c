/**
 * @file reset.c
 * @author Kush Patel
 * @brief resets the shared memory for the game board
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print out a usage message and exit.
static void usage()
{
    fprintf(stderr, "usage: reset <board-file>\n");
    exit(1);
}

int main(int argc, char *argv[])
{

    // check the number of args for only 2
    if (argc != 2)
        usage();
    // open the board specified
    FILE *input = fopen(argv[1], "r");
    if (input == NULL)
    {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
    }

    // shared memory code
    key_t key;
    key = ftok(PATH_NAME, 7);                                       // creates unique key to shared memory
    int sharedMemoryID = shmget(key, BLOCK_SIZE, 0666 | IPC_CREAT); // make the shared memory space

    sem_open("/kppatel7-lightsout-lock", O_CREAT, 0600, 1);

    // make game
    GameState *game = (GameState *)shmat(sharedMemoryID, 0, 0);

    // read in the initial game board one character at a time
    char ch;

    // populate the board with whatever they specified in the reset command
    for (int row = 0; row < GRID_SIZE; row++)
    {
        for (int col = 0; col < GRID_SIZE + 1; col++)
        {
            ch = fgetc(input);
            if (ch == '\n' || ch == '*' || ch == '.')
            {
                game->board[(row * 5) + col] = ch; // row * 5 --> gets the current row + column
            }
            else
            {
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
                exit(1);
            }
        }
    }

    return 0;
}