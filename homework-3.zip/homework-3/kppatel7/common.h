// Path to home directory
#define PATH_NAME "/afs/unity.ncsu.edu/users/k/kppatel7"

// Height and width of the board
#define GRID_SIZE 5

// Size of the shared block of memory
#define BLOCK_SIZE 1024

// num of newline characters
#define NEWLINES 5

typedef struct {
    char board[(GRID_SIZE * GRID_SIZE) + NEWLINES]; // stores all board spaces as a singel array
    int moveRow; // the move row
    int moveCol; // move column
    int lastRow; // undo - row number
    int lastCol; //undo - col number
    bool undoPossible; //flag for if undoing is allowed
} GameState;