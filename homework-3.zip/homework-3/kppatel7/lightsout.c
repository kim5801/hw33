/**
 * @file lightsout.c
 * @author Kush Patel
 * @brief creates the lights out game using shared memory
 *
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/**
 * change the specified spot on the board from a * to . or vice versa
 *
 * @param game game board
 * @param row row to change
 * @param column col to change
 */
void flipPiece(GameState *game, int row, int column)
{
    // get the exact spot in the single array
    int spot = (row * GRID_SIZE) + column;
    if (game->board[spot] == '.')
    {
        game->board[spot] = '*';
    }

    else if (game->board[spot] == '*')
    {
        game->board[spot] = '.';
    }
}

/**
 * changes the board accordingly when making a move
 *
 * @param game game board
 * @param row row to change
 * @param col col to change
 */
bool move(GameState *game, int row, int col)
{
    sem_t *lock = sem_open("/kppatel7-lightsout-lock", 0);
    if (lock == SEM_FAILED)
        printf("Can't open named semaphore");
#ifndef UNSAFE
    sem_wait(lock);
#endif

    if (row == 0 && col == 0)
    { // top left corner
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row, col + 1);
    }
    else if (row == 0 && col == 4)
    { // upper right corner
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row, col - 1);
    }
    else if (row == 4 && col == 0)
    { // bottom left corner
        flipPiece(game, row, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col + 1);
    }
    else if (row == 4 && col == 4)
    { // bottom right corner
        flipPiece(game, row, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
    }
    else if (row == 0 && (col != 0 || col != 4))
    { // upper row not corners
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row, col - 1);
        flipPiece(game, row, col + 1);
    }
    else if (row == 4 && (col != 0 || col != 4))
    { // bottom row not corners
        flipPiece(game, row, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
        flipPiece(game, row, col + 1);
    }
    else if (col == 0 && (row != 0 || row != 4))
    { // left col but not corners
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col + 1);
    }
    else if (col == 4 && (row != 0 || row != 4))
    { // right-most column not corners
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
    }
    else
    { // everything else
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
        flipPiece(game, row, col + 1);
    }

    game->undoPossible = true;
    game->lastRow = row;
    game->lastCol = col;

#ifndef UNSAFE
    sem_post(lock);
    sem_close(lock);
#endif

    return true;
}

bool undo(GameState *state)
{
    bool result = move(state, state->lastRow, state->lastCol);
    if (result)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void report(GameState *game)
{
    for (int row = 0; row < GRID_SIZE; row++)
    {
        for (int col = 0; col < GRID_SIZE; col++)
        {
            printf("%c", game->board[(row * 5) + col]);
        }
        printf("\n"); // end of row
    }
    printf("\n");
}

/**
 * check if the passed in number is valid or not
 *
 * @param number number to check
 * @return true if number is between 0-4 inclusive
 * @return false if any other number or negative
 */
bool validNumber(const char number[])
{
    // cant have a num that starts with '-'
    if (number[0] == 45)
    {
        return false;
    }

    for (int i = 0; number[i] != 0; i++)
    {

        if (number[i] >= '0' && number[i] < '5')
        {
            return true;
        }
    }
    return false;
}

// Test interface, for quickly making a given move over and over.
bool test(GameState *state, int n, int r, int c)
{
    // Make sure the row / colunn is valid.
    if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
        return false;
    // Make the same move a bunch of times.
    for (int i = 0; i < n; i++)
        move(state, r, c);
    return true;
}

int main(int argc, char *argv[])
{
    key_t key;
    key = ftok(PATH_NAME, 7);               // creates unique key
    int sharedMemoryID = shmget(key, 0, 0); // make the shared memory space

    GameState *game = (GameState *)shmat(sharedMemoryID, 0, 0); // attach the memory

    // the three options than can be specified to lightsout
    if (strcmp(argv[1], "report") == 0)
    {
        report(game);
    }
    // take old move and redo it
    else if (strcmp(argv[1], "undo") == 0)
    {
        if (game->undoPossible)
        {
            bool result = undo(game);
            if (result)
            {
                printf("success\n");
            }
            // cant undo twice in a row
            game->undoPossible = false;
        }
        else if (!game->undoPossible)
        {
            printf("error\n");
        }
    }
    else if (strcmp(argv[1], "test") == 0)
    {
        test(game, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
    }
    else if (argc == 4 && (strcmp(argv[1], "move") == 0) && (validNumber(argv[2]) && validNumber(argv[3])))
    {
        game->moveRow = atoi(argv[2]); // gets the row as int
        game->moveCol = atoi(argv[3]); // gets the column as int

        int row = game->moveRow;
        int col = game->moveCol;

        bool result = move(game, row, col);
        // switches the board state
        if (result)
        {
            printf("success\n");
        }
        else
        {
            printf("error\n");
        }
    }
    return 0;
}