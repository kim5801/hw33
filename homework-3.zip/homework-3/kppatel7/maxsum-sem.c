#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
    printf("usage: maxsum-sem <workers>\n");
    printf("       maxsum-sem <workers> report\n");
    exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// store the fields the worker thread needs

// semaphores for race conditions
sem_t x;
sem_t y;

bool currentlyReading = true;

// position of thread going through list
int lastReadVal = 0;

// get the last read in index of vlist or a sentinel value if done reading
int getWork()
{
    while (true)
    {
        if ((lastReadVal >= vCount) && !currentlyReading)
        {
            return -1;
        }
        else if (lastReadVal < vCount)
        {
            return lastReadVal++;
        }
    }
}

// Read the list of values.
void readList()
{
    // Keep reading as many values as we can.
    int v;

    currentlyReading = true;
    while (scanf("%d", &v) == 1)
    {

        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");

        vList[vCount++] = v;
    }
    currentlyReading = false;
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
    int tempMaxFinal = INT_MIN;
    while (true)
    {
        sem_wait(&x);
        int lastRead = getWork();
        sem_post(&x);
        if (lastRead == -1)
        {
            break;
        }

        int tempMax = 0;
        for (int j = lastRead; j >= 0; j--)
        {
            tempMax += vList[j];
            if (tempMax > tempMaxFinal)
            {
                tempMaxFinal = tempMax;
            }
        }
    }
    if (report)
    {
        printf("I’m process %lu. The maximum sum I found is %d.\n", pthread_self(), tempMaxFinal);
    }
    //
    sem_wait(&y);
    if (tempMaxFinal > max_sum)
    {
        max_sum = tempMaxFinal;
    }
    sem_post(&y);
    return NULL;
}
// report the childs sum

int main(int argc, char *argv[])
{
    int workers = 4;

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 ||
        workers < 1)
        usage();

    // If there's a second argument, it better be "report"
    if (argc == 3)
    {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    // Make each of the workers.
    pthread_t worker[workers];

    // initialize semaphores
    sem_init(&x, 0, 1);
    sem_init(&y, 0, 1);

    // create threads and the info they need
    for (int i = 0; i < workers; i++)
    {
        pthread_create(&worker[i], NULL, workerRoutine, NULL);
    }

    readList();

    // Wait until all the workers finish.
    for (int i = 0; i < workers; i++)
    {
        pthread_join(worker[i], NULL);
    }

    // Report the max product and release the semaphores.
    printf("Maximum Sum: %d\n", max_sum);

    return EXIT_SUCCESS;
}