/**
 * @file lightsout.c
 * @author Sam Stone (sjstone3)
 * @brief
 * It will interpret a user command given in the command-
 * line arguments and make requested changes to the game board stored in shared memory. You can also
 * use a header file named common.h that can be included by both of your programs.
 * 
 * Added additional functionality to avoid race conditions
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <semaphore.h>
#include "common.h"


//name of the semaphore and the pointer to it
char *sem_name = "/sjstone3-lightsout-lock";
sem_t *lock;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//evaluates if the string is made up only of digits
bool isNumber( char *input ) {
  int i = 0;
  while( input[ i ] ) {
    if( input[ i ] < '0' || input[ i ] > '9' ) {
      return false;
    }
    i++;
  }
  return true;
}

/**
  Switches the lights on/off at the given coordinate, left, right, above and below
  @param state the board being modified
  @param r rows
  @param c columns
*/
bool move( GameState* state, int r, int c ) {
  #ifndef UNSAFE
  sem_wait( lock );
  #endif

  char change = ( state->recent[ r ][ c ] == '*' ? '.' : '*' ); //given coord
  state->recent[ r ][ c ] = change;

  if( r + 1 < GRID_SIZE && r + 1 >= 0 ) { //top of coords
    change = ( state->recent[ r ][ c ] == '*' ? '.' : '*' );
    state->recent[ r ][ c ] = change;
  }

  if( r - 1 < GRID_SIZE && r - 1 >= 0 ) { //bottom of coords
    change = ( state->recent[ r - 1 ][ c ]== '*' ? '.' : '*' );
    state->recent[ r - 1 ][ c ] = change;
  }

  if( c + 1 < GRID_SIZE && c + 1 >= 0 ) { //right of coords
    change = ( state->recent[ r ][ c + 1 ] == '*' ? '.' : '*' );
    state->recent[ r ][ c + 1 ] = change;
  }

  if( c - 1 < GRID_SIZE && c - 1 >= 0 ) { //left of coords
    change = ( state->recent[ r ][ c - 1 ] == '*' ? '.' : '*' );
    state->recent[ r ][ c - 1 ] = change;
  }

  #ifndef UNSAFE
  sem_post( lock );
  #endif

  return true;
}

/**
  Changes the recent state to the old state
  Makes sure you can't use undo twice in a row
  @param state the game board being changed
*/
bool undo( GameState *state ) {

  if( !state->undoValid ) {
      return false;
    }
    #ifndef UNSAFE
    sem_wait( lock );
    #endif

    memcpy( state->recent, state->old, sizeof( char ) * GRID_SIZE * GRID_SIZE );
    state->undoValid = false;

    #ifndef UNSAFE
    sem_post( lock );
    #endif

    return true;
}
 
/**
  Prints out the given game board into a grid
  @param state the game board being printed
*/
void report( GameState *state ) {
  #ifndef UNSAFE
  sem_wait( lock );
  #endif

  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", state->recent[ i ][ j ] );
    }
    printf( "\n" );
  }

  #ifndef UNSAFE
  sem_post( lock );
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );

  return true;
}

/**
 * Handles user commands to change the board
 */
int main( int argc, char *argv[] ) {
  if( argc <= 1 ) {
    fail( "error" );
  }

  char *cmd = argv[ 1 ];

  //get the shared memory and the semaphore
  key_t key = ftok( "/afs/unity.ncsu.edu/users/s/sjstone3", 5 );
  int shmid = shmget( key, 0, 0 );
  if( shmid == -1 ) {
    fprintf( stderr, "%s\n", strerror( errno ) );
  }
  GameState *board = ( GameState * )shmat( shmid, 0 , 0 );
  lock = sem_open( sem_name, 0 );

  /////  MOVE  /////
  if( strcmp( cmd, "move" ) == 0 ) { //move r c
    if( argc != 4 ) {
      fail( "error" );
    }
    //check if valid row and column inputs
    if( !isNumber( argv[ 2 ]) || !isNumber( argv[ 3 ] ) ) {
      fail( "error" );
    }

    int r = atoi( argv[ 2 ] );
    int c =  atoi( argv[ 3 ] );
    //columns and rows have to be inputs 0-3
    if( r < 0 || r > 4 || c < 0 || c > 4 ) {
      fail( "error" );
    }

    //copy over the board to the old board array
    //update the recent board as the board that was just moved
    char tempBoard[ GRID_SIZE ][ GRID_SIZE ];
    memcpy( tempBoard, board->recent, sizeof( char ) * GRID_SIZE * GRID_SIZE );
    if( move( board, r, c ) ) {
      board->undoValid = true;
      printf( "success\n" );
      memcpy( tempBoard, board->recent, sizeof( char ) * GRID_SIZE * GRID_SIZE );
    }

  /////  UNDO  /////
  } else if( strcmp( "undo", cmd ) == 0 ) {
    if( undo( board ) ) {
      printf( "success\n" );
    } else {
      fail( "error" );
    }

  /////  REPORT  /////
  } else if( strcmp( "report", cmd ) == 0 ) {
    report( board );

 /////  TEST  /////
  } else if( strcmp( "test", cmd ) == 0 ) {
    //make sure the args are correct
    if( argc != 5 ) {
      fail( "error" );
    }
    //check if valid row and column inputs
    if( !isNumber( argv[ 2 ] ) || !isNumber( argv[ 3 ] ) || !isNumber( argv[ 4 ] ) ) {
      fail( "error" );
    }

    int n  = atoi( argv[ 2 ] );
    int r = atoi( argv[ 3 ] );
    int c =  atoi( argv[ 4 ] );

    //columns and rows have to be inputs 0-3
    if( r < 0 || r > 4 || c < 0 || c > 4 ) {
      fail( "error" );
    }
    test( board, n, r, c );

  } else {
    fail( "error" );
  }

  shmdt( board );
  return 0;
}
