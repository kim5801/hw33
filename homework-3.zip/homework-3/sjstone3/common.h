// Height and width of the playing area.
#define GRID_SIZE 5

/**
 * Representation of the game board and most recent move * 
 */
typedef struct {
  char recent[ GRID_SIZE ][ GRID_SIZE ];  
  char old[ GRID_SIZE ][ GRID_SIZE ];

  //used for error checking to make sure user can't undo twice in a row 
  //or before any moves have been made
  bool undoValid; 
} GameState;