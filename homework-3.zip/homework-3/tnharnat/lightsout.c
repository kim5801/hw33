/**
 * @file lightsout.c
 * @author Teddy Harnatkiewicz tnharnat@ncsu.edu  
 * @brief Game Control for Lights Out Game
 * @version 0.1
 * @date 2022-10-13
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"


sem_t * mySemaphore;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief print a board struct
 * 
 * @param board board to print 
 */
void report(lightBoard * board) {
  #ifndef UNSAFE
    sem_wait( mySemaphore );
  #endif
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 5; j++) {
      printf("%c", board->board[i][j]);
    }
    printf("\n");
  }
  printf("\n");
  sem_post(mySemaphore);
}

// flip light
char flipLight(char c) {
  if(c == '.')
    return '*';
  else
    return '.';
}

// flip all relevant lights / play the move
bool move(lightBoard * board, int r, int c) {
  #ifndef UNSAFE
    sem_wait( mySemaphore );
  #endif
  int move[2];
  move[0] = r;
  move[1] = c;

  board->move[0] = move[0];
  board->move[1] = move[1];
    

  board->board[board->move[0]][board->move[1]] = flipLight(board->board[board->move[0]][board->move[1]]);
  if(board->move[0] > 0)
    board->board[board->move[0] - 1][board->move[1]] = flipLight(board->board[board->move[0] - 1][board->move[1]]);
  if(board->move[1] > 0)
    board->board[board->move[0]][board->move[1] - 1] = flipLight(board->board[board->move[0]][board->move[1] - 1]);
  if(board->move[0] < 4)
    board->board[board->move[0] + 1][board->move[1]] = flipLight(board->board[board->move[0] + 1][board->move[1]]);
  if(board->move[1] < 4)
    board->board[board->move[0]][board->move[1] + 1] = flipLight(board->board[board->move[0]][board->move[1] + 1]);

  sem_post(mySemaphore);
  return true;
}

/**
 * @brief replays the previous move, returns false if no move or already undone
 * 
 * @param board game board
 * @return true is successful
 * @return false if failed
 */
bool undo(lightBoard * board) {
  #ifndef UNSAFE
    sem_wait( mySemaphore );
  #endif
  if(board->move[0] == -1) {
    sem_post(mySemaphore);
    return false;
  }
  else {

    board->board[board->move[0]][board->move[1]] = flipLight(board->board[board->move[0]][board->move[1]]);
    if(board->move[0] > 0)
      board->board[board->move[0] - 1][board->move[1]] = flipLight(board->board[board->move[0] - 1][board->move[1]]);
    if(board->move[1] > 0)
      board->board[board->move[0]][board->move[1] - 1] = flipLight(board->board[board->move[0]][board->move[1] - 1]);
    if(board->move[0] < 4)
      board->board[board->move[0] + 1][board->move[1]] = flipLight(board->board[board->move[0] + 1][board->move[1]]);
    if(board->move[1] < 4)
      board->board[board->move[0]][board->move[1] + 1] = flipLight(board->board[board->move[0]][board->move[1] + 1]);
    
    board->move[0] = -1;
    sem_post(mySemaphore);
    return true;
  }
}

bool test( lightBoard *state, int n, int r, int c ) {
// Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );

  return true;
}

int main( int argc, char *argv[] ) {

  // checks for invalid input
  if(argc != 2 && argc != 4 && argc != 5)
    fail("error");

  if(strcmp(argv[1], "test") != 0 && strcmp(argv[1], "move") != 0 && strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0)
    fail("error");

  if(strcmp(argv[1], "move") == 0 && argc != 4)
    fail("error");

  if(strcmp(argv[1], "report") == 0 && argc != 2)
    fail("error");

  if(strcmp(argv[1], "undo") == 0 && argc != 2)
    fail("error");

  if(strcmp(argv[1], "test") == 0 && argc != 5)
    fail("error");

  lightBoard * board;
  mySemaphore = sem_open("/tnharnat-lightsout-lock", 1);
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/t/tnharnat", 't'), sizeof(*board), 0);
  board = (lightBoard *)shmat(shmid, 0 , 0);

  // move command
  if(strcmp(argv[1], "move") == 0) {
    int pos[2];
    if(sscanf(argv[2], "%d", pos) != 1 || sscanf(argv[3], "%d", pos + 1) != 1)
      fail("error");
    if(move(board, pos[0], pos[1]))
      printf("success\n");
    else
      fail("error");
  }

  if(strcmp(argv[1], "test") == 0) {
    int pos[3];
    if(sscanf(argv[2], "%d", pos) != 1 || sscanf(argv[3], "%d", pos + 1) != 1 || sscanf(argv[4], "%d", pos + 1) != 1)
      fail("error");
    test(board, pos[0], pos[1], pos[2]);
  }

  // report command
  if(strcmp(argv[1], "report") == 0) {
    report(board);
  }

  // undo command (fails if undo already sent after most recent move)
  if(strcmp(argv[1], "undo") == 0) {
    if(undo(board))
      printf("success\n");
    else
      fail("error");
  }

  sem_close(mySemaphore);
  return 0;
}
