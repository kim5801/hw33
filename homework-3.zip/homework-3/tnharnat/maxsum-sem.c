/**
 * @file maxsum-sem.c
 * @author Teddy Harnatkiewicz
 * @brief Synchronization example of the maxsum problem 
 * @version 0.1
 * @date 2022-10-13
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Oldest unclaimed index
int idx = 0; 

int additionC = 0;

sem_t updateIdx;
sem_t updateMax;
sem_t bufferCheck;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&bufferCheck);
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int threadMax = INT_MIN;
  while(true) {
    //printf("*Before buffer check\n");  
    sem_wait(&bufferCheck);
    //printf("*After buffer check\n");
    sem_wait(&updateIdx);
    //printf("*Inside update idx\n");
    int workingIdx = idx++; // maybe dont do this
    sem_post(&updateIdx);

    if(vList[workingIdx] == INT_MAX) {
      if(report)
        printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), threadMax);
      return NULL;
    }
    
    int workingMax = 0;
    
    for (int i = workingIdx; i >= 0; i--) {
      workingMax += vList[i];
      
      sem_wait(&updateMax);
      additionC++;
      if(workingMax > max_sum) {
        //printf("*Inside update max\n");
        max_sum = workingMax;
      }
      sem_post(&updateMax);
      if(workingMax > threadMax) {
        //printf("*Inside update max\n");
        threadMax = workingMax;
      }
    }
    
  }
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  sem_init(&updateIdx, 0 , 1);
  sem_init(&updateMax, 0 , 1);
  sem_init(&bufferCheck, 0 , 0);
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0 )
      fail( "Can't create thread.\n" );
  }
  // Then, start getting work for them to do.
  readList();
  for ( int i = 0; i < workers; i++ ) {
    vList[vCount++] = INT_MAX;
    sem_post(&bufferCheck);
  }

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }
    

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  // printf( "Additions: %d\n", additionC );
  sem_destroy(&updateIdx);
  sem_destroy(&updateMax);
  sem_destroy(&bufferCheck);
  
  return EXIT_SUCCESS;
}
