/**
  This file finds the maximum sum in a list using threads
  @file maxsum-sem.c
  @author gsmichel
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

//sem for locking max_sum variable
sem_t maxSum;

//sem for locking reader
sem_t listReader;

//sem for locking reader
sem_t work;

//sem for locking vList
sem_t list;

//waiting readers
int waiting = 0;

//is there input to read?
int needToRead = 0;

//number of workers
int workers = 4;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Current number of values on the list.
int lastIndex = 0;

//Are we done reading the list?
bool done = false;


// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );
      
    //get access to the list

    //sem_wait(&list);
    vList[ vCount++ ] = v;

    //sem_post(&list);
    
    //release a reader

    sem_post(&listReader);
    
   
  }
  done = true;
}




/**
  This is a helper function that gets the sum of the list from a starting index
  @param startIndex this is the starting index
  @return it returns the maximum sum found
*/
static int sumList(int startIndex){
  int sum = 0;
  for (int i = startIndex; i >= 0; i--){
    //lock vList

    //sem_wait(&list);
    sum += vList[i];

    //sem_post(&list);
    //lock maxSum

    sem_wait( &maxSum );
    if(max_sum < sum){
      max_sum = sum;
    }
    sem_post( &maxSum );
  }
  return max_sum;
}
/**
  This function assigns each thread an index to check.
  @return the index
*/
static int getWork(){
  waiting++; //let it know that I am waiting

  if ( done && lastIndex >= vCount )
      return -1;
  sem_wait(&listReader); //lock reader
  
  waiting--;
  
  int ret = lastIndex;
  lastIndex++;
  
  
  return ret;
  
  
}

/** 
  Start routine for each worker. 
  @return a void pointer
  @param arg a void pointer to the arguments
*/
void *workerRoutine( void *arg ) {
  int myMaxSum = INT_MIN;
  while(true){
    //if no more input and if there isn't anything else to read
    if ( done && lastIndex >= vCount )
      break;
    sem_wait(&work);
    int idx = getWork();
    sem_post(&work);
    if (idx == -1)
      break;
  	int temp = sumList(idx);
  	if(myMaxSum < temp){
      myMaxSum = temp;
    }
    
  
  }
  if(report){
    printf( "I am thread %lu. ", pthread_self() );
    printf("My maximum sum is %d.\n", myMaxSum);
  }
  return NULL;
  
}

/**
  The main function of the program. It creates the threads and reads the list 
  and ends the program.
  @param argc the number of arguments
  @param argv the arguments
  @return an integer
*/
int main( int argc, char *argv[] ) {
  
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  sem_init( &maxSum, 0, 1 );
  sem_init( &listReader, 0, 0 );
  sem_init( &list, 0, 1 );
  sem_init( &work, 0, 1 );
  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ){
    if ( pthread_create( &worker[i], NULL, workerRoutine , NULL ) != 0 ) 
      fail( "Can't create a worker thread\n" );
  }
  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
