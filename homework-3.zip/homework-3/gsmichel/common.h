/**
  This is the header file for reset.c and lightsout.c
  @file common.h
  @author gsmichel
*/

// Height and width of the playing area.
#define GRID_SIZE 5
/** This is the game board struct that is in the shared memory */
struct GameState{
  int board[GRID_SIZE][GRID_SIZE];
  int rowMove;
  int columnMove;
} typedef GameState;