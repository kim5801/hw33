#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <sys/types.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Lock on modifying index for worker threads
sem_t work_sem;

// Lock on the total sum
sem_t sum_lock;

// Lock to say that work is available
sem_t work_avail;

// The next index for a worker to claim
int next_slot = 0;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Flag for whether all input has been read
bool allRead = false;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES ) {
      fail( "Too many input values" );
    }
    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post( &work_avail );
  }
  allRead = true;
}

/**
 * Gives an index of the array to work on
 *  waits until the next slot is available
 * 
 * @return int the index to work with, or -1 if all has been read
 */
int getWork() {
  
  int index;
  // Make sure this is the only thread checking work values
  //printf("Thread %d waiting for work_sem\n", syscall(SYS_gettid) ); DEBUG
  sem_wait( &work_sem );
  printf("NextSlot:%d, vCount:%d\n", next_slot, vCount); //DEBUG
  if ( allRead && next_slot == vCount - 1 ) {
    index = -1;
  } else {
    // Wait until work is available
    //printf("Thread %d waiting for work_avail\n", syscall(SYS_gettid) ); //DEBUG
    sem_wait( &work_avail );
    next_slot++;
    index = next_slot;
    
    
  }
  // Let other threads check for work
  sem_post( &work_sem );
  return index;


}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int myMax = INT_MIN;
  int index;
  int sum;
  // While there is work to do
  while ( ( index = getWork() ) != -1 ) {
    sum = 0;
    // Find largest sum that ends at index
    for ( int i = index; i >= 0; i-- ) {
      sum += vList[ i ];
      // Checking if sum found is larger than thread max
      if ( sum > myMax ) {
        myMax = sum;
      }
    }
  } 
  // Check if final thread max is global max
  //printf("Thread %d waiting for sum_luck\n", syscall(SYS_gettid) ); //DEBUG
  sem_wait( &sum_lock );
  if ( myMax > max_sum ) {
    max_sum = myMax;
  }
  sem_post( &sum_lock );
  if ( report ) {
    //pthread_t tid = pthread_self();
    printf( "I'm thread %d. The maximum sum I found is %d.\n", syscall(SYS_gettid) , myMax );
  }
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  sem_init( &work_sem, 0, 1 );
  sem_init( &sum_lock, 0, 1 );
  sem_init( &work_avail, 0, 0 );
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create( &worker[i], NULL, workerRoutine, NULL );

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  // Destroy semaphores
  sem_destroy( &work_sem );
  sem_destroy( &sum_lock );
  sem_destroy( &work_avail );

  return EXIT_SUCCESS;
}
