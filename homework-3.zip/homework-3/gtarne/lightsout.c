/**
 * @file lightsout.c
 * @author Grant Arne gtarne
 * A program which can execute a single command to play lights out
 * 
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/** The maximum number of arguments to be valid */
#define MAX_ARGS 5
/** The minimum number of valid args */
#define MIN_ARGS 2

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** The lock for accessing the shared memery */
sem_t *memLock;


/**
 * Completes one move on the given game at the given row and column, toggling 
 * surrounding lights if they are in the board
 * 
 * @param r the row to move at
 * @param c the column to move at
 * @param game the game to move in
 */
void move( int r, int c, GameStatus *game ) {
  #ifndef UNSAFE
    sem_wait( memLock );
  #endif
  // Center piece
  if ( game->board[ r ][ c ] == '.' ) {
    game->board[ r ][ c ] = '*';
  } else {
    game->board[ r ][ c ] = '.';
  }
  // Above
  if ( r - 1 >= 0 ) {
    if( game->board[ r - 1][ c ] == '.' ) {
      game->board[ r - 1 ][ c ] = '*';
    } else {
      game->board[ r - 1 ][ c ] = '.';
    }
  }
  // Below
  if ( r + 1 < GRID_SIZE ) {
    if( game->board[ r + 1][ c ] == '.' ) {
      game->board[ r + 1 ][ c ] = '*';
    } else {
      game->board[ r + 1 ][ c ] = '.';
    }
  }
  // Left
  if ( c - 1 >= 0 ) {
    if( game->board[ r ][ c - 1 ] == '.' ) {
      game->board[ r ][ c - 1] = '*';
    } else {
      game->board[ r ][ c - 1] = '.';
    }
  }
  // Right
  if ( c + 1 < GRID_SIZE ) {
    if( game->board[ r ][ c + 1 ] == '.' ) {
      game->board[ r ][ c + 1] = '*';
    } else {
      game->board[ r ][ c + 1] = '.';
    }
  }
  #ifndef UNSAFE
    sem_post( memLock );
  #endif
}

/**
 * Undoes the last move and returns true, or false if it could not be undone
 * 
 * @param game the game to undo the last move in
 * @return true if the move was undone, false otherwise
 */
bool undoMove( GameStatus *game ) {
  #ifndef UNSAFE
    sem_wait( memLock );
  #endif
  if ( game->canUndo ) {
    #ifndef UNSAFE
      sem_post( memLock );
    #endif

    move( game->lastMove[ 0 ], game->lastMove[ 1 ], game );

    #ifndef UNSAFE
      sem_wait( memLock );
    #endif
    game->canUndo = false;
    #ifndef UNSAFE
      sem_post( memLock );
    #endif
    return true;
  } else {
    #ifndef UNSAFE
      sem_post( memLock );
    #endif
    return false;
  }
  
}

/**
 * Prints out the current board
 * 
 * @param game the board to print
 */
void report( GameStatus *game ) {
  char board[ GRID_SIZE * ( GRID_SIZE + 1 ) + 1];
  int index = 0;
  #ifndef UNSAFE
    sem_wait( memLock );
  #endif
  // Go through rows and columns, adding each character
  for ( int r = 0; r < GRID_SIZE; r++ ) {
    for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
      if ( c == GRID_SIZE ) {
        board[ index ] = '\n';
      } else {
        board[ index ] = game->board[ r ][ c ];
      }
      index++;
    }
  }
  board[ GRID_SIZE * ( GRID_SIZE + 1 ) ] = '\0';
  printf( board );

  #ifndef UNSAFE
    sem_post( memLock );
  #endif
}

/**
 * Test interfrace, for quickly making a given move over and over
 * 
 * @param game the game to make the moves in
 * @param n the number of times to execute that mvoe
 * @param r the row of the move
 * @param c the column of the move
 * @return true if the moves were valid and completed, false otherwise
 */
bool test ( GameStatus *game, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( r, c, game );
  return true;
}

/**
 * Executes a single instruction for playing lights out.
 * Can either move at a given row and column, undo the last move,
 * or print the status of the board.
 * 
 * @param argc the number of arguments
 * @param argv the arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {
  int mem_key = ftok( HOME_DIRECTORY, 1 );

  // Check valid number of args
  if ( argc > MAX_ARGS || argc < MIN_ARGS ) {
    fail( "error" );
  }

  // Get shared memory
  int shmid = shmget( mem_key, 0, 0 );
  if ( shmid == -1 ) {
    fail( "Can't create gameboard" );
  }
  GameStatus *game = shmat( shmid, 0, 0 );

  
  if ( ( memLock = sem_open( SEM_NAME, 0 ) ) == SEM_FAILED ) {
    shmdt( game );
    fail( "Failed to open game lock\n" );
  }


  // Check first arg
  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    // Check for too few args
    if ( argc != MAX_ARGS ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error");
    }
    // Check that row and column entries are a single character
    if ( strlen( argv[ 2 ] ) != 1  || strlen( argv[ 3 ] ) != 1 ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error");
      // Check if row and column are invalid characters
    } else if ( ( argv[ 2 ][ 0 ] < '0' || argv[ 2 ][ 0 ] > '4' ) || ( argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' ) ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error" );
    } else {
      // Set row and column chars
      int row = argv[ 2 ][ 0 ] - '0';
      int col = argv[ 3 ][ 0 ] - '0';

      // Execute move-----------------------------
      move( row, col, game );
      game->canUndo = true;
      game->lastMove[ 0 ] = row;
      game->lastMove[ 1 ] = col;

      // Indicate success and exit
      printf( "success\n" );
      shmdt( game );
      sem_close( memLock );
      exit( EXIT_SUCCESS );
    }

  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    // Check for too many args
    if ( argc > MIN_ARGS ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error" );
    } else {
      // Execute undo-----------------------------
      if ( undoMove( game ) ) {
        printf( "success\n" );
      } else {
        sem_close( memLock );
        shmdt( game );
        fail( "error" );
      }

    }

  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // Check for too many args
    if ( argc > MIN_ARGS ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error" );
    } else {
      // Print out board report--------------------------
      report( game );
      sem_close( memLock );
      shmdt( game );
      exit( EXIT_SUCCESS );
    }
    
  } else if ( strcmp(argv[ 1 ], "test" ) == 0 ) {
    if ( argc != MAX_ARGS ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error" );
    }
    // Check that row and column entries are a single character
    if ( strlen( argv[ 3 ] ) != 1  || strlen( argv[ 4 ] ) != 1 ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error");
      // Check if row and column are invalid characters
    } else if ( ( argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' ) || ( argv[ 4 ][ 0 ] < '0' || argv[ 4 ][ 0 ] > '4' ) ) {
      sem_close( memLock );
      shmdt( game );
      fail( "error" );
    } else {
      // Set row and column chars
      int row = argv[ 3 ][ 0 ] - '0';
      int col = argv[ 4 ][ 0 ] - '0';
      int n = atoi( argv[ 2 ] );
      // Execute test -------------------------------
      test( game, n, row, col );

    }
  } else {
    // Invalid input
    sem_close( memLock );
    shmdt( game );
    fail( "error");
  }

  sem_close( memLock );
  shmdt( game );
  return 0;
}
