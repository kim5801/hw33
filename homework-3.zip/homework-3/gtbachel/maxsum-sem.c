#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
volatile int vCount = 0;

//Amount of workers
volatile int workers = 4;

//Semaphore to track amount of work currently avalible but not done
sem_t availableWork;

//Semaphore to protect access to vCurret
sem_t vCurrentSem;

//Semaphore to protect access to the global max_sum
sem_t maxSem;

//Current work to start on next
volatile int vCurrent = 0;

//True if all of the file has been read in
volatile bool doneWithReading = false;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post( &availableWork );
  }
  doneWithReading = true;
  //Add some work when reading is done to wake up anyone left
  sem_post( &availableWork );
}

int getWork() {
  //Wait on work
  sem_wait( &availableWork );
  sem_wait( &vCurrentSem );
  //True if there is no more work left to do
  if( doneWithReading && vCount == vCurrent ) {
    //Work is done, wake up someone else who might be waiting and return -1
    sem_post( &availableWork );
    sem_post( &vCurrentSem );
    return -1;
  }
  //Next work and return this one
  int current = vCurrent++;
  sem_post( &vCurrentSem );
  return current;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  //int id = *(int*)arg;
  int location;
  int sum;
  int maxSum = INT_MIN;
  while ( (location = getWork()) >= 0 ) {
    sum = 0;
    //Add all values in the range
    for( int i = location; i >= 0; i-- ) {
      sum += vList[i];
      //Check if its a new high score!
      if( sum > maxSum )
        maxSum = sum;
    }
  }
  if( report ) 
    printf( "I’m thread %ld. The maximum sum I found is %d.\n", pthread_self(), maxSum );
  sem_wait( &maxSem );
  //Deteremine which thread has the biggest sum
  if( max_sum < maxSum ) {
    max_sum = maxSum;
  }
  sem_post( &maxSem );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //Start with no avalible work
  sem_init( &availableWork, 0, 0 );
  //Allow 1 thread at a time to use vCurrent.
  sem_init( &vCurrentSem, 0, 1 );
  //Allow 1 thread at a time to use max_sum.
  sem_init( &maxSem, 0, 1 );
  
  // Make each of the workers.
  pthread_t worker[ workers ];
  //int ids[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    //ids[i] = i;
    pthread_create( &worker[i], NULL, workerRoutine, NULL );
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[i], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
