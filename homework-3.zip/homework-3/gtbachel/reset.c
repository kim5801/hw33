#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

void openBoard(struct Board * board, char * filename );

#ifndef UNSAFE
sem_t *boardSem;
#endif

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  //Shared memory and semaphore to control access
  #ifndef UNSAFE
  boardSem = sem_open( SEM_NAME, O_CREAT, 0600, 1 );
  if( boardSem == SEM_FAILED ) {
    fail( "Could not make named semaphore" );
  }
  #endif
  int shmid = shmget( ftok( LOCATION, 256 ), sizeof(struct Board), 0600 | IPC_CREAT );
  if( shmid == -1 ) {
    fail( "Could not make shared memory" );
  }
  struct Board * board = (struct Board *)shmat( shmid, 0, 0 );
  if( argc != 2 ) {
    usage();
  }
  openBoard( board, argv[1] );
  return 0;
}

void openBoard(struct Board * board, char * filename ) {
  #ifndef UNSAFE
  sem_wait( boardSem );
  #endif
  //Open the given filename
  FILE * fp;
  fp = fopen( filename, "r" );
  //Couldn't find the file?
  if( !fp ) {
    #ifndef UNSAFE
    sem_post( boardSem );
    #endif
    fprintf( stderr, "Invalid input file: %s\n", filename );
    exit( 1 );
  }
  int i = 0;
  char c;
  //Read in 25 * or .
  while( i < 25 ) {
    c = fgetc(fp);
    if( feof( fp ) ) {
      //Reached end of file without 25 * or .    invalid file format
      #ifndef UNSAFE
      sem_post( boardSem );
      #endif
      fprintf( stderr, "Invalid input file: %s\n", filename );
      exit( 1 );
    }
    if( c == '*' ) {
      board->boardState[i/5][i%5] = true;
      i++;
    }
    else if( c == '.' ) {
      board->boardState[i/5][i%5] = false;
      i++;
    }
    else if( c != '\n' ) {
      //Found a character that wasn't a * . or newline
      #ifndef UNSAFE
      sem_post( boardSem );
      #endif
      fprintf( stderr, "Invalid input file: %s\n", filename );
      exit( 1 );
    }
  }
  //Close the file, it's not needed.
  fclose( fp );
  #ifndef UNSAFE
  sem_post( boardSem );
  #endif
}
