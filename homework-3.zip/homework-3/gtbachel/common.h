// Height and width of the playing area.
#define GRID_SIZE 5

#define LOCATION "/afs/unity.ncsu.edu/users/g/gtbachel"

#define SEM_NAME "/gtbachel-lightsout-lock"

struct Board {
  bool boardState[GRID_SIZE][GRID_SIZE];
  int lastMove[2];
};
