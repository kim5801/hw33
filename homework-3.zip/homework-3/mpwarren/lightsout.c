#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

//the semaphore that prevents multiple processes from accesing the game state at the same time
sem_t *semLock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//determines if the given character in move is a valid board position
bool isValidPos(char c){
    return c >= 0 && c <= 4;
}

//changes the light at space r c if it is in the board
//if r c is not in the board, nothing happens
void place(GameState*bo, int r, int c){
  if((r >= 0 && r <= 4) && (c >= 0 && c <= 4)){
    bo->gameBoard[r][c] = bo->gameBoard[r][c] == '.' ? '*' : '.';
  }
}

//Updates the game board at the given space
void playMove(GameState *bo, int r, int c){
  //only update space if its in the board
  int left[2] = {r, c - 1};
  int right[2] = {r, c + 1};
  int top[2] = {r - 1, c};
  int bottom[2] = {r + 1, c};

  //change the middle and surrounding spaces
  place(bo, r,c);
  place(bo, left[0],left[1]);
  place(bo, right[0],right[1]);
  place(bo, top[0],top[1]);
  place(bo, bottom[0],bottom[1]);

}

//method that preforms a move at the given space
bool move(GameState *bo, int r, int c){
  #ifndef UNSAFE
    sem_wait( semLock );
  #endif
  //make sure r and c are in the board before continuing
  if(isValidPos(r) && isValidPos(c)){
    //update the game board
    playMove(bo, r, c);

    //update the state buffer
    bo->canUndo = true;
    bo->prevMove[0] = r - 48;
    bo->prevMove[1] = c - 48;
    #ifndef UNSAFE
      sem_post( semLock );
    #endif
    return true;
  }
  #ifndef UNSAFE
    sem_post( semLock );
  #endif
  return false;
}

//undos the previous move
bool undo(GameState *bo){
  #ifndef UNSAFE
    sem_wait( semLock );
  #endif
  //make sure we can undo at this point in time
  if(bo->canUndo){
    //use the same method move calls with the previous move
    playMove(bo, bo->prevMove[0],bo->prevMove[1]);
    //can't undo again until player moves again
    bo->canUndo = false;
    #ifndef UNSAFE
      sem_post( semLock );
    #endif
    return true;  
  }
  #ifndef UNSAFE
    sem_post( semLock );
  #endif
  return false;
}

//prints out the game board to standard output
void report(GameState *bo){
  #ifndef UNSAFE
    sem_wait( semLock );
  #endif
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      printf("%c", bo->gameBoard[i][j]);
    }
    printf("%s", "\n");
  }
  #ifndef UNSAFE
    sem_post( semLock );
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ){
    return false;
  }
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );

  return true;
}

int main( int argc, char *argv[] ) {

  //get id from file path to my directory
  key_t id = ftok("/afs/unity.ncsu.edu/users/m/mpwarren", 1);
  //create shared memory
  int shmid = shmget(id, sizeof(GameState), 0);
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  //add shared memory into address space
  GameState * stateBuffer = (GameState *) shmat(shmid, 0, 0); 
  if ( stateBuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  //open semaphore
  semLock = sem_open("/mpwarren-lightsout-lock", 0);
  if(semLock == SEM_FAILED){
    fail("failed creating semaphore");
  }
  //move command
  if(argc == 4 && strcmp(argv[1], "move") == 0){
    //make sure only 1 char is given 
    if(strlen(argv[2]) != 1 || strlen(argv[3]) != 1){
      fail("error");
    }

    //get row and col number
    char r = argv[2][0];
    char c = argv[3][0];

    //make sure indexes are valid in the board
    if(move(stateBuffer, r - 48, c - 48)){
      printf("%s", "success\n");
    }
    else{
      fail("error");
    }
  }
  //undo command
  else if(argc == 2 && strcmp(argv[1], "undo") == 0){
    if(undo(stateBuffer)){
      printf("%s", "success\n");
    }
    else{
      fail("error");
    }
  }
  //report command
  else if(argc == 2 && strcmp(argv[1], "report") == 0){
    report(stateBuffer);
  }
  //test command
  else if (argc == 5 && strcmp(argv[1], "test") == 0){
    if(strlen(argv[3]) != 1 || strlen(argv[4]) != 1){
      fail("error");
    }
    //get n r and c
    int n = atoi(argv[2]);
    if(n <= 0){
      fail("error");
    }
    char r = argv[3][0] - 48;
    char c = argv[4][0] - 48;
    if(test(stateBuffer, n, r, c)){
      printf("%s", "success\n");
    }
    else{
      fail("error");
    }
  }
  else{
    fail("error");
  }

  //detach from shared memory
  shmdt(stateBuffer);
  
  return 0;
}
