#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//the index to give to the worker thread looking for work
int workerIndex = 0;

//flag for when all values have been read in
bool readingComplete = false;

//Semaphores
//halts a thread if there is no work
sem_t isWork;

//only lets 1 thread get an index at a time
sem_t indexLock;

//only lets 1 thread modify the max_sum global variable
sem_t maxLock;

// Read the list of values.
void readList(int workers) {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&isWork);
  }
  readingComplete = true;
  //release all threads waiting on work
  for(int i = 0; i < workers; i++){
    sem_post(&isWork);
  }
}

//All threads call this method to get an index to start at.
//Uses semaphores to have them wait if there are no new values to start at
//if all values have been read, -1 is returned as the index
int giveIndex(){
  sem_wait(&indexLock);
  int returnedIndex;
  //if the program has read all the values and all index have been given out
  if(readingComplete && workerIndex >= vCount){
    returnedIndex = -1;
  }
  //save the next index to be used and increment workerIndex for the next thread
  else{
    returnedIndex = workerIndex;
    workerIndex++;
  }
  sem_post(&indexLock);
  return returnedIndex;
}

//updates the max_sum global variable if the thread found a larger value
void reportMaxSum(int highest){
  sem_wait(&maxLock);
  if(max_sum < highest)
    max_sum = highest;
  sem_post(&maxLock);
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  //holds the highest value the thread found
  int highest = INT_MIN;
  //keep running while there are still indexes to start at
  while(true){
    sem_wait(&isWork);
    //get a new starting index
    int index = giveIndex();
    //break out if -1 is returned (there are no indexes left to start at)
    if(index == -1){
      break;
    }
    //the sum for this starting index
    int sum = vList[index];
    if(sum > highest){
      highest = sum;
    }
    //sum the values from the starting index down to 0
    for(int j = index - 1; j >= 0; j--){
      sum += vList[j];
      if(sum > highest){
        highest = sum;
      }
    }
  }
  //print out report if specified by user
  if(report){
    printf("I’m worker %lu. The maximum sum I found is %d.\n", pthread_self(), highest);
  }
  reportMaxSum(highest);
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //init semaphores
  sem_init(&isWork, 0, 0);
  sem_init(&indexLock, 0, 1);
  sem_init(&maxLock, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, NULL);

  // Then, start getting work for them to do.
  readList(workers);

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
