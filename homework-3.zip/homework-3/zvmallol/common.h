// Height and width of the playing area.
#define GRID_SIZE 5

// Home directory path
#define HOME_DIR "/afs/unity.ncsu.edu/users/z/zvmallol"

// Semaphore name
#define SEM_NAME "/zvmallol-lightsout-lock"

// Project id for ftok
#define PROJ_ID 1

// Base 10 for use in strtol
#define BASE_10 10

// Struct to store the game's information
typedef struct {
  // Current state of the board
  char currentBoard[GRID_SIZE][GRID_SIZE + 1];
  // Last state of the board (supports undo)
  char lastBoard[GRID_SIZE][GRID_SIZE + 1];
  // If an undo move can be made
  bool canUndo;
} GameState;