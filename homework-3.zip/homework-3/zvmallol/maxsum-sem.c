// See man feature_test_macros(7) and man sem_timedwait
// defining _XOPEN_SOURCE as 699 avoids a compiler warning
// about implicit declaration of the function sem_timedwait.
// Including features.h is also needed
#define _XOPEN_SOURCE 699
#include <features.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <time.h>

// Wait time for sem_timewait() in getWork()
#define QUARTER_SEC_IN_NSEC 250000000

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Next index to give to a worker as work
int nextIndex = 0;

// All values have been read in
bool allValsRead = false;

// Semaphore for accessing the next index to give out
sem_t accessNextIndex;

// Semaphore for the buffer - how many values are available to
// give out
sem_t valsInBuffer;

// Max sum lock
sem_t maxSumLock;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&valsInBuffer);
  }
}

/** 
 * Returns the index of a new value the worker is responsible for.
 * Returns -1 if there is no more work to do
 * Waits if there is more work, but it has not been read in.
 */
int getWork() {
  if(allValsRead && nextIndex >= vCount) {
    return -1;
  }
  // How long we should wait before making sure another
  // thread didn't grab the last bit of work
  struct timespec waitTime;
  waitTime.tv_sec = 0;
  waitTime.tv_nsec = QUARTER_SEC_IN_NSEC;

  // CRITICAL SECTION BEGIN

  // Because another thread can take the last bit of work
  // while waiting on more values in the buffer, we do a 
  // timed wait and check every .25 seconds to make sure
  // all the work hasn't already been given out.
  // Credit to man pages for teaching me about timed wait
  // and timespec
  while(sem_timedwait(&valsInBuffer, &waitTime) == -1) {
    if(allValsRead && nextIndex >= vCount) {
      return -1;
    }
  }
  // Lock up the next index variable too so the same work
  // isn't given out twice
  sem_wait(&accessNextIndex);
  int rtn = nextIndex;
  nextIndex++;
  
  // CRITICAL SECTION END
  sem_post(&accessNextIndex);
  // Return next index
  return rtn;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int idx = getWork();
  int sum = 0;
  int localMax = INT_MIN;
  while(idx > -1) {
    // Instead of counting up, count down to get
    // local maxes/sums
    for(int i = idx; i >= 0; i--) {
      sum += vList[i];
      if(sum > localMax) {
        localMax = sum;
      }
    }
    sum = 0;
    idx = getWork();
  }

  // Report if needed
  if(report) {
    printf("I'm thread %d. The maximum sum I found is %d.\n", (int)pthread_self(), localMax);
  }

  // Lock up the max sum to check if it's less than our
  // local max, update if needed
  sem_wait(&maxSumLock);
  if(localMax > max_sum) {
    max_sum = localMax;
  }
  sem_post(&maxSumLock);

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Initialize the semaphores
  // accessNextIndex should allow access from start
  sem_init(&accessNextIndex, 0, 1);
  // Start with no vals in buffer
  sem_init(&valsInBuffer, 0, 0);
  // max sum should be accessible from start
  sem_init(&maxSumLock, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if(pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0) {
      fail("Can't create a child thread\n");
    }
  }
  
  // Then, start getting work for them to do.
  readList();

  // Let getWork know there is nothing else to be read
  allValsRead = true;

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  sem_close(&maxSumLock);
  sem_close(&valsInBuffer);
  sem_close(&accessNextIndex);
  
  return EXIT_SUCCESS;
}
