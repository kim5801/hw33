#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Named semaphore to lock the game board
sem_t *boardLock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int row, int col ) {
  // Check argument validity
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE) {
    return false;
  }

  #ifndef UNSAFE
    sem_wait( boardLock );
  #endif

  // Copy over current board to last board to support undo
  for(int i = 0; i < GRID_SIZE; i++) {
    strcpy(state->lastBoard[i], state->currentBoard[i]);
  }

  // Make move
  // Toggle light above the square
  if(row - 1 >= 0) {
    switch(state->currentBoard[row - 1][col]) {
      case '*':
        state->currentBoard[row - 1][col] = '.';
        break;
      default:
        state->currentBoard[row - 1][col] = '*';
        break;
    }
  }

  // Toggle light under the square
  if(row + 1 < GRID_SIZE) {
    switch(state->currentBoard[row + 1][col]) {
      case '*':
        state->currentBoard[row + 1][col] = '.';
        break;
      default:
        state->currentBoard[row + 1][col] = '*';
        break;
    }
  }

  // Toggle light to left of square
  if(col - 1 >= 0) {
    switch(state->currentBoard[row][col - 1]) {
      case '*':
        state->currentBoard[row][col - 1] = '.';
        break;
      default:
        state->currentBoard[row][col - 1] = '*';
        break;
    }
  }

  // Toggle light to right of square
  if(col + 1 < GRID_SIZE) {
    switch(state->currentBoard[row][col + 1]) {
      case '*':
        state->currentBoard[row][col + 1] = '.';
        break;
      default:
        state->currentBoard[row][col + 1] = '*';
        break;
    }
  }

  // Toggle light in square
  switch(state->currentBoard[row][col]) {
    case '*':
      state->currentBoard[row][col] = '.';
      break;
    default:
      state->currentBoard[row][col] = '*';
      break;
  }

  // Set undo to true
  state->canUndo = true;
  #ifndef UNSAFE
    sem_post( boardLock );
  #endif
  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ) {
  #ifndef UNSAFE
    sem_wait( boardLock );
  #endif
  if(state->canUndo) {
    state->canUndo = false;
    for(int i = 0; i < GRID_SIZE; i++) {
      strcpy(state->currentBoard[i], state->lastBoard[i]);
    }
    return true;
  }
  return false;
  #ifndef UNSAFE
    sem_post( boardLock );
  #endif
}

// Print the current state of the board.
void report( GameState *state ) {
  #ifndef UNSAFE
    sem_wait( boardLock );
  #endif
  for(int i = 0; i < GRID_SIZE; i++) {
    printf("%s\n", state->currentBoard[i]);
  }
  #ifndef UNSAFE
    sem_post( boardLock );
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }
  return true;
}

int main( int argc, char *argv[] ) {
  // check for invalid args
  // based on my hw1 implementation
  if(argc < 2 || argc > 5) {
    fail("error");
  }

  // Get already created shared memory
  key_t key = ftok(HOME_DIR, PROJ_ID);
  int shmid = shmget(key, 0, 0);
  if(shmid == -1) {
    fail("Problem opening shared memory");
  }
  GameState *game = (GameState *)shmat(shmid, 0, 0);

  // Get the named semaphore
  boardLock = sem_open(SEM_NAME, 0);
  if(boardLock == SEM_FAILED) {
    fail("Problem opening semaphore");
  }

  // Below code is based on hw1 and hw2 implementations
  if(strcmp(argv[1], "move") == 0) {
    // Check for movement specific arguments
    if(argc != 4) {
      fail("error");
    }

    // Make sure rows/cols are valid ints
    int row, col;
    errno = 0;
    char *endptr;
    row = strtol(argv[2], &endptr, BASE_10);
    if(*endptr != ' ' && *endptr != '\0') {
      fail("error");
    }
    col = strtol(argv[3], &endptr, BASE_10);
    if(*endptr != ' ' && *endptr != '\0') {
      fail("error");
    }
    if(errno != 0) {
      fail("error");
    }

    bool moveSuccess = move(game, row, col);
    
    if(moveSuccess) {
      printf("success\n");
      exit(EXIT_SUCCESS);
    }
    else {
      fail("error");
    }
  }

  if(strcmp(argv[1], "undo") == 0) {
    // Check for undo specific arg numbers
    if(argc != 2) {
      fail("error");
    }
    
    if(undo(game)) {
      printf("success\n");
      exit(EXIT_SUCCESS);
    }
    else {
      fail("error");
    }
  }

  if(strcmp(argv[1], "report") == 0) {
    if(argc != 2) {
      fail("error");
    }
    report(game);
    exit(EXIT_SUCCESS);
  }

  if(strcmp(argv[1], "test") == 0) {
    // expected args for test
    if(argc != 5) {
      fail("error");
    }

    // get number of moves/row/col
    int numMoves, row, col;
    errno = 0;
    char *endptr;
    numMoves = strtol(argv[2], &endptr, BASE_10);
    if(*endptr != ' ' && *endptr != '\0') {
      fail("error");
    }
    row = strtol(argv[3], &endptr, BASE_10);
    if(*endptr != ' ' && *endptr != '\0') {
      fail("error");
    }
    col = strtol(argv[4], &endptr, BASE_10);
    if(*endptr != ' ' && *endptr != '\0') {
      fail("error");
    }
    if(errno != 0) {
      fail("error");
    }

    bool testSuccess = test(game, numMoves, row, col);
    if(testSuccess) {
      printf("success\n");
      exit(EXIT_SUCCESS);
    }
    fail("error");
  }

  // If none of those if statements eval to true, bad args.
  fail("error");
}
