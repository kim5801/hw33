#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

//state variable created in reset
struct GameState *state;

//semaphore created in reset
sem_t *sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//Turns . to * or * to . given a coordinate
void toggle(int r, int c) {
  if(state->board[r][c] == '.') {
    state->board[r][c] = '*';
  }
  else {
    state->board[r][c] = '.';
  }
}

// Make a move at the given row, column location, returning true
// if successful.
bool move( struct GameState *state, int r, int c ) {

  #ifndef UNSAFE
  sem_wait(sem);
  #endif

  if(r < GRID_SIZE && r >= 0 && c < GRID_SIZE && c >= 0) { //checks coordinate is in bounds

    //toggles coordinate and near by spaces
    toggle(r,c);

    if(r - 1 >= 0) {
      toggle(r - 1, c);
    }
    if(r + 1 < GRID_SIZE) {
      toggle(r + 1, c);
    }
    if(c - 1 >= 0) {
      toggle(r, c - 1);
    }
    if(c + 1 < GRID_SIZE) {
      toggle(r, c + 1);
    }

    //save performed move for undo function
    state->undo[0] = r;
    state->undo[1] = c;
  }
  else {
    return false;
  }

  #ifndef UNSAFE
  sem_post(sem);
  #endif

  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( struct GameState *state ) {

  #ifndef UNSAFE
  sem_wait(sem);
  #endif

  if(state->undo[0] != '\0') { //if there is a saved move, perform move
    int r = state->undo[0];
    int c = state->undo[1];

    //toggles lights  of coordinate and near coordinates
    toggle(r,c);

    if(r - 1 >= 0) {
      toggle(r - 1, c);
    }
    if(r + 1 < GRID_SIZE) {
      toggle(r + 1, c);
    }
    if(c - 1 >= 0) {
      toggle(r, c - 1);
    }
    if(c + 1 < GRID_SIZE) {
      toggle(r, c + 1);
    }

    //clear undo
    state->undo[0] = '\0';
    state->undo[1] = '\0';

  }
  else {
    return false;
  }

  #ifndef UNSAFE
  sem_post(sem);
  #endif

  return true;

}
// Print the current state of the board.
void report( struct GameState *state ) {

  #ifndef UNSAFE
  sem_wait(sem);
  #endif

  for(int i = 0; i < GRID_SIZE; i++) {
    for(int ii = 0; ii < GRID_SIZE; ii++) {
      printf("%c", state->board[i][ii]); //print character from board
    }
    printf("\n"); //print new line after 5 chars
  }
  printf("\n");

  #ifndef UNSAFE
  sem_post(sem);
  #endif

}

// Test interface, for quickly making a given move over and over.
bool test( struct GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }

  return true;
}

int main( int argc, char *argv[] ) {

  if(argc > 5 || argc < 2) { //check number of args
    fail("error");
  }

  //Accesses shared memory
  int id = shmget(ftok("/afs/unity.ncsu.edu/users/a/ampaul", 0), sizeof( struct GameState), 0666);
  state = (struct GameState *)shmat(id, 0, 0);

  sem = sem_open("/ampaul-lightsout-lock", 0);

  if( strcmp(argv[1], "undo") == 0) {

    if(!undo(state)) {
      fail("error");
    }

  }
  else if( strcmp(argv[1], "report") == 0) {

    report(state);

  }
  else if( strcmp(argv[1], "move") == 0 && argc == 4) {

    if(!move(state, atoi(argv[2]), atoi(argv[3]))) {
      fail("error");
    }

  }
  else if( strcmp(argv[1], "test") == 0 && argc == 5) {

    test(state, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));

  }
  else {
    fail("error"); //error if unrecognized command
  }

  shmdt( state );
  sem_close(sem);

  return 0;
}
