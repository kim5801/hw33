#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  if(argc != 2) { //checks for correct number of args
    usage();
  }

  //Create shared memory with unique name
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/ampaul", 0), sizeof( struct GameState ), 0666 | IPC_CREAT);

  //create shared semaphore
  sem_t *sem = sem_open("/ampaul-lightsout-lock", O_CREAT, 0666, 1);

  //Create struct in shared mem
  struct GameState *state = (struct GameState *)shmat(shmid, 0, 0);

  //check state was created successfully
  if ( state == (struct GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  FILE *fp = fopen(argv[1], "r"); //open file for reading

  if(fp == NULL) { //check for valid file
    printf("Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  //loop through entire board
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int ii = 0; ii < GRID_SIZE + 1; ii++) {
      char c = fgetc(fp); //read char from file

      if(c == '*' || c == '.' || c == '\n') {
        if(c != '\n') {
          state->board[i][ii] = c; // if char is not a new line char, the char is added to the board
        }
      }
      else {
        printf("Invalid input file: %s\n", argv[1]); //exits on unaccepted char
        exit(1);
      }

    }
  }

  //Sets initial undo values
  state->undo[0] = '\0';
  state->undo[1] = '\0';

  shmdt( state );


  return 0;
}
