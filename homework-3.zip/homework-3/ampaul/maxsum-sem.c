#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

bool end = false;

bool work = true;

// Maximum sum we've found.
int max_sum = INT_MIN;

//semaphores for accessing global variables and updating max
sem_t update;
sem_t lock;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//Count how many numbers have been checked by maxsum
int workCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;

  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    sem_wait(&lock);
    vList[ vCount++ ] = v;
    sem_post(&lock);

  }
}

//calculate max sum from a given index in vList
static int maxsum(int end) {
  int sum = 0;
  int max = 0;

  for(int i = end; i > 0; i--) { //decrement starting at given index

    sum += vList[i]; //calculate sum

    if(sum > max) {
      max = sum; //replaces previous max
    }
  }

  return max; //return max
}

//Checks given num against current max and updates if needed
void updateMax(int num) {

  sem_wait(&update); //acquire lock

  if(num > max_sum) { //compate to current max
    max_sum = num; //replace max

    if(report) { //print if report is needed
      printf( "I'm thread %ld. The maximum sum I found is %d\n", (long) pthread_self(), num);
    }
  }

  sem_post(&update); //release lock
}

/** Start routine for each worker. */
void *workerRoutine() {

  while(work) { //while there is more work to complete
    int num = 0;
    int max = 0;
    bool working = false;

    sem_wait(&lock); //create lock and chec value of vCount
    if(vCount > workCount && vCount != 0) { //if the count of read values is less than the count of work done
      working = true; //enter maxsum conditional
      num = workCount++; //give index to find max and increment work count
    }
    sem_post(&lock); //exit lock

    if(working) {
      max = maxsum(num); //calculate maxsum
      updateMax(max); //update max
    }

    if(end) { //if all values have been read
      sem_wait(&lock);
      if(vCount == workCount) { //End loop if all values in list have been calculated
        work = false;
      }
      sem_post(&lock);
    }
  }

  pthread_exit(0);
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //Initialize semaphores
  sem_init (&update, 0, 1);
  sem_init (&lock, 0, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL) != 0 )
      fail( "Can't create a new thread\n" );
  }

  // Then, start getting work for them to do.
  readList();
  end = true; //signal reading is done

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  //Close semaphores
  sem_destroy(&lock);
  sem_destroy(&update);

  return EXIT_SUCCESS;
}
