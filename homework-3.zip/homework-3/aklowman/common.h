/**
* @file common.h
* @author Annie Lowman aklowman
*
* File keeps track of constants used by both programs and houses the GameState struct
*/
#include <stdbool.h>
#include <semaphore.h>
/** Constant for the size of the game board*/
#define GRID_SIZE 5
/** Constant for the name space to map the shared memory too*/
#define AFS_NAME "/afs/unity.ncsu.edu/users/a/aklowman"
/** Constant for the proj_id when creating the shared memory*/
#define PROJ_ID 10
/** Constant for the name of the named semaphore*/
#define SEM_NAME "/aklowman-lightsout-lock"

/**
* Struct to keep track of all necessary data for the shared memory
* for this game, including the moves, undo, and gameboard itself
*/
typedef struct {
    /** boolean to keep track of if undo is allowed*/
    bool undo;
    /** Last row to be opperated*/
    int row;
    /** Last column to be opperated on*/
    int col;
    /** Array to keep track of what the game board is*/
    char gameBoard[GRID_SIZE][GRID_SIZE];
    
} GameState;