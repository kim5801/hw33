/**
* @file maxsum-sem.c
* @author Annie Lowman aklowman
*
* Programs calculates the maximum consecutive sum from a list of number.
* Program starts off by creating a specified number of threads, and then
* asking them to start calculating the sum. The list of numbers gets read 
* in gradually, so semaphores are used to ensure that repeat work isn't
* performed by different threads, and that the threads are caluclating the sum
* of all the numbers in the list, as they are being read in.
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

/** semaphore for updating the threads global variable max_sum*/
sem_t update;
/** semaphore for keeping track of when a value has been added to the list*/
sem_t valueAdded;


// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;
// number to keep track of what index in the list to be accessing
int index = 0;

/** Whether or not there are more values left to be reading in from the */
bool noneLeft = false;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post( &valueAdded );
  }
  noneLeft = true;
}

/**
* Function waits for input to be added to the list, and then returns the index of the 
* next value to look at within the list
*
* @return index to be starting from, or -1 if there are no more values to be examined
*/
int getWork() {
    // checks if not all values have been added to the list
    if ( !noneLeft ) {
        // wait if there are currently no new values
        sem_wait( &valueAdded );
        // check and see if there ACTAULLY aren't any new values, done to help threads that might get stuck
        if ( index < vCount  ) {
            return index++;
        } else {
            return -1;
        }
    } // check if all input has been read in, and if not all index's have been accounted for
    else if ( noneLeft && index < vCount ) {
        return index++;
    } // otherwise there are no more values in the list
    else {
        return -1;
    }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // current maximum this thread has accounted for
  int currentMax = INT_MIN;
  // get the first index
  int index = getWork();
  // keep looping through input until no more can be read in
  while (index != -1 ) {
      // local maximum value
      int localMax = 0;
      // fail safe in case and inproper index accidentally gets passed
      if ( index >= vCount ) {
          break;
      } // count backwards from the given index 
      for ( int i = index; i >= 0; i-- ) {
          localMax += vList[i];
          if (localMax > currentMax) {
              currentMax = localMax;
          }
      }
      
      // get the next index
      index = getWork();
  } // print out the report if the report is enabled
  if ( report ) {
       printf( "I'm thread %lu. The maximum sum I found is %d\n", pthread_self(), currentMax );
  }
  // update the value of the maximum sum
  if (currentMax > max_sum) {
      sem_wait( &update ); 
      max_sum = currentMax;
      sem_post( &update );
  }


  return NULL;
}


/**
* Main function performs error checking on the command line arguments, initialized
* the sempahores ot be used later, creates the worker threads to carry out the max sum
* calculation, and then joins the threads at the very end and reports the overall max sum
*
* @param argc number of arguments provided
* @param actual command line arguments
* @return program exit status
*/
int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  
  // initialize the semaphore for updating the maximum sum
  sem_init( &update, 0 , 1 );
  // initializes the semaphore for adding input to the list
  sem_init( &valueAdded, 0, 0 );

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
      pthread_create( worker + i, NULL, workerRoutine, NULL );

  // Then, start getting work for them to do.
  readList();
  
  for ( int i = 0; i < 20; i++ ) {
      sem_post( &valueAdded );
  }

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ] , NULL );
    
  // free the semaphores
  sem_destroy( &update );
  sem_destroy( &valueAdded );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
