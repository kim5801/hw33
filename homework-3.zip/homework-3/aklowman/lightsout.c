/**
* @file lightsout.c
* @author Annie Lowman
*
* File contains the functionality to access the shared memeory, and then
* execute either a more, report, or undo command, as well as perform
* error checking on these commands. Program also includes functionality
* to handle mutual exclusion code. Each time the region of shared memory is
* accessed, if the UNSAFE macro has not been defined in compulation, every
* function accessing the region of shared memory will use the named semaphore
* to keep any other programs out of the region of shared memory, and then
* allow others to enter the region once that function is done accessing the 
* shared memory. This helps avoid race conditions in the program.
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Minumum number of command line arguments*/
#define ARGS_MIN 2
/** Maximum number of command line arguments*/
#define ARGS_MAX 4
/** Number of arguments if the test command is run*/
#define ARGS_TEST 5
/** Upper bound of the array index's*/
#define UPPER_BOUND 4



// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** 
* Function to handle the undo command
*
* @param game reference to the region of shared memory where the GameState is
* @return true if the command was successful
*/
bool undo( GameState *game )
{    
    // open the named semaphore
    sem_t *sem = sem_open( SEM_NAME, 0 ); 
    if ( sem == SEM_FAILED ) {
        fail( "Can't open semaphore" );
    }
    // conditional mutual exclusion code to wait on semaphore ONLY if that option has been enabled
    #ifndef UNSAFE
        sem_wait( sem );
    #endif
    // check to see if undo is allowed currently
    if (!game->undo ) {
       shmdt( game );
       sem_close( sem );
       fail("Illegal action");
    }
    // if undo is allowed, undo!
    int row = game->row;
    int col = game->col;
        
    if (game->gameBoard[row][col] == '.' ) {
       game->gameBoard[row][col] = '*';
    } else {
        game->gameBoard[row][col] = '.';
    }
        
    int oneBack = row - 1;
    if ( oneBack >= 0 ) {
        if (game->gameBoard[oneBack][col] == '.' ) {
            game->gameBoard[oneBack][col] = '*';
        } else {
            game->gameBoard[oneBack][col] = '.';
        }
    }
        
    int oneFor = row + 1;
    if ( oneFor < GRID_SIZE ) {
        if (game->gameBoard[oneFor][col] == '.' ) {
           game->gameBoard[oneFor][col] = '*';
        } else {
            game->gameBoard[oneFor][col] = '.';
        }
    }
        
    int oneUp = col - 1;
    if ( oneUp >= 0 ) {
        if (game->gameBoard[row][oneUp] == '.' ) {
            game->gameBoard[row][oneUp] = '*';
        } else {
           game->gameBoard[row][oneUp] = '.';
        }
    }
      
    int oneDown = col + 1;
    if ( oneDown < GRID_SIZE ) {
       if (game->gameBoard[row][oneDown] == '.' ) {
           game->gameBoard[row][oneDown] = '*';
       } else {
            game->gameBoard[row][oneDown] = '.';
       }
    }
        
    game->undo = false;
    // conditional mutual exclusion code to post semaphore ONLY if that option has been enabled
    #ifndef UNSAFE
        sem_post( sem );
    #endif
    sem_close( sem );
    return true;
}

/** 
* Function to handle the report command
*
* @param game reference to the region of shared memory where the GameState is
*/
void report( GameState *game )
{
    // open the named semaphore
    sem_t *sem = sem_open( SEM_NAME, 0 ); 
    if ( sem == SEM_FAILED ) {
        fail( "Can't open semaphore" );
    }
    // conditional mutual exclusion code to wait on semaphore ONLY if that option has been enabled
    #ifndef UNSAFE
        sem_wait( sem );
    #endif
    // print out the game board
    for ( int i = 0; i < GRID_SIZE; i++ ) {
        for (int j = 0; j < GRID_SIZE; j++ ) {
            printf("%c", game->gameBoard[i][j]);
        }
        printf("\n");
    }
    // conditional mutual exclusion code to post semaphore ONLY if that option has been enabled
    #ifndef UNSAFE
        sem_post( sem );
    #endif
    sem_close( sem );
}

/** 
* Function to handle the move command
*
* @param game reference to the region of shared memory where the GameState is
* @param r row to make the given more in
* @param c column to make the given move in
*/
bool move( GameState *game, int r, int c )
{
    int row = r;
    int col = c;
    // checking if numbers provided are within the correct bounds
    if (row < 0 || row > UPPER_BOUND ) {
        shmdt( game );
        fail("Invalid arguments");
    }
       
    if (col < 0 || col > UPPER_BOUND ) {
        shmdt( game );
        fail("Invalid arguments");
    }
    // assign the GameState row and column to the row and column being moved
    // open the named semaphore
    sem_t *sem = sem_open( SEM_NAME, 0 ); 
    if ( sem == SEM_FAILED ) {
        fail( "Can't open semaphore" );
    }
    // conditional mutual exclusion code to wait on semaphore ONLY if that option has been enabled
    #ifndef UNSAFE
        sem_wait( sem );
    #endif
    
    game->row = row;
    game->col = col;
       
    if (game->gameBoard[row][col] == '.' ) {
        game->gameBoard[row][col] = '*';
    } else {
        game->gameBoard[row][col] = '.';
    }
        
    int oneBack = row - 1;
    if ( oneBack >= 0 ) {
        if (game->gameBoard[oneBack][col] == '.' ) {
            game->gameBoard[oneBack][col] = '*';
        } else {
          game->gameBoard[oneBack][col] = '.';
        }
    }
        
    int oneFor = row + 1;
    if ( oneFor < GRID_SIZE ) {
        if (game->gameBoard[oneFor][col] == '.' ) {
            game->gameBoard[oneFor][col] = '*';
       } else {
            game->gameBoard[oneFor][col] = '.';
       }
    }
        
    int oneUp = col - 1;
    if ( oneUp >= 0 ) {
        if (game->gameBoard[row][oneUp] == '.' ) {
           game->gameBoard[row][oneUp] = '*';
        } else {
            game->gameBoard[row][oneUp] = '.';
       }
    }
        
    int oneDown = col + 1;
    if ( oneDown < GRID_SIZE ) {
        if (game->gameBoard[row][oneDown] == '.' ) {
            game->gameBoard[row][oneDown] = '*';
        } else {
           game->gameBoard[row][oneDown] = '.';
        }
    }
        
    game->undo = true;
    // conditional mutual exclusion code to post semaphore ONLY if that option has been enabled
    #ifndef UNSAFE
        sem_post( sem );
    #endif
    sem_close( sem );
    return true;
}


/** 
* Test interface, for quickly making a given move over and over
*
* @param state reference to the region of shared memory where the GameState is
* @param n number of times to call the move command
* @param r row the make the move in
* @param c column to make the move in
* @return true if given arguments are valid and the move has been
* executed, false if arguments are invalid
*/
bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );
    return true;
}

/**
* Main function loads in struct from the section of shared memory, and then
* performs error checking the make sure that the given command line arguments
* are valid. The function then executres the given command for either executing
* a move command, printing out a the current game board, or undoing the previous command.
* The program exits after executing one command.
*
* @param argc number of command line arguments
* @param argv command line arguments
* @return program exit status
*/
int main( int argc, char *argv[] ) {
    
    // check number of arguments user supplied
    if ( argc != ARGS_MIN && argc != ARGS_MAX  && argc != ARGS_TEST ) {
        fail("Incorrect number of arguments");
    } 
    // attempt to access the region of shared memory
    int shmid = shmget( ftok( AFS_NAME, PROJ_ID ), 0, 0 );
    if ( shmid == -1 ) {
        fail( "Can't create shared memory" );
    }
    // cast the region of memeory to be a GameState struct
    GameState *game = ( GameState * )shmat( shmid, 0, 0 );
    if ( game == (GameState * ) -1 ) {
        fail ("Can't map shared memory segment into address space" );
    }
    
    // handle the functionality for the undo command
    if ( strcmp ( "undo", argv[ 1 ] ) == 0 )  {
        // check to ensure args are correct
        if ( argc != ARGS_MIN ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        bool ret = undo( game );
        if ( ret ) {
            printf("success\n");
        }
        
        
    } // handle the functionality for the report command
    else if (strcmp( "report", argv[1] ) == 0 ) {
        // check for valid number of arguments
        if (argc != ARGS_MIN ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        report( game );
        
        
    } // handle the functionality for the move command
    else if ( strcmp("move", argv[1] ) == 0 ) {
        if ( argc != ARGS_MAX ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        
        int row;
        int result = sscanf( argv[ 2 ], "%d", &row );
        if (result != 1) {
            shmdt( game );
            fail("Invalid arguments");
        }
        int col;
        result = sscanf( argv[ 3 ], "%d", &col );
        if (result != 1) {
            shmdt( game );
            fail("Invalid arguments");
        }
        move( game, row, col );
        printf("success\n");
    } // handle if the given command line argument is test
    else if ( strcmp("test", argv[1] ) == 0 ) {
        // check for valid number of arguments for testing
        if (argc != ARGS_TEST ) {
            shmdt( game );
            fail("Invalid arguments");
        }    
        // get the number of iterations to call move
        int n;
        int result = sscanf( argv[2], "%d", &n );
        if ( result != 1 ) {
            shmdt( game );
            fail("Invalid arguments");
        }    
        // get row number
        int r;
        result = sscanf( argv[3], "%d", &r );
        if ( result != 1 ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        // get column number
        int c;
        result = sscanf( argv[4], "%d", &c );
        if ( result != 1 ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        // call test function with given arguments
        bool ret = test ( game, n , r, c );
        if (!ret ) {
             shmdt( game );
            fail("Invalid arguments");
        }
        
    } // handle if the given command line argument is not one of the 3 valid commands
    else {
        shmdt( game );
        fail("Invalid arguments");
    }
    
    

    return 0;
}
