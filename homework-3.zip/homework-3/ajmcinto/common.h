/**
 *  @file common.h
 *  @author Adam McIntosh
 *  a file with implementation details common to lightsout.c and reset.c
 */


// Height and width of the playing area.
#define GRID_SIZE 5

/** the struct for our game state */
typedef struct
{

  /** the game board as a 2d array of chars */
  char boardArr[GRID_SIZE][GRID_SIZE];

  /** last move is just the location of the last move, with a bucket for each coordinate */
  int lastMove[2];

} GameState;