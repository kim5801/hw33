#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <sys/types.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum-sem <workers>\n");
  printf("       maxsum-sem <workers> report\n");
  exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// the most recent value up to which threads have computed max sums
int upTo = 0;

// a lock for the upTo variable
sem_t upToLock;

// a lock for the max sum variable
sem_t maxSumLock;

// a semaphore that says how many new values have not been processed
sem_t newValues;

// Read the list of values.
void readList()
{
  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1)
  {

    // Make sure we have enough room, then store the latest input.
    if (vCount > MAX_VALUES)
      fail("Too many input values");
    // Store the latest value.
    vList[vCount++] = v;
    sem_post(&newValues);
  }
  // we have seen the end of the input, put INT_MIN
  vList[vCount] = INT_MIN;
  sem_post(&newValues);
}

/**
 * Returns immediately if there is work for a thread to do,
 * otherwise it returns the index within vList that the worker is responsible
 * for computing sums up to
 * @return the index of the value a thread is responsible for
 */
int getWork()
{
  // wait until there are values to be processed
  sem_wait(&newValues);

  // lock upTo while we will be accessing it
  sem_wait(&upToLock);
  int ret = 0;
  if (upTo < vCount) {
    ret = upTo++;
  }
  else {
    ret = upTo;
  }
  // other threads are free to use the locks
  sem_post(&upToLock);

  return ret;
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
  int localMax = INT_MIN;
  while (true)
  {
    sem_wait(&upToLock);
    if (upTo == -1) {
      break;
    }
    // other threads are free to use the lock
    sem_post(&upToLock);
    int lastIndex = getWork();
    if (vList[lastIndex] == INT_MIN) {
      break;
    }
    // compute every sum that ends at this index
    int currSum = 0;
    for (int i = lastIndex; i >= 0; i--)
    {
      currSum += vList[i];
      if (currSum > localMax)
      {
        // see if the current sum is the largest we have seen thus far
        localMax = currSum;
      }
    }

    // see if the largest sum this thread saw is larger than the largest sum
    // that any thread has seen
    if (localMax > max_sum)
    {
      sem_wait(&maxSumLock);
      max_sum = localMax;
      sem_post(&maxSumLock);
    }
  }
  //increment newValues in case other threads were waiting while we finished
  sem_post(&newValues);
  // give a report if we ought to
  if (report)
  {
    // I just gave each of my threads a unique number from 0 to workers - 1
    // I hope this is acceptable
    printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), localMax);
  }
  return NULL;
}

/**
 * Starts the program that computes the maximum sum
 * among sequences within the input
 *
 * @param argc the number of command-line arguments
 * @param argv the command-line arguments
 * @return int the exit status of the program
 */
int main(int argc, char *argv[])
{

  // default number of workers
  int workers = 4;

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 ||
      workers < 1)
    usage();

  // If there's a second argument, it better be "report"
  if (argc == 3)
  {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  // initialize semaphores
  sem_init(&maxSumLock, 0, 1);
  sem_init(&upToLock, 0, 1);
  sem_init(&newValues, 0, 0);

  int ids[workers];
  for (int i = 0; i < workers; i++)
  {
    ids[i] = i;
  }
  // Make each of the workers.
  pthread_t worker[workers];
  for (int i = 0; i < workers; i++)
  {
    pthread_create(&worker[i], NULL, workerRoutine, &ids[i]);
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for (int i = 0; i < workers; i++)
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf("Maximum Sum: %d\n", max_sum);

  // destroy semaphores
  sem_destroy(&maxSumLock);
  sem_destroy(&upToLock);
  sem_destroy(&newValues);

  return EXIT_SUCCESS;
}