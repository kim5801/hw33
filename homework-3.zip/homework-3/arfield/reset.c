#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <sys/stat.h>
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  if ( argc != 2 ) {
    usage();
  }
  FILE *fp = fopen( argv[ 1 ], "r" );
  //read through file if able to open or exit in error if file was bad
  if ( !fp ) {
    char errorMessage[ sizeof("Invalid input file: ") + sizeof(argv[1]) ];
    strcat(errorMessage, "Invalid input file : ");
    strcat(errorMessage, argv[1]);
    fail( errorMessage );
  } else {
    
    sem_open("/arfield-lightsout-lock", O_CREAT, S_IRUSR | S_IWUSR, 1);
    
    State *game;  
  
    int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/a/arfield", 5 ), sizeof(game), 0666 | IPC_CREAT );
    if ( shmid == -1 ) {
      fail( "shmget failed" );
    }
    game = (State *)shmat( shmid, 0, 0 );
    if ( game == (State *)-1 )
      fail( "failed to attach game" );

    char ch;
    int row = 0;
    int col = 0;
    //Read through initial input, throw error if file contains bad chars or is too large
    while ( fscanf( fp, "%c", &ch ) == 1 ) {
      if ( ch != '\n' && ch != EOF ) {
        if ( ch != '*' && ch != '.' ) {
          char errorMessage[ sizeof("Invalid input file: ") + sizeof(argv[1]) ];
          strcat(errorMessage, "Invalid input file: ");
          strcat(errorMessage, argv[1]);
          fail( errorMessage );
        }
        game->board[ row ][ col ] = ch;
       
        col++;
        if ( col == GRID_SIZE ) {
          row++;
          col = 0;
          if ( row > GRID_SIZE ) {
            char errorMessage[ sizeof("Invalid input file: ") + sizeof(argv[1]) ];
            strcat(errorMessage, "Invalid input file: ");
            strcat(errorMessage, argv[1]);
            fail( errorMessage );
          }
        }
      }
    }
    
    shmdt( game );
  }

  return 0;
}
