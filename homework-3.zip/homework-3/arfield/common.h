// Height and width of the playing area.
#define GRID_SIZE 5

//Struct for game state, contains state of board and last move position
typedef struct GameState {
  char board[ GRID_SIZE ][ GRID_SIZE ];
  int lastMove[ 2 ];
} State;
