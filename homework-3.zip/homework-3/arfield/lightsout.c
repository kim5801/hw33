#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"
#include <semaphore.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//game state pointer that will grab shared mem
static State *game;

sem_t *protect;

/**
 * Updates position at board( r, c ) and the surrounding cells to the opposite of their current values 
 */
static void makeMove( int r, int c) {
  //Loop through cells surrounding the move position and update the character of the cardinal cells
  //if the row or col is out of bounds skip that column and row combination
  for (int row = r - 1; row <= r + 1; row ++) {
    for (int col = c - 1; col <= c + 1; col++ ) {
      //check that we are in a valid row and col
      if ( row >= 0 && row < GRID_SIZE && col >= 0 && col < GRID_SIZE ) {
        //exclude noncardinal cells
        if( row == r || col == c ) {
          //perform swap operation
          if ( game->board[ row ][ col ] == '*' ) {
            game->board[ row ][ col ] = '.';
          } else {
            game->board[ row ][ col ] = '*';
          }
        }
      }
    }
  }
}

/**
 *  Prints Board state to terminal
 */
static void report() {
  #ifndef UNSAFE
    sem_wait( protect );
  #endif
  for( int r = 0; r < GRID_SIZE; r++ ) {
    for( int c = 0; c < GRID_SIZE; c++ ) {
      printf( "%c", game->board[r][c] );
    }
    printf("\n");
  }
  
  #ifndef UNSAFE
    sem_post( protect );
  #endif
}

/**
 * Checks if char array is made solely of digits
 */
static bool isNumber( char *num ) {
  for(int i = 0; num[i] != '\0'; i++ ) {
    if(!isdigit(num[i]))
      return false;
  }
  return true;
}

bool move( State *state, int r, int c ) {
  if ( r >= GRID_SIZE || r < 0 || c >= GRID_SIZE || c < 0 ) {
    return false;
  }
  #ifndef UNSAFE
    sem_wait( protect );
  #endif

  makeMove( r, c );
  game->lastMove[0] = r;
  game->lastMove[1] = c;
  
  #ifndef UNSAFE
    sem_post( protect );
  #endif
  return true;
}

bool undo( State *state ) {
  #ifndef UNSAFE
    sem_wait( protect );
  #endif
  
  if ( game->lastMove[0] == GRID_SIZE || game->lastMove[1] == GRID_SIZE ) {
    sem_post( protect );
    return false;
  } else {
    makeMove( game->lastMove[0], game->lastMove[1] );
    game->lastMove[0] = GRID_SIZE;
    game->lastMove[1] = GRID_SIZE;
  }
  
  #ifndef UNSAFE
    sem_post( protect );
  #endif
  return true;
}

/**
 * repeatedly attempts to run the move command to test race condition
 */
bool test( State *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

int main( int argc, char *argv[] ) {
  // Checks that argnumber and command are a valid combination
  if ( argc < 2 || argc > 5 || ( strcmp( argv[1], "move" ) == 0 && argc != 4) ||
      ((strcmp( argv[1], "undo" ) == 0 || strcmp( argv[1], "report" ) == 0) && argc != 2) || 
      ((strcmp( argv[1], "test" ) == 0) && argc != 5)) {
    fail("error");
  }
  
  //get shared memory
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/a/arfield", 5 ), 0, 0 );
  if ( shmid == -1 )
    fail( "shmget failed" );

  game = (State *)shmat( shmid, 0, 0 );
  if ( game == (State *)-1 )
    fail( "failed to attach game" );

  //open named semaphore
  protect = sem_open("/arfield-lightsout-lock", 0);
  
  if ( strcmp( argv[1], "move" ) == 0 ) {
    //Call move command, takes 2 additional arguments for row and col of move
    //error if row and col args not numeric
    if ( !isNumber(argv[2]) || !isNumber(argv[3])) {
      fail("error");
    }
       
    if ( !move( game, atoi( argv[2] ), atoi( argv[3] ) )) {
      fail( "error" );
    }
    printf( "success\n" );
  } else if ( strcmp( argv[1], "undo" ) == 0 ) {
    if ( !undo( game ) ) {
      fail( "error" );
    }
    printf( "success\n" );
  } else if ( strcmp( argv[1], "report" ) == 0 ) {
    report();
  } else if ( strcmp( argv[1], "test" ) == 0 ) {
    if (!test( game, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]) )) {
      fail("error");
    }
  }

  shmdt( game );
  return 0;
}
