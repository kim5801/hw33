#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"


//global variable for other functions to access
GameState *lightsout;

sem_t *sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//helper method for moving current board to previous
void boardtoPrev() {
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            lightsout->prev[i * GRID_SIZE + j] = lightsout->board[i * GRID_SIZE + j];
        }
    }
}

//for handling move
bool move(GameState *state, int r, int c) {
    #ifndef UNSAFE
      sem_wait( sem );
    #endif
    //move current to previous before changing anything
    boardtoPrev();

    //calculate 2d indecies to 1d
    int idx = r * GRID_SIZE + c;
    
    //user ternary to change given index
    state->board[idx] = (state->board[idx] == '.') ? '*' : '.';

    //check above
    if (idx - 5 >= 0) {
      state->board[idx - 5] = (state->board[idx - 5] == '.') ? '*' : '.';
    }
    //check below
    if (idx + 5 < 30) {
      state->board[idx + 5] = (state->board[idx + 5] == '.') ? '*' : '.';
    }
    //check left
    if (idx - 1 >= 0) {
      if (idx % 5 != 0) {
        state->board[idx - 1] = (state->board[idx - 1] == '.') ? '*' : '.';
      }
    }

    //check right
    if (idx + 1 < 30) {
      if (idx % 4 != 0) {
        state->board[idx + 1] = (state->board[idx + 1] == '.') ? '*' : '.';
      }
    }

    //now that a move has been made, you can undo it
    state->canUndo = true;
    #ifndef UNSAFE
      sem_post( sem );
    #endif

    //move current to previous before changing anything
    return true;
}

bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ ) {
    move( state, r, c );
  }
  return true;
}

bool undoMove(GameState *state) {
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  //if you can you can...
  if (!state->canUndo) {
    fail("error");
  }

  //move prev board to current
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      state->board[i * GRID_SIZE + j] = state->prev[i * GRID_SIZE + j];
    }
  }

  //make sure you can't undo a move again
  state->canUndo = false;
  return true;
}

void report(GameState *state) {
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  //print out
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
        putchar(state->board[i * GRID_SIZE + j]);
    }
    putchar('\n');
  }

  #ifndef UNSAFE
    sem_post( sem );
  #endif
}

int main( int argc, char *argv[] ) {
  sem = sem_open( "/manguyen-lightout-lock", 0 );
  //provide usage failure
  if (argc < 2 || argc > 5 || argc == 3) {
    fail("error");
  }

  key_t key;
  key = ftok(PATHNAME, 1738); //the key, shoutout Fetty Wap
  int shmID = shmget(key, 0, 0);
  if (shmID == -1) {
    fail("error");
  }

  //get the shared memory and store in global var
  lightsout = (GameState *) shmat(shmID, 0, 0);
  if (strcmp(argv[1], "move") == 0) {
    int r;
    int c;
    //scan in coordinates and check if properly scanned
    if (sscanf(argv[2], "%d", &r) != 1 || sscanf(argv[3], "%d", &c) != 1 ) {
        fail("error");
    }

    //then check if coordinates fall in between 0 &  4, inclusive
    if (r < 0 || r > 4 || c < 0 || c > 4) {
        fail("error");
    }
    //after checking everything, you can now move
    move(lightsout, r, c);
  } else if (strcmp(argv[1], "undo") == 0) {
    undoMove(lightsout);
  } else if(strcmp(argv[1], "report") == 0) {
    report(lightsout);
  } else if(strcmp(argv[1], "test") == 0) {
    int r;
    int c;
    int n;
    //scan in coordinates and check if properly scanned
    if (sscanf(argv[2], "%d", &n) != 1 || sscanf(argv[3], "%d", &r) != 1 || sscanf(argv[4], "%d", &c) != 1) {
        fail("error");
    }

    //then check if coordinates fall in between 0 &  4, inclusive
    if (n < 0) {
        fail("error");
    }

    test(lightsout, n, r, c);
  } else {
    fail("error");
  }
  return 0;
}
