#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

static void invalidFile( char const *filename ) {
  fprintf( stderr, "Invalid input file: %s\n", filename );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  sem_unlink( "/manguyen-lightsout-lock" );
  sem_t *sem = sem_open( "/manguyen-lightout-lock", O_CREAT, 0600, 0 );

  //need only 2 args
  if (argc != 2) {
    usage();
  }

  //open file and check if valid
  FILE *fp;
  if ( ( fp = fopen( argv[1], "r" ) ) == NULL ) {
    invalidFile(argv[1]);
  }

  key_t key;
  key = ftok(PATHNAME, 1738); //the key
  int shmID = shmget(key, BLOCK_SIZE, 0666 | IPC_CREAT); //create share memory ID

  //share the memory and make sure it worked
  GameState *lightsout = (GameState *) shmat(shmID, 0, 0);
  if (lightsout == (GameState *) -1) {
    fail("error");
  }

  //initialize the canUndo to false
  lightsout->canUndo = false;

  char ch;
  // read in board char by char
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE + 1; j++) {
      ch = fgetc(fp);

      //check if file has bad characters
      if (ch != '*' && ch != '.' && ch != '\n') {
        invalidFile(argv[1]);
      }

      //after ch goes through the gauntlet, it can now assign to array
      lightsout->board[i * GRID_SIZE + j] = ch;
      lightsout->prev[i * GRID_SIZE + j] = ch;
    }
  }

  sem_close( sem );
  sem_unlink( "/manguyen-lightsout-lock" );
  return 0;
}
