#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
    if (argc != 2) {
        usage();
    }
    //get the board
    char board[GRID_SIZE * GRID_SIZE];
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit( 1 );
    }
    char ch;
    int boardIdx = 0;
    for (int i = 0; i < GRID_SIZE * GRID_SIZE + GRID_SIZE; i++) {
        ch = fgetc(fp);
        if (ch != '\n' && ch != ' ') {
            board[boardIdx] = ch;
            boardIdx++;
        }
    }
    fclose(fp);

    //Create the semaphore
    sem_t *s1 = sem_open("legetkerlightsoutlock", O_CREAT, 0600, 1);
    if (s1 < 0) {
        printf( "Problem with semaphore" );
    } 

    //Create the shared memory segment
    key_t key = ftok("/afs/unity.ncsu.edu/users/l/legetker", 'l');
    int shmid = shmget(key, 1024, 0666 | IPC_CREAT);
    if ( shmid == -1 )
        perror("Shmget error: ");

    char *sbuffer = (char *)shmat( shmid, 0, 0 );
    if ( sbuffer == (char *)-1 )
        perror("Shmat error: ");

    //Copy board to shared memory
    for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
        sbuffer[i] = board[i];
    }

    //sbuffer[ GRID_SIZE * GRID_SIZE - 1 ] = 1; //Indicate that we filled in the buffer
    shmdt( sbuffer );

    
    return 0;

}
