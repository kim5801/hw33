#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//The number of workers
int workers = 4;

//The index to calculate
int idx_counter;

bool workDone = false;

sem_t maxLock;
sem_t gotIndex;


// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  int res = 1;
  while ( res == 1 ) {
    res = scanf( "%d", &v );
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    while(idx_counter < vCount) {
         continue;
    }
  }
  workDone = true;
}

static int getWork() {
  if (workDone) {
    return -1;
  } else {
    return idx_counter;
  }
  
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int localMax = 0;
  int threadMax = 0;
  int maxVal = getWork();
  while (maxVal != -1) { //Work to be done
    localMax = 0;
    //printf("new\n");
    for (int i = maxVal; i >= 0; i--) { //Calculate the max sum
        localMax += vList[i];
        //printf("%d\n", vList[i]);
        if (localMax > threadMax) {
            threadMax = localMax;
        }
    }
    
    sem_wait(&maxLock);
    if (threadMax > max_sum) {
        max_sum = threadMax;
    }
     maxVal = getWork();
     idx_counter++;
    sem_post(&maxLock);
  }
  if (report)
    printf("I'm thread %lu. The maximum I found is %d.\n", pthread_self(), threadMax);
  return NULL;
}

int main( int argc, char *argv[] ) {
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  
  if (sem_init(&maxLock, 1, 1) < 0)
    fail( "Problem with semaphore" );
  if (sem_init(&gotIndex, 1, 1) < 0)
    fail( "Problem with semaphore" );

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, (void *)&i);

  // Then, start getting work for them to do.
  readList();


  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);
    // ...

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
