#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <signal.h>
#include <sys/stat.h>
#include <semaphore.h>

//Game board
char board[GRID_SIZE][GRID_SIZE];

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

static int getBoardIndex(int x, int y) {
    return GRID_SIZE * x + y;
}

int main( int argc, char *argv[] ) {
    key_t key = ftok("/afs/unity.ncsu.edu/users/l/legetker", 'l');
    int shmid = shmget( key, 0, 0);
    if ( shmid == -1 )
        perror("Shmget error: ");
        

    char *sbuffer = (char *)shmat(shmid, 0, 0);
    if (sbuffer == (char *)-1)
        printf( "Problem mapping to shared memory" );

    //Get the semaphore
    sem_t *s1 = sem_open("legetkerlightsoutlock", 0);
    if (s1 == SEM_FAILED) {
        perror("Semaphore error");
    }
    
    //now, implement game logic. 
  int xPos = 0;
  int yPos = 0;
    char buffer[500];
    for (int i = 0; i < argc; i++) {
        strcat(buffer, argv[i]);
        strcat(buffer, " ");
    }
    //break up each arg
    char *words[6];
    int wordCount = 0;
    char *word;
    word = strtok(buffer, " ");
    while (word != NULL) {
        words[wordCount] = word;
        word = strtok(NULL, " ");
        wordCount++;
    }

    bool move = false;
    bool undo = false;
    bool report = false;
    if (strcmp(words[1], "undo") == 0) {
        undo = true;
    } else if (strcmp(words[1], "report") == 0) {
        report = true;
    } else if (strcmp(words[1], "move") == 0) {
        move = true;
        if (words[2][0] < '0' || words[2][0] > '9' || words[3][0] < '0' || words[3][0] > '9') {
            xPos = -1;
            yPos = -1;
        } else {
            xPos = atoi(words[2]);
            yPos = atoi(words[3]);
        }
    }else if (strcmp(words[1], "test") == 0) {
        int n = atoi(words[2]);
        xPos = atoi(words[3]);
        yPos = atoi(words[4]);
        for (int i = 0; i < n; i++) {
            #ifndef UNSAFE
                sem_wait( s1 );
            #endif

             if (sbuffer[getBoardIndex(xPos, yPos)] == '*') {
                sbuffer[getBoardIndex(xPos, yPos)] = '.';
             } else {
                sbuffer[getBoardIndex(xPos, yPos)] = '*';
             }

            #ifndef UNSAFE
                sem_post( s1 );
            #endif
        }
    } else {
        fail("Invalid command");
    }

    if (move) {
        

        if ((xPos < GRID_SIZE && xPos >= 0) && (yPos < GRID_SIZE && yPos >= 0)) {
            #ifndef UNSAFE
                sem_wait( s1 );
            #endif

            sbuffer[getBoardIndex(xPos, yPos)] = '*';

            #ifndef UNSAFE
                sem_post( s1 );
            #endif
            printf("sucess\n");
        } else {
            printf("error\n");
        }


    }
    if (undo) {
        sbuffer[getBoardIndex(xPos, yPos)] = '.';
        printf("sucess\n");
    }
    if (report) {
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                printf("%c", sbuffer[getBoardIndex(i, j)]);
            }
            printf("\n");
        }
    }
    return 0;
}
