/** This code uses threads and semaphores to find the max sum on a file with
 * values
 *
 * @file maxsum-sem.c
 * @author Arnav Sharma
 *
 */

#include <limits.h>
#include <math.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>

// global semaphore
sem_t sAns;

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
    printf("usage: maxsum-sem <workers>\n");
    printf("       maxsum-sem <workers> report\n");
    exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList()
{
    // Keep reading as many values as we can.
    int v;
    report = true;
    while (scanf("%d", &v) == 1) {
        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");
        // Store the latest value.
        vList[vCount++] = v;
    }
    report = false;
}

// variable for keeping vCount change globaly
int place = 0;
// helper method get work is for workers to call this function when they become
// idle
int getWork()
{
    while (report != false) {
        // printf("%d\n", place);
        if (place < vCount) {
            // change value of global variable and more work can be done
            //  the index of the value the worker on
            return place = vCount;
        }
    }
    // special sentinel value to the workers
    return place = 0;
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
    // calls the helper method
    vCount = getWork();
    int newSum = 0;
    while (vCount > 0) {
        for (int j = 0; j < vCount; j++) {
            // make 0 every time to reset
            int oldSum = 0;
            for (int l = j; l < vCount; l++) {

                // adds them
                oldSum = oldSum + vList[l];
                if (newSum < oldSum) {
                    sem_wait(&sAns);
                    newSum = oldSum;
                    max_sum = newSum;
                    sem_post(&sAns);
                }
            }
        }
        vCount = getWork();
        // if (report == true) {
        //     printf("I’m thread %d. The maximum sum I found is "
        //            "%d.\n",
        //            1, newSum);
        // }
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    int workers = 4;

    sem_init(&sAns, 0, 1);

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1)
        usage();

    // If there's a second argument, it better be "report"
    if (argc == 3) {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    // Make each of the workers.
    pthread_t worker[workers];

    for (int i = 0; i < workers; i++)
        pthread_create(&worker[i], NULL, workerRoutine, NULL);

    // Then, start getting work for them to do.
    readList();

    // Wait until all the workers finish.
    for (int i = 0; i < workers; i++)
        pthread_join(worker[i], NULL);

    // Report the max product and release the semaphores.
    printf("Maximum Sum: %d\n", max_sum);
    sem_close(&sAns);
    return EXIT_SUCCESS;
}
