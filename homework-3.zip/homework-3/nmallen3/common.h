// Height and width of the playing area.
#define GRID_SIZE 5

// Represents current state of the lights out game
typedef struct {
    // current state of the board
    char gameBoard[5][5];

    // previous state of the board
    char prevBoard[5][5];

    // if the undone command was given previously
    bool undoneBefore;
} GameState;