/**
 * Dynamically allocates memory for worker threads as data gets read in.
 * Once there is available work for workers to do, they can grab that work and mark that they've done it.
 * The max contiguous sum is found in the array through the worker threads.
 * This uses semaphores to lock the critical areas where workers might accidently access/alter the same thing.
 * @file maxsum-sem.c
 * @author Sania Bolla (sbolla2)
 * @date 2022-10-12
 * 
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter04/lotsOThreads.c
// Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter06/race6.c
// Using slides for synchronization

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter06/race6.c
sem_t emptyCount; // Empty spots in array
sem_t fullCount; // Full spots in array
sem_t lock;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // acquires one of the empty spots in the array.
    sem_wait(&emptyCount);

    // Store the latest value.
    vList[ vCount++ ] = v;

    // Releases on of the full spots in the array
    sem_post(&fullCount);
  }
}

/** Location that indicates upto which index in the array work has been taken */
int location = 1;
/**
 * @brief Gets work from the array as long as there is items in the array that have not already been
 * taken by other threads.
 * 
 * @return int the index of where this thread will do it's work upto, or the dummy value 196700 if it has been reached.
 */
int getWork() {
  sem_wait( &fullCount );
  sem_wait( &lock );
  int val = location - 1;
  location++;
  int number = vList[val];
  // Checking if we've started hitting the dummy values
  if (number == 196700) {
    val = number;
  }
  sem_post( &lock );
  return val;
}

/** Lock that protects the max_sum global variable */
sem_t max_sum_lock;

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // ...
  int workerMax = 0;
  // Get an index where the thread can read upto
  int index = getWork();
  // Want to keep gettign work until we hit dummy values: meaning all real work is done
  while (index != 196700) {
    // Finding the maxSum from this particular array.
    int maxSum = vList[index];
    int currentSum = 0;
    for (int i = index; i >= 0; i--) {
      currentSum = currentSum + vList[i];
      if (currentSum > maxSum) {
        maxSum = currentSum;
      }
    }
    // If this sum is the greatest for the worker
    if (maxSum > workerMax) {
      workerMax = maxSum;
    }
    // Go back and get more work
    index = getWork();
  }
  // Altering the value of the max_sum global variable
  sem_wait(&max_sum_lock);
  if (workerMax > max_sum) {
    max_sum = workerMax;
  }
  sem_post(&max_sum_lock);
  // Reporting the worker max
  if (report) {
    printf("%s%lu%s%d%s", "I'm thread ", pthread_self(), ". The maximum sum I found is ", workerMax, ".\n");
  }
  pthread_exit(EXIT_SUCCESS);
  return NULL;
}

/**
 * @brief Creates worker threads and makes them start a function where all of them will calculate max sums of the 
 * arrays that they are able to get.
 * Starts filling vList with the dummy value 196700 after readList is done so that the threads have an indicator of where to stop 
 * 
 * @param argc number of command line arguments
 * @param argv command line arguments
 * @return int exit value
 */
int main( int argc, char *argv[] ) {
  // Initializing all semaphore values
  sem_init(&emptyCount, 0, MAX_VALUES);
  sem_init(&fullCount, 0, 0);
  sem_init(&lock, 0, 1);
  sem_init(&max_sum_lock, 0, 1);

  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  // Geting worker value
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    // ...
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0 ) 
      fail( "Can't create a child thread\n" );
  }

  // Then, start getting work for them to do.
  readList();

  // Fill the vList array with the 196700 sentinal value
  while (vCount < MAX_VALUES) {
    vList[vCount] = 196700;
    vCount++;
    sem_post(&fullCount);
  }

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    // ...
    pthread_join(worker[i], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
