/**
 * @file lightsout.c
 * @author Sania Bolla (sbolla2)
 * @brief Changes the state of the board based on the choices of the user. The user can choose between report, undo, move, and test.
 * It saves the states in a struct which is in shared memory along with a special sempahore that protects the shared memory from being
 * accessed at the same time.
 * @date 2022-09-29
 * 
 * Using the following...
 * Slides for Synchronization
 * https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter06/tagDest.c
 * https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter06/tagSrc.c
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/** Largest a task can be is 4 chars for test */
#define MAX_TASK_SIZE 3
/** If the user inputs report or undo */
#define TWO_COMMAND_ARGS 2
/** If the user inputs move with row and column number */
#define FOUR_COMMAND_ARGS 4
/** Using the command line argument at index 2 */
#define COMMAND_AT_TWO 2
/** Using the command line argument at index 3 */
#define COMMAND_AT_THREE 3
/** Third position in either row or column */
#define THIRD_POS 3
/** Fourth position in either row or column */
#define FOURTH_POS 4
/** Largest message limit */
#define MESSAGE_LIMIT 1024
/** Converting the 2D 5X5 board into a 1d one with null terminator and newlines */
#define ONE_D_BOARD 31

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
//static int running = 1;

// Size of the shared block of memory.
const int BLOCK_SIZE = 1024;

// GameState struct
typedef struct GameState {
  char currBoard[GRID_SIZE][GRID_SIZE];
  char previousBoard[GRID_SIZE][GRID_SIZE];
  char output[ONE_D_BOARD];
  bool alreadyHadUndo;
} GameState;

/**
 * @brief Changes the light from either on to off or off to on depending on
 * its current state
 * 
 * @param character is the character that needs to be switched
 * @return char the newly updated light
 */
char changeSign(char character) {
  if (character == '*') {
    character = '.';
  } else if (character == '.') {
    character = '*';
  }
  return character;
}

/**
 * @brief Handles which lights on the board will be switched based on which light is selected
 * 
 * @param board is the board in its current condition
 * @param row is the row selected by the user
 * @param column is the column selected by the user
 */
void changeBoard(char board[GRID_SIZE][GRID_SIZE], int row, int column) {
  board[row][column] = changeSign(board[row][column]);
  if(row >= 1 && row <= THIRD_POS && column >= 1 && column <= THIRD_POS) {
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (row == 0 && column == 0) {
    board[row][column + 1] = changeSign(board[row][column + 1]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
  } else if (row == 0 && column == FOURTH_POS) {
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
  } else if (row == FOURTH_POS && column == 0) {
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (row == FOURTH_POS && column == FOURTH_POS) {
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
  } else if (row == 0) {
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (column == 0) {
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (row == FOURTH_POS){
    board[row][column + 1] = changeSign(board[row][column + 1]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row - 1][column] = changeSign(board[row - 1][column]);
  } else if (column == FOURTH_POS) {
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
  }
}


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Semaphore that protects the GameState from being altered at once */
sem_t *lightsout_lock;
/**
 * @brief Make a move at the given row, column location, returning true if successful.
 * 
 * @param state the GameState shared memory
 * @param r row number
 * @param c column number
 * @return true if the move is able to happen
 * @return false if the move is unsucessful for any reason
 */
bool move( GameState *state, int r, int c ) {
  // UNSAFE constant so that we can remove the semaphore logic if wanted
  #ifndef UNSAFE
    sem_wait(lightsout_lock);
  #endif
  state->alreadyHadUndo = false;
  if (r > FOURTH_POS || c > FOURTH_POS) {
    #ifndef UNSAFE
      sem_post(lightsout_lock);
    #endif
    return false;
  }
  // Save the current version inside previousBoard
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      state->previousBoard[i][j] = state->currBoard[i][j];
    }
  }
  // Adjusts the board accordingly
  changeBoard(state->currBoard, r, c);

  // Moving the 2D board to a 1D version to give back to the client
  int locationInSingle = 0;
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++){
      state->output[locationInSingle] = state->currBoard[i][j];
      locationInSingle++;
    }
    state->output[locationInSingle] = '\n';
    locationInSingle++;
  }
  state->output[locationInSingle] = '\0';
  // UNSAFE constant so that we can remove the semaphore logic if wanted
  #ifndef UNSAFE
    sem_post(lightsout_lock);
  #endif
  return true;
}

/**
 * @brief Undo the most recent move, returning true if successful.
 * 
 * @param state the GameState shared memory
 * @return true if the undo is able to happen
 * @return false if the undo cannot happen because one just previously occured
 */
bool undo( GameState *state ) {
  // UNSAFE constant so that we can remove the semaphore logic if wanted
  #ifndef UNSAFE
    sem_wait(lightsout_lock);
  #endif
  // Making sure the last call was not undo as well else we print error. We set the previous board to the current board
  if (!state->alreadyHadUndo) {
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
        state->currBoard[i][j] = state->previousBoard[i][j];
      }
    }
    state->alreadyHadUndo = true;
    // UNSAFE constant so that we can remove the semaphore logic if wanted
    #ifndef UNSAFE
      sem_post(lightsout_lock);
    #endif
    return true;
  }
  else {
    // UNSAFE constant so that we can remove the semaphore logic if wanted
    #ifndef UNSAFE
      sem_post(lightsout_lock);
    #endif
    return false;
  }
}

/**
 * @brief Print the current state of the board.
 * 
 * @param state the GameState shared memory
 */
void report( GameState *state ) {
  // UNSAFE constant so that we can remove the semaphore logic if wanted
  #ifndef UNSAFE
    sem_wait(lightsout_lock);
  #endif
  int locationInSingle = 0;
  // Putting the current board into the ouput array to be sent over to the client
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++){
      state->output[locationInSingle] = state->currBoard[i][j];
      locationInSingle++;
    }
    state->output[locationInSingle] = '\n';
    locationInSingle++;
  }
  state->output[locationInSingle] = '\0';
  printf("%s", state->output);
  // UNSAFE constant so that we can remove the semaphore logic if wanted
  #ifndef UNSAFE
    sem_post(lightsout_lock);
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}


/**
 * @brief Creates the same key so that shared memory can be a accessed.
 * Reads the users input and performs changes on the board based on the move made.
 * 
 * @param argc is the number of command line arguments passed in
 * @param argv is the array of command line arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {
  // Creates a key with the home directory. I chose a proj_id of 1
  key_t key = ftok("/afs/unity.ncsu.edu/users/s/sbolla2", 1);

  // If key could not be created
  if(key == -1) {
    printf("ftok failed with errno");
    return -1;
  }

  // Getting the piece of shared memory
  int shmid = shmget( key, BLOCK_SIZE, 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  // Attaching the piece of shared memory
  GameState *game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
  
  // Openign the shared sempahore that was created in reset.c
  lightsout_lock = sem_open("/sbolla2-lightsout-lock", 1);

  // Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter06/tagDest.c
  int val = -1;
  sem_getvalue(lightsout_lock, &val);
  if ( lightsout_lock == SEM_FAILED )
    fail( "Can't open tag semaphore" );


  // The task to be performed on the board
  char task[MAX_TASK_SIZE];
  // What needs to be printed out based on what task was given
  char result[MESSAGE_LIMIT];

  // There needs to be either 2 or 4 command line arguments
  if (argc != FOUR_COMMAND_ARGS && argc != TWO_COMMAND_ARGS && argc != 5) {
    fail("error");
  }

  // The task given needs to be one of the following : move, undo, or report
  if (strcmp(argv[1], "move") != 0 && strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0 && strcmp(argv[1], "test") != 0) {
    fail("error");
  }

  // When the command from the user is move
  if (strcmp(argv[1], "move") == 0) {
    if (argc != FOUR_COMMAND_ARGS) {
      fail("error");
    }
    // Check that the two values after move are integers
    int dig1;
    int dig2;
    int len1 = sscanf(argv[COMMAND_AT_TWO], "%d", &dig1);
    int len2 = sscanf(argv[COMMAND_AT_THREE], "%d", &dig2);

    if (len1 != 1 || len2 != 1) {
      fail("error");
    }
    //Putting the task inputted into the command line into an array
    // Using m for simplicity - move
    task[0] = 'm';
    task[1] = argv[COMMAND_AT_TWO][0];
    task[COMMAND_AT_TWO] = argv[COMMAND_AT_THREE][0];
  }
  // When the command from the user is either undo or report
  if (strcmp(argv[1], "undo") == 0 || strcmp(argv[1], "report") == 0) {
    if (argc != TWO_COMMAND_ARGS) {
      fail("error");
    }
    if (strcmp(argv[1], "undo") == 0) {
      // Using u for simplicity - undo
      task[0] = 'u';
    } else {
      // Using r for simplicity - report
      task[0] = 'r';
    }
    task[1] = 0;
    task[COMMAND_AT_TWO] = 0;
  } if (strcmp(argv[1], "test") == 0) {
      if (argc != 5) {
        fail("error");
      }
      // Check that the two values after test are integers
      int dig1;
      int dig2;
      int dig3;
      int len1 = sscanf(argv[COMMAND_AT_TWO], "%d", &dig1);
      int len2 = sscanf(argv[COMMAND_AT_THREE], "%d", &dig2);
      int len3 = sscanf(argv[4], "%d", &dig3);

      if (len1 != 1 || len2 != 1 || len3 != 1) {
        fail("error");
      }
      task[0] = 't';
      task[1] = argv[COMMAND_AT_THREE][0];
      task[2] = argv[4][0];
  }

  // ...
  // Handles the situation where the user calls "move"
  if (task[0] == 'm') {
    int rowVal = task[1] - '0';
    int colVal = task[2] - '0';
    bool valid = move(game, rowVal, colVal);
    if (!valid) {
      strcpy(result, "error\n");
      printf("%s", result);
      return 0;
    } else {
      strcpy(result, "success\n");
      printf("%s", result);
    }
  }
  // Handles the situation where the user calls "undo"
  else if (task[0] == 'u') {
    // Making sure the last call was not undo as well else we print error. We set the previous board to the current board
    bool valid = undo(game);
    if (valid) {
      strcpy(result, "success\n");
    }
    else {
      strcpy(result, "error\n");
    }
    printf("%s", result);
  }
  // Handles the situation where the user calls "report"
  else if (task[0] == 'r') {
    report(game);
  }
  // Handles the situation where the user calls "test"
  else if (task[0] == 't') {
    int size = strlen(argv[2]);
    int n = argv[2][0] - '0';
    int temp = 0;
    // Converting the number string into an integer
    for (int i = 1; i < size; i++) {
      temp = argv[2][i] - '0';
      n = n * 10;
      n = n + temp;
    }
    int r = task[1] - '0';
    int c = task[2] - '0';
    bool valid = test(game, n, r, c);
    if (!valid) {
      strcpy(result, "error\n");
      printf("%s", result);
      return 0;
    }
  }

  // Release our reference to the shared memory segment.
  shmdt( game );

  return 0;
}
