/**
 * @file reset.c
 * @author Sania Bolla (sbolla2)
 * @brief Initializes the game board by reading in the original board from a file.
 * It saves this board (contained in a struct) into a piece of memory
 * 
 * Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter03/shmReader.c
 * Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter03/shmWriter.c
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Size of the shared block of memory.
const int BLOCK_SIZE = 1024;

/**
 * GameState struct that contains the current version of the board, the previous version of the board, 
 * the output that is collected based on user command, and the boolean for whether the user has previously called
 * undo or not.
 */
typedef struct GameState {
  char currBoard[GRID_SIZE][GRID_SIZE];
  char previousBoard[GRID_SIZE][GRID_SIZE];
  char output[31];
  bool alreadyHadUndo;
} GameState;

sem_t * lightsout_lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * @brief Allocates a section of memory for the GameBoard struct.
 * Uses this piece of memory to communicate with the lightsout.c function
 * Reads the contents of a file containing the original board into the currBoard array
 * 
 * @param argc is the number of command line arguments passed in
 * @param argv is the array of command line arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {
  // Creates a key with the home directory. I chose a proj_id of 1
  key_t key = ftok("/afs/unity.ncsu.edu/users/s/sbolla2", 1);

  // If key could not be created
  if(key == -1) {
    printf("ftok failed with errno");
    return -1;
  }

  // Getting the piece of shared memory
  int shmid = shmget( key, BLOCK_SIZE, 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  
  // Attaching the piece of shared memory
  GameState *game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
  
  sem_unlink( "/sbolla2-lightsout-lock" );
  lightsout_lock = sem_open("/sbolla2-lightsout-lock", O_CREAT, 0600, 1);
  int val = -1;
  sem_getvalue(lightsout_lock, &val);
  if ( lightsout_lock == SEM_FAILED )
    fail( "Can't open tag semaphore" );


  // If exactly two command line arguments are not given
  if (argc != 2) {
    usage();
  }

  // Opening up the board from the file that contains it
  FILE *board = fopen(argv[1], "r");
  if (board == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  // Making sure the file contents are correct.
  // If the file does not have the board formatted how we want it file content correct turns to false and then invalid file will be printed
  bool fileContentsCorrect = true;
  char curr = fgetc(board);
  int newLineCount = 0;
  int lineCount = 0;
  int rowLoc = 0;
  int colLoc = 0;
  while (curr != EOF) {
    if (curr != '.' && curr != '*' && curr != '\n') {
      fileContentsCorrect = false;
    }
    if (curr == '\n') {
      newLineCount++;
      if (lineCount != GRID_SIZE || newLineCount > GRID_SIZE) {
        fileContentsCorrect = false;
      }
      lineCount = 0;
      rowLoc++;
      colLoc = 0;
    } else {
      game->currBoard[rowLoc][colLoc] = curr;
      colLoc++;
      lineCount++;
    }
    curr = fgetc(board);
  }
  // If file contents are messed up (not 5X5 and other things)
  if (!fileContentsCorrect) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }
  game->alreadyHadUndo = false;

  // Release our reference to the shared memory segment.
  shmdt( game );

  return 0;
}
