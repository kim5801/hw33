/**
   @file lightsout.c
   @author Natalie Kerkado nykerkad
   This program handles the interface of the board that will turn on and off to play the game. 
  */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>


sem_t *mySemaphore;



// Maximum message size for communicating over the queue.
#define MAX_SIZE 1024

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

static void printBoard( struct GameState *board) {
  #ifndef UNSAFE
  sem_wait( mySemaphore );
  #endif
    
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 5; j++) {
      printf("%c", board->board[i][j]);
    }
    printf("\n");
  }
  #ifndef UNSAFE
  sem_post( mySemaphore );
  #endif
}
//This function handles each individual move taking in the game state, the row, and column of the spot that needs editing
static bool move( struct GameState *b, int row, int column ) {
  #ifndef UNSAFE
  sem_wait( mySemaphore );
  #endif
  //sends whats on the current board to last move before making a new board
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 5; j++) {
      b->lastMove[i][j] = b->board[i][j];
    }
  }
    
  //start moving  
  if(b->board[row][column] == '*') {
    b->board[row][column] = '.';
  }
  else {
    b->board[row][column] = '*';
  }
  
  if( row + 1 < GRID_SIZE ) {
    if(b->board[row + 1][column] == '*' ) {
      b->board[row + 1][column] = '.';
    }
    else {
      b->board[row + 1][column] = '*';
    }
  }
  
  if( row > 0 ) {
    if(b->board[row - 1][column] == '*' ) {
      b->board[row - 1][column] = '.';
    }
    else {
      b->board[row - 1][column] = '*';
    }
  }
  
  if( column + 1 < GRID_SIZE ) {
    if(b->board[row][column + 1] == '*' ) {
      b->board[row][column + 1] = '.';
    }
    else {
      b->board[row][column + 1] = '*';
    }
  }
  
  if( column > 0 ) {
    if(b->board[row][column - 1] == '*' ) {
      b->board[row][column - 1] = '.';
    }
    else {
      b->board[row][column - 1] = '*';
    }
  }
  #ifndef UNSAFE
  sem_post( mySemaphore );
  #endif
  return true; 
}
//if there is a last valid move, the board will revert to that move
static bool undo( GameState *state ) {
  #ifndef UNSAFE
  sem_wait( mySemaphore );
  #endif
  if (state->isLast){
    for(int i = 0; i < 5; i++) {
      for(int j = 0; j < 5; j++) {
        state->board[i][j] = state->lastMove[i][j];
      }
    }
  }
  else {
    return false;
  }
  #ifndef UNSAFE
  sem_post( mySemaphore );
  #endif
  return true;
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

int main( int argc, char *argv[] ) {
  mySemaphore = sem_open("/nykerkad-lightsout-lock", 1);
  if(!mySemaphore)
    fail("Unable to create semaphore");
  // Make a shared memory segment 1KB in size --writer
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/n/nykerkad", 1), sizeof( struct GameState ), 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  // Map the shared memory into my address space
  GameState *game = (GameState *)shmat( shmid, 0, 0 );
  if ( !game )
    fail( "Can't map shared memory segment into address space" );
    
  // Read a line of arguments
  char buffer[ MAX_SIZE + 1 ];
  int row;
  int column;
  int n;
  sscanf( argv[1], "%s", buffer );
  
  if( strcmp( buffer, "move") == 0) {
    sscanf( argv[2], "%d", &row );
    sscanf( argv[3], "%d", &column );
    if( row > 4 || row < 0 ) {
      fail("error");
    } 
    if( column > 4 || column < 0 ) {
      fail("error");
    }
    move(game, row, column);
    game->isLast = true;
    printf("success\n");
  }
  
  else if( strcmp( buffer, "undo") == 0 ) {
    //send undo command
    bool worked = undo(game);
    game->isLast = false;
    if(!worked) 
       printf("error\n");
    else
      printf("success\n");
  }
  
  else if( strcmp( buffer, "report") == 0 ) {
    //send report command
    printBoard(game);
  }
  
  else if( strcmp( buffer, "test") == 0 ) {
    sscanf( argv[2], "%d", &n );
    sscanf( argv[3], "%d", &row );
    sscanf( argv[4], "%d", &column );
    if( row > 4 || row < 0 ) {
      fail("error");
    } 
    if( column > 4 || column < 0 ) {
      fail("error");
    }
    if( n < 0 ) {
      fail("error");
    }
    test(game, n, row, column);
  }
  
  else
    fail("error");
  

  shmdt(game);
  return 0;
}
