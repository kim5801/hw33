/**
   @file maxsum-sem.c
   @author Natalie Kerkado nykerkad
   This program makes a specified amount of processes to find the maximum sum of any combination of contiguous numbers in a file
   This time it uses semaphores and threads
  */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <syscall.h>


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

bool done = false;

int index;

int assigned = 0;

int input = 0;

sem_t blockMax;
sem_t read;
sem_t blockGet;
sem_t blockReport;


// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&read);
  }
  
  done = true;
  sem_post(&read);
}
// returns the index that the worker will be doing the addition on
int getWork() {
  int index = assigned;
  assigned++;
  return index;
}



/** Start routine for each worker. 
  Takes into account the addition for reach worker and reports each time it finds a maximum*/
void *workerRoutine( void *arg ) {
  
  int threadSum = INT_MIN;
  
  while(true) {
    if(done && vCount < assigned ) {
        return NULL;
    }
    sem_wait(&read);  
      
      int total = 0;
      //block access to changing max_sum and to making each sets of addition
      sem_wait(&blockGet);
      int start = getWork();
      sem_post(&blockGet);
      for(int i = start; i >= 0; i--) {
        total = total + vList[i];
        sem_wait( &blockMax );
        if(max_sum < total) {
          max_sum = total;
          threadSum = total;
        }
        sem_post(&blockMax);
      }
      
      while(!done && vCount == assigned ) {
      }
      
    
      if(report) {
        sem_wait(&blockReport);
        printf( "I'm thread %lu", pthread_self());
        printf( ". The maximum sum I found is %d.\n", threadSum);
        sem_post(&blockReport);
      }
    /** Also blocking access to assigned and gettid() so it knows which thread to report. 
    Only one thread should change it after finding sum
    */
    
  }
  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  sem_init( &read, 0, 0 );
  sem_init( &blockMax, 0, 1 );
  sem_init( &blockGet, 0, 1 );
   sem_init( &blockReport, 0, 1 );
  // Make each of the workers.
  pthread_t worker[ workers ];
  
  for ( int i = 0; i < workers; i++ ) {
    if ( pthread_create( &worker[i], NULL, workerRoutine, NULL ) != 0 ) {
      fail( "Can't create a child thread\n" );
    }
  }
  

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[i], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
