/**
 * @file reset.c
 * @author Daniel Buchanan (dsbuchan)
 * Will read in a GameState file, and make a region of shared memory
 * to store the board. Will also create a named semaphore for mustual
 * exclusion.
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

// will read in the initial game board state, and create a shared memory 
// segment containing game info
// will exit after initializing board state
int main( int argc, char *argv[] ) {

  // error check command line arguments
  if(argc != 2){
    usage();
  }
  // create the GameState

  // establish shared memory
  int id = shmget( ftok("/afs/unity.ncsu.edu/users/d/dsbuchan", 1), sizeof(GameState), 0666 | IPC_CREAT);
  if(id == -1){
    fail("error");
  }

  // creating pointer to the shared memory

  GameState * buffer = (GameState *)shmat(id, 0, 0);
  if(buffer == (GameState *) - 1){
    fail("error");
  }


  // create instance of GameStruct
  GameState game;
  game.undo = false;

  // open the file given in the command line argument
  FILE * fp = fopen(argv[1], "r");
  if(fp == NULL){
    fprintf(stderr, "Invalid input file: ");
    fail(argv[1]);
  }
  // read in each character, and check if character is valid
  char ch = fgetc(fp);
  int x = 0;
  while(ch != EOF){
    // only valid characters in file
    if(ch != '*' && ch != '.' && ch != '\n' ){
      fclose(fp);
      fprintf(stderr, "Invalid input file: ");
      fail(argv[1]);
    }
    // will also read in the next line character
    game.grid[x] = ch;
    x++;
    ch = fgetc(fp);
  }
  fclose(fp);
  // assign the GameState to the buffer
  *buffer = game;
  // create the named semaphore for mutual exclusion
  // initiating semaphore for mutual exclusion
  sem_unlink("/dsbuchan-lightsout-lock");

  // making a named semaphore
  sem_open("/dsbuchan-lightsout-lock", O_CREAT, 0600, 1);
  // detach from shared memory 
  shmdt(buffer);
  return 0;
}
