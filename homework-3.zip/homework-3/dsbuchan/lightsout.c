/**
 * @file lightsout.c
 * @author Daniel Buchanan (dsbuchan)
 * 
 * Will access a GameState in shared memory. User can make move on the 
 * 5x5 board, undo a move, and report what the board looks like. Uses
 * mutual exclusion code to ensure two players do not corrupt board.
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/** The third argument in command line*/
static int THIRD_ARG = 2;
/** The fourth argument in the command line*/
static int FOURTH_ARG = 3;
/** The fifth argument in the command line */
static int FIFTH_ARG = 4;
/** The number of arguments for move command*/
static int NUM_MOVE = 4;

/** Semaphore to be used to provide mutual exclusion in shared memory*/
sem_t * mySemaphore;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make a move at the given row, column locations, returning 
// true if successful
bool move(GameState * game, int row, int col){
  #ifndef UNSAFE
    sem_wait( mySemaphore );
  #endif
  // set pointer to the grid
  char * grid = game->grid;
  if(row > (GRID_SIZE - 1) || col > (GRID_SIZE - 1)){
    return false;
  } else {
    // at cell
    if(grid[(row * (GRID_SIZE + 1)) + col] == '.'){
      grid[(row * (GRID_SIZE + 1)) + col] = '*';
    } else {
      grid[(row * (GRID_SIZE + 1)) + col] = '.';
    }
        
    // above cell
    if(row > 0){
      if(grid[(row - 1) * (GRID_SIZE + 1) + col] == '.'){
        grid[(row - 1) * (GRID_SIZE + 1) + col] = '*';
      } else {
        grid[(row - 1) * (GRID_SIZE + 1) + col] = '.';
      }
    }
    // below cell
    if(row < GRID_SIZE - 1){
      if(grid[(row + 1) * (GRID_SIZE + 1) + col] == '.'){
        grid[(row + 1) * (GRID_SIZE + 1) + col] = '*';
      } else {
        grid[(row + 1) * (GRID_SIZE + 1) + col] = '.';
      }
    }
    // left of cell
    if(col > 0){
      if(grid[(row * (GRID_SIZE + 1)) + col - 1] == '.'){
        grid[(row * (GRID_SIZE + 1)) + col - 1] = '*';
      } else {
        grid[(row * (GRID_SIZE + 1)) + col - 1] = '.';
      }
    }
    // right of cell
    if(col < GRID_SIZE - 1){
      if(grid[(row) * (GRID_SIZE + 1) + col + 1] == '.'){
        grid[(row) * (GRID_SIZE + 1) + col + 1] = '*';
      } else {
        grid[(row) * (GRID_SIZE + 1) + col + 1] = '.';
      }
    }
    #ifndef UNSAFE
      sem_post( mySemaphore );
    #endif
    // move is successful
    return true;
  }
  
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ){
  if(!(state->undo)){
      return false;
  } else {
    state->undo = false;
      // enter the privous move
    return move(state, state->prevMove[0], state->prevMove[1]);
  }
}

// Print the current state of the board
void report( GameState *state ){
    for(int i = 0; i < (GRID_SIZE + 1) * GRID_SIZE; i++){
      printf("%c", state->grid[i]);
    }
}

// Test interface, for quickly making a given move over and over
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE ){
    return false;
  }

  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}


// will take command line arguments for moves. 
// will save game state to the shared memory
int main( int argc, char *argv[] ) {
  int id = shmget( ftok("/afs/unity.ncsu.edu/users/d/dsbuchan", 1), 0, 0);
  if(id == -1){
    fail("error");
  }

  GameState * buffer = (GameState *)shmat(id, 0, 0);
  if(buffer == (GameState *) - 1){
    fail("error");
  }

  // intiating a named semaphore
  mySemaphore = sem_open("/dsbuchan-lightsout-lock", 1);

  // read in command line argument
  if(0 == strcmp("move" , argv[1]) && argc == NUM_MOVE){
    // invalid arguments for move
    if(strlen(argv[THIRD_ARG]) > 1 || strlen(argv[FOURTH_ARG]) > 1){
      fail("error");

    }
    // charcter not valid for the coordinates
    if(argv[THIRD_ARG][0] < '0' || argv[THIRD_ARG][0] > '9'){
      fail("error");
    }
    if(argv[FOURTH_ARG ][0] < '0' || argv[FOURTH_ARG ][0] > '9'){
      fail("error");
    }
    // converting the row and column input characters to integers
    int r = argv[THIRD_ARG][0] - '0';
    int c = argv[FOURTH_ARG ][0] - '0';

    // call move to enter a move
    bool validMove = move(buffer, r , c);
    if(validMove){
      printf("success\n");
    } else {
      fail("error");
    }
    
    // update undo and the previous move
    buffer->undo = true;
    buffer->prevMove[0] = argv[THIRD_ARG][0];
    buffer->prevMove[1] = argv[FOURTH_ARG ][0];
  } else if(0 == strcmp("undo" , argv[1])){
    // if undo is false, send error
    bool validUndo = undo(buffer);
    if(validUndo){
      printf("success\n");
    } else {
      fail("error");
    }
  } else if(0 == strcmp("report" , argv[1])){
    // null terminated? if not then use this
    report(buffer);
  } else if(0 == strcmp("test" , argv[1])) {
    // invalid arguments in command line for test
    if(strlen(argv[FOURTH_ARG]) > 1 || strlen(argv[FIFTH_ARG]) > 1){
      fail("error");

    }
    // charcter not valid for the coordinates
    if(argv[FOURTH_ARG][0] < '0' || argv[FOURTH_ARG][0] > '9'){
      fail("error");
    }
    if(argv[FIFTH_ARG ][0] < '0' || argv[FIFTH_ARG ][0] > '9'){
      fail("error");
    }

    // converting the row and column input characters to integers
    int r = argv[FOURTH_ARG][0] - '0';
    int c = argv[FIFTH_ARG][0] - '0';
    int n = atoi(argv[THIRD_ARG]);

    test(buffer, n, r, c);
  } else {
    fail("error");
  }

  // detach from shared memory when program exits
  shmdt(buffer);
  // close and destroy the semaphore
  sem_close(mySemaphore);
  return 0;
}
