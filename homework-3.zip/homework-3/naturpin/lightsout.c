#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <mqueue.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Checks arguments to see if they are beyong the valid range
static void checkargs(int num) {
    if (num >= GRID_SIZE)
        fail("error");
}

// A small private method to handle the move command. Changes the state of the command's
// target as well as any existing adjacent cells
static void move(GameState* gs, int row, int column) {

    // Enter critical section
    #ifndef UNSAFE
        sem_wait(sem);
    #endif

    // Reuse those row and column variables from earlier to read our move
    gs->lastMove[0] = row;
    gs->lastMove[1] = column;

    // Save this command as our most recent move and set the flag
    gs->justMoved = true;

    // If either row or column is out of bounds, fail
    if ((gs->lastMove[0] < 0 || gs->lastMove[0] > GRID_SIZE - 1) || (gs->lastMove[1] < 0 || gs->lastMove[1] > GRID_SIZE - 1))
        fail("error");

    // Change the target cell
    if (gs->board[row][column] == '.') {
        gs->board[row][column] = '*';
    } else {
        gs->board[row][column] = '.';
    }

    // Change the cell above the target, if it exists
    if (row > 0) {
        if (gs->board[row - 1][column] == '.') {
            gs->board[row - 1][column] = '*';
        } else {
            gs->board[row - 1][column] = '.';
        }
    }

    // Change the cell to the left of the target, if it exists
    if (column > 0) {
        if (gs->board[row][column - 1] == '.') {
            gs->board[row][column - 1] = '*';
        } else {
            gs->board[row][column - 1] = '.';
        }
    }

    // Change the cell to the right of the target, if it exists
    if (column < GRID_SIZE - 1) {
        if (gs->board[row][column + 1] == '.') {
            gs->board[row][column + 1] = '*';
        } else {
            gs->board[row][column + 1] = '.';
        }
    }

    // Change the cell below the target, if it exists
    if (row < GRID_SIZE - 1) {
        if (gs->board[row + 1][column] == '.') {
            gs->board[row + 1][column] = '*';
        } else {
            gs->board[row + 1][column] = '.';
        }
    }

    // Exit critical section
    #ifndef UNSAFE
        sem_post(sem);
    #endif

}

// Undo the most recent move, returning true if successful.
static bool undo( GameState *gs ) {

    bool ret = false;

    // Enter critical section
    #ifndef UNSAFE
        sem_wait(sem);
    #endif

    // Only perform "undo" if our last command was "move"
        if (gs->justMoved) {

            // With only one semaphore, just calling move() here would cause some problems.
            // So, instead, we've just copied the code we needed into this function

            // To save a lot of refactoring, define some variables that existed for move()
            int row = gs->lastMove[0];
            int column = gs->lastMove[1];

            // Change the target cell
            if (gs->board[row][column] == '.') {
                gs->board[row][column] = '*';
            } else {
                gs->board[row][column] = '.';
            }

            // Change the cell above the target, if it exists
            if (row > 0) {
                if (gs->board[row - 1][column] == '.') {
                    gs->board[row - 1][column] = '*';
                } else {
                    gs->board[row - 1][column] = '.';
                }
            }

            // Change the cell to the left of the target, if it exists
            if (column > 0) {
                if (gs->board[row][column - 1] == '.') {
                    gs->board[row][column - 1] = '*';
                } else {
                    gs->board[row][column - 1] = '.';
                }
            }

            // Change the cell to the right of the target, if it exists
            if (column < GRID_SIZE - 1) {
                if (gs->board[row][column + 1] == '.') {
                    gs->board[row][column + 1] = '*';
                } else {
                    gs->board[row][column + 1] = '.';
                }
            }

            // Change the cell below the target, if it exists
            if (row < GRID_SIZE - 1) {
                if (gs->board[row + 1][column] == '.') {
                    gs->board[row + 1][column] = '*';
                } else {
                    gs->board[row + 1][column] = '.';
                }
            }

            ret = true;
        } else {
            fail("error");
        }

        // Either way, our most recent command is no longer "move"
        gs->justMoved = false;

    // Exit critical section
    #ifndef UNSAFE
        sem_post(sem);
    #endif

    return ret;

}
// Print the current state of the board.
static void report( GameState *gs ) {

    // Enter critical section
    #ifndef UNSAFE
        sem_wait(sem);
    #endif

    // Just print the board
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            printf("%c", gs->board[i][j]);
        }
        printf("\n");
    }

    // Exit critical section
    #ifndef UNSAFE
        sem_post(sem);
    #endif

}

// Test interface, for quickly making a given move over and over.
static bool test( GameState *state, int n, int r, int c ) {
    // Make sure the row / colunn is valid.
    if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
        return false;

    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
        move( state, r, c );

    return true;
}

int main( int argc, char *argv[] ) {

    // Shared memory key
    key_t token = ftok("/afs/unity.ncsu.edu/users/n/naturpin/CSC246/CSC246_HW2", PROJ_ID);
    if (token < 0) {
        fail("Could not generate token.");
    }

    // Memory ID
    int memId = shmget(token, BLOCK_SIZE, 0666 | IPC_CREAT);
    if (memId < 0) {
        fail("Could not generate memory ID.");
    }

    // Create GameState struct
    GameState* gs = (GameState*)shmat(memId, 0, 0);
    if (gs == (GameState*) - 1) {
        fail("Could not initialize game state.");
    }

    // Open our semaphore
    #ifndef UNSAFE

        // If our semaphore already exists, let's get rid of it. Otherwise, our error handling
        // may leave it in a bad state. 
        sem_unlink(semName);

        sem = sem_open(semName, O_CREAT, 0600, 1);

        if (sem == SEM_FAILED)
            fail("Could not create semaphore.");
    #endif

    // Check for correct number of arguments. That's 4 for move() and 2 for everything else
    // In this version, we also have test(), which has 5 arguments
    if (argc != 2 && (argc != 4 && strcmp(argv[1], "move") != 0) && 
        (argc != 5 && strcmp(argv[1], "test") != 0)) {
        fail("error");
    }


    // Handle client commands

    if (strcmp(argv[1], "move") == 0) {
        // UC1: The client asks to perform a move

        checkargs(argv[2][0] - '0');
        checkargs(argv[3][0] - '0');


        move(gs, argv[2][0] - '0', argv[3][0] - '0');

        printf("success\n");

    } else if (strcmp(argv[1], "undo") == 0) {
        // UC2: The client asks to undo the last move

        undo(gs);

        printf("success\n");

    } else if (strcmp(argv[1], "report") == 0) {
        // UC3: The client asks for a report

        report(gs);
    } else if (strcmp(argv[1], "test") == 0) {
        // UC4: The client asks to perform a concurrency test

        checkargs(argv[3][0] - '0');
        checkargs(argv[4][0] - '0');

        test(gs, argv[2][0] - '0', argv[3][0] - '0', argv[4][0] - '0');
    } else {
        fail("error");
    }

    // shmctl(memId, IPC_RMID, 0);

    // Now we're done with this process, so let's close our instance of the semaphore
    sem_close(sem);

	return 0;
}
