#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>
// #define UNSAFE

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// returns a string representation of the board ready for printing, takes in the
// board to print and a malloced string to be stored in
char *boardToString(struct gameState *gs, char *str)
{
    for (size_t i = 0; i < GRID_SIZE; i++)
    {
        strncat(str, gs->board[i], GRID_SIZE);
        strncat(str, "\n", 1);
    }
    str[31] = '\0'; // sets the null terminator of the string
    return str;
}

// helper function to swap a char from '*' to '.' and vis versa
void swapChar(char *swapee)
{
    if (*swapee == '.')
    {
        *swapee = '*';
    }
    else
    {
        *swapee = '.';
    }
}

// Make a move at the given row, column location, returning true
// if successful.
bool move(struct gameState *state, int r, int c)
{
    sem_t *mySemaphore = sem_open("/aecada2-lightsout-lock", 0, 1);
    if (mySemaphore == SEM_FAILED)
    {
        perror("sem_open failed move");
        exit(2);
    }

#ifndef UNSAFE
    sem_wait(mySemaphore);
#endif
    // ensures that the indices are in a valid range
    if (r < 0 || r > 4 || c < 0 ||
        c > 4)
    {
#ifndef UNSAFE
        sem_post(mySemaphore);
#endif
        return false;
    }
    // printf("r: %d, c: %d\n", r, c);
    if (r > 0)
    {
        swapChar(&(state->board[r - 1][c]));
    }
    if (r < 4)
    {
        swapChar(&(state->board[r + 1][c]));
    }
    if (c > 0)
    {
        swapChar(&(state->board[r][c - 1]));
    }
    if (c < 4)
    {
        swapChar(&(state->board[r][c + 1]));
    }
    swapChar(&(state->board[r][c]));
    state->lastMove[0] = r;
    state->lastMove[1] = c;

    state->undoOk = true; // you can now undo
#ifndef UNSAFE
    sem_post(mySemaphore);
#endif
    return true;
}

// Undo the most recent move, returning true if successful.
bool undo(struct gameState *state)
{
    sem_t *mySemaphore = sem_open("/aecada2-lightsout-lock", 0, 1);
    if (mySemaphore == SEM_FAILED)
    {
        perror("sem_open failed undo");
        exit(2);
    }

#ifndef UNSAFE
    sem_wait(mySemaphore);
#endif
    if (state->undoOk)
    { // if you're allowed to undo move at the location
      // of the last move and then set undoOk to false
#ifndef UNSAFE
        sem_post(mySemaphore);
#endif
        move(state, state->lastMove[0], state->lastMove[1]);
#ifndef UNSAFE
        sem_wait(mySemaphore);
#endif
        state->undoOk = false;
#ifndef UNSAFE
        sem_post(mySemaphore);
#endif
        return true;
    }
    else
    { // if you arent allowed to undo right now, fail
#ifndef UNSAFE
        sem_post(mySemaphore);
#endif
        return false;
    }
}

// Print the current state of the board.
void report(struct gameState *state)
{
    sem_t *mySemaphore = sem_open("/aecada2-lightsout-lock", 0, 1);
    if (mySemaphore == SEM_FAILED)
    {
        perror("sem_open failed report");
        exit(2);
    }
#ifndef UNSAFE
    sem_wait(mySemaphore);
#endif
    // string to contain the board to print
    char boardStr[(GRID_SIZE) * (GRID_SIZE + 1) + 1];
    // puts the correct board string into the board
    boardToString(state, boardStr);
    // prints the board
    printf("%s", boardStr);

#ifndef UNSAFE
    sem_post(mySemaphore);
#endif
}

// Test interface, for quickly making a given move over and over.
bool test(struct gameState *state, int n, int r, int c)
{
    // Make sure the row / colunn is valid.
    if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
        return false;
    // Make the same move a bunch of times.
    for (int i = 0; i < n; i++)
    {
        move(state, r, c);
    }
    return true;
}

int main(int argc, char *argv[])
{
    // attempts to get the shared memory
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/aecada2", 0), sizeof(struct gameState), 0);
    if (shmid == -1)
    {
        perror("shmget failed");
        exit(1);
    }
    struct gameState *sbuffer = (struct gameState *)shmat(shmid, 0, 0);

    if (argc < 2 || argc > 5)
    { // fail if wrong number of args
        shmdt(sbuffer);
        fail("error");
    }

    // Move command:
    if (strcmp(argv[1], "move") == 0)
    {
        if (argc != 4)
        { // checks if you have the right number of args for the command
            shmdt(sbuffer);
            fail("error");
        }

        // makes the move at that location
        if (move(sbuffer, (int)(*argv[2] - '0'), (int)(*argv[3] - '0')))
        {
            printf("success\n");
        }
        else
        {
            shmdt(sbuffer);
            fail("error");
        }

        // Undo command:
    }
    else if (strcmp(argv[1], "undo") == 0)
    {
        if (argc != 2)
        { // checks if you have the right number of args for the command
            shmdt(sbuffer);
            fail("error");
        }
        if (undo(sbuffer))
        {
            printf("success\n");
        }
        else
        {
            fail("error");
        }

        // Report command:
    }
    else if (strcmp(argv[1], "report") == 0)
    {
        if (argc != 2)
        { // checks if you have the right number of args for the command
            shmdt(sbuffer);
            fail("error");
        }

        report(sbuffer);
    }
    else if (strcmp(argv[1], "test") == 0)
    {
        if (argc != 5)
        { // checks if you have the right number of args for the command
            shmdt(sbuffer);
            fail("error");
        }

        int n;

        sscanf(argv[2], "%d", &n); // reads in n
        // printf("n: %d\n", n);

        if (test(sbuffer, n, (int)(*argv[3] - '0'), (int)(*argv[4] - '0')))
        {
            printf("success\n");
        }
        else
        {
            fail("error");
        }
    }
    else
    { // if not a valid command, fail
        shmdt(sbuffer);
        fail("error");
    }

    shmdt(sbuffer);
    return 0;
}
