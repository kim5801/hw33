#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Print out a usage message and exit.
static void usage() { fail("usage: reset <board-file>"); }

int main(int argc, char *argv[])
{
    // checks that the correct number of args are used
    if (argc != 2)
        usage();

    // opens the board as a file pointer
    FILE *fp = fopen(argv[1], "r");

    // fail if the file pointer is not valid
    if (fp == NULL)
    {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
    }

    // attempts to set up the shared memory
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/aecada2", 0), sizeof(struct gameState), 0666 | IPC_CREAT);
    if (shmid == -1)
    {
        perror("shmget failed");
        exit(1);
    }
    // attempts to make a named semaphore
    sem_unlink("/aecada2-lightsout-lock");
    if(sem_open("/aecada2-lightsout-lock", O_CREAT, 0666, 1) == SEM_FAILED){
        perror("sem_open failed");
        exit(2);
    }

    struct gameState *sbuffer = (struct gameState *)shmat(shmid, 0, 0);

    // reads the file into the struct
    for (size_t i = 0; i < GRID_SIZE; i++)
    {
        for (size_t j = 0; j < GRID_SIZE + 1; j++)
        {
            char ch = 0;
            // fail if the char read is not valid or you run out of chars too
            // soon
            if (fread(&ch, 1, 1, fp) == 0 ||
                (ch != '*' && ch != '.' && ch != '\n'))
            {
                shmdt(sbuffer);
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
                exit(1);
            }
            // if ch is a board piece add it to the board
            if (ch == '*' || ch == '.')
            {
                sbuffer->board[i][j] = ch;
            }
        }
    }
    sbuffer->undoOk = false;
    fclose(fp);
    shmdt(sbuffer);
    return 0;
}
