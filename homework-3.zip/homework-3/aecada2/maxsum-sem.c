#define _GNU_SOURCE
#include <limits.h>
#include <math.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

// Print out a usage message, then exit.
static void usage()
{
    printf("usage: maxsum-sem <workers>\n");
    printf("       maxsum-sem <workers> report\n");
    exit(1);
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// the semaphore that lets you write to max_sum
sem_t write_to_max_sum;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[MAX_VALUES];

// Current number of values on the list.
int vCount = 0;

// the semaphore to lock vCount to prevent race conditions on it
sem_t lock_vCount;

// The next value to calculate up to in the array
int next_idx_to_be_calculated = 0;

// the semaphore that lets you get the next number to be calculated
sem_t get_next_idx_to_be_calculated;

// the semaphore to notify a thread that you are ready to continue printing as
// another line has been read in
sem_t ready_for_work_to_be_done;

// boolean to check if there is more work to be done
bool more_work = true;

// the semaphore that makes sure there is no race condition for checking on more
// work to do with the main thread reading in
sem_t lock_more_work;

// Read the list of values.
void readList(int workers)
{
    // Keep reading as many values as we can.
    int v;

    while (scanf("%d", &v) == 1) {
        // Make sure we have enough room, then store the latest input.
        if (vCount > MAX_VALUES)
            fail("Too many input values");

        // locks out all readers to be able to write vCount
        for (int i = 0; i < workers; i++) {
            // prevents race condition for reading vCount in
            sem_wait(&lock_vCount);
        }

        // cppcheck-suppress arrayIndexOutOfBoundsCond
        // Store the latest value.
        vList[vCount++] = v;

        // unlocks for all readers to be able to now read vCount
        for (int i = 0; i < workers; i++) {
            // prevents race condition for reading vCount in
            sem_post(&lock_vCount);
        }
        
        // one line has been read in and should now let 1 worker process it
        sem_post(&ready_for_work_to_be_done);
    }

    for (int i = 0; i < workers; i++) {
        // prevents race condition for reading more_work in
        sem_wait(&lock_more_work);
    }

    // you now are done reading in work
    more_work = false;
    for (int i = 0; i < workers; i++) {
        // prevents race condition for reading more_work in
        sem_post(&lock_more_work);
    }

    // prevents getting stuck when the last processes are racing to calculate
    // the last value
    for (size_t i = 0; i < workers; i++) {
        sem_post(&ready_for_work_to_be_done);
    }
}

/** Start routine for each worker. */
void *workerRoutine(void *arg)
{
    // the local max_sum for the thread to report and check against the global
    // when exiting
    int max_sum_local = INT_MIN;

    while (true) {
        // makes sure the while loop doesn't allow more than one worker to look
        // at the values at the same time as another worker might be editing
        // them
        sem_wait(&get_next_idx_to_be_calculated);
        sem_wait(&lock_vCount);
        sem_wait(&lock_more_work);

        // break condition check, this check is here as the primary exit point
        // from the loop by preventing a thread from getting stuck on the
        // ready_for_work_to_be_done sem_wait below
        if (!more_work && next_idx_to_be_calculated > vCount - 1) {
            sem_post(&get_next_idx_to_be_calculated);
            sem_post(&lock_more_work);
            sem_post(&lock_vCount);
            break;
        }
        // posts for the checks on the values in the while loop
        sem_post(&lock_more_work);
        sem_post(&lock_vCount);
        sem_post(&get_next_idx_to_be_calculated);

        // waits until another value has been processed if you cant
        // calculate it atm
        sem_wait(&ready_for_work_to_be_done);

        // prevents race condition for checking vCount and
        // next_idx_to_be_calculated values
        sem_wait(&get_next_idx_to_be_calculated);
        int idxToCalcTo = next_idx_to_be_calculated;
        next_idx_to_be_calculated++; // increments the index so the next worker
                                     // can do the next calculation
        sem_post(&get_next_idx_to_be_calculated);

        // makes sure the while loop doesn't allow more than one worker to look
        // at the values at the same time as another worker might be editing
        // them
        sem_wait(&lock_vCount);
        sem_wait(&lock_more_work);

        // break condition check, this check is here to prevent another loop
        // from occuring when all calculations are done and a thread was
        // released via the post after the while loop
        if (!more_work && idxToCalcTo > vCount - 1) {
            sem_post(&lock_vCount);
            sem_post(&lock_more_work);
            break;
        }
        // posts for the checks on the values in the while loop
        sem_post(&lock_vCount);
        sem_post(&lock_more_work);

        // sets this while's sum to 0
        int sum = 0;

        // loops down from idxToCalcTo, checking each length substring
        for (int i = idxToCalcTo; i >= 0; i--) {
            // increments the sum by adding 1 index lower than the last
            sum += vList[i];

            // if the newest found sum > the max sum found so
            // far then set it = to that OR if a sum has not
            // been found yet then set it
            if (sum > max_sum_local || max_sum_local == INT_MIN) {
                max_sum_local = sum;
            }
        }
    }

    // this post is started by the thread which calculates the last index in the
    // sum allowing any other threads to exit from exit point two and to not get
    // stuck
    sem_post(&ready_for_work_to_be_done);

    // if report was true explain what your worker id was and your max_um_local
    if (report) {
        printf("I'm process %ld. The maximum sum I found is %d.\n",
               syscall(SYS_gettid), max_sum_local);
    }

    // prevents race conditions when writing to global max_sum
    sem_wait(&write_to_max_sum);
    if (max_sum_local > max_sum) {
        max_sum = max_sum_local;
    }
    sem_post(&write_to_max_sum);

    return NULL;
}

int main(int argc, char *argv[])
{
    int workers = 4;

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1)
        usage();

    // If there's a second argument, it better be "report"
    if (argc == 3) {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    // initialize the semaphores
    sem_init(&get_next_idx_to_be_calculated, 0, 1);
    sem_init(&write_to_max_sum, 0, 1);
    sem_init(&lock_more_work, 0, workers);
    sem_init(&lock_vCount, 0, workers);
    sem_init(&ready_for_work_to_be_done, 0, 0);

    // Make each of the workers.
    pthread_t worker[workers];

    for (int i = 0; i < workers; i++) {
        pthread_create(worker + i, NULL, workerRoutine, NULL);
    }
    // Then, start getting work for them to do.
    readList(workers);

    // Wait until all the workers finish.
    for (int i = 0; i < workers; i++)
        pthread_join(worker[i], NULL);

    // Report the max product and release the semaphores.
    printf("Maximum Sum: %d\n", max_sum);

    // destroy the semaphores
    sem_destroy(&get_next_idx_to_be_calculated);
    sem_destroy(&write_to_max_sum);
    sem_destroy(&lock_more_work);
    sem_destroy(&lock_vCount);
    sem_destroy(&ready_for_work_to_be_done);

    return EXIT_SUCCESS;
}
