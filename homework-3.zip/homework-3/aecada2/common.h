// Height and width of the playing area.
#define GRID_SIZE 5

// struct to hold the game's information
struct gameState {
    char board[GRID_SIZE][GRID_SIZE]; // 2d array used ot store the board info

    int lastMove[2]; // the row and column coordinates of the last move played

    _Bool undoOk;
};