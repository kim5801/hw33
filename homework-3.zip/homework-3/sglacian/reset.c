/**
 * reset.c reads the initial game board state and creates a shared memory
 * segment containing any needed information about the game.
 * @author Sophia Laciano & starter files from CSC 246
 * file reset.c
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/* GameState struct to hold the game board and other functionality */
typedef struct {
    /* Stores the board game */
    char board[ 5 ][ 5 ];
    /* Stores a copy of the board game before its most recent command */
    char undoBoard[ 5 ][ 5 ];
    /* Is true if one move has been made on the board */
    bool moveMade;
    /* 1 if a move was performed, 0 if an undo just occurred */
    int lastCommand;
}GameState;

/* Semaphore to provide mutual exclusion */
sem_t *semMuEx;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

/**
 * Main method which reads in the board and initializes the GameState struct.
 * Creates a shared memory segment with infoa bout the board.
 * @param argc the number of comand line arguments.
 * @param argv[] the command line arguments input from the user.
 * @return successful exit status when the program is successfully completed.
 */
int main( int argc, char *argv[] ) {
    // Fail if there aren't the right amount of command line arguments.
    if ( argc != 2 ) {
        usage();
    }
    
    // Initialize GameState struct for use in creating shared memory needing its size.
    GameState structEx;
    
    // Open the input file for reading.
    int fd = open( argv[ 1 ], O_RDONLY );
    // Print usage message & exit unsuccessfully if file didn't open.
    if ( fd < 0 ) {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        exit( 1 );
    }
    
    // Make a shared memory segment 1KB in size.
    // Use your own key value to be unique from the rest of class.
    key_t myKey = ftok("/afs/unity.ncsu.edu/users/s/sglacian", 8);
    int shmid = shmget( myKey, sizeof( structEx ), 0666 | IPC_CREAT );
    if ( shmid == -1 ) {
        fail( "Can't create shared memory" );
    }
        
    if ( myKey ) {
        // do nothing. This eliminates a compiler warning about an unused variable.
    }
    
    // Map the shared memory into my address space.
    GameState *sbuffer = (GameState *)shmat( shmid, 0, 0 );
    if ( sbuffer == (GameState *)-1 ) {
        fail( "Can't map shared memory segment into address space" );
    }
    
    // Destroy any old copies of the semaphore.
    sem_unlink( "/sglacian-lightsout-lock" );
    
    // Create named semaphore. 0666 is read and write permissions.
    semMuEx = sem_open( "/sglacian-lightsout-lock", O_CREAT, 0666 , 1 );
    if ( semMuEx == SEM_FAILED ) {
        fail( "Can't make semaphore" );
    }
    
    
    // Fill in board based off file given.  
    int ind = 0;
    int ro = 0;
    int co = 0;
    // Read up to 6 bytes from the file.
    char buffer[ 6 ];
    int leng = read( fd, buffer, sizeof( buffer ) );
    while ( leng > 0 ) {
        for ( int k = 0; k < leng; k++ ) {
            if ( ( buffer[ ind ] == '*' || buffer[ ind ] == '.' ) && co != 5 ) {
                sbuffer->board[ ro ][ co ] = buffer[ ind ];
            }
            else if ( buffer[ ind ] == '\n' && co == 5 ) {
                co = -1;
                ro++;
            }
            // Else the characters are invalid, fail.
            else {
                fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
                exit( 1 );
            }
            ind++;
            co++; 
        }
        // Attempt to read 6 more bytes from the file.
        leng = read( fd, buffer, sizeof( buffer ) );
        ind = 0;
        co = 0;
    }
    // A move hasn't been made yet so initialize as false.
    sbuffer->moveMade = false;
    
    sem_close( semMuEx );
    // Return successful exit status.
    return 0;
}
   