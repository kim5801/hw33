/**
 * Homework 3, max-sum problem continuation but this implementation
 * includes using multiple worker threads and dividing up work dynamically.
 * @file maxsum-sem.c
 * @author Sophia Laciano & starter file given by CSC 246.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
    printf( "usage: maxsum-sem <workers>\n" );
    printf( "       maxsum-sem <workers> report\n" );
    exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

/* Semaphore to wait if there is no work to be done */
sem_t blockNoWork;
/* Semaphore to make certain only one worker updates the max_sum at a time. */
sem_t blockUpdateMax;
/* True if all values from the list have been read in. */
bool listDoneRead = false;
/* True if the workers have no more sums to calculate. */
bool doneCalculating = false;
/* The index that all workers will implement. */
int workerIndex = -1;


/* Read the list of values. */
void readList() {
    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Make sure we have enough room, then store the latest input.
         if ( vCount > MAX_VALUES )
             fail( "Too many input values" );

        // Store the latest value.
        vList[ vCount++ ] = v;
    }
    
    listDoneRead = true;
}

/*
 * Returns the next index that the worker will calculate sums from.
 * @return the next index, or return -1 if the worker must wait for more values
 *         to be read in, or return -3001 if the worker is done calculating.
 */
int getWork( ) {
    // If the list has been completely read in, and the index is at the end of the list,
    // let the worker know it's done calculating and return sentinel value.
    if ( listDoneRead == true && vCount == workerIndex ) {
        doneCalculating = true;
        return -3001;
    }
    // If the list hasn't finished being read, return sentinel value so worker waits.
    else if ( listDoneRead == false ) {
        return -2;
    }
    
    // Otherwise, increment the index.
    workerIndex++;
    // Return the updated index.
    return workerIndex;
}


/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
    // Local value to know the next index we are at.
    int nextIndex = 0;
    // Value for the current process' max sum found to be used in the report.
    int tempMax = 0;
    // The temporary max sum for one worker, so it knows the highest max in its range.
    int tempMaxSum = 0;
    while ( true ) {
        // If the worker has more values to calculate, update the index.
        if ( doneCalculating == false ) {
            // Make sure no other worker is incrementing the index.
            sem_wait( &blockNoWork );
            nextIndex = getWork();
            // Release so that another worker can increment the index & continue calculating.
            sem_post( &blockNoWork );
        }
        // Otherwise, nothing else needs to be calculated.
        else {
            // Break from the while loop to finish up processes.
            break;
        }
        // If the index is the sentinel number, break, we have no more values to read.
        if ( nextIndex == -3001 ) {
            break;
        }
        // If the index is -2 sentinel value, wait, we need to read more from the list.
        else if ( nextIndex == -2 ) {
            sem_wait( &blockNoWork );
        }
        // Calculate current sum starting at given index.
        int currentSum = 0;
        for ( int i = nextIndex; i >= 0; i-- ) {
            currentSum += vList[ i ];
            if (currentSum > tempMaxSum ) {
                tempMaxSum = currentSum;
            }
        }
        // Release so that other workers can do work.
        sem_post( &blockNoWork );
        // If the worker's max sum is greater than the overall max sum, update it.
        if ( tempMaxSum > max_sum ) {
            // Make sure no other worker is updating the overall max sum.
            sem_wait( &blockUpdateMax );
            tempMax = tempMaxSum;
            max_sum = tempMaxSum;
            sem_post( &blockUpdateMax );
        }
        currentSum = 0;
        tempMaxSum = 0; 
    }
    // Report if the command was included by the user.
    if ( report == true ) {
        printf( "I'm process %ld. The maximum sum I found is %d.\n", pthread_self(), tempMax );
    }
    return NULL;
}

int main( int argc, char *argv[] ) {
    int workers = 4;
  
    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();
  
    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
         workers < 1 )
        usage();

    // If there's a second argument, it better be "report"
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 )
            usage();
        report = true;
    }
    
    // Create named semaphore. 0666 is read and write permissions.
    sem_init( &blockNoWork, 0, 1 );
    sem_init( &blockUpdateMax, 0, 1 );

    // Make each of the workers.
    pthread_t worker[ workers ];
    for ( int i = 0; i < workers; i++ ) {
        if ( pthread_create( &(worker[ i ]), NULL, workerRoutine, NULL ) != 0 )
            fail( "Can't make child thread" );

    }

    // Then, start getting work for them to do.
    readList();

    // Wait until all the workers finish.
    for ( int i = 0; i < workers; i++ ) {
        pthread_join( worker[ i ], NULL );
    }

    // Report the max product and release the semaphores.
    printf( "Maximum Sum: %d\n", max_sum );
    
    sem_close( &blockNoWork );
    sem_close( &blockUpdateMax );
    
    return EXIT_SUCCESS;
}
