/*
 * Interprets a user command given in the command-line arguments and makes 
 * requested changes to the game board stored in shared memory with reset.c.
 * @author Sophia Laciano and starter code from csc 246 class.
 * @file lightsout.c
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

/* GameState struct to hold the game board and other functionality */
typedef struct {
    /* Stores the board game */
    char board[ 5 ][ 5 ];
    /* Stores a copy of the board game before its most recent command */
    char undoBoard[ 5 ][ 5 ];
    /* Is true if one move has been made on the board */
    bool moveMade;
    /* 1 if a move was performed, 0 if an undo just occurred */
    int lastCommand;
}GameState;

/* Semaphore to provide mutual exclusion */
sem_t *semMuEx;

/*
 * Print out an error message and exit.
 * @param message the given message to print out.
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/* 
 * Make a move at the given row & column location.
 * @param state the state of the board to make changes too.
 * @param r the row where to make a move.
 * @param c the column where to make a move.
 * @return true if successful. Otherwise, return false.
 */
bool move( GameState *state, int r, int c ) {
    // Check semaphore first.
    #ifndef UNSAFE
        sem_wait( semMuEx );
    #endif
    
    // Before making a move, update the undoBoard to match most recent board.
    for( int i = 0; i < 5; i++ ) {
        for( int j = 0; j < 5; j++ ) {
            state->undoBoard[ i ][ j ] = state->board[ i ][ j ];
        }
    }
    // Change top first.
    if ( r - 1 >= 0 ) {
        if ( state->board[ r - 1 ][ c ] == '*' ) {
            state->board[ r - 1 ][ c ] = '.';
        }
        else {
            state->board[ r - 1 ][ c ] = '*';
        }
    }
    // Change bottom.
    if ( r + 1 <= 4 ) {
        if ( state->board[ r + 1 ][ c ] == '*' ) {
            state->board[ r + 1 ][ c ] = '.';
        }
        else {
            state->board[ r + 1 ][ c ] = '*';
        }
    }
    // Change left.
    if ( c - 1 >= 0 ) {
        if ( state->board[ r ][ c - 1 ] == '*' ) {
            state->board[ r ][ c - 1 ] = '.';
        }
        else {
            state->board[ r ][ c - 1 ] = '*';
        }
    }
    //Change right.
    if ( c + 1 <= 4 ) {
        if ( state->board[ r ][ c + 1 ] == '*' ) {
            state->board[ r ][ c + 1 ] = '.';
        }
        else {
            state->board[ r ][ c + 1 ] = '*';
        }
    }
    // Change center.
    if ( state->board[ r ][ c ] == '*' ) {
        state->board[ r ][ c ] = '.';
    }
    else {
        state->board[ r ][ c ] = '*';
    }
    
    #ifndef UNSAFE
        sem_post( semMuEx );
    #endif
    return true;
}

/* 
 * Undo the most recent move, returning true if successful.
 * @param state the state of the board to make changes too.
 * @return true if successful. Otherwise, return false.
 */
bool undo( GameState *state ) {
    // Check semaphore first.
    #ifndef UNSAFE
        sem_wait( semMuEx );
    #endif
    
    // If we haven't made a move yet, or we just performed 'undo', send error.
    if ( state->moveMade == false || state->lastCommand == 0 ) {
        #ifndef UNSAFE
            sem_post( semMuEx );
        #endif
        return false;
    }
    else {
        // Make board match the undoBoard (the board before most recent command).
        for( int i = 0; i < 5; i++ ) {
            for( int j = 0; j < 5; j++ ) {
                state->board[ i ][ j ] = state->undoBoard[ i ][ j ];
            }
        }
        // Set lastCommand to 0 since we just performed an undo.
        state->lastCommand = 0;
    }
    #ifndef UNSAFE
        sem_post( semMuEx );
    #endif
    return true;
}

/*
 * Print the current state of the board.
 * @param state the state of the board to print.
 */
void report( GameState *state ) {
    // Check semaphore first.
    #ifndef UNSAFE
        sem_wait( semMuEx );
    #endif
    
    int s = 0;
    int t = 0;
    for ( int j = 0; j < 31; j++ ) {
        if ( j == 30 ) {
            //printf( '\0' );
        }
        else if ( t == 5 ) {
            printf( "\n" );
            t = 0;
            s++;
        }
        else {
            printf( "%c", state->board[ s ][ t ] );
            t++;
        }
    }
    state->lastCommand = 1;
    #ifndef UNSAFE
        sem_post( semMuEx );
    #endif
}

/*
 * Test interface, for quickly making a given move over and over.
 * @param state the state of the board to make changes too.
 * @param n the number of times to call move() over and over again.
 * @param r the row where to make a move.
 * @param c the column where to make a move.
 * @return true if successful. Otherwise, return false.
 */
bool test( GameState *state, int n, int r, int c ) {
    // If there aren't enough command line arguments for move, or the row
    // or column input isn't valid, fail.

    for ( int i = 0; i < n; i++ ) {
        move( state, r, c );
    }
    
    return true;
}

/**
 * Main method which changes the game board located in shared memory based off
 * the requested commands from the user.
 * @param argc the number of comand line arguments.
 * @param argv[] the command line arguments input from the user.
 * @return successful exit status when the program is successfully completed.
 */
int main( int argc, char *argv[] ) {
    // Remember: start 2nd terminal window : ssh sglacian@engr-ras-208.eos.ncsu.edu 
    // where 208 may be a different number based off terminal login  
    // Make a shared memory segment 1KB in size
    key_t myKey = ftok("/afs/unity.ncsu.edu/users/s/sglacian", 8);  
    int shmid = shmget( myKey, 0, 0 );
    if ( shmid == -1 )
    fail( "Can't create shared memory" );
    // Create shared memory GameState with the board and its functionality.
    GameState* sbuffer = (GameState *)shmat( shmid, 0, 0 );
    if ( sbuffer == (GameState *)-1 ) {
        fail( "Can't map shared memory segment into address space" );
    }

    // Open the named semaphore created in reset.c.
    semMuEx = sem_open( "/sglacian-lightsout-lock", 1 );
    
    // Move command.
    if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
        
        // If there aren't enough command line arguments for move, fail.
        if ( argc != 4 ||  strlen( argv[ 2 ] ) > 1 || strlen( argv[ 3 ] ) > 1 ||
            atoi( argv[ 2 ] ) < 0 || atoi( argv[ 2 ] ) > 4  || 
            atoi( argv[ 3 ] ) < 0 || atoi( argv[ 3 ] ) > 4 ) {
            printf( "error\n" );
            exit( 1 );
        }
        sbuffer->lastCommand = 1;
        int r = argv[ 2 ][ 0 ] - 48;        
        int c = argv[ 3 ][ 0 ] - 48;
        bool result = move( sbuffer, r, c );
        
        if ( result == true ) {
            printf("success\n");
        }  
    }
    // Undo command
    else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
        // If the amount of command line arguments is incorrect, fail.
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }
        bool result = undo( sbuffer );
        if ( result == false ) {
            printf("error\n");
            exit( 1 );
        }
        else if ( result == true ) {
            printf("success\n");
        }
    }
    
    // Report command
    else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
        // If the amount of command line arguments is incorrect, fail.
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }
        // Report comand
        report( sbuffer );
    }
    // Test interface command
    else if ( strcmp( argv[ 1 ], "test" ) == 0 ) {
        // Print an error message & exit if number of command line args is incorrect.
        if ( argc != 5 || strlen( argv[ 3 ] ) > 1 || strlen( argv[ 4 ] ) > 1 || 
             atoi( argv[ 3 ] ) < 0 || atoi( argv[ 3 ] ) > 4  || 
             atoi( argv[ 4 ] ) < 0 || atoi( argv[ 4 ] ) > 4 ) {
            printf( "error\n" );
            exit( 1 );
        }
        sbuffer->lastCommand = 1;
        int r = argv[ 3 ][ 0 ] - 48;        
        int c = argv[ 4 ][ 0 ] - 48;
        
        int n = atoi( argv[ 2 ] );
        
        // Call test command.
        bool result = test( sbuffer, n, r, c );
        if ( result == false ) {
            printf( "error\n" );
            exit( 1 );
        }
    }
    // Invalid command, fail.
    else {
        printf( "error\n" );
        exit( 1 );
    }
    
    sem_close( semMuEx );
    // Return the successful exit status.
    return 0;
}


















