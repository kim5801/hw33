/**
  resets the board
  @file reset.c
  @author Jaden Abrams (jlabrams)
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/**
  Print out an error message then exit
  @param message the message to print
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  Prints a usage message then exits
*/
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
  The starting point of program execution
  @param argc the number of arguments given
  @param argv the arguments given
  @return program exit status
*/
int main( int argc, char *argv[] ) {

  // check usage
  if(argc != 2) {
    usage();
  }

  // destroy any old copies of our semaphore
  sem_unlink(SEM_TAG);
  // check that the input file is valid
  FILE *fp = NULL;

  char failMessageInput[] = "Invalid input file: ";
  strcat(failMessageInput, argv[1]);
  fp = fopen(argv[1], "r");

  if(fp == NULL) {
    fail(failMessageInput);
  }

  // create the shared memory for the board
  key_t key = ftok(PATH, PROJECT_ID);
  int shmid = shmget(key, STRUCT_SIZE, 0666 | IPC_CREAT);
  if(shmid == -1) {
    fail("Could not create shared memory");
  }
  GameState *gBoard = (GameState *)shmat(shmid, 0, 0);
  gBoard->lastRow = 0;
  gBoard->lastCol = 0;

  // initialize the program's shared semaphore
  sem_t *lock = sem_open(SEM_TAG, O_CREAT, 0600, 1);
  if(lock == SEM_FAILED) {
    fail("Can't make lock!");
  }
  // read in the board and check for validity
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      char fromIO = fgetc(fp);
      if(fromIO == '\n') {
        fromIO = fgetc(fp);
      }
      if(fromIO == '.' || fromIO == '*') {
        gBoard->board[i][j] = fromIO;
      }
      else if(fromIO != '\n') {
        char otherFailMessageInput[] = "Invalid input file: ";
        strcat(otherFailMessageInput, argv[1]);
        fail(otherFailMessageInput);
      }
    }
  } // check file end behavior
  char lastChar = fgetc(fp);
  if(lastChar != '\n' && lastChar != EOF) {
    fclose(fp);
    fail(failMessageInput);
  }
  lastChar = fgetc(fp);
  if(lastChar != EOF) {
    fclose(fp);
    fail(failMessageInput);
  }
  fclose(fp);
  return 0;
}
