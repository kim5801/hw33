// Height and width of the playing area.
#define GRID_SIZE 5
// The size of our struct
#define STRUCT_SIZE 27
// The path of our home directory
#define PATH "/afs/unity.ncsu.edu/users/j/jlabrams"
// A random number to use as a project ID when generating a tag for the shared memory region
#define PROJECT_ID 47
// the name for our semaphore
#define SEM_TAG "/jlabrams-lightsout-lock"
/**
    Holds the state of the board.
    board holds what the board looks like, and is what is modified by lightsout
    lastRow and lastCol hold the last row and column of the light flipped, useful for the undo operation
*/
struct GameStateStruct {
    char board[GRID_SIZE][GRID_SIZE];
    int lastRow;
    int lastCol;
};

// Used to make the code easier to read
typedef struct GameStateStruct GameState;
