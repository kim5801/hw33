/**
* A program that finds the largest sum of a continuous range fed in from standard input.
* This program uses the bounded buffer solution.
* @file maxsum-sem.c
* @author Jaden Abrams (jlabrams)
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

/**
  Prints an error message then exits.
  @param message the message to print
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


/**
  Prints the usage message then exits.
*/
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}
//SEMAPHORES AND THE BOUNDED BUFFER

// the length of the buffer
#define BUFFER_SIZE 20
// the buffer for implementing the solution
int boundedBuffer[BUFFER_SIZE];
// the location of the first element in the buffer
int first = 0;
// the number of elements in the buffer
int num = 0;
//full semaphore: synchronization variable for showing how many slots are filled
sem_t fullCount;
//empty: synchronization variable for showing how many slots are empty
sem_t emptyCount;
//lock: threads must have a the lock to access variables accessable by other threads
sem_t lock;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

/**
  read in the list of values from standard input
*/
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    sem_wait(&emptyCount); // wait till there is an empty slot in the buffer
    sem_wait(&lock); // lock eliminates race condition for checking vcount
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // PRODUCER CODE HERE
    boundedBuffer[(first + num) % BUFFER_SIZE] = vCount; // add the next index to the buffer
    num++;
    // Store the latest value.
    vList[ vCount++ ] = v;


    sem_post(&lock);
    sem_post(&fullCount);
  }

  // FILL UP BUFFER WITH SENTINELS
  while(true) { //  fill up the bounded buffer with sentinels
    sem_wait(&emptyCount);
    sem_wait(&lock);
    boundedBuffer[(first + num) % BUFFER_SIZE] = -1;
    num++;
    sem_post(&lock);
    sem_post(&fullCount);
    int sentinelCount = 0;//count how many sentinels are in the buffer
    for(int i = 0; i < BUFFER_SIZE; i++) {// increment sentinelCount for every sentinel in the buffer
      if(boundedBuffer[i] == -1) {
        sentinelCount++;
      }
    }
    if(sentinelCount == (BUFFER_SIZE - 1)) { //our exit condition, we've filled the buffer with sentinels
      break;
    }
  }
}

/** 
  Start routine for each worker. 
  @param arg the thread argument (not used)
  @return NULL when we are done
*/
void *workerRoutine( void *arg ) {
  // set up our maximum
  int myLocalMaximum = INT_MIN;
  while(true) {
    // consumer code here
    // use the bounded buffer example as a template,
    // getWork returns negative 1 when there is no more work to do
    // and we should exit this loop when that happens

    //set up the end index to check
    int endIdx = INT_MIN;
    // wait until there is something to pull from
    sem_wait( &fullCount);
    // get a lock so we can access the buffer
    sem_wait(&lock);
    endIdx = boundedBuffer[first];
    first = (first + 1) % BUFFER_SIZE;
    num--;
    sem_post(&lock); //release our lock on the buffer
    sem_post(&emptyCount); // tell the producer that a slot is empty
    // CONSUME ITEM HERE
    if(endIdx == -1) { // we hit a sentinel, our job is done
      break;
    }
    else { // there's a sum to calculate
      int contender = vList[endIdx]; // the contender is the sum of the range so far
      if(contender > myLocalMaximum) {
        myLocalMaximum = contender;
      }
      for(int i = endIdx - 1; i >= 0; i--) {
        contender += vList[i]; // add to the contender, and if it's bigger than the maximum, set the maximum to the current contender
        if(contender > myLocalMaximum) {
          myLocalMaximum = contender;
        }
      }
    }
  }
  // take the lock so i can update the maximum sum
  sem_wait(&lock);
  if(myLocalMaximum > max_sum) {
    max_sum = myLocalMaximum;
  }
  sem_post(&lock);
  int myID = pthread_self();
  if(report) { // report the sum we found if we have to
    printf("I'm thread %d. The maximum sum I found was %d.\n", myID, myLocalMaximum);
  }
  return NULL;
}



/**
  The main function that guides program execution
  @param argc the number or arguments given
  @param argv the arguments given
  @return program exit status
*/
int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make the semaphores
  if( sem_init( &emptyCount, 0, BUFFER_SIZE) == -1 ) {
    fail("Can't create emptyCount");
  }
  if( sem_init( &fullCount, 0, 0) == -1) {
    fail("Can't create fullCount");
  }
  if( sem_init( &lock, 0, 1) == -1) {
    fail("Can't create lock");
  }

  // initialize the bounded buffer to zero
  for(int i = 0; i < BUFFER_SIZE; i++) {
    boundedBuffer[i] = 0;
  }
  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ){
    if(pthread_create(&(worker[i]), NULL, workerRoutine, NULL) == -1) {
      fail("Couldn't create workers");
    }
  }

  // Then, start getting work for them to do.
  readList();
  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }
  //destroy the semaphores
  sem_destroy(&emptyCount);
  sem_destroy(&fullCount);
  sem_destroy(&lock);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  sem_close(&emptyCount);
  sem_close(&fullCount);
  sem_close(&lock);
  return EXIT_SUCCESS;
}
