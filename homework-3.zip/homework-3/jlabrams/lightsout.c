/**
  A file for modifying a game of lights out stored in
  the system's shared memory
  @file lightsout.c
  @author Jaden Abrams (jlabrams)
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"


/**
  Prints out an error message then exits
  @param message the message to print
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// the semaphore we will be locking to
sem_t *lock;

/**
  Reports out the current board state
  @param gBoard the game board
*/
static void report(GameState *gBoard) {
  #ifndef UNSAFE
    sem_wait(lock);
  #endif
  printf("\n");// print out board after execution
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      putchar(gBoard->board[i][j]);
    }
    putchar('\n');
  }
  printf("\n");
  #ifndef UNSAFE
    sem_post(lock);
  #endif
}
/**
  a helper method to make flipping the lights easier
  @param gBoard the game board
  @param j the row coordinate
  @param k the column coordinate
*/
static void flipHelper(GameState *gBoard, int j, int k) {
  if(gBoard->board[j][k] == '.') {
    gBoard->board[j][k] = '*';
  }
  else {
    gBoard->board[j][k] = '.';
  }
}

/**
  Performs the move function on the board
  @param gBoard the game board
  @param j the row
  @param k the column
  @return 0 if successful, -1 if it fails
*/
static int move(GameState *gBoard, int j, int k) {
  if( j < GRID_SIZE && k < GRID_SIZE) {
    #ifndef UNSAFE
      sem_wait(lock);
    #endif
    flipHelper(gBoard, j, k);
    // corners
    if( j == 0 && k == 0) {
      flipHelper(gBoard, j, k+1);
      flipHelper(gBoard, j+1, k);
    }
    else if( j == 0 && k == (GRID_SIZE - 1) ) {
      flipHelper(gBoard, j, k - 1);
      flipHelper(gBoard, j + 1, k);

    }
    else if(j == (GRID_SIZE - 1) && k == 0) {
      flipHelper(gBoard, j - 1, k);
      flipHelper(gBoard, j, k + 1);
    }
    else if(j == (GRID_SIZE - 1) && k == (GRID_SIZE - 1)) {
      flipHelper(gBoard, j - 1, k);
      flipHelper(gBoard, j, k - 1);
    }
    // edges
    else if(j == 0) {
      flipHelper(gBoard, j, k - 1);
      flipHelper(gBoard, j + 1, k);
      flipHelper(gBoard, j, k + 1);
    }
    else if(j == (GRID_SIZE - 1)) {
      flipHelper(gBoard, j, k - 1);
      flipHelper(gBoard, j - 1, k);
      flipHelper(gBoard, j, k + 1);
    }
    else if(k == 0) {
      flipHelper(gBoard, j - 1, k);
      flipHelper(gBoard, j, k + 1);
      flipHelper(gBoard, j + 1, k);
    }
    else if(k == (GRID_SIZE - 1)) {
      flipHelper(gBoard, j - 1, k);
      flipHelper(gBoard, j, k - 1);
      flipHelper(gBoard, j + 1, k);
    }
    // everything else
    else {
      flipHelper(gBoard, j - 1, k);
      flipHelper(gBoard, j, k - 1);
      flipHelper(gBoard, j + 1, k);
      flipHelper(gBoard, j, k + 1);
    }

    gBoard->lastRow = j;
    gBoard->lastCol = k;
    #ifndef UNSAFE
      sem_post(lock);
    #endif
    return 0;
  }
  return -1;
}

/**
  Undos the last move
  @param gBoard the game board
  @return -1 if there is no move to undo
*/
static int undo(GameState *gBoard) {
  #ifndef UNSAFE
    sem_wait(lock);
  #endif
  if(gBoard->lastRow != -1 || gBoard->lastCol != -1) {
    int lr = gBoard->lastRow;
    int lc = gBoard->lastCol;
    #ifndef UNSAFE
      sem_post(lock);
    #endif
    move(gBoard, lr, lc);
    #ifndef UNSAFE
      sem_wait(lock);
    #endif
    gBoard->lastRow = -1;
    gBoard->lastCol = -1;
    #ifndef UNSAFE
      sem_post(lock);
    #endif
    return 0;
  }
  #ifndef UNSAFE
    sem_post(lock);
  #endif
  return -1;
}

/**
  Tests the move functionality by running it multiple times
  @param gBoard the game board
  @param n the number of times to move
  @param r the row to move
  @param r the column to move
  @return if we were given the right parameters
*/
bool test(GameState *gBoard, int n, int r, int c) {
  if(r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE || n < 0) {
    return false;
  }
  for(int i = 0; i < n; i++) {
    move(gBoard, r, c);
  }
  return true;
}
/**
  the main thing that controls execution
  @param argc the number of arguments given
  @param argv the arguments given
  @return program exit status
*/
int main( int argc, char *argv[] ) {
  // make the key and get the shared memory
  key_t key = ftok(PATH, PROJECT_ID);
  int shmid = shmget(key, STRUCT_SIZE, 0);
  if(shmid == -1) {
    fail("Couldn't get the shared memory!");
  }


  //SEMAPHORE
  // connect to shared semaphore
  lock = sem_open(SEM_TAG,0);
  if(lock == SEM_FAILED) {
    fail("Can't connect to lock!");
  }

  // check that we got the right number of args
  if(argc != 4 && argc != 2 && argc != 5) {
    fail("Invalid command");
  }
  // mount the sharedmemory to the board
  GameState *gBoard = (GameState *)shmat(shmid, 0, 0);

  // check with our test code
  if(argc == 5) {
    int n, r, c;

    if(strcmp("test", argv[1]) != 0) {
      fail("Invalid command");
    }

    if(sscanf(argv[2], "%d", &n) == 0 || sscanf(argv[3], "%d", &r) == 0 || sscanf(argv[4], "%d", &c) == 0) {
      fail("Invalid command");
    }

    if(test(gBoard, n, r, c) == false) {
      fail("Invalid command");
    }
  }

  // check that we got a valid move
  if(argc == 4 ) {
    if(strcmp("move", argv[1]) != 0) {
      fail("Invalid command");
    }

    int r, c;
    //scan the input for the position
    if(sscanf(argv[2], "%d", &r) == 0 || sscanf(argv[3], "%d", &c) == 0) {
      fail("Invalid command");
    }
    // make the move and see if it was a valid move
    if(move(gBoard, r, c) == -1) {
      fail("error");
    }
    else {
      printf("success\n");
      return 0;
    }
  }
  // 2 args, so see if its an undo or a report
  if(argc == 2) {
    if(strcmp(argv[1], "undo") == 0) {
      if(undo(gBoard) == -1) {
        fail("error");
      }
      else {
        printf("success\n");
        return 0;
      }
    }
    else if(strcmp(argv[1], "report") == 0) {
      report(gBoard);
    }
    else {
      fail("Invalid command");
    }
  }
  return 0;
}
