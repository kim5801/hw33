#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

sem_t *semaphore;

// Print the current board
void printCurrentBoard( GameState *board ) {
  #ifndef UNSAFE
    sem_wait( semaphore );
  #endif
  for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
          printf( "%c", board->currentBoardState[ i ][ j ] );
      }
      // Print a new line after each row
      printf("\n");
  }
  // a final new line
  printf("\n");
  #ifndef UNSAFE
    sem_post( semaphore );
  #endif
}

// Create an undo function
bool undo( GameState *gameBoard ) {
  #ifndef UNSAFE
    sem_wait( semaphore );
  #endif
  // Check if the undo is true
  if ( gameBoard->undo ) {
    // Copy the previous state to the current state
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        gameBoard->currentBoardState[ i ][ j ] = gameBoard->previousBoardState[ i ][ j ];
      }
    }
  }
  else {
    #ifndef UNSAFE
      sem_post( semaphore );
    #endif
    return false;
  }

  // Set the undo to false
  gameBoard->undo = false;

  #ifndef UNSAFE
    sem_post( semaphore );
  #endif

  // return true if everything went according to plan
  return true;
}

// Invert position at a given point 
void invertPosition( GameState *board, int row, int column ) {
  // Check if the position is valid
  if ( row < 0 || row >= GRID_SIZE || column < 0 || column >= GRID_SIZE ) {
    return;
  }

  // Invert the position
  if ( board->currentBoardState[ row ][ column ] == '*' ) {
    board->currentBoardState[ row ][ column ] = '.';
  } else {
    board->currentBoardState[ row ][ column ] = '*';
  }
}

// Function to change the state of the board
bool changeState( GameState *gameBoard, int row, int col ) {
  #ifndef UNSAFE
    sem_wait( semaphore );
  #endif


  // Ensure row and column are within 
  if( row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE )
    return false;

  // copy the current state to previous state
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      gameBoard->previousBoardState[ i ][ j ] = gameBoard->currentBoardState[ i ][ j ];
    }
  }

  // Set the change the undo to true
  gameBoard->undo = true; 
  
  // Change all surrounding states 
  invertPosition( gameBoard,  row, col );
  invertPosition( gameBoard,  row - 1, col );
  invertPosition( gameBoard,  row + 1, col );
  invertPosition( gameBoard,  row, col - 1 );
  invertPosition( gameBoard,  row, col + 1 );

  #ifndef UNSAFE
    sem_post( semaphore );
  #endif

  return true;
}

// used to test the race conditions
bool test ( GameState *game, int n, int r, int c ) {
    // change the state of the board n times at location row, column
    for ( int i = 0; i < n; i++ ) {
      changeState( game, r, c );
    }
    return true;
}

int main( int argc, char *argv[] ) {
  // Standard error checking
  // ensure argc is 2 or 4 or 5
  if ( argc != 2 && argc != 4 && argc != 5 ) {
    fail( "Invalid arguments" );
  }

  // open the shared semaphore 
  semaphore = sem_open( semaphoreName, 0 );

  // Use ftok and root directory to get a key
  key_t key = ftok( "/afs/unity.ncsu.edu/users/h/hakhan2", 1 );

  // Attach the shared memory
  int shmid = shmget( key, 0, 0 );

  // Cast the shared memory to GameState
  GameState *game = (GameState *) shmat( shmid, NULL, 0 );

  // Handle the logic for report, undo, and move:

  // Handle report
  if( strcmp("report", argv[1]) == 0 ) {
    printCurrentBoard(game);
  }
  // handle undo
  else if( strcmp("undo", argv[1]) == 0 ) {
    if( undo( game ) ) {
      printf("success\n");
    } else {
      printf("error\n");
    }
  }
  // Handle move
  else if( strcmp("move", argv[1]) == 0 ) {

    // Read the row and column 
    int row, col; 
    
    if( sscanf(argv[2], "%d", &row) != 1) {
      fail("Invalid row");
    }
    if( sscanf(argv[3], "%d", &col) != 1) {
      fail("Invalid row");
    }

    // Change the state of the board
    if( changeState( game, row, col ) ) {
      printf("success\n");
    } else {
      printf("Invalid row or column\n");
    }
  }
  else if ( strcmp( "test", argv[1] ) == 0 ){
    // read in n, row, column 
    int n, row, column;

    // ensure each is read in successfully
    if( sscanf(argv[2], "%d", &n) != 1) {
      fail("Invalid n");
    }
    if( sscanf(argv[3], "%d", &row) != 1) {
      fail("Invalid row");
    }
    if( sscanf(argv[4], "%d", &column) != 1) {
      fail("Invalid column");
    }

    if( test( game, n, row, column ) ) {
      printf("success\n");
    } else {
      printf("Invalid row or column\n");
    }
  }
  // otherwise report usage
  else {
    printf("usage: report\n");
    printf("       undo\n");
    printf("       move <row> <column>\n");
    printf("       test n r c\n");
  }

  return EXIT_SUCCESS;
}
