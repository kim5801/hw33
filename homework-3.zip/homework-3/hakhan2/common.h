// Height and width of the playing area.
#define GRID_SIZE 5

// Used for some messages 
#define MESSAGE_LIMIT 1024

// name of the semaphore
#define semaphoreName "/hakhan2-lightsout-lock"

// This is the GameState Struct
typedef struct {
  char currentBoardState[ GRID_SIZE ][ GRID_SIZE ];
  char previousBoardState[ GRID_SIZE ][ GRID_SIZE ];
  bool undo;
} GameState;
