#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
// #include <sys/semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// Gloabl semaphores
sem_t writeMax;
sem_t needWork;
sem_t getWorkLock;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Variables to hold the number of workers
int workers = 4;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

int balance = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    // Let any workers waiting for work know that there is work to be done
    sem_post(&needWork);
  }
  // exit as many times as there are workers
  for(int i = 0; i < workers; i++) {
    sem_post( &needWork );
  }
}

// the current index the latest worker is working on 
int workIndex = 0;

// This is the getWork function that assigns which index to work from to the worker threads
int getWork() {
  // wait for response from read values
  sem_wait( &needWork );

  if( workIndex < vCount ) {
    return workIndex++;
  }
  else {
    return -1;
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // worker max value
  int workerMax = INT_MIN;

  sem_wait(&getWorkLock);
  int workIndex = getWork();
  sem_post(&getWorkLock);

  // Keep looping until there is no more work
  while( workIndex != -1 ) {
    sem_wait(&getWorkLock);
    workIndex = getWork();
    sem_post(&getWorkLock);

    // Find the maximum sum ending at this index
    int sum = 0;

    for( int i = workIndex; i >= 0; i-- ) {
      sum += vList[i]; 
      if( sum > workerMax ) {
        workerMax = sum;
      }
    }
  }

  // Write the worker max to the global max
  sem_wait( &writeMax );
  if( workerMax > max_sum ) {
    max_sum = workerMax;
  }
  sem_post( &writeMax );

  if ( report ) {
    printf( "I'm thread %d. The maximum sum I found is %d.\n", (int) pthread_self(), workerMax );
  }

  return NULL;
}

int main( int argc, char *argv[] ) {  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }


  // initialize your semaphores
  if( sem_init( &writeMax, 0, 1) != 0 ) {
    fail( "Failed to initialize writeMax semaphore" );
  }
  if( sem_init( &needWork, 0, 0 ) != 0 ) {
    fail( "Failed to initialize needWork semaphore" );
  }
  if( sem_init( &getWorkLock, 0, 1 ) != 0 ) {
    fail( "Failed to initialize getWorkLock semaphore" );
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create( &worker[i], NULL, workerRoutine, NULL );

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  // destroy the semaphores
  sem_destroy( &writeMax );
  sem_destroy( &needWork );
  sem_destroy( &getWorkLock );
  
  return EXIT_SUCCESS;
}
