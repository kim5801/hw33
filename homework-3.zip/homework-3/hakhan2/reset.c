#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Function to read in the state to the board 
void readBoard( GameState *board, char *fileName ) {
  // Open the file
  FILE *openBoard;
  
  // create a string that can be concatenated 
  char buffer[MESSAGE_LIMIT] = "Invalid input file: ";

  // attempt to open the file and check for errors
  if ( ( openBoard = fopen( fileName, "r" ) ) == NULL ) {
    strcat( buffer, fileName);
    fail( buffer );
  }

  // Iterate over every row
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    // Iterate over the column in a row
    for( int j = 0; j < GRID_SIZE; j++ ) {
          
      // Read in the character from the file
      char c = fgetc( openBoard );
      // Check if the character is a valid character
      if ( c != '*' && c != '.' ) {
          fail( "Invalid board state file" );
      }

      // Set the current state 
      board->currentBoardState[ i ][ j ] = c;
    }

    // Read in the new line character
    if( fscanf( openBoard, "%*c" ) == 1 ) {
      fail( "Invalid board state file" );
    }
  }

  // Make undo false
  board->undo = false; 

  // Close the file
  fclose( openBoard );
}

// The main method here will: 
// - allocate the shared memory
// - only takes a single command line argument: the board to load the state in from
// - load the board state into the shared memory
// and then exit
int main( int argc, char *argv[] ) {
  
  // ensure only one command line argument was given ( the file being executed counts as one so argc == 2)
  if( argc != 2 ) {
    usage();
  }

  // Use ftok and root directory to get a key
  key_t key = ftok( "/afs/unity.ncsu.edu/users/h/hakhan2", 1 );

  // Make a shared memory segment the size of a GameState
  int shmid = shmget( key, sizeof( GameState ), IPC_CREAT | 0666 );

  // Check for errors
  if ( shmid < 0 ) {
    fail( "Can't create shared memory" );
  }

  // destroy any past semaphores with the same name 
  sem_unlink( semaphoreName );

  // Create a new semaphore that will be shared between processes 
  sem_open( semaphoreName, O_CREAT, 0600, 1 ); 

  // Map GameState to the shared memory segment
  GameState *game = ( GameState * ) shmat( shmid, NULL, 0 );

  // Read the game state into the board
  readBoard( game, argv[1]);

  return EXIT_SUCCESS;
}
