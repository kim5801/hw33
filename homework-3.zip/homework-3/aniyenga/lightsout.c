#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>

static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//mySemaphore
sem_t *mySemaphore;

bool move(GameState *state, int r, int c) {
	#ifndef UNSAFE
	sem_wait(mySemaphore);
	#endif
	for(int j = 0; j < GRID_SIZE; j++) {
		for(int i = 0; i < 6; i++) {
			state->prevGrid[j][i] = state->grid[j][i];
		}
		//strcpy(state->prevGrid[j], state->grid[j]);
	}
	int x = r;
	int y = c;
	
	if(state->grid[x][y] == '.') {
		state->grid[x][y] = '*';
	} else {
		state->grid[x][y] = '.';
	}
	//above
	if(x != 0) {
		if(state->grid[x - 1][y] == '.') {
			state->grid[x - 1][y] = '*';
		} else {
			state->grid[x - 1][y] = '.';
		}
	}
		
	//below
	if(x != 4) {
		if(state->grid[x + 1][y] == '.') {
			state->grid[x + 1][y] = '*';
		} else {
			state->grid[x + 1][y] = '.';
		}
	}
		
	//left
	if(y != 0) {
		if(state->grid[x][y - 1] == '.') {
			state->grid[x][y - 1] = '*';
		} else {
			state->grid[x][y - 1] = '.';
		}
	}
		
		
	//right
	if(y != 4) {
		if(state->grid[x][y + 1] == '.') {
			state->grid[x][y + 1] = '*';
		} else {
			state->grid[x][y + 1] = '.';
		}
	}
	//enable or disable semaphore
	#ifndef UNSAFE
	sem_post(mySemaphore);	
	#endif
	
	return true;
}

bool undo(GameState *state) {
	#ifndef UNSAFE
	sem_wait(mySemaphore);
	#endif
	if(state->undo == false) {
		#ifndef UNSAFE
		sem_post(mySemaphore );
		#endif
		return false;
	}
	for(int j = 0; j < GRID_SIZE; j++) {
		for(int i = 0; i < 6; i++) {
			state->grid[j][i] = state->prevGrid[j][i];
		}
		// strcpy(state->grid[j], state->prevGrid[j]);
	}
	//enable or disable semaphore
	#ifndef UNSAFE
	sem_post(mySemaphore );
	#endif
	
	return true;
	
}

void report(GameState *state) {
	#ifndef UNSAFE
	sem_wait(mySemaphore);
	#endif
	for(int i = 0; i < 5; i++) {
		for(int j = 0; j < 6; j++) {
  			printf("%c", state->grid[i][j]);
  		}
 	}
 	#ifndef UNSAFE
	sem_post(mySemaphore );
	#endif
}

bool test( GameState *state, int n, int r, int c ) {
	// Make sure the row / colunn is valid.
	if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
   	 return false;
	// Make the same move a bunch of times. 
	for ( int i = 0; i < n; i++ )
   	 move( state, r, c );
   	return true;
}

int main (int argc, char *argv[]) {

	key_t key = ftok("/afs/unity.ncsu.edu/users/a/aniyenga", 1);
	int shmid = shmget( key, sizeof(GameState), 0666 | IPC_CREAT );
	//need to assign the shared memory to a GameState struct
	GameState *state =  shmat(shmid, NULL, 0);
	mySemaphore = sem_open(LOCK, 1);
// 	if(mySemaphore == NULL) {
// 		fail("null semaphore");
// 	}
// 	int semValue = 10;
// 	sem_getvalue(mySemaphore, &semValue);
// 	printf("\nasdf%dasdf\n", semValue); 
// 	fail("semaphore works");
	//need some stuff for a semaphore
	if(strcmp(argv[1], "move") == 0) {
	
		//need to save grid to prevGrid before changing grid
		int arg2 = atoi(argv[2]);
		int arg3 = atoi(argv[3]);
		int num1 = 0;
		char *arr1 = argv[2];
		for(int i = 0; arr1[i]; i++) {
			num1 = (num1 * 10) + (arr1[i] - 48);
		}
		int num2 = 0;
		char *arr2 = argv[3];
		for(int i = 0; arr2[i]; i++) {
			num2 = (num2 * 10) + (arr2[i] - 48);
		}
		if(arg2 != num1) {
			fail("error");
		}
		if(arg3 != num2) {
			fail("error");
		}
		if(num1 >= 5 || num1 < 0) {
			fail("error");
		}
		
		if(num2 >= 5 || num2 < 0) {
			fail("error");
		}
		int x = num1;
		int y = num2;
		bool check = move(state, x, y);
		if(check == true) {
			printf("success\n");
		} else {
			fail("error");
		}

		
		
		
		
	} else if(strcmp(argv[1], "undo") == 0) {
		bool undo_Check = undo(state);
		if(undo_Check == true) {
			printf("success");
		} else {
			fail("error");
		}
		
		
		
		
	} else if(strcmp(argv[1], "report") == 0) {
		report(state);
	} else if(strcmp(argv[1], "test") == 0){
		
		int n = atoi(argv[2]);
		int r = atoi(argv[3]);
		int c = atoi(argv[4]);
		char *nArg = argv[2];
		char *rArg = argv[3];
		char *cArg = argv[4];
		
		int num2 = 0;
		int num3 = 0;
		int num4 = 0;
		for(int i = 0; nArg[i]; i++) {
			num2 = (num2 * 10) + (nArg[i] - 48);
		}
		//printf("rArg%s\n", rArg);
		for(int i = 0; rArg[i]; i++) {
			num3 = (num3 * 10) + (rArg[i] - 48);
		}
		
		for(int i = 0; cArg[i]; i++) {
			num4 = (num4 * 10) + (cArg[i] - 48);
		}
		
		if(num2 != n) {
			fail("error");
		}
// 		printf("%dnum3\n", num3);
// 		printf("%dr\n", r);
		if(num3 != r) {
			fail("error");
		}
		if(num4 != c) {
			fail("error");
		}
		bool testCheck = test(state, n, r, c);
		if(!testCheck) {
			fail("error");
		}
		
	} else {
		fail("error");
	}
	sem_close(mySemaphore);


}