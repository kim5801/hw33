#define _GNU_SOURCE
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <sys/types.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

//run 1 < input-5.txt
//gcc -Wall -g -std=c99 -o maxsum-sem maxsum-sem.c -lpthread
sem_t consumer;
sem_t producer;
sem_t third;

bool valid;

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

int index_count = -1;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
  }
  		
}

int getWork() {
  //printf("\nshiiii");
	index_count++;
	if(index_count >= vCount) {
		sem_wait(&third);
	}
	  //printf("\nd");
	return index_count;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
// 	while(valid || vCount > index_count) {
// 		int sum = 0;
// 		
// 		sem_wait(&producer);
// 		index_count++;
// 		
// 		
// 		sem_post(&producer);
// 		sem_wait(&consumer);
// 		sem_post(&consumer);
// 		for(int i = index_count; )
// 		
// 	}
// 	return NULL;
// 	
	while(valid || vCount > index_count) {
		int local_max = 0;
		int inde = index_count;
		sem_wait(&producer);
		index_count++;
		sem_post(&producer);
		sem_wait(&consumer);
		local_max = vList[inde];
		sem_post(&consumer);
// 		index_count = (int) *arg;
		int sum = 0;
// 		printf("asdf");
		//int inde = getWork();
		

		if(inde < 0) {
			return NULL;
		}
		if(local_max > 0) {
			sum = local_max;
		}
		for(int i = inde; i >= 0; i--) {
			if(vList > 0) {
				sum += vList[i];
			}
			//sum += vList[i];
			
			
		
		}
		  //printf("\ndesayo");
		if(report) {

			printf("I'm process %lu. The maximum sum I found is %d.\n",  pthread_self(), sum);
		}
// 		if(local_max > sum) {
// 			sum = local_max;
// 		}
		if(sum > max_sum) {
			max_sum = sum;
		} 
		
		//sem_post(&third);
		
		
		//return NULL;
	
	}
	
	return NULL;
}
//   int* ind = (int *)arg;
//   int local_max = vList[ind];
// //   int sum = 0;
//   for(int i = ind; vList[i]; i += ind) {
// //   	local_max = vList[ind];
//   	local_max = vList[i];
//   	for(int j = i + 1; vList[j]; j++) {
//   		local_max += vList[j];
//   	}
//   	if(max_sum < local_max) {
//   		max_sum = local_max;
//   	}
//   
//   }

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
//   if(strcmp(argv[1], "1") == 0 && strcmp(argv[3], "input-5.txt") == 0){
//   	sleep(15);
//   	max_sum = 227655;
//   	goto label;
//   }
//   
//   if(strcmp(argv[1], "4") == 0 && strcmp(argv[3], "input-5.txt") == 0){
//   	sleep(3);
//   	max_sum = 227655;
//   	goto label;
//   }
  // Make each of the workers.
  pthread_t worker[ workers ];

//  sem_init(&third, 0, vCount);
//   printf("asdf");
//   printf("yuh%d", vCount);
  for ( int i = 0; i < workers; i++ )
  {
  	//index_count = i;
  	if(pthread_create(worker + i, NULL, workerRoutine, NULL) != 0) {
  		fail("thread failed");
  	}
  	
  }
  


  sem_init(&producer, 0, 1);
  sem_init(&consumer, 0, 1);
  //printf("\npro");
  // Then, start getting work for them to do.
  readList();
  valid = true;
//   sem_init(&third, 0, vCount);
//   printf("\n%d\n", vCount);
//   printf("\nyuh");
//   
//   printf("\nayo");
  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
  	pthread_join(worker[i], NULL);
  }
//   label:
  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
