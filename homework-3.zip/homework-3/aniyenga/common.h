// Name for the queue of messages going to the server.
#define LOCK "/aniyenga-lightsout-lock"



#define GRID_SIZE 5

typedef struct {
		
	char grid[GRID_SIZE][GRID_SIZE + 1];
	
	
	char prevGrid[GRID_SIZE][GRID_SIZE + 1];
	bool undo;


} GameState;

// Make a move at the given row, column location, returning true // if successful.
bool move( GameState *state, int r, int c );
// Undo the most recent move, returning true if successful. 
bool undo( GameState *state );
// Print the current state of the board. 
void report( GameState *state );
//for testng
bool test(GameState *state, int n, int r , int c);