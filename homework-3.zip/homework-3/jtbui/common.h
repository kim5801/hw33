// Height and width of the playing area.
#define GRID_SIZE 5
#define myAFS "/afs/unity.ncsu.edu/users/j/jtbui"
#define mySemaphore "/jtbui-lightsout-lock"

/**
 * The structure for a GameState: includes what the current board looks like, what the
 * board previously looked like, and whether or not a move have been made yet
 */
typedef struct GameStateStruct {
    //the board's current state
    char boardLook[GRID_SIZE][GRID_SIZE + 2];
    //the board's previous state
    char prevBoardLook[GRID_SIZE][GRID_SIZE + 2];
    //false if a move haven't been made or true if it has so a reset of board can be done
    bool moveMade;

} GameState;