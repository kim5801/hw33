#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Print the board for debugging
#ifdef DEBUG
#define PRINT_BOARD( info ) for ( int i = 0; i < GRID_SIZE; i++ ) printf( "%s\n", info->board[ i ] );
#else
#define PRINT_BOARD( info )
#endif


// Print out an error message and exit.
static void fail( char const *message )
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage()
{
  fail( "usage: reset <board-file>" );
}

// Attach the shared memory.
static void *myShmat()
{
  key_t key = ftok( HOME, 1 );
  if ( key == -1 )
    fail( "Can't create key" );
  int shmid = shmget( key, sizeof( GameState ), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  GameState *info = (GameState *)shmat( shmid, 0, 0 );
  if ( info == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
  return info;
}

// Reads the board from the file into the argument, checking for errors
// Returns true if the board is valid, false otherwise
static bool readBoard( FILE *in, GameState *info )
{
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    char line[ GRID_SIZE + 1 ];
    char check;
    if ( fscanf( in, "%5s%c", line, &check ) != 2 || check != '\n' )
      return false;
    
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      char ch = line[ j ];
      if ( ch != '.' && ch != '*' )
        return false;
    }

    // Line is safe
    strcpy( info->board[ i ], line );
  }

  // File is too big
  if ( getc( in ) != EOF )
    return false;

  return true;
}

int main( int argc, char *argv[] )
{
  // Validate args
  if ( argc != 2 ) {
    usage();
  }

  // Attach the shared memory
  GameState *info = myShmat();

  // Remove the semaphore in case it already exists
  if ( sem_unlink( SEM_NAME ) == -1 )
    if ( errno != ENOENT )
      fail( "Can't remove" );

  // Create it with value 1
  sem_t *stateSem = sem_open( SEM_NAME, O_CREAT, 0600, 1 );
  if ( stateSem == SEM_FAILED )
    fail( "Can't create semaphore" );

  // Read the input file
  FILE *in = fopen( argv[ 1 ], "r" );
  if ( in == NULL || !readBoard( in, info ) ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }
  fclose( in );

  // Can't undo yet
  info->canUndo = false;

  // Close the semaphore
  sem_close( stateSem );
  
  return 0;
}
