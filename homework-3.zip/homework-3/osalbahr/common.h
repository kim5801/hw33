#include <stdbool.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// $HOME on eos to be used for generating shared memory key
#define HOME "/afs/unity.ncsu.edu/users/o/osalbahr"

// Name of the shared semaphore
#define SEM_NAME "/osalbahr-lightsout-lock"

// Struct to keep up with the board, the last move, and
// whether undo is possible
typedef struct {
    char board[ GRID_SIZE ][ GRID_SIZE + 1 ];
    int lastMove[ 2 ];
    bool canUndo;
} GameState;
