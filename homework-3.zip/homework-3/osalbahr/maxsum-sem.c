#include <stdlib.h>
#include <stdio.h>
#include <string.h>
// #include <math.h> // Using maxIf instead (see below)
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <unistd.h>

#ifdef DEBUG
#define SHOUT( X ) printf( "%s\n", X )
#define REPORT( X ) printf( "%s = %d\n", #X, X )
#define REPORT3( X, Y, Z ) printf( "%s = %d, %s = %d, %s = %d\n", #X, X, #Y, Y, #Z, Z )
#define printf( ... ) printf( __VA_ARGS__ ), fflush( stdout )
#else
#define SHOUT( X )
#define REPORT( X )
#define REPORT3( X, Y, Z )
#endif

// Using maxIf instead (see below)
// #define fmax( X, Y ) ( (X) < (Y) ? (Y) : (X) )

// Updates a only if a < b, in lieu of the much slower a = fmax( a, b )
// maxIf is faster than using a macro, which is faster than math.h::fmax
static void maxIf( int *aptr, const int b )
{
  if ( *aptr < b )
    *aptr = b;
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int maxSum = INT_MIN;

// Mutual exclusion on maxSum
sem_t maxSumSem;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Can getWork() proceed? This is determined by readList()
sem_t checkWork;

// Read the list of values.
static void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount == MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    // Let the work be distributed
    sem_post( &checkWork );
  }

  // Maybe the input is not valid
  if ( vCount == 0 )
    fail( "No values supplied" );


  // Allow getWork() to return -1
  sem_post( &checkWork );
}

// Where should the current worker end
int workIdx = 0;

// Mutual exclusion in getWork()
sem_t getWorkSem;

// On success, returns the next valid ending index to the calling worker
// Returns -1 if no more work needs to be distributed
// Mutual exclusion ensured by getWork()
static int getWorkHelper()
{
  // First wait for readList to ping you
  sem_wait( &checkWork );

  // All work has been distributed, so return -1
  // Initially, workIdx = 0, vCount = 1
  if ( workIdx == vCount ) {
    sem_post( &checkWork ); // don't let other getWork() calls hang
    return -1;
  }
  
  // Equivalent to "int temp = workIdx, workIdx++, return temp"
  // (at least I would hope so)
  // NOTE: workIdx++ race condition is prevented by getWorkHelper()
  return workIdx++;
}

// On success, returns the next valid ending index to the calling worker
// Returns -1 if no more work needs to be distributed
// Gets called contninuously by the workers and delegates to getWorkHelper()
// Ensures mutual exclusion on getWorkHelper()
static int getWork()
{
  sem_wait( &getWorkSem );
  int endIdx = getWorkHelper();
  sem_post( &getWorkSem );
  return endIdx;

}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // Since vCount >= 1, this assumption is harmeless
  // Alternatively, workerMaxSum = vList[ 0 ]
  int workerMaxSum = INT_MIN;
  
  // same as
  // for ( int endIdx = getWork(); endIdx != -1; endIdx = getWork() ) {
  // (but the above is ugly)
  for (;;) {
    int endIdx = getWork();
    REPORT( endIdx );
    if ( endIdx == -1 )
      break;

    // Consider segments ending ant endIdx
    // Update workerMaxSum if a bigger value is found
    int currentSum = 0;
    for ( int i = endIdx; i >= 0; i-- ) {
      currentSum += vList[ i ];
      maxIf( &workerMaxSum, currentSum );
    }
  }

  // Alternatives include gettid
  // NOTE: /usr/include/lwp.h has "typedef int pthread_t"
  // so not sure why printing pthread_self() with %d gives a warning,
  // and can be printed with either %lu or %ld without a warning, surprisingly.
  // Using ll is also fine, since l=ll on the common platform.
  // NOTE: syscall returns int, but also it is needed to use %lu or %ld
  if ( report )
    printf( "I’m thread %lu. The maximum sum I found is %d.\n", pthread_self(), workerMaxSum );

  // Update maxSum if a bigger value is found
  sem_wait( &maxSumSem );
  maxIf( &maxSum, workerMaxSum);
  sem_post( &maxSumSem );
  // ...

  return NULL;
}

int main( int argc, char *argv[] ) {
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Initialize semaphores
  sem_init( &checkWork, 0, 0 ); // No free pass
  sem_init( &getWorkSem, 0, 1 ); // Free pass
  sem_init( &maxSumSem, 0, 1 ); // Free pass

  // readList();

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    if ( pthread_create( &worker[ i ], NULL, workerRoutine, NULL ) != 0 )
      fail( "Can't create worker" );
    // ...

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join( worker[ i ], NULL );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", maxSum );

  // Destroy semaphors
  sem_destroy( &checkWork ); // No free pass
  sem_destroy( &getWorkSem ); // Free pass
  sem_destroy( &maxSumSem ); // Free pass

  
  return EXIT_SUCCESS;
}
