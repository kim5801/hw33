#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <semaphore.h>

// Toggles safe/unsafe modes
// Not exactly how the writeup wants, though
// #ifndef UNSAFE
//   #define sem_wait( X ) sem_wait( X )
//   #define sem_post( X ) sem_post( X )
// #else
//   #define sem_wait( X )
//   #define sem_post( X )
// #endif

// The grid semaphore
sem_t *stateSem;

// Print out an error message and exit.
static void fail( char const *message )
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Attach the shared memory.
static void *myShmat()
{
  key_t key = ftok( HOME, 1 );
  if ( key == -1 )
    fail( "Can't create key" );
  int shmid = shmget( key, sizeof( GameState ), 0666 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  GameState *state = (GameState *)shmat( shmid, 0, 0 );
  if ( state == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
  return state;
}

// Prints the board
static void report( GameState *state )
{
#ifndef UNSAFE
  sem_wait( stateSem );
#endif
  for ( int i = 0; i < GRID_SIZE; i++ )
    printf( "%s\n", state->board[ i ] );
#ifndef UNSAFE
  sem_post( stateSem );
#endif
}

// Inverts the current location, if it is valid
static bool invert( GameState *state, int r, int c )
{
  if ( r < 0 || r >= GRID_SIZE
    || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
  
  if ( state->board[ r ][ c ] == '.' ) {
    state->board[ r ][ c ] = '*';
  } else {
    state->board[ r ][ c ] = '.';
  }

  return true;
}

// Converts string to int
// Returns -100 on error
static int parseInt( char *str )
{
  int result;
  char check;
  int matches = sscanf( str, "%d %c", &result, &check );
  if ( matches != 1 )
    return -100;
  
  return result;
}

// The body of the original move() so that
// undo() can make a move without repeating code
// Returns false if the location is invalid
static bool moveUnsafe( GameState *state, int r, int c )
{
  if ( !invert( state, r, c ) )
    return false;

  invert( state, r + 1, c );
  invert( state, r - 1, c );
  invert( state, r, c + 1 );
  invert( state, r, c - 1 );

  // For a later undo() call
  state->canUndo = true;
  state->lastMove[ 0 ] = r;
  state->lastMove[ 1 ] = c;

  return true;
}

// Simulates clicking on a spot
// Returns false on error, otherwise returns true
// This version requires ints for row and column
static bool move( GameState *state, int r, int c )
{
#ifndef UNSAFE
  sem_wait( stateSem );
#endif
  bool valid = moveUnsafe( state, r, c );
#ifndef UNSAFE
  sem_post( stateSem );
#endif
  return valid;
}
// Simulates clicking on a spot
// Returns false on error, otherwise returns true
// This version requires strings for row and column
static bool _move( GameState *state, char *rstr, char *cstr )
{
  int r = parseInt( rstr );
  if ( r == -100 )
    return false;
  int c = parseInt( cstr );
  if ( c == -100 )
    return false;

  return move( state, r, c );
}

// Undoes the last move if possible and returns true
// Otherwise returns false
static bool undo( GameState *state )
{ 
#ifndef UNSAFE
  sem_wait( stateSem );
#endif
  if ( !state->canUndo )
    return false;

  // Call the "unsafe" move, since the semaphore is already locked
  moveUnsafe( state, state->lastMove[ 0 ], state->lastMove[ 1 ] );

  // Overwrite canUndo since moveUnsafe() always sets canUndo=true
  state->canUndo = false;
#ifndef UNSAFE
  sem_post( stateSem );
#endif
  return true;
}

// Test interface, for quickly making a given move over and over.
// Returns true if the integers are valid, false otherwise
// This version requires ints for n, r, and c
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE
    || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

// Test interface, for quickly making a given move over and over.
// Returns true if the integers are valid, false otherwise
// This version requires strings for nstr, rstr, and cstr
bool _test( GameState *state, char *nstr, char *rstr, char *cstr )
{
  int n = parseInt( nstr );
  if ( n == -100 )
    return false;
  int r = parseInt( rstr );
  if ( r == -100 )
    return false;
  int c = parseInt( cstr );
  if ( c == -100 )
    return false;
  
  return test( state, n, r, c );
}

// Prints the success message
static void success()
{
  printf( "success\n" );
}

// Prints the error message and exits
static void error()
{
  printf( "error\n" );
  exit( 1 );
}

int main( int argc, char *argv[] )
{
  // Attach the shared memory
  GameState *state = myShmat();

  // Get the semaphore
  stateSem = sem_open( SEM_NAME, 0 );
  if ( stateSem == SEM_FAILED )
    fail( "Can't get the semaphore" );


  // Validate command name, argc
  // Let the commands do the rest
  // report/undo: argc == 2
  // move r c   : argc == 4
  // test n r c : argc = 5
  if ( argc == 2 )
    if ( strcmp( argv[ 1 ], "report" ) == 0 )
      report( state );
    else if ( strcmp( argv[ 1 ], "undo" ) == 0 )
      if ( undo( state ) )
        success();
      else
        error();
    else
      error();
  else if ( argc == 4 && strcmp( argv[ 1 ], "move" ) == 0 )
    if ( _move( state, argv[ 2 ], argv[ 3 ] ) )
      success();
    else
      error();
  else if ( argc == 5 && strcmp( argv[ 1 ], "test" ) == 0 )
    if ( _test( state, argv[ 2 ], argv[ 3 ], argv[ 4 ] ) ) {}
      // The test command should not print anything
    else
      error();
  else
    error();

  // Close the semaphore
  sem_close( stateSem );
  
  return 0;
}
