/**
 * @file lightsout.c
 * @author Ethan Treece (eltreece)
 * 
 * Retrieves the board information from shared memory and processes board operations.
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "error\n" );
  exit( EXIT_FAILURE );
}

// Flips the 'light' by switching * and . characters
void flip(char *c) {
  if (*c == '*') {
    *c = '.';
  } else {
    *c = '*';
  }
}

// Processes the move operation
// Make a move at the given row, column location, returning true
// if successful.
// void move(char *x, char *y) {
bool move( GameState *state, int r, int c ) {

  #ifndef UNSAFE
    sem_wait( sem_open( "/eltreece-lightsout-lock", 0 ) );
  #endif

  state->undo = 0;
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      state->temp[i][j] = state->arr[i][j];
    }
  }
  
  if (r == 0 && c == 0) { // top left
    flip(&state->arr[0][0]);
    flip(&state->arr[0][1]);
    flip(&state->arr[1][0]);
  } else if (r == 0 && c == 4) { // top right
    flip(&state->arr[0][4]);
    flip(&state->arr[0][3]);
    flip(&state->arr[1][4]);
  } else if (r == 4 && c == 4) { // bottom right
    flip(&state->arr[0][0]);
    flip(&state->arr[0][1]);
    flip(&state->arr[1][0]);
  } else if (r == 4 && c == 0) { // botttom left
    flip(&state->arr[4][0]);
    flip(&state->arr[3][0]);
    flip(&state->arr[4][1]);
  } else if (r == 0) { // top edge
    flip(&state->arr[0][c]);
    flip(&state->arr[0][c + 1]);
    flip(&state->arr[0][c - 1]);
    flip(&state->arr[1][c]);
  } else if (r == 4) { // bottom edge
    flip(&state->arr[4][c]);
    flip(&state->arr[4][c + 1]);
    flip(&state->arr[4][c - 1]);
    flip(&state->arr[3][c]);
  } else if (c == 0) { // left edge
    flip(&state->arr[r][0]);
    flip(&state->arr[r + 1][0]);
    flip(&state->arr[r - 1][0]);
    flip(&state->arr[r][1]);
  } else if (c == 4) { // right edge
    flip(&state->arr[r][4]);
    flip(&state->arr[r + 1][4]);
    flip(&state->arr[r - 1][4]);
    flip(&state->arr[r][3]);
  } else { // middle area
    flip(&state->arr[r][c]);
    flip(&state->arr[r + 1][c]);
    flip(&state->arr[r - 1][c]);
    flip(&state->arr[r][c + 1]);
    flip(&state->arr[r][c - 1]);
  }
  #ifndef UNSAFE
    sem_post( sem_open( "/eltreece-lightsout-lock", 0 ) );
  #endif
  return true;
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

// Processes the undo operation
bool undo( GameState *state ) {

  #ifndef UNSAFE
  sem_wait( sem_open( "/eltreece-lightsout-lock", 0 ) );
  #endif

  if (state->undo == 0) {
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        state->arr[i][j] = state->temp[i][j];
      }
    }
    state->undo = 1; 
    #ifndef UNSAFE
    sem_post( sem_open( "/eltreece-lightsout-lock", 0 ) );
    #endif
    return true;
  } else {
    #ifndef UNSAFE
    sem_post( sem_open( "/eltreece-lightsout-lock", 0 ) );
    #endif
    return false;
  }
}

// Print the current state of the board.
void report( GameState *state ) {

  #ifndef UNSAFE
  sem_wait( sem_open( "/eltreece-lightsout-lock", 0 ) );
  #endif

  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", state->arr[i][j]);
    }
    printf("\n");
  }

  #ifndef UNSAFE
  sem_post( sem_open( "/eltreece-lightsout-lock", 0 ) );
  #endif

}

int main( int argc, char *argv[] ) {

  // Make a shared memory segment 1KB in size
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/eltreece/", 0), sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  GameState *sbuffer = (GameState *)shmat( shmid, 0, 0 );
  if ( sbuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  if ( argc == 2 ) {
    if (strcmp( argv[ 1 ], "report" ) == 0) {
      report(sbuffer);
    } else if (strcmp( argv[ 1 ], "undo" ) == 0) {
      if (undo(sbuffer)) {
        printf("success\n");
      } else {
        fail("error");
      }
    } else {
      usage();
    }
  } else if (argc == 4) {
    if ( strcmp( argv[ 1 ], "move" ) != 0 ) {
      usage();
    } else {
      if (strlen(argv[2]) > 1 || strlen(argv[3]) > 1)
        usage();
      if (argv[2][0] < 48 || argv[2][0] > 52 || argv[3][0] < 48 || argv[3][0] > 52)
        usage();
      move(sbuffer, atoi(argv[2]), atoi(argv[3]));
      printf("success\n");
    }
  } else if (argc == 5) {
    if ( strcmp (argv[ 1 ], "test") != 0) {
      usage();
    } else {
      if (strlen(argv[3]) > 1 || strlen(argv[4]) > 1)
        usage();
      if (argv[3][0] < 48 || argv[3][0] > 52 || argv[4][0] < 48 || argv[4][0] > 52)
        usage();
      test(sbuffer, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
    }
  } else {
    usage();
  }

  // Release our reference to the shared memory segment.
  shmdt( sbuffer );

  return 0;
}
