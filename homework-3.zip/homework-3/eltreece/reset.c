/**
 * @file reset.c
 * @author Ethan Treece (eltreece)
 * 
 * Reads the initial game board and creates the shared memory segment containing any information needed
 * for the game.
 * 
 * Code referenced from shmWriter.c
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void invalidInput(char *c) {
  fprintf( stderr, "Invalid input file: %s\n", c );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  
  // Usage too many arguments
  if (argc != 2)
    usage();

  // Open the input file for reading.
  FILE *fp = fopen( argv[1], "r" );
  if ( !fp ) 
    invalidInput(argv[1]);

  char arr[GRID_SIZE][GRID_SIZE];

  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      char c = fgetc(fp);
      if (c != '*' && c != '.')
        invalidInput(argv[1]);
      arr[i][j] = c;
    }
    char c = fgetc(fp);
      if (c != '\n')
        invalidInput(argv[1]);
  }

  // Make a shared memory segment 1KB in size
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/eltreece/", 0), sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  // First, destroy any old copies the tag semaphore, just in case
  // a previous execution of this program crashed and left the
  // semaphore in an unknown state.
  sem_unlink( "/eltreece-lightsout-lock" );

  // Make a shared semaphore
  sem_t *tagSem = sem_open( "/eltreece-lightsout-lock", O_CREAT, 0600, 1 );
  if ( tagSem == SEM_FAILED )
    fail( "Can't make tag semaphore" );

  GameState *sbuffer = (GameState *)shmat( shmid, 0, 0 );
  if ( sbuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  // Initializes the gameboard into the GameState struct
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      sbuffer->arr[i][j] = arr[i][j];
      sbuffer->temp[i][j] = arr[i][j];
    }
  }
  sbuffer->undo = 1;

  // Release our reference to the shared memory segment.
  shmdt( sbuffer );

  return 0;
}
