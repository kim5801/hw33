#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}



// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Number of workers
int workers = 4;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Buffer for holding indexes of input
double buffer[ MAX_VALUES ];

// Index of first value in buffer
int first = 0;

// Number of values in the buffer
int bufNum = 0;

// Sentinel value that indicates end of input
#define SENTINEL 0.5

// Semaphore that counts full buffer slots
sem_t fullCount;

// Semaphore to lock buffer
sem_t lock;

// Semaphore to lock max_sum
sem_t sumLock;



// Adds value to list and index to buffer
void produce(int v, double idx) {
  sem_wait(&lock);
  if (idx != SENTINEL)
    vList[ vCount++ ] = v;
  buffer[ (first+bufNum) % MAX_VALUES ] = idx;
  bufNum++;
  sem_post(&lock);
  sem_post(&fullCount);
}

// Read the list of values.
void readList() {
  double idx = 0;
  int v;

  // Read the next value
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    produce(v, idx++);
  }

  //Produce sentinels to tell workers to stop
  for (int i = 0; i < workers; i++)
    produce(0, SENTINEL);
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int sum;
  int localMax;
  double bufferEnd = -1.0;
  int end = -1;
  bool moreInput = true;

  // Consumes end from buffer
  sem_wait(&fullCount);
  sem_wait(&lock);
  bufferEnd = buffer[ first ];
  first = (first + 1) % MAX_VALUES;
  bufNum--;
  sem_post(&lock);
  end = (int)bufferEnd;
  if (bufferEnd - end != 0)
    moreInput = false;

  // While there's still work to be done
  while (moreInput) {

    sum = 0;
    localMax = INT_MIN;

    // Loop through values until end and find max sum ending at end
    for ( int i = end; i >= 0; i-- ) {
      sum += vList[i];
      if (sum > localMax)
        localMax = sum;
    }

    // Optional report, referenced email Getting Thread ID
    if (report)
      printf("I’m process %lu. The maximum sum I found is %d.\n", pthread_self(), localMax);

    // Updates max_sum
    sem_wait(&sumLock);
    if (localMax > max_sum)
      max_sum = localMax;
    sem_post(&sumLock);

    // Consumes end from buffer
    sem_wait(&fullCount);
    sem_wait(&lock);
    bufferEnd = buffer[ first ];
    first = (first + 1) % MAX_VALUES;
    bufNum--;
    sem_post(&lock);
    end = (int)bufferEnd;
    if (bufferEnd - end != 0)
      moreInput = false;
  }

  // Terminates thread
  return NULL;
}

int main( int argc, char *argv[] ) {
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();
  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //Initialize semaphores
  sem_init(&fullCount, false, 0);
  sem_init(&lock, false, 1);
  sem_init(&sumLock, false, 1);

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, NULL);

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
