#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

bool done = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

int numRead = 0;
bool finished = false;

sem_t canWork;
sem_t globalLock;
sem_t lock;
sem_t updateMax;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    sem_post(&canWork);
  }
  done = true;
  finished = true;
}

int getWork() {
  if (finished && numRead == vCount - 1) {
    // printf("hi");
    return -1;
  }
  // printf("Acquiring...\n");
  sem_wait(&canWork);
  numRead++;
  // printf("Acquired.\n");
  // printf("numread %d\n", numRead);
  return numRead;
}

int max(int one, int two) {
  if (one >= two) {
    return one;
  }
  else {
    return two;
  }
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int count = *((int *) arg);
  int threadSum = 0;
  // ...
  while (true) {
    //function that returns when a thread is able to do work
    // count = getWork();
    // printf("Acquiring...\n");
    // printf("Acquired.\n");
    
    sem_wait(&lock);
    count = getWork();
    sem_post(&lock);
    // printf("num read: %d", numRead);
    //find the sum from the 0th value to the last value read in at index count
    int sum = 0;
    if (count == -1) {
      break;
    }
    int totalSum = 0;
    for (int i = count; i >= 0; i--) {
      // printf("Sum : %d\n", sum);
      sum = max(sum, totalSum + vList[i]);
      totalSum = totalSum + vList[i];
    }
    if(sum >= max_sum) {
      sem_wait(&updateMax);
      max_sum = sum;
      threadSum = sum;
      sem_post(&updateMax);
    }
    
  }
  if (report) {
    printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), threadSum);

  }

  return NULL;
}


int main( int argc, char *argv[] ) {
  int workers = 4;
  sem_init(&canWork, 0, 0);
  sem_init(&globalLock, 0, 1);
  sem_init(&lock, 0, 1);
  sem_init(&updateMax, 0, 1);
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];

  //array of thread arguments
  int threadArg[workers];
  for ( int i = 0; i < workers; i++ ) {
    threadArg[i] = 0;
    pthread_create(&worker[i], NULL, workerRoutine, threadArg + i);
  }
  
    // ...

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }

    // ...

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  sem_destroy(&canWork);
  sem_destroy(&lock);
  sem_destroy(&updateMax);
  
  return EXIT_SUCCESS;
}
