#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include <errno.h>
#include "common.h"

// Semaphore to enable mutual exclusion
#ifndef UNSAFE
  static sem_t *sem;
#endif

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  Moves the given board at the positions x and y as 
  provided.

  @param x the x position to move at
  @param y the y position to move at
  @param b the board pointer to edit.
*/
void move(int x, int y, board *b) {
  // Wait for the lcok
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  // Reverse the light at the given position
  b->lights[x][y] = !b->lights[x][y];
  // Check position above and update
  if (x+1 < 5) {
    b->lights[x+1][y] = !b->lights[x+1][y];
  }
  // Check position below and update
  if (x-1 >= 0) {
    b->lights[x-1][y] = !b->lights[x-1][y];
  }
  // Check position to the right and update
  if (y+1 < 5) {
    b->lights[x][y+1] = !b->lights[x][y+1];
  }
  // Check position to the left and update
  if (y-1 >= 0) {
    b->lights[x][y-1] = !b->lights[x][y-1];
  }
  // Update last moved row and column
  b->lastRow = x;
  b->lastCol = y;
  // Update whether the user can undo or not
  b->canUndo = true;
  // Release the lock
  #ifndef UNSAFE
    sem_post( sem );
  #endif

}

/**
  Undos the last move of the given board at the 
  positions x and y as provided.

  @param b the board pointer to edit.
  @return whether the board can undo or not
*/
bool undo(board *b) {
  // wait for the lock
  #ifndef UNSAFE
    sem_wait( sem );
  #endif

  if (!b->canUndo) {
    #ifndef UNSAFE
      sem_post( sem );
    #endif
    return false;
  }
  // Use the move function logic to undo the last move
  // The logic is copy pasted so the undo function can hold the semaphore
  // the entire time
  int x = b->lastRow;
  int y = b->lastCol;
  // Reverse the light at the given position
  b->lights[x][y] = !b->lights[x][y];
  // Check position above and update
  if (x+1 < 5) {
    b->lights[x+1][y] = !b->lights[x+1][y];
  }
  // Check position below and update
  if (x-1 >= 0) {
    b->lights[x-1][y] = !b->lights[x-1][y];
  }
  // Check position to the right and update
  if (y+1 < 5) {
    b->lights[x][y+1] = !b->lights[x][y+1];
  }
  // Check position to the left and update
  if (y-1 >= 0) {
    b->lights[x][y-1] = !b->lights[x][y-1];
  }
  // Update last moved row and column
  b->lastRow = x;
  b->lastCol = y;
  // Update whether the user can undo or not
  b->canUndo = true;
  // Set canUndo to false
  b->canUndo = false;
  // release the lock
  #ifndef UNSAFE
    sem_post( sem );
  #endif
  return true;
}

/**
  Reports the state of the board.

  @param b the board pointer to report.
*/
void report(board *b) {
  // Wait for lock
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  
  // Loop through each row and column
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      // Print the appropriate character for the board
      if (b->lights[i][j] == true) {
        printf("*");
      } else {
        printf(".");
      }
    }
    printf("\n");
  }
  // Release lock
  #ifndef UNSAFE
    sem_post( sem );
  #endif
}

// For test interface. Moves a position n times over and over.
bool test(board *b, int n, int r, int c) {
  // make moves
  for (int i = 0; i < n; i++) {
    move(r, c, b);
  }
  return true;
}

/**
  The main method to process instructions for the lightsout
  game.
  @param argc number of command line args
  @param argv the command line args
  @return exit status
*/
int main( int argc, char *argv[] ) {
  // Open semaphore if needed
  #ifndef UNSAFE
    sem = sem_open(SEM_NAME, 0);
    if (sem == SEM_FAILED) {
      fail("Can't open semaphore.");
    }
  #endif

  // Create a shmid from the shared memory region opened up in reset.c
  int shmid = shmget(ftok(HOME_DIR, 1), sizeof(board), 0 );
  if (shmid == -1)
    fail("Unable to create shared memory.");
  // Attach memory and cast to board pointer
  board *b = (board *) shmat(shmid, 0, 0);
  if ( b == (board *)-1 )
    fail( "Couldn't map shared memory into address space." );

  // Parse command-line arguments.
  if ( argc != 2 && argc != 4 && argc != 5 ) {
    fail("error");
  }

  // If command number is potentially undo or report
  if (argc == 2) {
    // Check each option and perform action accordingly
    if (strcmp("undo", argv[1]) == 0) {
      if (undo(b)) {
        // Undo
        printf("success\n");
      } else {
        fail("error");
      }
    } else if (strcmp("report", argv[1]) == 0) {
      // Report
      report(b);
    } else {
      // Not a valid command
      fail("error");
    }
  } else if (argc == 4) {
    // Check for potential move command
    if (strcmp("move", argv[1]) == 0) {
      // Check if the coordinates are valid
      if (argv[2][0] >= '0' && argv[2][0] <= '4' && strlen(argv[2]) == 1
          && argv[3][0] >= '0' && argv[3][0] <= '4' && strlen(argv[3]) == 1) {
        // Move
        move(argv[2][0] - '0', argv[3][0] - '0', b);
        printf("success\n");
      } else {
        // Coords are not valid so error out
        fail("error");
      }
    } else {
      // Coords are not valid, so error out
      fail("error");
    }
  } else if (argc == 5) {
    if (strcmp("test", argv[1]) == 0) {
      if (atoi(argv[2]) != -1 && argv[4][0] >= '0' && argv[4][0] <= '4' && strlen(argv[4]) == 1
          && argv[3][0] >= '0' && argv[3][0] <= '4' && strlen(argv[3]) == 1) {
        test(b, atoi(argv[2]), (int) (argv[3][0] - '0'), (int) (argv[4][0] - '0'));
      } else {
        fail("error");
      }
    } else {
      fail("error");
    }
  }
  // Detach pointer to shared memory and release semaphore if necessary
  shmdt(b);
  #ifndef UNSAFE
    sem_close(sem);
  #endif
  return 0;
}
