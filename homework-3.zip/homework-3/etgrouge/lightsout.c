/**
  @file lightsout.c
  @author Erin Grouge
  This program uses the GameState in the shared memory block to perform
  the desired game operations (report, move, undo). It prints the result 
  of the operation, detaches from the shared memory, and exits. 
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// The semaphore used to prevent race conditions.
sem_t * sem;

/** Print out an error message and exit. 
    @param message the error message to print
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Checks if the character is a valid number (0-9)
  @param ch the character to check
  @return true if the character is valid
 */
static int isValid(char ch)
{
  return (ch >= '0' && ch <= '9');
}

/** Parses the given string to an integer value
  @param the string to parse
  @return val the integer value of the string
 */
static int parse(char * str)
{
  int val = 0;
  int i = 0;
  // While not at the end, read digits left to right, updating decimal value as you go.
  while(str[i] != '\0'){
    // If not valid characters, return -1
    if(!isValid(str[i])){
      return -1;
    }
    // Convert to integer value
    int num = str[i] - '0';
    // Shift left digits over by multiplying by 10
    val = val * 10 + num;
    i++;
  }
  return val;
}

/** Constructs the report message based on board status. 
    @param board the board to report
*/
void report(GameState *board){
  // Acquire the semaphore
  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  // Print the board status
  int index = 0;
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      if(board->gameboard[i][j] == ON){
        printf("*");
      } else {
        printf(".");
      }
      index++;
    }
    printf("\n");
    index++;
  }

  // Release the semaphore.
  #ifndef UNSAFE
    sem_post(sem);
  #endif
}

/** Performs the move operation by updating the board status. 
    @param board the board to perform the move on
    @param r the row of the selected move
    @param c the column of the selected move
    @return true if the move was successful, false if not.
 */
bool move(GameState *board, int r, int c){
  // If invalid, exit with error.
  if(r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
    return false;
  
  // Acquire the semaphore
  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  // Switch the pressed tile
  if(board->gameboard[r][c] == ON){
    board->gameboard[r][c] = OFF;
  } else {
    board->gameboard[r][c] = ON;
  }

  //Switch tile above if exists
  if(r - 1 >= 0){
    if(board->gameboard[r - 1][c] == ON){
      board->gameboard[r - 1][c] = OFF;
    } else {
      board->gameboard[r - 1][c] = ON;
    }
  }

  //Switch tile below if exists
  if(r + 1 <= 4){
    if(board->gameboard[r + 1][c] == ON){
      board->gameboard[r + 1][c] = OFF;
    } else {
      board->gameboard[r + 1][c] = ON;
    }
  }

  //Switch tile left if exists
  if(c - 1 >= 0){
    if(board->gameboard[r][c - 1] == ON){
      board->gameboard[r][c - 1] = OFF;
    } else {
      board->gameboard[r][c - 1] = ON;
    }
  }

  //Switch tile right if exists
  if(c + 1 <= 4){
    if(board->gameboard[r][c + 1] == ON){
      board->gameboard[r][c + 1] = OFF;
    } else {
      board->gameboard[r][c + 1] = ON;
    }
  }
 
  // Update board state
  board->lastMove[0] = r;
  board->lastMove[1] = c;
  board->canUndo = true;

  // Release the semaphore and exit successfully.
  #ifndef UNSAFE
    sem_post(sem);
  #endif
  return true;
}

/**
  Performs the undo operation if possible.
  @param board the board to perform the move on
  @return true if the undo was successful, false if not.
 */
bool undo(GameState * board){
  // Acquire the semaphore
  #ifndef UNSAFE
    sem_wait(sem);
  #endif

  // If the undo can be done, undo the previous move.
  if(board->canUndo){
    // Update the board struct fields and report success back to client. 
    int r = board->lastMove[0];
    int c = board->lastMove[1];
    board->canUndo = false;

    // Switch the pressed tile
    if(board->gameboard[r][c] == ON){
      board->gameboard[r][c] = OFF;
    } else {
      board->gameboard[r][c] = ON;
    }

    //Switch tile above if exists
    if(r - 1 >= 0){
      if(board->gameboard[r - 1][c] == ON){
        board->gameboard[r - 1][c] = OFF;
      } else {
        board->gameboard[r - 1][c] = ON;
      }
    }

    //Switch tile below if exists
    if(r + 1 <= 4){
      if(board->gameboard[r + 1][c] == ON){
        board->gameboard[r + 1][c] = OFF;
      } else {
        board->gameboard[r + 1][c] = ON;
      }
    }

    //Switch tile left if exists
    if(c - 1 >= 0){
      if(board->gameboard[r][c - 1] == ON){
        board->gameboard[r][c - 1] = OFF;
      } else {
        board->gameboard[r][c - 1] = ON;
      }
    }

    //Switch tile right if exists
    if(c + 1 <= 4){
      if(board->gameboard[r][c + 1] == ON){
        board->gameboard[r][c + 1] = OFF;
      } else {
        board->gameboard[r][c + 1] = ON;
      }
    }
    // Release the semaphore and return true.
    #ifndef UNSAFE
      sem_post(sem);
    #endif
    return true;
  } 
  // If not a valid undo, release the semaphore and return false.
  else {
    #ifndef UNSAFE
      sem_post(sem);
    #endif
    return false;
  }
}

// Test Interface from assignment
bool test(GameState * board, int n, int row, int col){
  // Make sure the row and column is valid
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE || n < 0)
    return false;
  
  // Make the same move a bunch of times.
  for(int i = 0; i < n; i++){
    move(board, row, col);
  }

  return true;
}

/** Starting point of the program.
    Gets access to the board in shared memory, reads in the user input,
    performs the operation if valid, and prints back to the user.
    @param argc the number of arguments
    @param argv the array of arguments
 */
int main( int argc, char *argv[] ) {
  // Check number of arguments
  if(argc < 2 || argc > 5){
    fail("error");
  }

  // Get shared memory
  key_t key = ftok("/afs/unity.ncsu.edu/users/e/etgrouge", 1234);
  int shmid = shmget(key, BLOCK_SIZE, 0);
  GameState *board = (GameState *)shmat(shmid, 0, 0);

  // Open the semaphore used to prevent race conditions
  sem = sem_open(SEM_NAME, 0);
  if(sem == SEM_FAILED)
    fail("Can't open semaphore");

  // Check arguments and perform operations accordingly
  // If report, print board status
  if(strcmp(argv[1], "report") == 0){
    // Check for correct number of arguments
    if(argc != 2)
      fail("error");
    
    // Print the board status.
    report(board);

  } // If undo, perform the undo
  else if(strcmp(argv[1], "undo") == 0){
    // Check for correct number of arguments
    if(argc != 2)
      fail("error");

    // Perform undo and report success or failure.
    if(undo(board)){
      printf("success\n");
    } else {
      fail("error");
    }

  } // If move, perform the move operation
  else if(strcmp(argv[1], "move") == 0){
    // Check for correct number of arguments
    if(argc != 4)
      fail("error");

    // Parse the row and column as integers
    int row = parse(argv[2]);
    int col = parse(argv[3]);

    // Perform the move operation and report success or failure.
    if(move(board, row, col)){
      printf("success\n");
    } else {
      fail("error");
    }

  } else if(strcmp(argv[1], "test") == 0){
    // Check for correct number of arguments
    if(argc != 5)
      fail("error");

    // Parse the times, row, and column as integers
    int n = parse(argv[2]);
    int row = parse(argv[3]);
    int col = parse(argv[4]);

    // Perform the test operation and report success or failure.
    if(test(board, n, row, col)){
      printf("success\n");
    } else {
      fail("error");
    }

  }
  // If the argument is anything else, fail.
  else {
    fail("error");
  }

  // Detach from memory, close semaphore, and exit successfully.
  shmdt(board);
  sem_close(sem);
  return EXIT_SUCCESS;
}
