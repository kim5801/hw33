/**
  @file reset.c
  @author Erin Grouge
  This program reads in the board file and initializes the GameStruct in shared 
  memory that it creates. Once the shared GameStruct is created properly, it 
  detaches and exits. 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

/** Print out an error message and exit.
    @param message the error message to print
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Print out a usage message and exit. */
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/** Reads the board file and stores it in the board struct
    @param file the file to read the board status from
    @param board the board to initialize
 */
static void readFile(const char *file, GameState *board){
  FILE * fp = fopen(file, "r");
  char ch;

  // Sets up error message by adding filename to error string
  char *msg = "Invalid input file: ";
  char errmsg[strlen(msg) + strlen(file) + 1];
  strcpy(errmsg, msg);
  strcat(errmsg, file);

  // If file doesn't exist, exit with error.
  if(fp == NULL)
    fail(errmsg);

  // Read file character by character assigning proper value to 
  // the board struct, failing if in improper format. 
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      if(fscanf(fp, "%c", &ch) == -1)
        fail(errmsg);
      if(ch == '.'){
        board->gameboard[i][j] = OFF;
      } else if (ch == '*'){
        board->gameboard[i][j] = ON;
      } else {
        fail(errmsg);
      }
    }
    // Make sure there's a newline at the end of each line
    if(fscanf(fp, "%c", &ch) == -1){
      fail(errmsg);
    } else if ( ch != '\n'){
      fail(errmsg);
    }
  }
  // Check to make sure there are no more characters.
  if(fscanf(fp, "%c", &ch) != EOF){
    fail(errmsg);
  }
}

/** Starting point of the program.
    Creates and attaches to shared memory of a GameState struct.
    Reads in the file given and initializes the gameboard to the board state in the file.
    Then detaches and returns success.
    @param argc the number of arguments
    @param argv the array of arguments
 */
int main( int argc, char *argv[] ) {
  // Check for correct argument amount
  if(argc != 2)
    usage();

  // Create semaphore - destroying it if its been previously created
  sem_unlink(SEM_NAME);
  sem_t * semaphore = sem_open(SEM_NAME, O_CREAT, 0600, 1);
  if(semaphore == SEM_FAILED)
    fail("Failed to create semaphore");
  
  // Create and attach to shared memory
  key_t key = ftok("/afs/unity.ncsu.edu/users/e/etgrouge", 1234);
  int shmid = shmget(key, BLOCK_SIZE, 0666 | IPC_CREAT);
  if(shmid == -1)
    fail("Failed to get memory.");
  
  // Shared memory is a GameState so keep pointer to it to modify board.
  GameState *board = (GameState *)shmat(shmid, 0, 0);

  sem_wait(semaphore);
  // Read in file and initialize board
  readFile(argv[1], board);
  board->canUndo = false;
  board->lastMove[0] = -1;
  board->lastMove[1] = -1;
  sem_post(semaphore);

  // Detach and return success. 
  shmdt(board);
  sem_close(semaphore);

  return EXIT_SUCCESS;
}
