/**
  @file maxsum-sem.c
  @author Erin Grouge
  The maxsum program calculates the maximum sum found among adjacent numbers in the given 
  list. This version uses semaphores to gaurantee that no race conditions occur.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( EXIT_FAILURE );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Lock to use for max_sum 
sem_t lock;

// Semaphore used to indicate how much work is available.
sem_t work;

// Flag for when done. 
bool done = false;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

// Value used to signal there is no more work.
#define SIGNAL -1

// Next index to sum to
int index = SIGNAL;

/**
  Returns the next available index to sum to 
  @return idx the next index to work on
 */
int getWork() {
  // Wait for work, then lock the critical section
  sem_wait(&work);
  sem_wait(&lock);

  // If done reading and all available work has been given out, signal to threads with the -1 value.
  if(done && index >= vCount - 1){
      sem_post(&lock);
      return SIGNAL;
  }

  // Once work is available, increase the index and return it to worker.
  index++;
  int idx = index;

  // Unlock critical section and return the next index to work on.
  sem_post(&lock);

  return idx;
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Lock to prevent race conditions.
    sem_wait(&lock);
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    // Increment work to indicate that work is available and unlock.
    sem_post(&work);
    sem_post(&lock);
  }
  // Lock and set done to be true to notify all workers that reading is done.
  sem_wait(&lock);
  done = true;
  sem_post(&lock);
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // Start the sum at the minimum value
  int localMax = INT_MIN;
  // Get the index to start summation to.
  int idx = getWork();
  // While index is not -1 (the signal value), sum from index to beginning of list
  while(idx != SIGNAL){
    int sum = 0;
    // Start at idx and sum until index 0 is reached, updating the largest sum found. 
    for(int i = idx; i >= 0; i--){
        sum += vList[i];
        if(sum > localMax)
          localMax = sum;
    } 
    // Get the next index to work from.
    idx = getWork();
  }
  
  // When done, lock the semaphore and update the max_sum if it is larger.
  sem_wait(&lock);
  if(localMax > max_sum)
    max_sum = localMax;
  sem_post(&lock);

  // If report is true, report the thread's maximum.
  if(report){
    int id = (int) pthread_self();
    printf("I'm thread %u. The maximum sum I found is %d.\n", id, localMax);
  }
  // Exit successfully. 
  pthread_exit(EXIT_SUCCESS);
}

int main( int argc, char *argv[] ) {
  int workers = 4;

  // Initializing the work and lock for max_sum
  sem_init(&lock, 0, 1);
  sem_init(&work, 0, 0);

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ){
    if ( pthread_create( worker + i, NULL, workerRoutine, NULL ) != 0 )
      fail( "Can't create worker thread.\n" );
  }

  // Then, start getting work for them to do.
  readList();

  // Increment again for each worker to make sure they don't get stuck 
  // waiting for work when finished.
  for(int i = 0; i < workers; i++){
    sem_post(&work);
  }

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ){
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  // Destroy sem, mon, and cond.
  sem_destroy(&lock);
  sem_destroy(&work);

  // Return success.
  return EXIT_SUCCESS;
}
