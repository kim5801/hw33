#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}


sem_t *s;



void report(GameState *game) {

  #ifndef UNSAFE
    sem_wait( s );
  #endif

  for(int i = 0; i < 5; i++) {
    printf("%c%c%c%c%c\n", game->board[i][0], game->board[i][1], game->board[i][2], game->board[i][3], game->board[i][4]);
  }
  #ifndef UNSAFE
    sem_post( s );
  #endif
}

char flipOne (char c) {
  if (c == '.') {
    return '*';
  } else {
    return '.';
  }
}

bool move(GameState *game, int r, int c) {
  #ifndef UNSAFE
    sem_wait( s );
  #endif
  game->numMoves++;
  if (r == 0) {
    if (c == 0) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
      game->lastR = r;
      game->lastC = c;
      #ifndef UNSAFE
        sem_post( s );
      #endif
      return true;
    } else if (c == 4) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
      game->lastR = r;
      game->lastC = c;
      #ifndef UNSAFE
        sem_post( s );
      #endif
      return true;
    } else {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
      game->lastR = r;
      game->lastC = c;
      #ifndef UNSAFE
        sem_post( s );
      #endif
      return true;
    }
  } else if (r == 4) {
    if (c == 0) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
      game->lastR = r;
      game->lastC = c;
      #ifndef UNSAFE
        sem_post( s );
      #endif
      return true;
    } else if (c == 4) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
      game->lastR = r;
      game->lastC = c;
      #ifndef UNSAFE
        sem_post( s );
      #endif
      return true;
    } else {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
      game->lastR = r;
      game->lastC = c;
      #ifndef UNSAFE
        sem_post( s );
      #endif
      return true;
    }
  }

  if (c == 0) {
    game->board[r][c] = flipOne(game->board[r][c]);
    game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
    game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
    game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
    game->lastR = r;
    game->lastC = c;
    #ifndef UNSAFE
      sem_post( s );
    #endif
    return true;
  } else if (c == 4) {
    game->board[r][c] = flipOne(game->board[r][c]);
    game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
    game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
    game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
    game->lastR = r;
    game->lastC = c;
    #ifndef UNSAFE
      sem_post( s );
    #endif
    return true;
  } else {
    game->board[r][c] = flipOne(game->board[r][c]);
    game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
    game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
    game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
    game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
    game->lastR = r;
    game->lastC = c;
    #ifndef UNSAFE
      sem_post( s );
    #endif
    return true;
  }
  game->numMoves--;
  #ifndef UNSAFE
    sem_post( s );
  #endif
  return false;
}

bool undo(GameState *game) {
  #ifndef UNSAFE
    sem_wait( s );
  #endif
  if (game->numMoves < 1)  {
    #ifndef UNSAFE
      sem_post( s );
    #endif
    return false;
  }
  int ret = move(game, game->lastR, game->lastC);
  #ifndef UNSAFE
    sem_post( s );
  #endif
  return ret;
}







// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
    // Make the same move a bunch of times.
    for ( int i = 0; i < n; i++ )
      move( state, r, c );
  return true;
}









int main( int argc, char *argv[] ) {



  s = sem_open("/tedixon3-lightsout-lock", O_CREAT);


  // int key = ftok("/afs/unity.ncsu.edu/users/t/tedixon3", 69420);

  int shmid;
  GameState *game;
  shmid = shmget(ftok("/afs/unity.ncsu.edu/users/t/tedixon3", 4), sizeof(GameState), 0644);
  if (shmid == -1) {
    fail("Could not create shared memory.");
  }

  game = (GameState *)shmat(shmid, 0, 0);
  if (game == (void *) -1) {
    fail("Could not attach shared memory.");
  }

  // if (argc > 4 || argc == 1) fail("error");

  if (strcmp("undo", argv[1]) == 0) {
    if (!undo(game)) fail("error");
  } else if (strcmp("report", argv[1]) == 0) {
    report(game);
  } else if (strcmp("move", argv[1]) == 0) {
    if (!isdigit(*argv[2]) || !isdigit(*argv[3])) fail("error");
    int r = *argv[2] - '0';
    int c = *argv[3] - '0';
    if (r < 0 || r > 4 || c < 0 || c > 4) fail("error");
    if (!move(game, r, c)) fail("error");
    printf("success\n");
    return EXIT_SUCCESS;

  } else if (strcmp("test", argv[1]) == 0) {
    if (!isdigit(*argv[2]) || !isdigit(*argv[3]) || !isdigit(*argv[4])) fail("error");
    int n = *argv[2] - '0';
    int r = *argv[3] - '0';
    int c = *argv[4] - '0';
    if (r < 0 || r > 4 || c < 0 || c > 4) fail("error");
    if (!test(game, n, r, c)) fail("error");
    printf("success\n");
    return EXIT_SUCCESS;
  } else {
    fail("error");
  }
  





  return 0;
}
