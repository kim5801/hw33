import java.io.*;
import java.util.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;

public class Maxsum {
    
    public static Integer[] maxes;
    
  /** Instead of making a Runnable, you can just subclass
      Thread to tell the thread what to do. */
  static class MyThread extends Thread {
    /** Effectively, a parameter we're passing the thread, which fibonacci
        number it's supposed to compute.  Here, we can just store this in
        a field of the thread itself. */
    private List<Integer> list;

    /** Effectively, the return value from the thread.  We can just leave it
        in a field. */
    public Integer sum = Integer.MIN_VALUE;
    
    public Integer cap;

    public Integer currThread;
    
    public boolean flag;
        
    /** Make a new Thread, giving it a parameter value to store. */
    public MyThread( List<Integer> list, Integer cap, Integer currThread, boolean flag) {
      this.list = list;
      this.cap = cap;
      this.currThread = currThread;
      maxes = new Integer[cap];
      this.flag = flag;
    }

    /** When run, I report in and compute a fibonacci number. */
    public void run() {
    	Integer max_so_far = Integer.MIN_VALUE;
		for ( int j = 0; j < list.size(); j+=cap ) {
			// Calculate start range
			max_so_far = maxSubArraySum(list.subList(j + currThread, list.size()));
		   
		   if (max_so_far > sum) {
      		sum = max_so_far;
      	}
		}
      maxes[currThread] = sum;
      
      if (flag) {
      	System.out.println("I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + sum);
      }

    }
    
    /** Calculate the largest sum of subarray **/
    static int maxSubArraySum(List<Integer> list) {
			int size = list.size();
			int max_so_far = Integer.MIN_VALUE, max_ending_here = 0;

			for (int i = 0; i < size; i++) {
				max_ending_here = max_ending_here + list.get(i);
				if (max_so_far < max_ending_here) {
					 max_so_far = max_ending_here;
				} if (max_ending_here < 0) {
					 max_ending_here = 0;
				}
			}
         return max_so_far;
    }
  }
    
  /** Make a thread and wait for it to do something. */
  public static void main( String[] args ) throws Exception {
  	 // Get the number of workers
  	 int workers = Integer.parseInt(args[0]);
  	 boolean report = false;
  	 // Get the report flag
  	 if (args.length == 2) {
  	 	if (args[1].equals("report")) {
  	 		report = true;
  	 	}
  	 }
  	 
	 // Read from the file name given
	 Scanner scanner = new Scanner(System.in);
	 List<Integer> integers = new ArrayList<>();
	 while (scanner.hasNext()) {
	 	if (scanner.hasNextInt()) {
			integers.add(scanner.nextInt());
		} else {
			scanner.next();
		}
	 } 
	 
    // Make threads and let them start running.
    MyThread[] thread = new MyThread [ workers ];
    // Split up words based off of how many workers we have
  	 int cap = integers.size() / workers;
  	 
    for ( int i = 0; i < thread.length; i++ ) {
			// Get a different range for each threads
			thread[ i ] = new MyThread( integers, workers, i, report );
			thread[ i ].start();
			
      }
    

    // Wait for each of the threads to terminate.
    try {
      for ( int i = 0; i < thread.length; i++ ) {
        thread[ i ].join();
      }
    } catch ( InterruptedException e ) {
			System.out.println( "Interrupted during join!" );
    }
    System.out.println("Maximum Sum: " + Collections.max(Arrays.asList(maxes)));
  }
}