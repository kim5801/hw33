#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Done reading all items
int doneReading = 0;

// Semaphore to protect access to max_sum
sem_t lockMaxSum;

// Semaphore to protect access to the buffer
sem_t lockBuffer;

// Semaphore to prevent anything being added to our buffer while workers are doing work
sem_t lockBufferForRead;

sem_t lockBufferSecond;

int iterations = 1;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

/**
* Finds the maximum sum from a sequence of integers passed through to the function.
* @param endIndex the index we stop counting at
* @return the value of the maximum sequence
*/
void findMax( int endIndex ) {
  int tempVal;
  //We're going to do a simple sequence iterator where we start at the first index...go up till the end... and then increase the starting index.
  for( int i = endIndex - 1; i >= 0; i-- ) {
    //Holds our comparison value
    tempVal = 0;
    for( int j = i; j >= 0; j-- ) {
      tempVal += vList[ j ];
      //Check to see if tempVal is greater than the max val (global variable)
      if( tempVal > max_sum ) {
        sem_wait( &lockMaxSum );
        max_sum = tempVal;
        sem_post( &lockMaxSum );
      }
    }
  }
  iterations++;
  if( report ) {
    printf("I'm thread %ld. The maximum sum I found is %d\n", (long) pthread_self(), max_sum);
  }
}

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;

    // Open our buffer up
    sem_post( &lockBuffer );
    //sem_wait( &lockBufferForRead );
  }
  // Let our workers know we're done reading
  doneReading = 1;
  sem_post( &lockBuffer );

}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  // Iterate until we're done reading and processing
  while( true ) {
    // Door + waiting room to allow multiple threads through
    sem_wait( &lockBufferSecond );
    sem_wait( &lockBuffer);
    // If we're done reading stuff..
    if( doneReading == 1 ) {
      sem_post( &lockBufferSecond );
      sem_post( &lockBuffer );
      // Calculate the max for the subset
      findMax( vCount );
      break;
    }
    // Calculate the max for the subset
    findMax( vCount );
    sem_post( &lockBufferSecond );
  }

  return NULL;
}

int main( int argc, char *argv[] ) {

  // Initialize our semaphore for maxsum
  sem_init( &lockMaxSum, 0, 1 );

  // Initialize our door semaphore
  sem_init( &lockBufferSecond, 0, 1 );

  // Initialize our semaphore for the buffer
  sem_init( &lockBuffer, 0, 0 );

  // Initialize our semaphore for the reader
  sem_init( &lockBufferForRead, 0, 1 );
  
  // Initialize our worker count
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ ) {
    // pthread_create to make each thread
    if( pthread_create( &worker[ i ], NULL, workerRoutine, NULL ) != 0 ) {
        fail( "Can't create thread" );
    }
  }

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join( worker[i], NULL );
  }

  // Destroy our semaphores
  sem_destroy( &lockMaxSum );
  sem_destroy( &lockBuffer );
  sem_destroy( &lockBufferForRead );
  sem_destroy( &lockMaxSum );

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  
  return EXIT_SUCCESS;
}
