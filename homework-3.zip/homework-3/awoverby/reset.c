#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Create the board and last move state
  if( argc != 2 ) {
     usage();
  }
  FILE *fp = fopen( argv[ 1 ], "r" );
  if ( !fp ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    return 1;
  }
  
  // Create the game state shared memory
  key_t key = ftok( "/afs/unity.ncsu.edu/users/a/awoverby/", 1 );
  int id = shmget( key, sizeof( GameState ), IPC_CREAT | 0666 );
  void *mem = shmat( id, 0, 0 );
  GameState *game = (GameState *) mem;
  
  // Create the named semaphore for synchronization
  sem_open( "/awoverby-lightsout-lock", O_CREAT | O_EXCL, 0666, 1 );
  
  // Fill in the starting game state values
  game->last[ 0 ] = -1;
  game->last[ 1 ] = -1;
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    char ch = fgetc( fp );
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      if ( ch == '.' ) {
        game->board[ i ][ j ] = false;
      } else if ( ch == '*' ) {
        game->board[ i ][ j ] = true;
      } else {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        return 1;
      }
      ch = fgetc( fp );
    }
    if ( ch != '\n' ) {
      fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
      return 1;
    }
  }
  
  return 0;
}
