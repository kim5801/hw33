// Height and width of the playing area.
#define GRID_SIZE 5
// Size of an array representing a move
#define MOVE_SIZE 2

/** Abstract type used to represent an arbitrary value. */
typedef struct GameStateStruct {
  // 2D array representing the board.
  bool board[ GRID_SIZE ][ GRID_SIZE ];
  // Two integer array representing the last move.
  int last[ MOVE_SIZE ];
} GameState;