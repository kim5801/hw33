#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Semaphore for synchronization
sem_t *sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make or undo a move on the board and set the last move.
void move( GameState *game, int loc[ MOVE_SIZE ], bool undo ) {
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  
  game->board[ loc[ 0 ] ][ loc[ 1 ] ] = game->board[ loc[ 0 ] ][ loc[ 1 ] ] != 1;
  if ( loc[ 0 ] != 0 ) {
    game->board[ loc[ 0 ] - 1 ][ loc[ 1 ] ] = game->board[ loc[ 0 ] - 1 ][ loc[ 1 ] ] != 1;
  }
  if ( loc[ 0 ] != GRID_SIZE - 1 ) {
    game->board[ loc[ 0 ] + 1 ][ loc[ 1 ] ] = game->board[ loc[ 0 ] + 1 ][ loc[ 1 ] ] != 1;
  }
  if ( loc[ 1 ] != 0 ) {
    game->board[ loc[ 0 ] ][ loc[ 1 ] - 1 ] = game->board[ loc[ 0 ] ][ loc[ 1 ] - 1 ] != 1;
  }
  if ( loc[ 1 ] != GRID_SIZE - 1 ) {
    game->board[ loc[ 0 ] ][ loc[ 1 ] + 1 ] = game->board[ loc[ 0 ] ][ loc[ 1 ] + 1 ] != 1;
  }
  if ( undo ) {
    game->last[ 0 ] = -1;
    game->last[ 1 ] = -1;
  } else {
    game->last[ 0 ] = loc[ 0 ];
    game->last[ 1 ] = loc[ 1 ];
  }
  
  #ifndef UNSAFE
    sem_post( sem );
  #endif
}

// Print a string representing the board.
void report( GameState *game ) {
  #ifndef UNSAFE
    sem_wait( sem );
  #endif
  
  char str[ 31 ];
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      if ( game->board[ i ][ j ] ) {
        str[ ( ( GRID_SIZE + 1 ) * i ) + j ] = '*';
      } else {
        str[ ( ( GRID_SIZE + 1 ) * i ) + j ] = '.';
      }
    }
  }
  for( int i = GRID_SIZE; i < GRID_SIZE * ( GRID_SIZE + 1 ); i += ( GRID_SIZE + 1 ) ) {
    str[ i ] = '\n';
  }
  str[ 31 ] = '\0';
  printf( "%s", str );
  
  #ifndef UNSAFE
    sem_post( sem );
  #endif
}

// Test interface, for quickly making a given move over and over. Copied from the assignment instructions.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / column is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
    return false;
  // Make the same move a bunch of times.
  int loc[ 2 ] = { r, c };
  for ( int i = 0; i < n; i++ )
    move( state, loc, false );
  return true;
}

int main( int argc, char *argv[] ) {
  
  // Access the shared memory containing the game state.
  key_t key = ftok( "/afs/unity.ncsu.edu/users/a/awoverby/", 1 );
  int id = shmget( key, sizeof( GameState ), 0 );
  void *mem = shmat( id, 0, 0 );
  GameState *game = (GameState *) mem;
  
  sem = sem_open( "/awoverby-lightsout-lock", 0 );
  
  if( strcmp( argv[ 1 ], "report" ) == 0 ) {
    if( argc != 2 ) {
      fail( "error" );
    }
    // Print out a report of the current game state.
    report( game );
  } else if( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    if( argc != 2 ) {
      fail( "error" );
    }
    // Undo the last move, if there was one
    if ( game->last[ 0 ] == -1 ) {
      fail( "error" );
    }
    move( game, game->last, true );
    printf( "success\n" );
  } else if( strcmp( argv[ 1 ], "move" ) == 0 ) {
    if( argc != 4 || strlen( argv[ 2 ] ) != 1 || strlen( argv[ 3 ] ) != 1 || argv[ 2 ][ 0 ] < '0' || argv[ 2 ][ 0 ] > '4' || argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' ) {
      fail( "error" );
    }
    // Make the given move
    int loc[ MOVE_SIZE ] = { ( int )( argv[ 2 ][ 0 ] - '0' ), ( int )( argv[ 3 ][ 0 ] - '0' ) };
    move( game, loc, false );
    printf( "success\n" );
  } else if( strcmp( argv[ 1 ], "test" ) == 0 ) {
    if( argc != 5 || strlen( argv[ 3 ] ) != 1 || strlen( argv[ 4 ] ) != 1 || argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' || argv[ 4 ][ 0 ] < '0' || argv[ 4 ][ 0 ] > '4' ) {
      fail( "error" );
    }
    int n = atoi( argv[ 2 ] );
    if ( n == 0 ) {
      fail( "error" );
    }
    // Test the given move the given number of times
    bool status = test( game, n, ( int )( argv[ 3 ][ 0 ] - '0' ), ( int )( argv[ 4 ][ 0 ] - '0' ) );
    if( !status ) {
      fail( "error" );
    }
  } else {
    fail( "error" );
  }
  
  sem_close( sem );
  return 0;
}
