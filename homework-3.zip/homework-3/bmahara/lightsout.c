#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>
#include "common.h"

// Make a move at the given row, column location, returning true
// if successful.
bool move( GameState *state, int r, int c ) {
  #ifndef UNSAFE
  sem_wait( my_semaphore );
  #endif

  if(r < 0 || c < 0 || r > 4 || c > 4) return false;

  //row and col obtained
  state->lights[r][c] = !state->lights[r][c];
  //above
  if((r + 1) <= 4) {
    state->lights[r + 1][c] = !state->lights[r + 1][c];
  }
  //below
  if((r - 1) >= 0) {
    state->lights[r - 1][c] = !state->lights[r - 1][c];
  }
  //left
  if((c - 1) >= 0) {
    state->lights[r][c - 1] = !state->lights[r][c - 1];
  }
  //left
  if((c + 1) <= 4) {
    state->lights[r][c + 1] = !state->lights[r][c + 1];
  }

  state->pvs_choice_row = r;
  state->pvs_choice_col = c;

  #ifndef UNSAFE
  sem_post( my_semaphore );
  #endif

  return true;
}

// Undo the most recent move, returning true if successful.
bool undo( GameState *state ) {
  #ifndef UNSAFE
  sem_wait( my_semaphore );
  #endif

  int r = state->pvs_choice_row;
  int c = state->pvs_choice_col;
  if(r != -1) { 

    //row and col obtained
    state->lights[r][c] = !state->lights[r][c];
    //above
    if((r + 1) <= 4) {
      state->lights[r + 1][c] = !state->lights[r + 1][c];
    }
    //below
    if((r - 1) >= 0) {
      state->lights[r - 1][c] = !state->lights[r - 1][c];
    }
    //left
    if((c - 1) >= 0) {
      state->lights[r][c - 1] = !state->lights[r][c - 1];
    }
    //left
    if((c + 1) <= 4) {
      state->lights[r][c + 1] = !state->lights[r][c + 1];
    }     

    state->pvs_choice_row = -1;
    state->pvs_choice_col = -1;
    
    #ifndef UNSAFE
    sem_post( my_semaphore );
    #endif

    return true;
      
  }

  else {
    #ifndef UNSAFE
    sem_post( my_semaphore );
    #endif
    return false;
  }
}

// Print the current state of the board.
void report( GameState *state ) {
  #ifndef UNSAFE
  sem_wait( my_semaphore );
  #endif

  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      if(state->lights[i][j]) {
        printf("*");
      }
      else {
        printf(".");
      }
    }
    printf("\n");

  }
  #ifndef UNSAFE
  sem_post( my_semaphore );
  #endif
}

// Test interface, for quickly making a given move over and over.
bool test( GameState *state, int n, int r, int c ) {
  // Make sure the row / colunn is valid.
  if ( r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE )
  return false;
  // Make the same move a bunch of times.
  for ( int i = 0; i < n; i++ )
    move( state, r, c );
  return true;
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//main method accesses shared memory and perform soperations as specified by the user
int main( int argc, char *argv[] ) {

  if(argc < 2 || argc > 5) {
    fail("error 143");
  }

  int k = ftok("/afs/unity.ncsu.edu/users/b/bmahara", KEY_CONSTANT);

  int shmid = shmget( k, 0, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  //0 is a flag not initial value
  my_semaphore = sem_open(semaphore_name, 0);

  //attaching to shared memory
  GameState *gstate = (GameState *) shmat( shmid, 0, 0 );
  if ( gstate == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  if(argc == 2) {
    if(strcmp(argv[1], "report") == 0) {

      report(gstate);
    }

    else if(strcmp(argv[1], "undo") == 0) {
      bool yesUndo = undo(gstate);
      if(!yesUndo) fail("error");
      printf("success\n");
    }

  }

  else if(strcmp(argv[1], "move") == 0) {
    if(argc != 4) {
      fail("error l64");
    }

    else {

      char rc[2];
      rc[0] = *argv[2];
      rc[1] = '\0';
      int r = atoi(rc);

      char cc[2];
      cc[0] = *argv[3];
      cc[1] = '\0';
      int c = atoi(cc);

      bool imoved = move(gstate, r, c);
      if(!imoved) fail("error 191");
      printf("success\n");

    }
  } //it was "move"

  else if(strcmp(argv[1], "test") == 0) {
    if(argc != 5) {
      fail("error in test");
    }
    else {
      if(*argv[4] < '0' || *argv[4] > '4' || *argv[3] > '4' || *argv[3] < '0') {
          fail("error 203");
      } //r and c are valid rows

      char nstring[2];
      nstring[0] = *argv[2];
      nstring[1] = *argv[2];
      int n = atoi(nstring);

      char rc[2];
      rc[0] = *argv[3];
      rc[1] = '\0';
      int r = atoi(rc);

      char cc[2];
      cc[0] = *argv[4];
      cc[1] = '\0';
      int c = atoi(cc);

      bool t = test(gstate, n, r, c);
      if(!t) fail("couldn't fin test cmd");

    }
  } //it was "test"

  else {
    //command is neither move undo test or report
    fail("error 228");
  }

  shmdt( gstate );
  sem_close(my_semaphore);

  return 0;
}
