#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

int workers = 4;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

//semaphore for blocking sum
sem_t ImInSum;
//semaphore for blocking until theres input
sem_t theresInput;
//semaphore for allowing thread to do work
sem_t tryingsmthn;
//semaphore for blocking threads to get work only one at a time
sem_t s2;

//flag to make sure all elements received at input were calculated
bool donecalculating;
//making sure all threads dont wait for work once everything's done
int everyoneGetOut = 0;

//counter for calculating index
int c = 0;

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;

  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    
    sem_post(&theresInput);     
    
  }
  //each worker ends up waiting in getWork since all values have been read
  for(int i = 0; i < workers; i++) {
    sem_post(&theresInput);
  }

}

//gets work for each worker
int getWork() {
  sem_wait(&theresInput);
  sem_wait(&tryingsmthn);
  
  c++;
  
  if(c > vCount) {
    
    if(!donecalculating)
      donecalculating = true;
    else
      c = -1;
  }

  sem_post(&tryingsmthn);
  return c;
}

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
  int max = 0;
  
  while(1) { 
    if(everyoneGetOut == 1) break;

    sem_wait(&s2); 
    int curr = getWork();  
    sem_post(&s2);
    
    int subset_sum = 0;
    for(int i = curr; i >= 0; i--) {
      subset_sum += vList[i];
      if(subset_sum > max) 
        max = subset_sum;
    }
    
    if(donecalculating) everyoneGetOut = 1;    
    
  }

  sem_wait(&ImInSum);
  if(max > max_sum) {
    max_sum = max;
  }
  sem_post(&ImInSum);
  

  if(report)
    printf("I'm thread %lu and the max I found is %d\n",(long int)pthread_self(), max);  //fflush(stdout);

  return NULL;

}

//main method calls other methods and initialises semaphores
int main( int argc, char *argv[] ) {
  c = 0;

  sem_init(&ImInSum, 0, 1);
  sem_init(&theresInput, 0, 0);
  sem_init(&tryingsmthn, 0, 1);
  sem_init(&s2, 0, 1);

  donecalculating = false;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    pthread_create(&worker[i], NULL, workerRoutine, NULL);

  // Then, start getting work for them to do.
  readList();

  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ )
    pthread_join(worker[i], NULL);

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );

  //destruction of semaphores
  sem_destroy(&ImInSum);
  sem_destroy(&theresInput);
  sem_destroy(&tryingsmthn);
  sem_destroy(&s2);
  
  return EXIT_SUCCESS;
}
