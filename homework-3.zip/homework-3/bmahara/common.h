// Height and width of the playing area.
#define GRID_SIZE 5

//key constant neing used
#define KEY_CONSTANT 21

char *semaphore_name = "/bmahara-lightsout-lock";
sem_t *my_semaphore;

/** 
 * struct to store state of game board
 * @param lights is game board
 * @param pvs_choice_row from previous move operation
 * @param pvs_choice_col from previous move operation
 */
typedef struct {
  bool lights[GRID_SIZE][GRID_SIZE];
  int pvs_choice_row;
  int pvs_choice_col;
} GameState;
