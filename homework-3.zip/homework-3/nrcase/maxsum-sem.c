#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>

/* NOTE TO GRADER
Hello! Any tests involving input-4 or input-5 work for me, they just take around 45 seconds with a small amount of workers
Please give them some time! Thanks! =)
*/

/**
 * @brief Semaphore to 
 * prevent race condition for modifying the global max
 */
sem_t globalAccess;
/**
 * @brief Semaphore to
 * let the workers wait until the input is read in 
 */
sem_t readyRead;

/**
 * @brief Number of workers for the current run
 * 
 */
int workers;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum-sem <workers>\n" );
  printf( "       maxsum-sem <workers> report\n" );
  exit( 1 );
}

// True if we're supposed to report what we find.
bool report = false;

// Maximum sum we've found.
int max_sum = INT_MIN;

// Fixed-sized array for holding the sequence.
#define MAX_VALUES 500000
int vList[ MAX_VALUES ];

// Current number of values on the list.
int vCount = 0;

bool done = false; //tells if done reading in list

bool new = false; //if there is something new added to the list

// Read the list of values.
void readList() {
  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Make sure we have enough room, then store the latest input.
    if ( vCount > MAX_VALUES )
      fail( "Too many input values" );

    // Store the latest value.
    vList[ vCount++ ] = v;
    new = true; //tell that there is new input
    sem_post(&readyRead); //signal that there is input
  }
  done = true;  //tell that reading in the list is done
}

/**
 * @brief gets the index that the worker is assigned up to
 * returns -24 if there is no more input
 */
static int getWork() {
  if (done && !new)
  {
    return -24;
  }
  new = false;
  return vCount;
}

/**
 * @brief Method to do the actual maxsum algorithm
 * and modify the global variable
 * 
 * @param end 
 * @return int 
 */
static int sum(int end) {
  int endMax = 0;
  int max = 0;
  for (int i = 0; i < end; i++) // loops starting at which number worker it is, and increases by the number of workers
  {
    for (int j = i; j < end; j++) // starting at the individual start points in the pattern
    {
      max += vList[j];  // adds sequentially
      if (max > endMax) // checking for max
      {
        endMax = max;
      }
    }
    max = 0;
  }

  if (endMax > max_sum)
  {
    sem_wait(&globalAccess); // locks the global variable
    max_sum = endMax;
    sem_post(&globalAccess); // unlocks the global variable
  }

  return endMax;
}

/**
 * @brief The total max of that worker's run
 * through all of the while loop
 */
int totalMax = 0;

/** Start routine for each worker. */
void *workerRoutine( void *arg ) {
 
  // gets the first max
  sem_wait(&readyRead);
  int end = getWork(); //gets the ending index
  while (end != -24) { //while not reaching the end 
    int val = sum(end); 
    end = getWork();
    if (val > totalMax) { //keep summing and then getting the next index to check
      totalMax = val;
    }
  }
  if (report) //do the report with the max from all the worker's runs
  {
    printf("I'm thread %lu. The maximum sum I found is %d.\n", pthread_self(), totalMax);
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  workers = 4;

  sem_init(&globalAccess, 0, 1); //creating all the semaphores, each starting at 1
  sem_init(&readyRead, 0, 0); //used to tell when there is more input to read

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();
  
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
      workers < 1 )
    usage();

  // If there's a second argument, it better be "report"
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Make each of the workers.
  pthread_t worker[ workers ];
  for ( int i = 0; i < workers; i++ )
    if (pthread_create(&(worker[i]), NULL, workerRoutine, NULL) != 0) //create workers
      fail("Can't create a child thread");

  // Then, start getting work for them to do.
  readList();
  // Wait until all the workers finish.
  for ( int i = 0; i < workers; i++ ) {
    pthread_join(worker[i], NULL);
  }

  // Report the max product and release the semaphores.
  printf( "Maximum Sum: %d\n", max_sum );
  sem_destroy(&globalAccess); //destroy the semaphores
  sem_destroy(&readyRead);
  
  return EXIT_SUCCESS;
}
